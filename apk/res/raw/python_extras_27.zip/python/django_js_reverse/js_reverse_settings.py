# -*- coding: utf-8 -*-
JS_VAR_NAME = 'Urls'
JS_MINIFY = True
JS_EXCLUDE_NAMESPACES = []
JS_SCRIPT_PREFIX = None
JS_GLOBAL_OBJECT_NAME = 'this'
