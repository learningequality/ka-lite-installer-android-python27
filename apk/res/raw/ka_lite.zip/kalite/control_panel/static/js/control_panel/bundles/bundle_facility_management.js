require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"facility_management":[function(require,module,exports){
var $ = require("base/jQuery");
var _ = require("underscore");
var get_params = require("utils/get_params");
var api = require("utils/api");
require("jquery-sparkline");

function getSelectedItems(select) {
    // Retrieve a list of selected users.
    // var items = $(select).find("tr.selected").map(function () {
    //     return $(this).attr("value");
    // }).get();
    var items = $(select).find("tr.selectable.selected").map(function () {
        return $(this).attr("value");
    }).get();
    return items;
}

function setActionButtonState(select) {
    // argument to allow conditional selection of action buttons.
    if($(select).find("tr.selectable.selected").length) {

        $('button[value="'+select+'"]').removeAttr("disabled").removeAttr("title");
    } else {
        $('button[value="'+select+'"]').attr("disabled", "disabled");
        $('button[value="'+select+'"]').attr("title", "You must select one or more rows from the table below before taking this action.");
    }
}

function setSelectAllState(selectAllId) {
    var allChecked = true;
    // If all checkboxes selected, set to checked, if not, set to unchecked
    var boxes = $(selectAllId).find('tbody').find('input[type="checkbox"]');
    _.each(boxes, function(box) {
        if ($(box).prop('checked') === false){
            allChecked = false;
        }
    });
    var selectAllBox = $(selectAllId).find('thead').find('.select-all');
    $(selectAllBox).prop("checked", allChecked);
}

$(function() {
    // on load add the same title tag to all disabled buttons 
    $('button[disabled="disabled"]').attr("title", "You must select one or more rows from the table below before taking this action.");

    $("#group").change(function(){
        // Change the URL to the selected group.
        GetParams["group_id"] = $("#group option:selected").val();
        window.location.href = get_params.setGetParamDict(window.location.href, GetParams);
    });

    $(".all").click(function(event){
        // Select all checkboxes within local table
        var el = $(event.target.value);
        el.find("thead").find("input.select-all").prop("checked", true);
        el.find("tbody").find("tr").not(".selected").mousedown();
    });

    $(".none").click(function(event){
        // Unselect all checkboxes within local table
        var el = $(event.target.value);
        el.find("thead").find("input.select-all").prop("checked", false);
        el.find("tbody").find("tr.selected").mousedown();
    });

    $(".movegroup").click(function(event) {
        // Move users to the selected group
        var users = getSelectedItems(this.value);
        var group = $(this.value).find('select[value="'+this.value+'"] option:selected').val();

        if (group==="----") {
            alert(gettext("Please choose a group to move users to."));
        } else if (users.length===0) {
            alert(gettext("Please select users first."));
        } else if(!confirm(gettext("You are about to move selected users to another group."))) {
            return;
        } else {
            api.doRequest(window.Urls.move_to_group(), {users: users, group: group})
                .success(function() {
                    location.reload();
                });
        }
    });

    // Code for checkboxes
    $(".select-all").click(function(event){
        // Select all checkboxes within local table
        var el = $(event.target.value);
        if(!event.target.checked){
            el.find("tbody").find("input:checked").mousedown();
        } else {
            el.find("tbody").find("input:checkbox:not(:checked)").mousedown();
        }
    });

    $("input:checkbox").click(function(event){
        var el = event.target.value;
        // Only set action button state on related action buttons.
        setActionButtonState(el);
    });

    $("input:checkbox").mouseup(function(event){
        var el = event.target.value;
        // Set state of select all checkbox based on clicks 
        setSelectAllState(el);
    });

    $(".delete").click(function(event) {
        // Delete the selected users
        var users = getSelectedItems(this.value);

        if (users.length === 0) {
            alert(gettext("Please select users first."));
        } else if (!confirm(gettext("You are about to delete selected users, they will be permanently deleted."))) {
            return;
        } else {
            api.doRequest(window.Urls.delete_users(), {users: users})
                .success(function() {
                    location.reload();
                });
        }
    });

    $(".delete-group").click(function(event) {
        // Delete the selected users
        var groups = getSelectedItems(this.value);

        if (groups.length === 0) {
            alert(gettext("Please select groups first."));
        } else if (!confirm(gettext("You are about to permanently delete the selected group(s). Note that any learners currently in this group will now be characterized as 'Ungrouped' but their profiles will not be deleted."))) {
            return;
        } else {
            api.doRequest(window.Urls.group_delete(), {groups: groups})
                .success(function() {
                    location.reload();
                });
        }
    });

    // When mouse is pressed over a row in the table body (not the header row), make mouseovers select.
    $(".selectable-table").find("tbody").find("tr.selectable").mousedown(function(){
        $(this).toggleClass("selected");
        var checkbox = $(this).find("input");
        if (checkbox.prop("checked")) {
            checkbox.prop("checked", false);
        } else {
            checkbox.prop("checked", true);
        }
        var el = "#" + $(this).attr("type");
        setActionButtonState(el);
        setSelectAllState(el);
        
        // (Currently disabled due to a bit of bugginess with not registering the mouseup event, which created a weird flickering effect. Also, this won't work on tablets, since drag is scroll.) 
        // This code is to allow rows of a selectable-table class table to be clicked for selection,
        // and dragged across with mousedown for selection.
        // $(".selectable-table").find("tbody").find("tr.selectable").mouseover(function(){
        //     $(this).toggleClass("selected");
        //     var checkbox = $(this).find("input");
        //     if (checkbox.prop("checked")) {
        //         checkbox.prop("checked", false);
        //     } else {
        //         checkbox.prop("checked", true);
        //     }
        //     setActionButtonState("#" + $(this).attr("type"));
        // });
    });

    // (Currently disabled for the same reasons as above)
    // Unbind the mouseover selection once the button has been released.
    // $(".selectable-table").find("tbody").find("tr.selectable").mouseup(function(){
    //     $(".selectable-table").find("tbody").find("tr.selectable").unbind("mouseover");
    // });

    // If the mouse moves out of the table with the button still depressed, the above unbind will not fire.
    // Unbind the mouseover once the mouse leaves the table.
    // This means that moving the mouse out and then back in with the button depressed will not select.

    // $(".selectable-table").mouseleave(function(){
    //     $(".selectable-table").find("tbody").find("tr.selectable").unbind("mouseover");
    // })


    // Prevent propagation of click events on links to limit confusing behaviour
    // of rows being selected when links clicked.
    $(".selectable-table").find("a").mousedown(function(event) {
        event.stopPropagation();
        return false;
    });

    $(".selectable-table").find("tbody").find("input").mousedown(function(event){
        event.preventDefault();
    });

    $(".selectable-table").find("tbody").find("input").click(function(event){
        event.preventDefault();
        return false;
    });

    $('.sparklines').sparkline('html', { enableTagOptions: true, disableInteraction: true });
});

module.exports = {
    $: $
};
},{"base/jQuery":45,"jquery-sparkline":362,"underscore":582,"utils/api":124,"utils/get_params":127}],362:[function(require,module,exports){
/**
*
* jquery.sparkline.js
*
* v2.1.3
* (c) Splunk, Inc
* Contact: Gareth Watts (gareth@splunk.com)
* http://omnipotent.net/jquery.sparkline/
*
* Generates inline sparkline charts from data supplied either to the method
* or inline in HTML
*
* Compatible with Internet Explorer 6.0+ and modern browsers equipped with the canvas tag
* (Firefox 2.0+, Safari, Opera, etc)
*
* License: New BSD License
*
* Copyright (c) 2012, Splunk Inc.
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without modification,
* are permitted provided that the following conditions are met:
*
*     * Redistributions of source code must retain the above copyright notice,
*       this list of conditions and the following disclaimer.
*     * Redistributions in binary form must reproduce the above copyright notice,
*       this list of conditions and the following disclaimer in the documentation
*       and/or other materials provided with the distribution.
*     * Neither the name of Splunk Inc nor the names of its contributors may
*       be used to endorse or promote products derived from this software without
*       specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
* OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
* SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
* OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
* OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*
*
* Usage:
*  $(selector).sparkline(values, options)
*
* If values is undefined or set to 'html' then the data values are read from the specified tag:
*   <p>Sparkline: <span class="sparkline">1,4,6,6,8,5,3,5</span></p>
*   $('.sparkline').sparkline();
* There must be no spaces in the enclosed data set
*
* Otherwise values must be an array of numbers or null values
*    <p>Sparkline: <span id="sparkline1">This text replaced if the browser is compatible</span></p>
*    $('#sparkline1').sparkline([1,4,6,6,8,5,3,5])
*    $('#sparkline2').sparkline([1,4,6,null,null,5,3,5])
*
* Values can also be specified in an HTML comment, or as a values attribute:
*    <p>Sparkline: <span class="sparkline"><!--1,4,6,6,8,5,3,5 --></span></p>
*    <p>Sparkline: <span class="sparkline" values="1,4,6,6,8,5,3,5"></span></p>
*    $('.sparkline').sparkline();
*
* For line charts, x values can also be specified:
*   <p>Sparkline: <span class="sparkline">1:1,2.7:4,3.4:6,5:6,6:8,8.7:5,9:3,10:5</span></p>
*    $('#sparkline1').sparkline([ [1,1], [2.7,4], [3.4,6], [5,6], [6,8], [8.7,5], [9,3], [10,5] ])
*
* By default, options should be passed in as the second argument to the sparkline function:
*   $('.sparkline').sparkline([1,2,3,4], {type: 'bar'})
*
* Options can also be set by passing them on the tag itself.  This feature is disabled by default though
* as there's a slight performance overhead:
*   $('.sparkline').sparkline([1,2,3,4], {enableTagOptions: true})
*   <p>Sparkline: <span class="sparkline" sparkType="bar" sparkBarColor="red">loading</span></p>
* Prefix all options supplied as tag attribute with "spark" (configurable by setting tagOptionsPrefix)
*
* Supported options:
*   lineColor - Color of the line used for the chart
*   fillColor - Color used to fill in the chart - Set to '' or false for a transparent chart
*   width - Width of the chart - Defaults to 3 times the number of values in pixels
*   height - Height of the chart - Defaults to the height of the containing element
*   chartRangeMin - Specify the minimum value to use for the Y range of the chart - Defaults to the minimum value supplied
*   chartRangeMax - Specify the maximum value to use for the Y range of the chart - Defaults to the maximum value supplied
*   chartRangeClip - Clip out of range values to the max/min specified by chartRangeMin and chartRangeMax
*   chartRangeMinX - Specify the minimum value to use for the X range of the chart - Defaults to the minimum value supplied
*   chartRangeMaxX - Specify the maximum value to use for the X range of the chart - Defaults to the maximum value supplied
*   composite - If true then don't erase any existing chart attached to the tag, but draw
*           another chart over the top - Note that width and height are ignored if an
*           existing chart is detected.
*   tagValuesAttribute - Name of tag attribute to check for data values - Defaults to 'values'
*   enableTagOptions - Whether to check tags for sparkline options
*   tagOptionsPrefix - Prefix used for options supplied as tag attributes - Defaults to 'spark'
*   disableHiddenCheck - If set to true, then the plugin will assume that charts will never be drawn into a
*           hidden dom element, avoding a browser reflow
*   disableInteraction - If set to true then all mouseover/click interaction behaviour will be disabled,
*       making the plugin perform much like it did in 1.x
*   disableTooltips - If set to true then tooltips will be disabled - Defaults to false (tooltips enabled)
*   disableHighlight - If set to true then highlighting of selected chart elements on mouseover will be disabled
*       defaults to false (highlights enabled)
*   highlightLighten - Factor to lighten/darken highlighted chart values by - Defaults to 1.4 for a 40% increase
*   tooltipContainer - Specify which DOM element the tooltip should be rendered into - defaults to document.body
*   tooltipClassname - Optional CSS classname to apply to tooltips - If not specified then a default style will be applied
*   tooltipOffsetX - How many pixels away from the mouse pointer to render the tooltip on the X axis
*   tooltipOffsetY - How many pixels away from the mouse pointer to render the tooltip on the r axis
*   tooltipFormatter  - Optional callback that allows you to override the HTML displayed in the tooltip
*       callback is given arguments of (sparkline, options, fields)
*   tooltipChartTitle - If specified then the tooltip uses the string specified by this setting as a title
*   tooltipFormat - A format string or SPFormat object  (or an array thereof for multiple entries)
*       to control the format of the tooltip
*   tooltipPrefix - A string to prepend to each field displayed in a tooltip
*   tooltipSuffix - A string to append to each field displayed in a tooltip
*   tooltipSkipNull - If true then null values will not have a tooltip displayed (defaults to true)
*   tooltipValueLookups - An object or range map to map field values to tooltip strings
*       (eg. to map -1 to "Lost", 0 to "Draw", and 1 to "Win")
*   numberFormatter - Optional callback for formatting numbers in tooltips
*   numberDigitGroupSep - Character to use for group separator in numbers "1,234" - Defaults to ","
*   numberDecimalMark - Character to use for the decimal point when formatting numbers - Defaults to "."
*   numberDigitGroupCount - Number of digits between group separator - Defaults to 3
*
* There are 7 types of sparkline, selected by supplying a "type" option of 'line' (default),
* 'bar', 'tristate', 'bullet', 'discrete', 'pie' or 'box'
*    line - Line chart.  Options:
*       spotColor - Set to '' to not end each line in a circular spot
*       minSpotColor - If set, color of spot at minimum value
*       maxSpotColor - If set, color of spot at maximum value
*       spotRadius - Radius in pixels
*       lineWidth - Width of line in pixels
*       normalRangeMin
*       normalRangeMax - If set draws a filled horizontal bar between these two values marking the "normal"
*                      or expected range of values
*       normalRangeColor - Color to use for the above bar
*       drawNormalOnTop - Draw the normal range above the chart fill color if true
*       defaultPixelsPerValue - Defaults to 3 pixels of width for each value in the chart
*       highlightSpotColor - The color to use for drawing a highlight spot on mouseover - Set to null to disable
*       highlightLineColor - The color to use for drawing a highlight line on mouseover - Set to null to disable
*       valueSpots - Specify which points to draw spots on, and in which color.  Accepts a range map
*
*   bar - Bar chart.  Options:
*       barColor - Color of bars for postive values
*       negBarColor - Color of bars for negative values
*       zeroColor - Color of bars with zero values
*       nullColor - Color of bars with null values - Defaults to omitting the bar entirely
*       barWidth - Width of bars in pixels
*       colorMap - Optional mappnig of values to colors to override the *BarColor values above
*                  can be an Array of values to control the color of individual bars or a range map
*                  to specify colors for individual ranges of values
*       barSpacing - Gap between bars in pixels
*       zeroAxis - Centers the y-axis around zero if true
*
*   tristate - Charts values of win (>0), lose (<0) or draw (=0)
*       posBarColor - Color of win values
*       negBarColor - Color of lose values
*       zeroBarColor - Color of draw values
*       barWidth - Width of bars in pixels
*       barSpacing - Gap between bars in pixels
*       colorMap - Optional mappnig of values to colors to override the *BarColor values above
*                  can be an Array of values to control the color of individual bars or a range map
*                  to specify colors for individual ranges of values
*
*   discrete - Options:
*       lineHeight - Height of each line in pixels - Defaults to 30% of the graph height
*       thesholdValue - Values less than this value will be drawn using thresholdColor instead of lineColor
*       thresholdColor
*
*   bullet - Values for bullet graphs msut be in the order: target, performance, range1, range2, range3, ...
*       options:
*       targetColor - The color of the vertical target marker
*       targetWidth - The width of the target marker in pixels
*       performanceColor - The color of the performance measure horizontal bar
*       rangeColors - Colors to use for each qualitative range background color
*
*   pie - Pie chart. Options:
*       sliceColors - An array of colors to use for pie slices
*       offset - Angle in degrees to offset the first slice - Try -90 or +90
*       borderWidth - Width of border to draw around the pie chart, in pixels - Defaults to 0 (no border)
*       borderColor - Color to use for the pie chart border - Defaults to #000
*
*   box - Box plot. Options:
*       raw - Set to true to supply pre-computed plot points as values
*             values should be: low_outlier, low_whisker, q1, median, q3, high_whisker, high_outlier
*             When set to false you can supply any number of values and the box plot will
*             be computed for you.  Default is false.
*       showOutliers - Set to true (default) to display outliers as circles
*       outlierIQR - Interquartile range used to determine outliers.  Default 1.5
*       boxLineColor - Outline color of the box
*       boxFillColor - Fill color for the box
*       whiskerColor - Line color used for whiskers
*       outlierLineColor - Outline color of outlier circles
*       outlierFillColor - Fill color of the outlier circles
*       spotRadius - Radius of outlier circles
*       medianColor - Line color of the median line
*       target - Draw a target cross hair at the supplied value (default undefined)
*
*
*
*   Examples:
*   $('#sparkline1').sparkline(myvalues, { lineColor: '#f00', fillColor: false });
*   $('.barsparks').sparkline('html', { type:'bar', height:'40px', barWidth:5 });
*   $('#tristate').sparkline([1,1,-1,1,0,0,-1], { type:'tristate' }):
*   $('#discrete').sparkline([1,3,4,5,5,3,4,5], { type:'discrete' });
*   $('#bullet').sparkline([10,12,12,9,7], { type:'bullet' });
*   $('#pie').sparkline([1,1,2], { type:'pie' });
*/

/*jslint regexp: true, browser: true, jquery: true, white: true, nomen: false, plusplus: false, maxerr: 500, indent: 4 */

(function(document, Math, undefined) { // performance/minified-size optimization
(function(factory) {
    if(typeof define === 'function' && define.amd) {
        define(['jquery'], factory);
    } else if (jQuery && !jQuery.fn.sparkline) {
        factory(jQuery);
    }
}
(function($) {
    'use strict';

    var UNSET_OPTION = {},
        getDefaults, createClass, SPFormat, clipval, quartile, normalizeValue, normalizeValues,
        remove, isNumber, all, sum, addCSS, ensureArray, formatNumber, RangeMap,
        MouseHandler, Tooltip, barHighlightMixin,
        line, bar, tristate, discrete, bullet, pie, box, defaultStyles, initStyles,
        VShape, VCanvas_base, VCanvas_canvas, VCanvas_vml, pending, shapeCount = 0;

    /**
     * Default configuration settings
     */
    getDefaults = function () {
        return {
            // Settings common to most/all chart types
            common: {
                type: 'line',
                lineColor: '#00f',
                fillColor: '#cdf',
                defaultPixelsPerValue: 3,
                width: 'auto',
                height: 'auto',
                composite: false,
                tagValuesAttribute: 'values',
                tagOptionsPrefix: 'spark',
                enableTagOptions: false,
                enableHighlight: true,
                highlightLighten: 1.4,
                tooltipSkipNull: true,
                tooltipPrefix: '',
                tooltipSuffix: '',
                disableHiddenCheck: false,
                numberFormatter: false,
                numberDigitGroupCount: 3,
                numberDigitGroupSep: ',',
                numberDecimalMark: '.',
                disableTooltips: false,
                disableInteraction: false
            },
            // Defaults for line charts
            line: {
                spotColor: '#f80',
                highlightSpotColor: '#5f5',
                highlightLineColor: '#f22',
                spotRadius: 1.5,
                minSpotColor: '#f80',
                maxSpotColor: '#f80',
                lineWidth: 1,
                normalRangeMin: undefined,
                normalRangeMax: undefined,
                normalRangeColor: '#ccc',
                drawNormalOnTop: false,
                chartRangeMin: undefined,
                chartRangeMax: undefined,
                chartRangeMinX: undefined,
                chartRangeMaxX: undefined,
                tooltipFormat: new SPFormat('<span style="color: {{color}}">&#9679;</span> {{prefix}}{{y}}{{suffix}}')
            },
            // Defaults for bar charts
            bar: {
                barColor: '#3366cc',
                negBarColor: '#f44',
                stackedBarColor: ['#3366cc', '#dc3912', '#ff9900', '#109618', '#66aa00',
                    '#dd4477', '#0099c6', '#990099'],
                zeroColor: undefined,
                nullColor: undefined,
                zeroAxis: true,
                barWidth: 4,
                barSpacing: 1,
                chartRangeMax: undefined,
                chartRangeMin: undefined,
                chartRangeClip: false,
                colorMap: undefined,
                tooltipFormat: new SPFormat('<span style="color: {{color}}">&#9679;</span> {{prefix}}{{value}}{{suffix}}')
            },
            // Defaults for tristate charts
            tristate: {
                barWidth: 4,
                barSpacing: 1,
                posBarColor: '#6f6',
                negBarColor: '#f44',
                zeroBarColor: '#999',
                colorMap: {},
                tooltipFormat: new SPFormat('<span style="color: {{color}}">&#9679;</span> {{value:map}}'),
                tooltipValueLookups: { map: { '-1': 'Loss', '0': 'Draw', '1': 'Win' } }
            },
            // Defaults for discrete charts
            discrete: {
                lineHeight: 'auto',
                thresholdColor: undefined,
                thresholdValue: 0,
                chartRangeMax: undefined,
                chartRangeMin: undefined,
                chartRangeClip: false,
                tooltipFormat: new SPFormat('{{prefix}}{{value}}{{suffix}}')
            },
            // Defaults for bullet charts
            bullet: {
                targetColor: '#f33',
                targetWidth: 3, // width of the target bar in pixels
                performanceColor: '#33f',
                rangeColors: ['#d3dafe', '#a8b6ff', '#7f94ff'],
                base: undefined, // set this to a number to change the base start number
                tooltipFormat: new SPFormat('{{fieldkey:fields}} - {{value}}'),
                tooltipValueLookups: { fields: {r: 'Range', p: 'Performance', t: 'Target'} }
            },
            // Defaults for pie charts
            pie: {
                offset: 0,
                sliceColors: ['#3366cc', '#dc3912', '#ff9900', '#109618', '#66aa00',
                    '#dd4477', '#0099c6', '#990099'],
                borderWidth: 0,
                borderColor: '#000',
                tooltipFormat: new SPFormat('<span style="color: {{color}}">&#9679;</span> {{value}} ({{percent.1}}%)')
            },
            // Defaults for box plots
            box: {
                raw: false,
                boxLineColor: '#000',
                boxFillColor: '#cdf',
                whiskerColor: '#000',
                outlierLineColor: '#333',
                outlierFillColor: '#fff',
                medianColor: '#f00',
                showOutliers: true,
                outlierIQR: 1.5,
                spotRadius: 1.5,
                target: undefined,
                targetColor: '#4a2',
                chartRangeMax: undefined,
                chartRangeMin: undefined,
                tooltipFormat: new SPFormat('{{field:fields}}: {{value}}'),
                tooltipFormatFieldlistKey: 'field',
                tooltipValueLookups: { fields: { lq: 'Lower Quartile', med: 'Median',
                    uq: 'Upper Quartile', lo: 'Left Outlier', ro: 'Right Outlier',
                    lw: 'Left Whisker', rw: 'Right Whisker'} }
            }
        };
    };

    // You can have tooltips use a css class other than jqstooltip by specifying tooltipClassname
    defaultStyles = '.jqstooltip { ' +
            'position: absolute;' +
            'left: 0px;' +
            'top: 0px;' +
            'visibility: hidden;' +
            'background: rgb(0, 0, 0) transparent;' +
            'background-color: rgba(0,0,0,0.6);' +
            'filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#99000000, endColorstr=#99000000);' +
            '-ms-filter: "progid:DXImageTransform.Microsoft.gradient(startColorstr=#99000000, endColorstr=#99000000)";' +
            'color: white;' +
            'font: 10px arial, san serif;' +
            'text-align: left;' +
            'white-space: nowrap;' +
            'padding: 5px;' +
            'border: 1px solid white;' +
            'box-sizing: content-box;' +
            'z-index: 10000;' +
            '}' +
            '.jqsfield { ' +
            'color: white;' +
            'font: 10px arial, san serif;' +
            'text-align: left;' +
            '}';

    /**
     * Utilities
     */

    createClass = function (/* [baseclass, [mixin, ...]], definition */) {
        var Class, args;
        Class = function () {
            this.init.apply(this, arguments);
        };
        if (arguments.length > 1) {
            if (arguments[0]) {
                Class.prototype = $.extend(new arguments[0](), arguments[arguments.length - 1]);
                Class._super = arguments[0].prototype;
            } else {
                Class.prototype = arguments[arguments.length - 1];
            }
            if (arguments.length > 2) {
                args = Array.prototype.slice.call(arguments, 1, -1);
                args.unshift(Class.prototype);
                $.extend.apply($, args);
            }
        } else {
            Class.prototype = arguments[0];
        }
        Class.prototype.cls = Class;
        return Class;
    };

    /**
     * Wraps a format string for tooltips
     * {{x}}
     * {{x.2}
     * {{x:months}}
     */
    $.SPFormatClass = SPFormat = createClass({
        fre: /\{\{([\w.]+?)(:(.+?))?\}\}/g,
        precre: /(\w+)\.(\d+)/,

        init: function (format, fclass) {
            this.format = format;
            this.fclass = fclass;
        },

        render: function (fieldset, lookups, options) {
            var self = this,
                fields = fieldset,
                match, token, lookupkey, fieldvalue, prec;
            return this.format.replace(this.fre, function () {
                var lookup;
                token = arguments[1];
                lookupkey = arguments[3];
                match = self.precre.exec(token);
                if (match) {
                    prec = match[2];
                    token = match[1];
                } else {
                    prec = false;
                }
                fieldvalue = fields[token];
                if (fieldvalue === undefined) {
                    return '';
                }
                if (lookupkey && lookups && lookups[lookupkey]) {
                    lookup = lookups[lookupkey];
                    if (lookup.get) { // RangeMap
                        return lookups[lookupkey].get(fieldvalue) || fieldvalue;
                    } else {
                        return lookups[lookupkey][fieldvalue] || fieldvalue;
                    }
                }
                if (isNumber(fieldvalue)) {
                    if (options.get('numberFormatter')) {
                        fieldvalue = options.get('numberFormatter')(fieldvalue);
                    } else {
                        fieldvalue = formatNumber(fieldvalue, prec,
                            options.get('numberDigitGroupCount'),
                            options.get('numberDigitGroupSep'),
                            options.get('numberDecimalMark'));
                    }
                }
                return fieldvalue;
            });
        }
    });

    // convience method to avoid needing the new operator
    $.spformat = function(format, fclass) {
        return new SPFormat(format, fclass);
    };

    clipval = function (val, min, max) {
        if (val < min) {
            return min;
        }
        if (val > max) {
            return max;
        }
        return val;
    };

    quartile = function (values, q) {
        var vl;
        if (q === 2) {
            vl = Math.floor(values.length / 2);
            return values.length % 2 ? values[vl] : (values[vl-1] + values[vl]) / 2;
        } else {
            if (values.length % 2 ) { // odd
                vl = (values.length * q + q) / 4;
                return vl % 1 ? (values[Math.floor(vl)] + values[Math.floor(vl) - 1]) / 2 : values[vl-1];
            } else { //even
                vl = (values.length * q + 2) / 4;
                return vl % 1 ? (values[Math.floor(vl)] + values[Math.floor(vl) - 1]) / 2 :  values[vl-1];

            }
        }
    };

    normalizeValue = function (val) {
        var nf;
        switch (val) {
            case 'undefined':
                val = undefined;
                break;
            case 'null':
                val = null;
                break;
            case 'true':
                val = true;
                break;
            case 'false':
                val = false;
                break;
            default:
                nf = parseFloat(val);
                if (val == nf) {
                    val = nf;
                }
        }
        return val;
    };

    normalizeValues = function (vals) {
        var i, result = [];
        for (i = vals.length; i--;) {
            result[i] = normalizeValue(vals[i]);
        }
        return result;
    };

    remove = function (vals, filter) {
        var i, vl, result = [];
        for (i = 0, vl = vals.length; i < vl; i++) {
            if (vals[i] !== filter) {
                result.push(vals[i]);
            }
        }
        return result;
    };

    isNumber = function (num) {
        return !isNaN(parseFloat(num)) && isFinite(num);
    };

    formatNumber = function (num, prec, groupsize, groupsep, decsep) {
        var p, i;
        num = (prec === false ? parseFloat(num).toString() : num.toFixed(prec)).split('');
        p = (p = $.inArray('.', num)) < 0 ? num.length : p;
        if (p < num.length) {
            num[p] = decsep;
        }
        for (i = p - groupsize; i > 0; i -= groupsize) {
            num.splice(i, 0, groupsep);
        }
        return num.join('');
    };

    // determine if all values of an array match a value
    // returns true if the array is empty
    all = function (val, arr, ignoreNull) {
        var i;
        for (i = arr.length; i--; ) {
            if (ignoreNull && arr[i] === null) continue;
            if (arr[i] !== val) {
                return false;
            }
        }
        return true;
    };

    // sums the numeric values in an array, ignoring other values
    sum = function (vals) {
        var total = 0, i;
        for (i = vals.length; i--;) {
            total += typeof vals[i] === 'number' ? vals[i] : 0;
        }
        return total;
    };

    ensureArray = function (val) {
        return $.isArray(val) ? val : [val];
    };

    // http://paulirish.com/2008/bookmarklet-inject-new-css-rules/
    addCSS = function(css) {
        var tag, iefail;
        if (document.createStyleSheet) {
            try {
                document.createStyleSheet().cssText = css;
                return;
            } catch (e) {
                // IE <= 9 maxes out at 31 stylesheets; inject into page instead.
                iefail = true;
            }
        }
        tag = document.createElement('style');
        tag.type = 'text/css';
        document.getElementsByTagName('head')[0].appendChild(tag);
        if (iefail) {
            document.styleSheets[document.styleSheets.length - 1].cssText = css;
        } else {
            tag[(typeof document.body.style.WebkitAppearance == 'string') /* webkit only */ ? 'innerText' : 'innerHTML'] = css;
        }
    };

    // Provide a cross-browser interface to a few simple drawing primitives
    $.fn.simpledraw = function (width, height, useExisting, interact) {
        var target, mhandler;
        if (useExisting && (target = this.data('_jqs_vcanvas'))) {
            return target;
        }

        if ($.fn.sparkline.canvas === false) {
            // We've already determined that neither Canvas nor VML are available
            return false;

        } else if ($.fn.sparkline.canvas === undefined) {
            // No function defined yet -- need to see if we support Canvas or VML
            var el = document.createElement('canvas');
            if (!!(el.getContext && el.getContext('2d'))) {
                // Canvas is available
                $.fn.sparkline.canvas = function(width, height, target, interact) {
                    return new VCanvas_canvas(width, height, target, interact);
                };
            } else if (document.namespaces && !document.namespaces.v) {
                // VML is available
                document.namespaces.add('v', 'urn:schemas-microsoft-com:vml', '#default#VML');
                $.fn.sparkline.canvas = function(width, height, target, interact) {
                    return new VCanvas_vml(width, height, target);
                };
            } else {
                // Neither Canvas nor VML are available
                $.fn.sparkline.canvas = false;
                return false;
            }
        }

        if (width === undefined) {
            width = $(this).innerWidth();
        }
        if (height === undefined) {
            height = $(this).innerHeight();
        }

        target = $.fn.sparkline.canvas(width, height, this, interact);

        mhandler = $(this).data('_jqs_mhandler');
        if (mhandler) {
            mhandler.registerCanvas(target);
        }
        return target;
    };

    $.fn.cleardraw = function () {
        var target = this.data('_jqs_vcanvas');
        if (target) {
            target.reset();
        }
    };

    $.RangeMapClass = RangeMap = createClass({
        init: function (map) {
            var key, range, rangelist = [];
            for (key in map) {
                if (map.hasOwnProperty(key) && typeof key === 'string' && key.indexOf(':') > -1) {
                    range = key.split(':');
                    range[0] = range[0].length === 0 ? -Infinity : parseFloat(range[0]);
                    range[1] = range[1].length === 0 ? Infinity : parseFloat(range[1]);
                    range[2] = map[key];
                    rangelist.push(range);
                }
            }
            this.map = map;
            this.rangelist = rangelist || false;
        },

        get: function (value) {
            var rangelist = this.rangelist,
                i, range, result;
            if ((result = this.map[value]) !== undefined) {
                return result;
            }
            if (rangelist) {
                for (i = rangelist.length; i--;) {
                    range = rangelist[i];
                    if (range[0] <= value && range[1] >= value) {
                        return range[2];
                    }
                }
            }
            return undefined;
        }
    });

    // Convenience function
    $.range_map = function(map) {
        return new RangeMap(map);
    };

    MouseHandler = createClass({
        init: function (el, options) {
            var $el = $(el);
            this.$el = $el;
            this.options = options;
            this.currentPageX = 0;
            this.currentPageY = 0;
            this.el = el;
            this.splist = [];
            this.tooltip = null;
            this.over = false;
            this.displayTooltips = !options.get('disableTooltips');
            this.highlightEnabled = !options.get('disableHighlight');
        },

        registerSparkline: function (sp) {
            this.splist.push(sp);
            if (this.over) {
                this.updateDisplay();
            }
        },

        registerCanvas: function (canvas) {
            var $canvas = $(canvas.canvas);
            this.canvas = canvas;
            this.$canvas = $canvas;
            $canvas.mouseenter($.proxy(this.mouseenter, this));
            $canvas.mouseleave($.proxy(this.mouseleave, this));
            $canvas.click($.proxy(this.mouseclick, this));
        },

        reset: function (removeTooltip) {
            this.splist = [];
            if (this.tooltip && removeTooltip) {
                this.tooltip.remove();
                this.tooltip = undefined;
            }
        },

        mouseclick: function (e) {
            var clickEvent = $.Event('sparklineClick');
            clickEvent.originalEvent = e;
            clickEvent.sparklines = this.splist;
            this.$el.trigger(clickEvent);
        },

        mouseenter: function (e) {
            $(document.body).unbind('mousemove.jqs');
            $(document.body).bind('mousemove.jqs', $.proxy(this.mousemove, this));
            this.over = true;
            this.currentPageX = e.pageX;
            this.currentPageY = e.pageY;
            this.currentEl = e.target;
            if (!this.tooltip && this.displayTooltips) {
                this.tooltip = new Tooltip(this.options);
                this.tooltip.updatePosition(e.pageX, e.pageY);
            }
            this.updateDisplay();
        },

        mouseleave: function () {
            $(document.body).unbind('mousemove.jqs');
            var splist = this.splist,
                 spcount = splist.length,
                 needsRefresh = false,
                 sp, i;
            this.over = false;
            this.currentEl = null;

            if (this.tooltip) {
                this.tooltip.remove();
                this.tooltip = null;
            }

            for (i = 0; i < spcount; i++) {
                sp = splist[i];
                if (sp.clearRegionHighlight()) {
                    needsRefresh = true;
                }
            }

            if (needsRefresh) {
                this.canvas.render();
            }
        },

        mousemove: function (e) {
            this.currentPageX = e.pageX;
            this.currentPageY = e.pageY;
            this.currentEl = e.target;
            if (this.tooltip) {
                this.tooltip.updatePosition(e.pageX, e.pageY);
            }
            this.updateDisplay();
        },

        updateDisplay: function () {
            var splist = this.splist,
                 spcount = splist.length,
                 needsRefresh = false,
                 offset = this.$canvas.offset(),
                 localX = this.currentPageX - offset.left,
                 localY = this.currentPageY - offset.top,
                 tooltiphtml, sp, i, result, changeEvent;
            if (!this.over) {
                return;
            }
            for (i = 0; i < spcount; i++) {
                sp = splist[i];
                result = sp.setRegionHighlight(this.currentEl, localX, localY);
                if (result) {
                    needsRefresh = true;
                }
            }
            if (needsRefresh) {
                changeEvent = $.Event('sparklineRegionChange');
                changeEvent.sparklines = this.splist;
                this.$el.trigger(changeEvent);
                if (this.tooltip) {
                    tooltiphtml = '';
                    for (i = 0; i < spcount; i++) {
                        sp = splist[i];
                        tooltiphtml += sp.getCurrentRegionTooltip();
                    }
                    this.tooltip.setContent(tooltiphtml);
                }
                if (!this.disableHighlight) {
                    this.canvas.render();
                }
            }
            if (result === null) {
                this.mouseleave();
            }
        }
    });


    Tooltip = createClass({
        sizeStyle: 'position: static !important;' +
            'display: block !important;' +
            'visibility: hidden !important;' +
            'float: left !important;',

        init: function (options) {
            var tooltipClassname = options.get('tooltipClassname', 'jqstooltip'),
                sizetipStyle = this.sizeStyle,
                offset;
            this.container = options.get('tooltipContainer') || document.body;
            this.tooltipOffsetX = options.get('tooltipOffsetX', 10);
            this.tooltipOffsetY = options.get('tooltipOffsetY', 12);
            // remove any previous lingering tooltip
            $('#jqssizetip').remove();
            $('#jqstooltip').remove();
            this.sizetip = $('<div/>', {
                id: 'jqssizetip',
                style: sizetipStyle,
                'class': tooltipClassname
            });
            this.tooltip = $('<div/>', {
                id: 'jqstooltip',
                'class': tooltipClassname
            }).appendTo(this.container);
            // account for the container's location
            offset = this.tooltip.offset();
            this.offsetLeft = offset.left;
            this.offsetTop = offset.top;
            this.hidden = true;
            $(window).unbind('resize.jqs scroll.jqs');
            $(window).bind('resize.jqs scroll.jqs', $.proxy(this.updateWindowDims, this));
            this.updateWindowDims();
        },

        updateWindowDims: function () {
            this.scrollTop = $(window).scrollTop();
            this.scrollLeft = $(window).scrollLeft();
            this.scrollRight = this.scrollLeft + $(window).width();
            this.updatePosition();
        },

        getSize: function (content) {
            this.sizetip.html(content).appendTo(this.container);
            this.width = this.sizetip.width() + 1;
            this.height = this.sizetip.height();
            this.sizetip.remove();
        },

        setContent: function (content) {
            if (!content) {
                this.tooltip.css('visibility', 'hidden');
                this.hidden = true;
                return;
            }
            this.getSize(content);
            this.tooltip.html(content)
                .css({
                    'width': this.width,
                    'height': this.height,
                    'visibility': 'visible'
                });
            if (this.hidden) {
                this.hidden = false;
                this.updatePosition();
            }
        },

        updatePosition: function (x, y) {
            if (x === undefined) {
                if (this.mousex === undefined) {
                    return;
                }
                x = this.mousex - this.offsetLeft;
                y = this.mousey - this.offsetTop;

            } else {
                this.mousex = x = x - this.offsetLeft;
                this.mousey = y = y - this.offsetTop;
            }
            if (!this.height || !this.width || this.hidden) {
                return;
            }

            y -= this.height + this.tooltipOffsetY;
            x += this.tooltipOffsetX;

            if (y < this.scrollTop) {
                y = this.scrollTop;
            }
            if (x < this.scrollLeft) {
                x = this.scrollLeft;
            } else if (x + this.width > this.scrollRight) {
                x = this.scrollRight - this.width;
            }

            this.tooltip.css({
                'left': x,
                'top': y
            });
        },

        remove: function () {
            this.tooltip.remove();
            this.sizetip.remove();
            this.sizetip = this.tooltip = undefined;
            $(window).unbind('resize.jqs scroll.jqs');
        }
    });

    initStyles = function() {
        addCSS(defaultStyles);
    };

    $(initStyles);

    pending = [];
    $.fn.sparkline = function (userValues, userOptions) {
        return this.each(function () {
            var options = new $.fn.sparkline.options(this, userOptions),
                 $this = $(this),
                 render, i;
            render = function () {
                var values, width, height, tmp, mhandler, sp, vals;
                if (userValues === 'html' || userValues === undefined) {
                    vals = this.getAttribute(options.get('tagValuesAttribute'));
                    if (vals === undefined || vals === null) {
                        vals = $this.html();
                    }
                    values = vals.replace(/(^\s*<!--)|(-->\s*$)|\s+/g, '').split(',');
                } else {
                    values = userValues;
                }

                width = options.get('width') === 'auto' ? values.length * options.get('defaultPixelsPerValue') : options.get('width');
                if (options.get('height') === 'auto') {
                    if (!options.get('composite') || !$.data(this, '_jqs_vcanvas')) {
                        // must be a better way to get the line height
                        tmp = document.createElement('span');
                        tmp.innerHTML = 'a';
                        $this.html(tmp);
                        height = $(tmp).innerHeight() || $(tmp).height();
                        $(tmp).remove();
                        tmp = null;
                    }
                } else {
                    height = options.get('height');
                }

                if (!options.get('disableInteraction')) {
                    mhandler = $.data(this, '_jqs_mhandler');
                    if (!mhandler) {
                        mhandler = new MouseHandler(this, options);
                        $.data(this, '_jqs_mhandler', mhandler);
                    } else if (!options.get('composite')) {
                        mhandler.reset();
                    }
                } else {
                    mhandler = false;
                }

                if (options.get('composite') && !$.data(this, '_jqs_vcanvas')) {
                    if (!$.data(this, '_jqs_errnotify')) {
                        alert('Attempted to attach a composite sparkline to an element with no existing sparkline');
                        $.data(this, '_jqs_errnotify', true);
                    }
                    return;
                }

                sp = new $.fn.sparkline[options.get('type')](this, values, options, width, height);

                sp.render();

                if (mhandler) {
                    mhandler.registerSparkline(sp);
                }
            };
            if (($(this).html() && !options.get('disableHiddenCheck') && $(this).is(':hidden')) || !$(this).parents('body').length) {
                if (!options.get('composite') && $.data(this, '_jqs_pending')) {
                    // remove any existing references to the element
                    for (i = pending.length; i; i--) {
                        if (pending[i - 1][0] == this) {
                            pending.splice(i - 1, 1);
                        }
                    }
                }
                pending.push([this, render]);
                $.data(this, '_jqs_pending', true);
            } else {
                render.call(this);
            }
        });
    };

    $.fn.sparkline.defaults = getDefaults();


    $.sparkline_display_visible = function () {
        var el, i, pl;
        var done = [];
        for (i = 0, pl = pending.length; i < pl; i++) {
            el = pending[i][0];
            if ($(el).is(':visible') && !$(el).parents().is(':hidden')) {
                pending[i][1].call(el);
                $.data(pending[i][0], '_jqs_pending', false);
                done.push(i);
            } else if (!$(el).closest('html').length && !$.data(el, '_jqs_pending')) {
                // element has been inserted and removed from the DOM
                // If it was not yet inserted into the dom then the .data request
                // will return true.
                // removing from the dom causes the data to be removed.
                $.data(pending[i][0], '_jqs_pending', false);
                done.push(i);
            }
        }
        for (i = done.length; i; i--) {
            pending.splice(done[i - 1], 1);
        }
    };


    /**
     * User option handler
     */
    $.fn.sparkline.options = createClass({
        init: function (tag, userOptions) {
            var extendedOptions, defaults, base, tagOptionType;
            this.userOptions = userOptions = userOptions || {};
            this.tag = tag;
            this.tagValCache = {};
            defaults = $.fn.sparkline.defaults;
            base = defaults.common;
            this.tagOptionsPrefix = userOptions.enableTagOptions && (userOptions.tagOptionsPrefix || base.tagOptionsPrefix);

            tagOptionType = this.getTagSetting('type');
            if (tagOptionType === UNSET_OPTION) {
                extendedOptions = defaults[userOptions.type || base.type];
            } else {
                extendedOptions = defaults[tagOptionType];
            }
            this.mergedOptions = $.extend({}, base, extendedOptions, userOptions);
        },


        getTagSetting: function (key) {
            var prefix = this.tagOptionsPrefix,
                val, i, pairs, keyval;
            if (prefix === false || prefix === undefined) {
                return UNSET_OPTION;
            }
            if (this.tagValCache.hasOwnProperty(key)) {
                val = this.tagValCache.key;
            } else {
                val = this.tag.getAttribute(prefix + key);
                if (val === undefined || val === null) {
                    val = UNSET_OPTION;
                } else if (val.substr(0, 1) === '[') {
                    val = val.substr(1, val.length - 2).split(',');
                    for (i = val.length; i--;) {
                        val[i] = normalizeValue(val[i].replace(/(^\s*)|(\s*$)/g, ''));
                    }
                } else if (val.substr(0, 1) === '{') {
                    pairs = val.substr(1, val.length - 2).split(',');
                    val = {};
                    for (i = pairs.length; i--;) {
                        keyval = pairs[i].split(':', 2);
                        val[keyval[0].replace(/(^\s*)|(\s*$)/g, '')] = normalizeValue(keyval[1].replace(/(^\s*)|(\s*$)/g, ''));
                    }
                } else {
                    val = normalizeValue(val);
                }
                this.tagValCache.key = val;
            }
            return val;
        },

        get: function (key, defaultval) {
            var tagOption = this.getTagSetting(key),
                result;
            if (tagOption !== UNSET_OPTION) {
                return tagOption;
            }
            return (result = this.mergedOptions[key]) === undefined ? defaultval : result;
        }
    });


    $.fn.sparkline._base = createClass({
        disabled: false,

        init: function (el, values, options, width, height) {
            this.el = el;
            this.$el = $(el);
            this.values = values;
            this.options = options;
            this.width = width;
            this.height = height;
            this.currentRegion = undefined;
        },

        /**
         * Setup the canvas
         */
        initTarget: function () {
            var interactive = !this.options.get('disableInteraction');
            if (!(this.target = this.$el.simpledraw(this.width, this.height, this.options.get('composite'), interactive))) {
                this.disabled = true;
            } else {
                this.canvasWidth = this.target.pixelWidth;
                this.canvasHeight = this.target.pixelHeight;
            }
        },

        /**
         * Actually render the chart to the canvas
         */
        render: function () {
            if (this.disabled) {
                this.el.innerHTML = '';
                return false;
            }
            return true;
        },

        /**
         * Return a region id for a given x/y co-ordinate
         */
        getRegion: function (x, y) {
        },

        /**
         * Highlight an item based on the moused-over x,y co-ordinate
         */
        setRegionHighlight: function (el, x, y) {
            var currentRegion = this.currentRegion,
                highlightEnabled = !this.options.get('disableHighlight'),
                newRegion;
            if (x > this.canvasWidth || y > this.canvasHeight || x < 0 || y < 0) {
                return null;
            }
            newRegion = this.getRegion(el, x, y);
            if (currentRegion !== newRegion) {
                if (currentRegion !== undefined && highlightEnabled) {
                    this.removeHighlight();
                }
                this.currentRegion = newRegion;
                if (newRegion !== undefined && highlightEnabled) {
                    this.renderHighlight();
                }
                return true;
            }
            return false;
        },

        /**
         * Reset any currently highlighted item
         */
        clearRegionHighlight: function () {
            if (this.currentRegion !== undefined) {
                this.removeHighlight();
                this.currentRegion = undefined;
                return true;
            }
            return false;
        },

        renderHighlight: function () {
            this.changeHighlight(true);
        },

        removeHighlight: function () {
            this.changeHighlight(false);
        },

        changeHighlight: function (highlight)  {},

        /**
         * Fetch the HTML to display as a tooltip
         */
        getCurrentRegionTooltip: function () {
            var options = this.options,
                header = '',
                entries = [],
                fields, formats, formatlen, fclass, text, i,
                showFields, showFieldsKey, newFields, fv,
                formatter, format, fieldlen, j;
            if (this.currentRegion === undefined) {
                return '';
            }
            fields = this.getCurrentRegionFields();
            formatter = options.get('tooltipFormatter');
            if (formatter) {
                return formatter(this, options, fields);
            }
            if (options.get('tooltipChartTitle')) {
                header += '<div class="jqs jqstitle">' + options.get('tooltipChartTitle') + '</div>\n';
            }
            formats = this.options.get('tooltipFormat');
            if (!formats) {
                return '';
            }
            if (!$.isArray(formats)) {
                formats = [formats];
            }
            if (!$.isArray(fields)) {
                fields = [fields];
            }
            showFields = this.options.get('tooltipFormatFieldlist');
            showFieldsKey = this.options.get('tooltipFormatFieldlistKey');
            if (showFields && showFieldsKey) {
                // user-selected ordering of fields
                newFields = [];
                for (i = fields.length; i--;) {
                    fv = fields[i][showFieldsKey];
                    if ((j = $.inArray(fv, showFields)) != -1) {
                        newFields[j] = fields[i];
                    }
                }
                fields = newFields;
            }
            formatlen = formats.length;
            fieldlen = fields.length;
            for (i = 0; i < formatlen; i++) {
                format = formats[i];
                if (typeof format === 'string') {
                    format = new SPFormat(format);
                }
                fclass = format.fclass || 'jqsfield';
                for (j = 0; j < fieldlen; j++) {
                    if (!fields[j].isNull || !options.get('tooltipSkipNull')) {
                        $.extend(fields[j], {
                            prefix: options.get('tooltipPrefix'),
                            suffix: options.get('tooltipSuffix')
                        });
                        text = format.render(fields[j], options.get('tooltipValueLookups'), options);
                        entries.push('<div class="' + fclass + '">' + text + '</div>');
                    }
                }
            }
            if (entries.length) {
                return header + entries.join('\n');
            }
            return '';
        },

        getCurrentRegionFields: function () {},

        calcHighlightColor: function (color, options) {
            var highlightColor = options.get('highlightColor'),
                lighten = options.get('highlightLighten'),
                parse, mult, rgbnew, i;
            if (highlightColor) {
                return highlightColor;
            }
            if (lighten) {
                // extract RGB values
                parse = /^#([0-9a-f])([0-9a-f])([0-9a-f])$/i.exec(color) || /^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(color);
                if (parse) {
                    rgbnew = [];
                    mult = color.length === 4 ? 16 : 1;
                    for (i = 0; i < 3; i++) {
                        rgbnew[i] = clipval(Math.round(parseInt(parse[i + 1], 16) * mult * lighten), 0, 255);
                    }
                    return 'rgb(' + rgbnew.join(',') + ')';
                }

            }
            return color;
        }

    });

    barHighlightMixin = {
        changeHighlight: function (highlight) {
            var currentRegion = this.currentRegion,
                target = this.target,
                shapeids = this.regionShapes[currentRegion],
                newShapes;
            // will be null if the region value was null
            if (shapeids) {
                newShapes = this.renderRegion(currentRegion, highlight);
                if ($.isArray(newShapes) || $.isArray(shapeids)) {
                    target.replaceWithShapes(shapeids, newShapes);
                    this.regionShapes[currentRegion] = $.map(newShapes, function (newShape) {
                        return newShape.id;
                    });
                } else {
                    target.replaceWithShape(shapeids, newShapes);
                    this.regionShapes[currentRegion] = newShapes.id;
                }
            }
        },

        render: function () {
            var values = this.values,
                target = this.target,
                regionShapes = this.regionShapes,
                shapes, ids, i, j;

            if (!this.cls._super.render.call(this)) {
                return;
            }
            for (i = values.length; i--;) {
                shapes = this.renderRegion(i);
                if (shapes) {
                    if ($.isArray(shapes)) {
                        ids = [];
                        for (j = shapes.length; j--;) {
                            shapes[j].append();
                            ids.push(shapes[j].id);
                        }
                        regionShapes[i] = ids;
                    } else {
                        shapes.append();
                        regionShapes[i] = shapes.id; // store just the shapeid
                    }
                } else {
                    // null value
                    regionShapes[i] = null;
                }
            }
            target.render();
        }
    };

    /**
     * Line charts
     */
    $.fn.sparkline.line = line = createClass($.fn.sparkline._base, {
        type: 'line',

        init: function (el, values, options, width, height) {
            line._super.init.call(this, el, values, options, width, height);
            this.vertices = [];
            this.regionMap = [];
            this.xvalues = [];
            this.yvalues = [];
            this.yminmax = [];
            this.hightlightSpotId = null;
            this.lastShapeId = null;
            this.initTarget();
        },

        getRegion: function (el, x, y) {
            var i,
                regionMap = this.regionMap; // maps regions to value positions
            for (i = regionMap.length; i--;) {
                if (regionMap[i] !== null && x >= regionMap[i][0] && x <= regionMap[i][1]) {
                    return regionMap[i][2];
                }
            }
            return undefined;
        },

        getCurrentRegionFields: function () {
            var currentRegion = this.currentRegion;
            return {
                isNull: this.yvalues[currentRegion] === null,
                x: this.xvalues[currentRegion],
                y: this.yvalues[currentRegion],
                color: this.options.get('lineColor'),
                fillColor: this.options.get('fillColor'),
                offset: currentRegion
            };
        },

        renderHighlight: function () {
            var currentRegion = this.currentRegion,
                target = this.target,
                vertex = this.vertices[currentRegion],
                options = this.options,
                spotRadius = options.get('spotRadius'),
                highlightSpotColor = options.get('highlightSpotColor'),
                highlightLineColor = options.get('highlightLineColor'),
                highlightSpot, highlightLine;

            if (!vertex) {
                return;
            }
            if (spotRadius && highlightSpotColor) {
                highlightSpot = target.drawCircle(vertex[0], vertex[1],
                    spotRadius, undefined, highlightSpotColor);
                this.highlightSpotId = highlightSpot.id;
                target.insertAfterShape(this.lastShapeId, highlightSpot);
            }
            if (highlightLineColor) {
                highlightLine = target.drawLine(vertex[0], this.canvasTop, vertex[0],
                    this.canvasTop + this.canvasHeight, highlightLineColor);
                this.highlightLineId = highlightLine.id;
                target.insertAfterShape(this.lastShapeId, highlightLine);
            }
        },

        removeHighlight: function () {
            var target = this.target;
            if (this.highlightSpotId) {
                target.removeShapeId(this.highlightSpotId);
                this.highlightSpotId = null;
            }
            if (this.highlightLineId) {
                target.removeShapeId(this.highlightLineId);
                this.highlightLineId = null;
            }
        },

        scanValues: function () {
            var values = this.values,
                valcount = values.length,
                xvalues = this.xvalues,
                yvalues = this.yvalues,
                yminmax = this.yminmax,
                i, val, isStr, isArray, sp;
            for (i = 0; i < valcount; i++) {
                val = values[i];
                isStr = typeof(values[i]) === 'string';
                isArray = typeof(values[i]) === 'object' && values[i] instanceof Array;
                sp = isStr && values[i].split(':');
                if (isStr && sp.length === 2) { // x:y
                    xvalues.push(Number(sp[0]));
                    yvalues.push(Number(sp[1]));
                    yminmax.push(Number(sp[1]));
                } else if (isArray) {
                    xvalues.push(val[0]);
                    yvalues.push(val[1]);
                    yminmax.push(val[1]);
                } else {
                    xvalues.push(i);
                    if (values[i] === null || values[i] === 'null') {
                        yvalues.push(null);
                    } else {
                        yvalues.push(Number(val));
                        yminmax.push(Number(val));
                    }
                }
            }
            if (this.options.get('xvalues')) {
                xvalues = this.options.get('xvalues');
            }

            this.maxy = this.maxyorg = Math.max.apply(Math, yminmax);
            this.miny = this.minyorg = Math.min.apply(Math, yminmax);

            this.maxx = Math.max.apply(Math, xvalues);
            this.minx = Math.min.apply(Math, xvalues);

            this.xvalues = xvalues;
            this.yvalues = yvalues;
            this.yminmax = yminmax;

        },

        processRangeOptions: function () {
            var options = this.options,
                normalRangeMin = options.get('normalRangeMin'),
                normalRangeMax = options.get('normalRangeMax');

            if (normalRangeMin !== undefined) {
                if (normalRangeMin < this.miny) {
                    this.miny = normalRangeMin;
                }
                if (normalRangeMax > this.maxy) {
                    this.maxy = normalRangeMax;
                }
            }
            if (options.get('chartRangeMin') !== undefined && (options.get('chartRangeClip') || options.get('chartRangeMin') < this.miny)) {
                this.miny = options.get('chartRangeMin');
            }
            if (options.get('chartRangeMax') !== undefined && (options.get('chartRangeClip') || options.get('chartRangeMax') > this.maxy)) {
                this.maxy = options.get('chartRangeMax');
            }
            if (options.get('chartRangeMinX') !== undefined && (options.get('chartRangeClipX') || options.get('chartRangeMinX') < this.minx)) {
                this.minx = options.get('chartRangeMinX');
            }
            if (options.get('chartRangeMaxX') !== undefined && (options.get('chartRangeClipX') || options.get('chartRangeMaxX') > this.maxx)) {
                this.maxx = options.get('chartRangeMaxX');
            }

        },

        drawNormalRange: function (canvasLeft, canvasTop, canvasHeight, canvasWidth, rangey) {
            var normalRangeMin = this.options.get('normalRangeMin'),
                normalRangeMax = this.options.get('normalRangeMax'),
                ytop = canvasTop + Math.round(canvasHeight - (canvasHeight * ((normalRangeMax - this.miny) / rangey))),
                height = Math.round((canvasHeight * (normalRangeMax - normalRangeMin)) / rangey);
            this.target.drawRect(canvasLeft, ytop, canvasWidth, height, undefined, this.options.get('normalRangeColor')).append();
        },

        render: function () {
            var options = this.options,
                target = this.target,
                canvasWidth = this.canvasWidth,
                canvasHeight = this.canvasHeight,
                vertices = this.vertices,
                spotRadius = options.get('spotRadius'),
                regionMap = this.regionMap,
                rangex, rangey, yvallast,
                canvasTop, canvasLeft,
                vertex, path, paths, x, y, xnext, xpos, xposnext,
                last, next, yvalcount, lineShapes, fillShapes, plen,
                valueSpots, hlSpotsEnabled, color, xvalues, yvalues, i;

            if (!line._super.render.call(this)) {
                return;
            }

            this.scanValues();
            this.processRangeOptions();

            xvalues = this.xvalues;
            yvalues = this.yvalues;

            if (!this.yminmax.length || this.yvalues.length < 2) {
                // empty or all null valuess
                return;
            }

            canvasTop = canvasLeft = 0;

            rangex = this.maxx - this.minx === 0 ? 1 : this.maxx - this.minx;
            rangey = this.maxy - this.miny === 0 ? 1 : this.maxy - this.miny;
            yvallast = this.yvalues.length - 1;

            if (spotRadius && (canvasWidth < (spotRadius * 4) || canvasHeight < (spotRadius * 4))) {
                spotRadius = 0;
            }
            if (spotRadius) {
                // adjust the canvas size as required so that spots will fit
                hlSpotsEnabled = options.get('highlightSpotColor') &&  !options.get('disableInteraction');
                if (hlSpotsEnabled || options.get('minSpotColor') || (options.get('spotColor') && yvalues[yvallast] === this.miny)) {
                    canvasHeight -= Math.ceil(spotRadius);
                }
                if (hlSpotsEnabled || options.get('maxSpotColor') || (options.get('spotColor') && yvalues[yvallast] === this.maxy)) {
                    canvasHeight -= Math.ceil(spotRadius);
                    canvasTop += Math.ceil(spotRadius);
                }
                if (hlSpotsEnabled ||
                     ((options.get('minSpotColor') || options.get('maxSpotColor')) && (yvalues[0] === this.miny || yvalues[0] === this.maxy))) {
                    canvasLeft += Math.ceil(spotRadius);
                    canvasWidth -= Math.ceil(spotRadius);
                }
                if (hlSpotsEnabled || options.get('spotColor') ||
                    (options.get('minSpotColor') || options.get('maxSpotColor') &&
                        (yvalues[yvallast] === this.miny || yvalues[yvallast] === this.maxy))) {
                    canvasWidth -= Math.ceil(spotRadius);
                }
            }


            canvasHeight--;

            if (options.get('normalRangeMin') !== undefined && !options.get('drawNormalOnTop')) {
                this.drawNormalRange(canvasLeft, canvasTop, canvasHeight, canvasWidth, rangey);
            }

            path = [];
            paths = [path];
            last = next = null;
            yvalcount = yvalues.length;
            for (i = 0; i < yvalcount; i++) {
                x = xvalues[i];
                xnext = xvalues[i + 1];
                y = yvalues[i];
                xpos = canvasLeft + Math.round((x - this.minx) * (canvasWidth / rangex));
                xposnext = i < yvalcount - 1 ? canvasLeft + Math.round((xnext - this.minx) * (canvasWidth / rangex)) : canvasWidth;
                next = xpos + ((xposnext - xpos) / 2);
                regionMap[i] = [last || 0, next, i];
                last = next;
                if (y === null) {
                    if (i) {
                        if (yvalues[i - 1] !== null) {
                            path = [];
                            paths.push(path);
                        }
                        vertices.push(null);
                    }
                } else {
                    if (y < this.miny) {
                        y = this.miny;
                    }
                    if (y > this.maxy) {
                        y = this.maxy;
                    }
                    if (!path.length) {
                        // previous value was null
                        path.push([xpos, canvasTop + canvasHeight]);
                    }
                    vertex = [xpos, canvasTop + Math.round(canvasHeight - (canvasHeight * ((y - this.miny) / rangey)))];
                    path.push(vertex);
                    vertices.push(vertex);
                }
            }

            lineShapes = [];
            fillShapes = [];
            plen = paths.length;
            for (i = 0; i < plen; i++) {
                path = paths[i];
                if (path.length) {
                    if (options.get('fillColor')) {
                        path.push([path[path.length - 1][0], (canvasTop + canvasHeight)]);
                        fillShapes.push(path.slice(0));
                        path.pop();
                    }
                    // if there's only a single point in this path, then we want to display it
                    // as a vertical line which means we keep path[0]  as is
                    if (path.length > 2) {
                        // else we want the first value
                        path[0] = [path[0][0], path[1][1]];
                    }
                    lineShapes.push(path);
                }
            }

            // draw the fill first, then optionally the normal range, then the line on top of that
            plen = fillShapes.length;
            for (i = 0; i < plen; i++) {
                target.drawShape(fillShapes[i],
                    options.get('fillColor'), options.get('fillColor')).append();
            }

            if (options.get('normalRangeMin') !== undefined && options.get('drawNormalOnTop')) {
                this.drawNormalRange(canvasLeft, canvasTop, canvasHeight, canvasWidth, rangey);
            }

            plen = lineShapes.length;
            for (i = 0; i < plen; i++) {
                target.drawShape(lineShapes[i], options.get('lineColor'), undefined,
                    options.get('lineWidth')).append();
            }

            if (spotRadius && options.get('valueSpots')) {
                valueSpots = options.get('valueSpots');
                if (valueSpots.get === undefined) {
                    valueSpots = new RangeMap(valueSpots);
                }
                for (i = 0; i < yvalcount; i++) {
                    color = valueSpots.get(yvalues[i]);
                    if (color) {
                        target.drawCircle(canvasLeft + Math.round((xvalues[i] - this.minx) * (canvasWidth / rangex)),
                            canvasTop + Math.round(canvasHeight - (canvasHeight * ((yvalues[i] - this.miny) / rangey))),
                            spotRadius, undefined,
                            color).append();
                    }
                }

            }
            if (spotRadius && options.get('spotColor') && yvalues[yvallast] !== null) {
                target.drawCircle(canvasLeft + Math.round((xvalues[xvalues.length - 1] - this.minx) * (canvasWidth / rangex)),
                    canvasTop + Math.round(canvasHeight - (canvasHeight * ((yvalues[yvallast] - this.miny) / rangey))),
                    spotRadius, undefined,
                    options.get('spotColor')).append();
            }
            if (this.maxy !== this.minyorg) {
                if (spotRadius && options.get('minSpotColor')) {
                    x = xvalues[$.inArray(this.minyorg, yvalues)];
                    target.drawCircle(canvasLeft + Math.round((x - this.minx) * (canvasWidth / rangex)),
                        canvasTop + Math.round(canvasHeight - (canvasHeight * ((this.minyorg - this.miny) / rangey))),
                        spotRadius, undefined,
                        options.get('minSpotColor')).append();
                }
                if (spotRadius && options.get('maxSpotColor')) {
                    x = xvalues[$.inArray(this.maxyorg, yvalues)];
                    target.drawCircle(canvasLeft + Math.round((x - this.minx) * (canvasWidth / rangex)),
                        canvasTop + Math.round(canvasHeight - (canvasHeight * ((this.maxyorg - this.miny) / rangey))),
                        spotRadius, undefined,
                        options.get('maxSpotColor')).append();
                }
            }

            this.lastShapeId = target.getLastShapeId();
            this.canvasTop = canvasTop;
            target.render();
        }
    });

    /**
     * Bar charts
     */
    $.fn.sparkline.bar = bar = createClass($.fn.sparkline._base, barHighlightMixin, {
        type: 'bar',

        init: function (el, values, options, width, height) {
            var barWidth = parseInt(options.get('barWidth'), 10),
                barSpacing = parseInt(options.get('barSpacing'), 10),
                chartRangeMin = options.get('chartRangeMin'),
                chartRangeMax = options.get('chartRangeMax'),
                chartRangeClip = options.get('chartRangeClip'),
                stackMin = Infinity,
                stackMax = -Infinity,
                isStackString, groupMin, groupMax, stackRanges,
                numValues, i, vlen, range, zeroAxis, xaxisOffset, min, max, clipMin, clipMax,
                stacked, vlist, j, slen, svals, val, yoffset, yMaxCalc, canvasHeightEf;
            bar._super.init.call(this, el, values, options, width, height);

            // scan values to determine whether to stack bars
            for (i = 0, vlen = values.length; i < vlen; i++) {
                val = values[i];
                isStackString = typeof(val) === 'string' && val.indexOf(':') > -1;
                if (isStackString || $.isArray(val)) {
                    stacked = true;
                    if (isStackString) {
                        val = values[i] = normalizeValues(val.split(':'));
                    }
                    val = remove(val, null); // min/max will treat null as zero
                    groupMin = Math.min.apply(Math, val);
                    groupMax = Math.max.apply(Math, val);
                    if (groupMin < stackMin) {
                        stackMin = groupMin;
                    }
                    if (groupMax > stackMax) {
                        stackMax = groupMax;
                    }
                }
            }

            this.stacked = stacked;
            this.regionShapes = {};
            this.barWidth = barWidth;
            this.barSpacing = barSpacing;
            this.totalBarWidth = barWidth + barSpacing;
            this.width = width = (values.length * barWidth) + ((values.length - 1) * barSpacing);

            this.initTarget();

            if (chartRangeClip) {
                clipMin = chartRangeMin === undefined ? -Infinity : chartRangeMin;
                clipMax = chartRangeMax === undefined ? Infinity : chartRangeMax;
            }

            numValues = [];
            stackRanges = stacked ? [] : numValues;
            var stackTotals = [];
            var stackRangesNeg = [];
            for (i = 0, vlen = values.length; i < vlen; i++) {
                if (stacked) {
                    vlist = values[i];
                    values[i] = svals = [];
                    stackTotals[i] = 0;
                    stackRanges[i] = stackRangesNeg[i] = 0;
                    for (j = 0, slen = vlist.length; j < slen; j++) {
                        val = svals[j] = chartRangeClip ? clipval(vlist[j], clipMin, clipMax) : vlist[j];
                        if (val !== null) {
                            if (val > 0) {
                                stackTotals[i] += val;
                            }
                            if (stackMin < 0 && stackMax > 0) {
                                if (val < 0) {
                                    stackRangesNeg[i] += Math.abs(val);
                                } else {
                                    stackRanges[i] += val;
                                }
                            } else {
                                stackRanges[i] += Math.abs(val - (val < 0 ? stackMax : stackMin));
                            }
                            numValues.push(val);
                        }
                    }
                } else {
                    val = chartRangeClip ? clipval(values[i], clipMin, clipMax) : values[i];
                    val = values[i] = normalizeValue(val);
                    if (val !== null) {
                        numValues.push(val);
                    }
                }
            }
            this.max = max = Math.max.apply(Math, numValues);
            this.min = min = Math.min.apply(Math, numValues);
            this.stackMax = stackMax = stacked ? Math.max.apply(Math, stackTotals) : max;
            this.stackMin = stackMin = stacked ? Math.min.apply(Math, numValues) : min;

            if (options.get('chartRangeMin') !== undefined && (options.get('chartRangeClip') || options.get('chartRangeMin') < min)) {
                min = options.get('chartRangeMin');
            }
            if (options.get('chartRangeMax') !== undefined && (options.get('chartRangeClip') || options.get('chartRangeMax') > max)) {
                max = options.get('chartRangeMax');
            }

            this.zeroAxis = zeroAxis = options.get('zeroAxis', true);
            if (min <= 0 && max >= 0 && zeroAxis) {
                xaxisOffset = 0;
            } else if (zeroAxis == false) {
                xaxisOffset = min;
            } else if (min > 0) {
                xaxisOffset = min;
            } else {
                xaxisOffset = max;
            }
            this.xaxisOffset = xaxisOffset;

            range = stacked ? (Math.max.apply(Math, stackRanges) + Math.max.apply(Math, stackRangesNeg)) : max - min;

            // as we plot zero/min values a single pixel line, we add a pixel to all other
            // values - Reduce the effective canvas size to suit
            this.canvasHeightEf = (zeroAxis && min < 0) ? this.canvasHeight - 2 : this.canvasHeight - 1;

            if (min < xaxisOffset) {
                yMaxCalc = (stacked && max >= 0) ? stackMax : max;
                yoffset = (yMaxCalc - xaxisOffset) / range * this.canvasHeight;
                if (yoffset !== Math.ceil(yoffset)) {
                    this.canvasHeightEf -= 2;
                    yoffset = Math.ceil(yoffset);
                }
            } else {
                yoffset = this.canvasHeight;
            }
            this.yoffset = yoffset;

            if ($.isArray(options.get('colorMap'))) {
                this.colorMapByIndex = options.get('colorMap');
                this.colorMapByValue = null;
            } else {
                this.colorMapByIndex = null;
                this.colorMapByValue = options.get('colorMap');
                if (this.colorMapByValue && this.colorMapByValue.get === undefined) {
                    this.colorMapByValue = new RangeMap(this.colorMapByValue);
                }
            }

            this.range = range;
        },

        getRegion: function (el, x, y) {
            var result = Math.floor(x / this.totalBarWidth);
            return (result < 0 || result >= this.values.length) ? undefined : result;
        },

        getCurrentRegionFields: function () {
            var currentRegion = this.currentRegion,
                values = ensureArray(this.values[currentRegion]),
                result = [],
                value, i;
            for (i = values.length; i--;) {
                value = values[i];
                result.push({
                    isNull: value === null,
                    value: value,
                    color: this.calcColor(i, value, currentRegion),
                    offset: currentRegion
                });
            }
            return result;
        },

        calcColor: function (stacknum, value, valuenum) {
            var colorMapByIndex = this.colorMapByIndex,
                colorMapByValue = this.colorMapByValue,
                options = this.options,
                color, newColor;
            if (this.stacked) {
                color = options.get('stackedBarColor');
            } else {
                color = (value < 0) ? options.get('negBarColor') : options.get('barColor');
            }
            if (value === 0 && options.get('zeroColor') !== undefined) {
                color = options.get('zeroColor');
            }
            if (colorMapByValue && (newColor = colorMapByValue.get(value))) {
                color = newColor;
            } else if (colorMapByIndex && colorMapByIndex.length > valuenum) {
                color = colorMapByIndex[valuenum];
            }
            return $.isArray(color) ? color[stacknum % color.length] : color;
        },

        /**
         * Render bar(s) for a region
         */
        renderRegion: function (valuenum, highlight) {
            var vals = this.values[valuenum],
                options = this.options,
                xaxisOffset = this.xaxisOffset,
                result = [],
                range = this.range,
                stacked = this.stacked,
                target = this.target,
                x = valuenum * this.totalBarWidth,
                canvasHeightEf = this.canvasHeightEf,
                yoffset = this.yoffset,
                y, height, color, isNull, yoffsetNeg, i, valcount, val, minPlotted, allMin;

            vals = $.isArray(vals) ? vals : [vals];
            valcount = vals.length;
            val = vals[0];
            isNull = all(null, vals);
            allMin = all(xaxisOffset, vals, true);

            if (isNull) {
                if (options.get('nullColor')) {
                    color = highlight ? options.get('nullColor') : this.calcHighlightColor(options.get('nullColor'), options);
                    y = (yoffset > 0) ? yoffset - 1 : yoffset;
                    return target.drawRect(x, y, this.barWidth - 1, 0, color, color);
                } else {
                    return undefined;
                }
            }
            yoffsetNeg = yoffset;
            for (i = 0; i < valcount; i++) {
                val = vals[i];

                if (stacked && val === xaxisOffset) {
                    if (!allMin || minPlotted) {
                        continue;
                    }
                    minPlotted = true;
                }

                if (range > 0) {
                    height = Math.floor(canvasHeightEf * ((Math.abs(val - xaxisOffset) / range))) + 1;
                } else {
                    height = 1;
                }
                if (val < xaxisOffset || (val === xaxisOffset && yoffset === 0)) {
                    y = yoffsetNeg;
                    yoffsetNeg += height;
                } else {
                    y = yoffset - height;
                    yoffset -= height;
                }
                color = this.calcColor(i, val, valuenum);
                if (highlight) {
                    color = this.calcHighlightColor(color, options);
                }
                result.push(target.drawRect(x, y, this.barWidth - 1, height - 1, color, color));
            }
            if (result.length === 1) {
                return result[0];
            }
            return result;
        }
    });

    /**
     * Tristate charts
     */
    $.fn.sparkline.tristate = tristate = createClass($.fn.sparkline._base, barHighlightMixin, {
        type: 'tristate',

        init: function (el, values, options, width, height) {
            var barWidth = parseInt(options.get('barWidth'), 10),
                barSpacing = parseInt(options.get('barSpacing'), 10);
            tristate._super.init.call(this, el, values, options, width, height);

            this.regionShapes = {};
            this.barWidth = barWidth;
            this.barSpacing = barSpacing;
            this.totalBarWidth = barWidth + barSpacing;
            this.values = $.map(values, Number);
            this.width = width = (values.length * barWidth) + ((values.length - 1) * barSpacing);

            if ($.isArray(options.get('colorMap'))) {
                this.colorMapByIndex = options.get('colorMap');
                this.colorMapByValue = null;
            } else {
                this.colorMapByIndex = null;
                this.colorMapByValue = options.get('colorMap');
                if (this.colorMapByValue && this.colorMapByValue.get === undefined) {
                    this.colorMapByValue = new RangeMap(this.colorMapByValue);
                }
            }
            this.initTarget();
        },

        getRegion: function (el, x, y) {
            return Math.floor(x / this.totalBarWidth);
        },

        getCurrentRegionFields: function () {
            var currentRegion = this.currentRegion;
            return {
                isNull: this.values[currentRegion] === undefined,
                value: this.values[currentRegion],
                color: this.calcColor(this.values[currentRegion], currentRegion),
                offset: currentRegion
            };
        },

        calcColor: function (value, valuenum) {
            var values = this.values,
                options = this.options,
                colorMapByIndex = this.colorMapByIndex,
                colorMapByValue = this.colorMapByValue,
                color, newColor;

            if (colorMapByValue && (newColor = colorMapByValue.get(value))) {
                color = newColor;
            } else if (colorMapByIndex && colorMapByIndex.length > valuenum) {
                color = colorMapByIndex[valuenum];
            } else if (values[valuenum] < 0) {
                color = options.get('negBarColor');
            } else if (values[valuenum] > 0) {
                color = options.get('posBarColor');
            } else {
                color = options.get('zeroBarColor');
            }
            return color;
        },

        renderRegion: function (valuenum, highlight) {
            var values = this.values,
                options = this.options,
                target = this.target,
                canvasHeight, height, halfHeight,
                x, y, color;

            canvasHeight = target.pixelHeight;
            halfHeight = Math.round(canvasHeight / 2);

            x = valuenum * this.totalBarWidth;
            if (values[valuenum] < 0) {
                y = halfHeight;
                height = halfHeight - 1;
            } else if (values[valuenum] > 0) {
                y = 0;
                height = halfHeight - 1;
            } else {
                y = halfHeight - 1;
                height = 2;
            }
            color = this.calcColor(values[valuenum], valuenum);
            if (color === null) {
                return;
            }
            if (highlight) {
                color = this.calcHighlightColor(color, options);
            }
            return target.drawRect(x, y, this.barWidth - 1, height - 1, color, color);
        }
    });

    /**
     * Discrete charts
     */
    $.fn.sparkline.discrete = discrete = createClass($.fn.sparkline._base, barHighlightMixin, {
        type: 'discrete',

        init: function (el, values, options, width, height) {
            discrete._super.init.call(this, el, values, options, width, height);

            this.regionShapes = {};
            this.values = values = $.map(values, Number);
            this.min = Math.min.apply(Math, values);
            this.max = Math.max.apply(Math, values);
            this.range = this.max - this.min;
            this.width = width = options.get('width') === 'auto' ? values.length * 2 : this.width;
            this.interval = Math.floor(width / values.length);
            this.itemWidth = width / values.length;
            if (options.get('chartRangeMin') !== undefined && (options.get('chartRangeClip') || options.get('chartRangeMin') < this.min)) {
                this.min = options.get('chartRangeMin');
            }
            if (options.get('chartRangeMax') !== undefined && (options.get('chartRangeClip') || options.get('chartRangeMax') > this.max)) {
                this.max = options.get('chartRangeMax');
            }
            this.initTarget();
            if (this.target) {
                this.lineHeight = options.get('lineHeight') === 'auto' ? Math.round(this.canvasHeight * 0.3) : options.get('lineHeight');
            }
        },

        getRegion: function (el, x, y) {
            return Math.floor(x / this.itemWidth);
        },

        getCurrentRegionFields: function () {
            var currentRegion = this.currentRegion;
            return {
                isNull: this.values[currentRegion] === undefined,
                value: this.values[currentRegion],
                offset: currentRegion
            };
        },

        renderRegion: function (valuenum, highlight) {
            var values = this.values,
                options = this.options,
                min = this.min,
                max = this.max,
                range = this.range,
                interval = this.interval,
                target = this.target,
                canvasHeight = this.canvasHeight,
                lineHeight = this.lineHeight,
                pheight = canvasHeight - lineHeight,
                ytop, val, color, x;

            val = clipval(values[valuenum], min, max);
            x = valuenum * interval;
            ytop = Math.round(pheight - pheight * ((val - min) / range));
            color = (options.get('thresholdColor') && val < options.get('thresholdValue')) ? options.get('thresholdColor') : options.get('lineColor');
            if (highlight) {
                color = this.calcHighlightColor(color, options);
            }
            return target.drawLine(x, ytop, x, ytop + lineHeight, color);
        }
    });

    /**
     * Bullet charts
     */
    $.fn.sparkline.bullet = bullet = createClass($.fn.sparkline._base, {
        type: 'bullet',

        init: function (el, values, options, width, height) {
            var min, max, vals;
            bullet._super.init.call(this, el, values, options, width, height);

            // values: target, performance, range1, range2, range3
            this.values = values = normalizeValues(values);
            // target or performance could be null
            vals = values.slice();
            vals[0] = vals[0] === null ? vals[2] : vals[0];
            vals[1] = values[1] === null ? vals[2] : vals[1];
            min = Math.min.apply(Math, values);
            max = Math.max.apply(Math, values);
            if (options.get('base') === undefined) {
                min = min < 0 ? min : 0;
            } else {
                min = options.get('base');
            }
            this.min = min;
            this.max = max;
            this.range = max - min;
            this.shapes = {};
            this.valueShapes = {};
            this.regiondata = {};
            this.width = width = options.get('width') === 'auto' ? '4.0em' : width;
            this.target = this.$el.simpledraw(width, height, options.get('composite'));
            if (!values.length) {
                this.disabled = true;
            }
            this.initTarget();
        },

        getRegion: function (el, x, y) {
            var shapeid = this.target.getShapeAt(el, x, y);
            return (shapeid !== undefined && this.shapes[shapeid] !== undefined) ? this.shapes[shapeid] : undefined;
        },

        getCurrentRegionFields: function () {
            var currentRegion = this.currentRegion;
            return {
                fieldkey: currentRegion.substr(0, 1),
                value: this.values[currentRegion.substr(1)],
                region: currentRegion
            };
        },

        changeHighlight: function (highlight) {
            var currentRegion = this.currentRegion,
                shapeid = this.valueShapes[currentRegion],
                shape;
            delete this.shapes[shapeid];
            switch (currentRegion.substr(0, 1)) {
                case 'r':
                    shape = this.renderRange(currentRegion.substr(1), highlight);
                    break;
                case 'p':
                    shape = this.renderPerformance(highlight);
                    break;
                case 't':
                    shape = this.renderTarget(highlight);
                    break;
            }
            this.valueShapes[currentRegion] = shape.id;
            this.shapes[shape.id] = currentRegion;
            this.target.replaceWithShape(shapeid, shape);
        },

        renderRange: function (rn, highlight) {
            var rangeval = this.values[rn],
                rangewidth = Math.round(this.canvasWidth * ((rangeval - this.min) / this.range)),
                color = this.options.get('rangeColors')[rn - 2];
            if (highlight) {
                color = this.calcHighlightColor(color, this.options);
            }
            return this.target.drawRect(0, 0, rangewidth - 1, this.canvasHeight - 1, color, color);
        },

        renderPerformance: function (highlight) {
            var perfval = this.values[1],
                perfwidth = Math.round(this.canvasWidth * ((perfval - this.min) / this.range)),
                color = this.options.get('performanceColor');
            if (highlight) {
                color = this.calcHighlightColor(color, this.options);
            }
            return this.target.drawRect(0, Math.round(this.canvasHeight * 0.3), perfwidth - 1,
                Math.round(this.canvasHeight * 0.4) - 1, color, color);
        },

        renderTarget: function (highlight) {
            var targetval = this.values[0],
                x = Math.round(this.canvasWidth * ((targetval - this.min) / this.range) - (this.options.get('targetWidth') / 2)),
                targettop = Math.round(this.canvasHeight * 0.10),
                targetheight = this.canvasHeight - (targettop * 2),
                color = this.options.get('targetColor');
            if (highlight) {
                color = this.calcHighlightColor(color, this.options);
            }
            return this.target.drawRect(x, targettop, this.options.get('targetWidth') - 1, targetheight - 1, color, color);
        },

        render: function () {
            var vlen = this.values.length,
                target = this.target,
                i, shape;
            if (!bullet._super.render.call(this)) {
                return;
            }
            for (i = 2; i < vlen; i++) {
                shape = this.renderRange(i).append();
                this.shapes[shape.id] = 'r' + i;
                this.valueShapes['r' + i] = shape.id;
            }
            if (this.values[1] !== null) {
                shape = this.renderPerformance().append();
                this.shapes[shape.id] = 'p1';
                this.valueShapes.p1 = shape.id;
            }
            if (this.values[0] !== null) {
                shape = this.renderTarget().append();
                this.shapes[shape.id] = 't0';
                this.valueShapes.t0 = shape.id;
            }
            target.render();
        }
    });

    /**
     * Pie charts
     */
    $.fn.sparkline.pie = pie = createClass($.fn.sparkline._base, {
        type: 'pie',

        init: function (el, values, options, width, height) {
            var total = 0, i;

            pie._super.init.call(this, el, values, options, width, height);

            this.shapes = {}; // map shape ids to value offsets
            this.valueShapes = {}; // maps value offsets to shape ids
            this.values = values = $.map(values, Number);

            if (options.get('width') === 'auto') {
                this.width = this.height;
            }

            if (values.length > 0) {
                for (i = values.length; i--;) {
                    total += values[i];
                }
            }
            this.total = total;
            this.initTarget();
            this.radius = Math.floor(Math.min(this.canvasWidth, this.canvasHeight) / 2);
        },

        getRegion: function (el, x, y) {
            var shapeid = this.target.getShapeAt(el, x, y);
            return (shapeid !== undefined && this.shapes[shapeid] !== undefined) ? this.shapes[shapeid] : undefined;
        },

        getCurrentRegionFields: function () {
            var currentRegion = this.currentRegion;
            return {
                isNull: this.values[currentRegion] === undefined,
                value: this.values[currentRegion],
                percent: this.values[currentRegion] / this.total * 100,
                color: this.options.get('sliceColors')[currentRegion % this.options.get('sliceColors').length],
                offset: currentRegion
            };
        },

        changeHighlight: function (highlight) {
            var currentRegion = this.currentRegion,
                 newslice = this.renderSlice(currentRegion, highlight),
                 shapeid = this.valueShapes[currentRegion];
            delete this.shapes[shapeid];
            this.target.replaceWithShape(shapeid, newslice);
            this.valueShapes[currentRegion] = newslice.id;
            this.shapes[newslice.id] = currentRegion;
        },

        renderSlice: function (valuenum, highlight) {
            var target = this.target,
                options = this.options,
                radius = this.radius,
                borderWidth = options.get('borderWidth'),
                offset = options.get('offset'),
                circle = 2 * Math.PI,
                values = this.values,
                total = this.total,
                next = offset ? (2*Math.PI)*(offset/360) : 0,
                start, end, i, vlen, color;

            vlen = values.length;
            for (i = 0; i < vlen; i++) {
                start = next;
                end = next;
                if (total > 0) {  // avoid divide by zero
                    end = next + (circle * (values[i] / total));
                }
                if (valuenum === i) {
                    color = options.get('sliceColors')[i % options.get('sliceColors').length];
                    if (highlight) {
                        color = this.calcHighlightColor(color, options);
                    }

                    return target.drawPieSlice(radius, radius, radius - borderWidth, start, end, undefined, color);
                }
                next = end;
            }
        },

        render: function () {
            var target = this.target,
                values = this.values,
                options = this.options,
                radius = this.radius,
                borderWidth = options.get('borderWidth'),
                shape, i;

            if (!pie._super.render.call(this)) {
                return;
            }
            if (borderWidth) {
                target.drawCircle(radius, radius, Math.floor(radius - (borderWidth / 2)),
                    options.get('borderColor'), undefined, borderWidth).append();
            }
            for (i = values.length; i--;) {
                if (values[i]) { // don't render zero values
                    shape = this.renderSlice(i).append();
                    this.valueShapes[i] = shape.id; // store just the shapeid
                    this.shapes[shape.id] = i;
                }
            }
            target.render();
        }
    });

    /**
     * Box plots
     */
    $.fn.sparkline.box = box = createClass($.fn.sparkline._base, {
        type: 'box',

        init: function (el, values, options, width, height) {
            box._super.init.call(this, el, values, options, width, height);
            this.values = $.map(values, Number);
            this.width = options.get('width') === 'auto' ? '4.0em' : width;
            this.initTarget();
            if (!this.values.length) {
                this.disabled = 1;
            }
        },

        /**
         * Simulate a single region
         */
        getRegion: function () {
            return 1;
        },

        getCurrentRegionFields: function () {
            var result = [
                { field: 'lq', value: this.quartiles[0] },
                { field: 'med', value: this.quartiles[1] },
                { field: 'uq', value: this.quartiles[2] }
            ];
            if (this.loutlier !== undefined) {
                result.push({ field: 'lo', value: this.loutlier});
            }
            if (this.routlier !== undefined) {
                result.push({ field: 'ro', value: this.routlier});
            }
            if (this.lwhisker !== undefined) {
                result.push({ field: 'lw', value: this.lwhisker});
            }
            if (this.rwhisker !== undefined) {
                result.push({ field: 'rw', value: this.rwhisker});
            }
            return result;
        },

        render: function () {
            var target = this.target,
                values = this.values,
                vlen = values.length,
                options = this.options,
                canvasWidth = this.canvasWidth,
                canvasHeight = this.canvasHeight,
                minValue = options.get('chartRangeMin') === undefined ? Math.min.apply(Math, values) : options.get('chartRangeMin'),
                maxValue = options.get('chartRangeMax') === undefined ? Math.max.apply(Math, values) : options.get('chartRangeMax'),
                canvasLeft = 0,
                lwhisker, loutlier, iqr, q1, q2, q3, rwhisker, routlier, i,
                size, unitSize;

            if (!box._super.render.call(this)) {
                return;
            }

            if (options.get('raw')) {
                if (options.get('showOutliers') && values.length > 5) {
                    loutlier = values[0];
                    lwhisker = values[1];
                    q1 = values[2];
                    q2 = values[3];
                    q3 = values[4];
                    rwhisker = values[5];
                    routlier = values[6];
                } else {
                    lwhisker = values[0];
                    q1 = values[1];
                    q2 = values[2];
                    q3 = values[3];
                    rwhisker = values[4];
                }
            } else {
                values.sort(function (a, b) { return a - b; });
                q1 = quartile(values, 1);
                q2 = quartile(values, 2);
                q3 = quartile(values, 3);
                iqr = q3 - q1;
                if (options.get('showOutliers')) {
                    lwhisker = rwhisker = undefined;
                    for (i = 0; i < vlen; i++) {
                        if (lwhisker === undefined && values[i] > q1 - (iqr * options.get('outlierIQR'))) {
                            lwhisker = values[i];
                        }
                        if (values[i] < q3 + (iqr * options.get('outlierIQR'))) {
                            rwhisker = values[i];
                        }
                    }
                    loutlier = values[0];
                    routlier = values[vlen - 1];
                } else {
                    lwhisker = values[0];
                    rwhisker = values[vlen - 1];
                }
            }
            this.quartiles = [q1, q2, q3];
            this.lwhisker = lwhisker;
            this.rwhisker = rwhisker;
            this.loutlier = loutlier;
            this.routlier = routlier;

            unitSize = canvasWidth / (maxValue - minValue + 1);
            if (options.get('showOutliers')) {
                canvasLeft = Math.ceil(options.get('spotRadius'));
                canvasWidth -= 2 * Math.ceil(options.get('spotRadius'));
                unitSize = canvasWidth / (maxValue - minValue + 1);
                if (loutlier < lwhisker) {
                    target.drawCircle((loutlier - minValue) * unitSize + canvasLeft,
                        canvasHeight / 2,
                        options.get('spotRadius'),
                        options.get('outlierLineColor'),
                        options.get('outlierFillColor')).append();
                }
                if (routlier > rwhisker) {
                    target.drawCircle((routlier - minValue) * unitSize + canvasLeft,
                        canvasHeight / 2,
                        options.get('spotRadius'),
                        options.get('outlierLineColor'),
                        options.get('outlierFillColor')).append();
                }
            }

            // box
            target.drawRect(
                Math.round((q1 - minValue) * unitSize + canvasLeft),
                Math.round(canvasHeight * 0.1),
                Math.round((q3 - q1) * unitSize),
                Math.round(canvasHeight * 0.8),
                options.get('boxLineColor'),
                options.get('boxFillColor')).append();
            // left whisker
            target.drawLine(
                Math.round((lwhisker - minValue) * unitSize + canvasLeft),
                Math.round(canvasHeight / 2),
                Math.round((q1 - minValue) * unitSize + canvasLeft),
                Math.round(canvasHeight / 2),
                options.get('lineColor')).append();
            target.drawLine(
                Math.round((lwhisker - minValue) * unitSize + canvasLeft),
                Math.round(canvasHeight / 4),
                Math.round((lwhisker - minValue) * unitSize + canvasLeft),
                Math.round(canvasHeight - canvasHeight / 4),
                options.get('whiskerColor')).append();
            // right whisker
            target.drawLine(Math.round((rwhisker - minValue) * unitSize + canvasLeft),
                Math.round(canvasHeight / 2),
                Math.round((q3 - minValue) * unitSize + canvasLeft),
                Math.round(canvasHeight / 2),
                options.get('lineColor')).append();
            target.drawLine(
                Math.round((rwhisker - minValue) * unitSize + canvasLeft),
                Math.round(canvasHeight / 4),
                Math.round((rwhisker - minValue) * unitSize + canvasLeft),
                Math.round(canvasHeight - canvasHeight / 4),
                options.get('whiskerColor')).append();
            // median line
            target.drawLine(
                Math.round((q2 - minValue) * unitSize + canvasLeft),
                Math.round(canvasHeight * 0.1),
                Math.round((q2 - minValue) * unitSize + canvasLeft),
                Math.round(canvasHeight * 0.9),
                options.get('medianColor')).append();
            if (options.get('target')) {
                size = Math.ceil(options.get('spotRadius'));
                target.drawLine(
                    Math.round((options.get('target') - minValue) * unitSize + canvasLeft),
                    Math.round((canvasHeight / 2) - size),
                    Math.round((options.get('target') - minValue) * unitSize + canvasLeft),
                    Math.round((canvasHeight / 2) + size),
                    options.get('targetColor')).append();
                target.drawLine(
                    Math.round((options.get('target') - minValue) * unitSize + canvasLeft - size),
                    Math.round(canvasHeight / 2),
                    Math.round((options.get('target') - minValue) * unitSize + canvasLeft + size),
                    Math.round(canvasHeight / 2),
                    options.get('targetColor')).append();
            }
            target.render();
        }
    });

    // Setup a very simple "virtual canvas" to make drawing the few shapes we need easier
    // This is accessible as $(foo).simpledraw()

    VShape = createClass({
        init: function (target, id, type, args) {
            this.target = target;
            this.id = id;
            this.type = type;
            this.args = args;
        },
        append: function () {
            this.target.appendShape(this);
            return this;
        }
    });

    VCanvas_base = createClass({
        _pxregex: /(\d+)(px)?\s*$/i,

        init: function (width, height, target) {
            if (!width) {
                return;
            }
            this.width = width;
            this.height = height;
            this.target = target;
            this.lastShapeId = null;
            if (target[0]) {
                target = target[0];
            }
            $.data(target, '_jqs_vcanvas', this);
        },

        drawLine: function (x1, y1, x2, y2, lineColor, lineWidth) {
            return this.drawShape([[x1, y1], [x2, y2]], lineColor, lineWidth);
        },

        drawShape: function (path, lineColor, fillColor, lineWidth) {
            return this._genShape('Shape', [path, lineColor, fillColor, lineWidth]);
        },

        drawCircle: function (x, y, radius, lineColor, fillColor, lineWidth) {
            return this._genShape('Circle', [x, y, radius, lineColor, fillColor, lineWidth]);
        },

        drawPieSlice: function (x, y, radius, startAngle, endAngle, lineColor, fillColor) {
            return this._genShape('PieSlice', [x, y, radius, startAngle, endAngle, lineColor, fillColor]);
        },

        drawRect: function (x, y, width, height, lineColor, fillColor) {
            return this._genShape('Rect', [x, y, width, height, lineColor, fillColor]);
        },

        getElement: function () {
            return this.canvas;
        },

        /**
         * Return the most recently inserted shape id
         */
        getLastShapeId: function () {
            return this.lastShapeId;
        },

        /**
         * Clear and reset the canvas
         */
        reset: function () {
            alert('reset not implemented');
        },

        _insert: function (el, target) {
            $(target).html(el);
        },

        /**
         * Calculate the pixel dimensions of the canvas
         */
        _calculatePixelDims: function (width, height, canvas) {
            // XXX This should probably be a configurable option
            var match;
            match = this._pxregex.exec(height);
            if (match) {
                this.pixelHeight = match[1];
            } else {
                this.pixelHeight = $(canvas).height();
            }
            match = this._pxregex.exec(width);
            if (match) {
                this.pixelWidth = match[1];
            } else {
                this.pixelWidth = $(canvas).width();
            }
        },

        /**
         * Generate a shape object and id for later rendering
         */
        _genShape: function (shapetype, shapeargs) {
            var id = shapeCount++;
            shapeargs.unshift(id);
            return new VShape(this, id, shapetype, shapeargs);
        },

        /**
         * Add a shape to the end of the render queue
         */
        appendShape: function (shape) {
            alert('appendShape not implemented');
        },

        /**
         * Replace one shape with another
         */
        replaceWithShape: function (shapeid, shape) {
            alert('replaceWithShape not implemented');
        },

        /**
         * Insert one shape after another in the render queue
         */
        insertAfterShape: function (shapeid, shape) {
            alert('insertAfterShape not implemented');
        },

        /**
         * Remove a shape from the queue
         */
        removeShapeId: function (shapeid) {
            alert('removeShapeId not implemented');
        },

        /**
         * Find a shape at the specified x/y co-ordinates
         */
        getShapeAt: function (el, x, y) {
            alert('getShapeAt not implemented');
        },

        /**
         * Render all queued shapes onto the canvas
         */
        render: function () {
            alert('render not implemented');
        }
    });

    VCanvas_canvas = createClass(VCanvas_base, {
        init: function (width, height, target, interact) {
            VCanvas_canvas._super.init.call(this, width, height, target);
            this.canvas = document.createElement('canvas');
            if (target[0]) {
                target = target[0];
            }
            $.data(target, '_jqs_vcanvas', this);
            $(this.canvas).css({ display: 'inline-block', width: width, height: height, verticalAlign: 'top' });
            this._insert(this.canvas, target);
            this._calculatePixelDims(width, height, this.canvas);
            this.canvas.width = this.pixelWidth;
            this.canvas.height = this.pixelHeight;
            this.interact = interact;
            this.shapes = {};
            this.shapeseq = [];
            this.currentTargetShapeId = undefined;
            $(this.canvas).css({width: this.pixelWidth, height: this.pixelHeight});
        },

        _getContext: function (lineColor, fillColor, lineWidth) {
            var context = this.canvas.getContext('2d');
            if (lineColor !== undefined) {
                context.strokeStyle = lineColor;
            }
            context.lineWidth = lineWidth === undefined ? 1 : lineWidth;
            if (fillColor !== undefined) {
                context.fillStyle = fillColor;
            }
            return context;
        },

        reset: function () {
            var context = this._getContext();
            context.clearRect(0, 0, this.pixelWidth, this.pixelHeight);
            this.shapes = {};
            this.shapeseq = [];
            this.currentTargetShapeId = undefined;
        },

        _drawShape: function (shapeid, path, lineColor, fillColor, lineWidth) {
            var context = this._getContext(lineColor, fillColor, lineWidth),
                i, plen;
            context.beginPath();
            context.moveTo(path[0][0] + 0.5, path[0][1] + 0.5);
            for (i = 1, plen = path.length; i < plen; i++) {
                context.lineTo(path[i][0] + 0.5, path[i][1] + 0.5); // the 0.5 offset gives us crisp pixel-width lines
            }
            if (lineColor !== undefined) {
                context.stroke();
            }
            if (fillColor !== undefined) {
                context.fill();
            }
            if (this.targetX !== undefined && this.targetY !== undefined &&
                context.isPointInPath(this.targetX, this.targetY)) {
                this.currentTargetShapeId = shapeid;
            }
        },

        _drawCircle: function (shapeid, x, y, radius, lineColor, fillColor, lineWidth) {
            var context = this._getContext(lineColor, fillColor, lineWidth);
            context.beginPath();
            context.arc(x, y, radius, 0, 2 * Math.PI, false);
            if (this.targetX !== undefined && this.targetY !== undefined &&
                context.isPointInPath(this.targetX, this.targetY)) {
                this.currentTargetShapeId = shapeid;
            }
            if (lineColor !== undefined) {
                context.stroke();
            }
            if (fillColor !== undefined) {
                context.fill();
            }
        },

        _drawPieSlice: function (shapeid, x, y, radius, startAngle, endAngle, lineColor, fillColor) {
            var context = this._getContext(lineColor, fillColor);
            context.beginPath();
            context.moveTo(x, y);
            context.arc(x, y, radius, startAngle, endAngle, false);
            context.lineTo(x, y);
            context.closePath();
            if (lineColor !== undefined) {
                context.stroke();
            }
            if (fillColor) {
                context.fill();
            }
            if (this.targetX !== undefined && this.targetY !== undefined &&
                context.isPointInPath(this.targetX, this.targetY)) {
                this.currentTargetShapeId = shapeid;
            }
        },

        _drawRect: function (shapeid, x, y, width, height, lineColor, fillColor) {
            return this._drawShape(shapeid, [[x, y], [x + width, y], [x + width, y + height], [x, y + height], [x, y]], lineColor, fillColor);
        },

        appendShape: function (shape) {
            this.shapes[shape.id] = shape;
            this.shapeseq.push(shape.id);
            this.lastShapeId = shape.id;
            return shape.id;
        },

        replaceWithShape: function (shapeid, shape) {
            var shapeseq = this.shapeseq,
                i;
            this.shapes[shape.id] = shape;
            for (i = shapeseq.length; i--;) {
                if (shapeseq[i] == shapeid) {
                    shapeseq[i] = shape.id;
                }
            }
            delete this.shapes[shapeid];
        },

        replaceWithShapes: function (shapeids, shapes) {
            var shapeseq = this.shapeseq,
                shapemap = {},
                sid, i, first;

            for (i = shapeids.length; i--;) {
                shapemap[shapeids[i]] = true;
            }
            for (i = shapeseq.length; i--;) {
                sid = shapeseq[i];
                if (shapemap[sid]) {
                    shapeseq.splice(i, 1);
                    delete this.shapes[sid];
                    first = i;
                }
            }
            for (i = shapes.length; i--;) {
                shapeseq.splice(first, 0, shapes[i].id);
                this.shapes[shapes[i].id] = shapes[i];
            }

        },

        insertAfterShape: function (shapeid, shape) {
            var shapeseq = this.shapeseq,
                i;
            for (i = shapeseq.length; i--;) {
                if (shapeseq[i] === shapeid) {
                    shapeseq.splice(i + 1, 0, shape.id);
                    this.shapes[shape.id] = shape;
                    return;
                }
            }
        },

        removeShapeId: function (shapeid) {
            var shapeseq = this.shapeseq,
                i;
            for (i = shapeseq.length; i--;) {
                if (shapeseq[i] === shapeid) {
                    shapeseq.splice(i, 1);
                    break;
                }
            }
            delete this.shapes[shapeid];
        },

        getShapeAt: function (el, x, y) {
            this.targetX = x;
            this.targetY = y;
            this.render();
            return this.currentTargetShapeId;
        },

        render: function () {
            var shapeseq = this.shapeseq,
                shapes = this.shapes,
                shapeCount = shapeseq.length,
                context = this._getContext(),
                shapeid, shape, i;
            context.clearRect(0, 0, this.pixelWidth, this.pixelHeight);
            for (i = 0; i < shapeCount; i++) {
                shapeid = shapeseq[i];
                shape = shapes[shapeid];
                this['_draw' + shape.type].apply(this, shape.args);
            }
            if (!this.interact) {
                // not interactive so no need to keep the shapes array
                this.shapes = {};
                this.shapeseq = [];
            }
        }

    });

    VCanvas_vml = createClass(VCanvas_base, {
        init: function (width, height, target) {
            var groupel;
            VCanvas_vml._super.init.call(this, width, height, target);
            if (target[0]) {
                target = target[0];
            }
            $.data(target, '_jqs_vcanvas', this);
            this.canvas = document.createElement('span');
            $(this.canvas).css({ display: 'inline-block', position: 'relative', overflow: 'hidden', width: width, height: height, margin: '0px', padding: '0px', verticalAlign: 'top'});
            this._insert(this.canvas, target);
            this._calculatePixelDims(width, height, this.canvas);
            this.canvas.width = this.pixelWidth;
            this.canvas.height = this.pixelHeight;
            groupel = '<v:group coordorigin="0 0" coordsize="' + this.pixelWidth + ' ' + this.pixelHeight + '"' +
                    ' style="position:absolute;top:0;left:0;width:' + this.pixelWidth + 'px;height=' + this.pixelHeight + 'px;"></v:group>';
            this.canvas.insertAdjacentHTML('beforeEnd', groupel);
            this.group = $(this.canvas).children()[0];
            this.rendered = false;
            this.prerender = '';
        },

        _drawShape: function (shapeid, path, lineColor, fillColor, lineWidth) {
            var vpath = [],
                initial, stroke, fill, closed, vel, plen, i;
            for (i = 0, plen = path.length; i < plen; i++) {
                vpath[i] = '' + (path[i][0]) + ',' + (path[i][1]);
            }
            initial = vpath.splice(0, 1);
            lineWidth = lineWidth === undefined ? 1 : lineWidth;
            stroke = lineColor === undefined ? ' stroked="false" ' : ' strokeWeight="' + lineWidth + 'px" strokeColor="' + lineColor + '" ';
            fill = fillColor === undefined ? ' filled="false"' : ' fillColor="' + fillColor + '" filled="true" ';
            closed = vpath[0] === vpath[vpath.length - 1] ? 'x ' : '';
            vel = '<v:shape coordorigin="0 0" coordsize="' + this.pixelWidth + ' ' + this.pixelHeight + '" ' +
                 ' id="jqsshape' + shapeid + '" ' +
                 stroke +
                 fill +
                ' style="position:absolute;left:0px;top:0px;height:' + this.pixelHeight + 'px;width:' + this.pixelWidth + 'px;padding:0px;margin:0px;" ' +
                ' path="m ' + initial + ' l ' + vpath.join(', ') + ' ' + closed + 'e">' +
                ' </v:shape>';
            return vel;
        },

        _drawCircle: function (shapeid, x, y, radius, lineColor, fillColor, lineWidth) {
            var stroke, fill, vel;
            x -= radius;
            y -= radius;
            stroke = lineColor === undefined ? ' stroked="false" ' : ' strokeWeight="' + lineWidth + 'px" strokeColor="' + lineColor + '" ';
            fill = fillColor === undefined ? ' filled="false"' : ' fillColor="' + fillColor + '" filled="true" ';
            vel = '<v:oval ' +
                 ' id="jqsshape' + shapeid + '" ' +
                stroke +
                fill +
                ' style="position:absolute;top:' + y + 'px; left:' + x + 'px; width:' + (radius * 2) + 'px; height:' + (radius * 2) + 'px"></v:oval>';
            return vel;

        },

        _drawPieSlice: function (shapeid, x, y, radius, startAngle, endAngle, lineColor, fillColor) {
            var vpath, startx, starty, endx, endy, stroke, fill, vel;
            if (startAngle === endAngle) {
                return '';  // VML seems to have problem when start angle equals end angle.
            }
            if ((endAngle - startAngle) === (2 * Math.PI)) {
                startAngle = 0.0;  // VML seems to have a problem when drawing a full circle that doesn't start 0
                endAngle = (2 * Math.PI);
            }

            startx = x + Math.round(Math.cos(startAngle) * radius);
            starty = y + Math.round(Math.sin(startAngle) * radius);
            endx = x + Math.round(Math.cos(endAngle) * radius);
            endy = y + Math.round(Math.sin(endAngle) * radius);

            if (startx === endx && starty === endy) {
                if ((endAngle - startAngle) < Math.PI) {
                    // Prevent very small slices from being mistaken as a whole pie
                    return '';
                }
                // essentially going to be the entire circle, so ignore startAngle
                startx = endx = x + radius;
                starty = endy = y;
            }

            if (startx === endx && starty === endy && (endAngle - startAngle) < Math.PI) {
                return '';
            }

            vpath = [x - radius, y - radius, x + radius, y + radius, startx, starty, endx, endy];
            stroke = lineColor === undefined ? ' stroked="false" ' : ' strokeWeight="1px" strokeColor="' + lineColor + '" ';
            fill = fillColor === undefined ? ' filled="false"' : ' fillColor="' + fillColor + '" filled="true" ';
            vel = '<v:shape coordorigin="0 0" coordsize="' + this.pixelWidth + ' ' + this.pixelHeight + '" ' +
                 ' id="jqsshape' + shapeid + '" ' +
                 stroke +
                 fill +
                ' style="position:absolute;left:0px;top:0px;height:' + this.pixelHeight + 'px;width:' + this.pixelWidth + 'px;padding:0px;margin:0px;" ' +
                ' path="m ' + x + ',' + y + ' wa ' + vpath.join(', ') + ' x e">' +
                ' </v:shape>';
            return vel;
        },

        _drawRect: function (shapeid, x, y, width, height, lineColor, fillColor) {
            return this._drawShape(shapeid, [[x, y], [x, y + height], [x + width, y + height], [x + width, y], [x, y]], lineColor, fillColor);
        },

        reset: function () {
            this.group.innerHTML = '';
        },

        appendShape: function (shape) {
            var vel = this['_draw' + shape.type].apply(this, shape.args);
            if (this.rendered) {
                this.group.insertAdjacentHTML('beforeEnd', vel);
            } else {
                this.prerender += vel;
            }
            this.lastShapeId = shape.id;
            return shape.id;
        },

        replaceWithShape: function (shapeid, shape) {
            var existing = $('#jqsshape' + shapeid),
                vel = this['_draw' + shape.type].apply(this, shape.args);
            existing[0].outerHTML = vel;
        },

        replaceWithShapes: function (shapeids, shapes) {
            // replace the first shapeid with all the new shapes then toast the remaining old shapes
            var existing = $('#jqsshape' + shapeids[0]),
                replace = '',
                slen = shapes.length,
                i;
            for (i = 0; i < slen; i++) {
                replace += this['_draw' + shapes[i].type].apply(this, shapes[i].args);
            }
            existing[0].outerHTML = replace;
            for (i = 1; i < shapeids.length; i++) {
                $('#jqsshape' + shapeids[i]).remove();
            }
        },

        insertAfterShape: function (shapeid, shape) {
            var existing = $('#jqsshape' + shapeid),
                 vel = this['_draw' + shape.type].apply(this, shape.args);
            existing[0].insertAdjacentHTML('afterEnd', vel);
        },

        removeShapeId: function (shapeid) {
            var existing = $('#jqsshape' + shapeid);
            this.group.removeChild(existing[0]);
        },

        getShapeAt: function (el, x, y) {
            var shapeid = el.id.substr(8);
            return shapeid;
        },

        render: function () {
            if (!this.rendered) {
                // batch the intial render into a single repaint
                this.group.innerHTML = this.prerender;
                this.rendered = true;
            }
        }
    });

}))}(document, Math));

},{}]},{},["facility_management"])
//# sourceMappingURL=data:application/json;charset:utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9mYWN0b3ItYnVuZGxlL25vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJrYWxpdGUvY29udHJvbF9wYW5lbC9zdGF0aWMvanMvY29udHJvbF9wYW5lbC9idW5kbGVfbW9kdWxlcy9mYWNpbGl0eV9tYW5hZ2VtZW50LmpzIiwibm9kZV9tb2R1bGVzL2pxdWVyeS1zcGFya2xpbmUvZGlzdC9qcXVlcnkuc3BhcmtsaW5lLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzNNQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsImZpbGUiOiJnZW5lcmF0ZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsiKGZ1bmN0aW9uIGUodCxuLHIpe2Z1bmN0aW9uIHMobyx1KXtpZighbltvXSl7aWYoIXRbb10pe3ZhciBhPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7aWYoIXUmJmEpcmV0dXJuIGEobywhMCk7aWYoaSlyZXR1cm4gaShvLCEwKTt2YXIgZj1uZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBtb2R1bGUgJ1wiK28rXCInXCIpO3Rocm93IGYuY29kZT1cIk1PRFVMRV9OT1RfRk9VTkRcIixmfXZhciBsPW5bb109e2V4cG9ydHM6e319O3Rbb11bMF0uY2FsbChsLmV4cG9ydHMsZnVuY3Rpb24oZSl7dmFyIG49dFtvXVsxXVtlXTtyZXR1cm4gcyhuP246ZSl9LGwsbC5leHBvcnRzLGUsdCxuLHIpfXJldHVybiBuW29dLmV4cG9ydHN9dmFyIGk9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtmb3IodmFyIG89MDtvPHIubGVuZ3RoO28rKylzKHJbb10pO3JldHVybiBzfSkiLCJ2YXIgJCA9IHJlcXVpcmUoXCJiYXNlL2pRdWVyeVwiKTtcbnZhciBfID0gcmVxdWlyZShcInVuZGVyc2NvcmVcIik7XG52YXIgZ2V0X3BhcmFtcyA9IHJlcXVpcmUoXCJ1dGlscy9nZXRfcGFyYW1zXCIpO1xudmFyIGFwaSA9IHJlcXVpcmUoXCJ1dGlscy9hcGlcIik7XG5yZXF1aXJlKFwianF1ZXJ5LXNwYXJrbGluZVwiKTtcblxuZnVuY3Rpb24gZ2V0U2VsZWN0ZWRJdGVtcyhzZWxlY3QpIHtcbiAgICAvLyBSZXRyaWV2ZSBhIGxpc3Qgb2Ygc2VsZWN0ZWQgdXNlcnMuXG4gICAgLy8gdmFyIGl0ZW1zID0gJChzZWxlY3QpLmZpbmQoXCJ0ci5zZWxlY3RlZFwiKS5tYXAoZnVuY3Rpb24gKCkge1xuICAgIC8vICAgICByZXR1cm4gJCh0aGlzKS5hdHRyKFwidmFsdWVcIik7XG4gICAgLy8gfSkuZ2V0KCk7XG4gICAgdmFyIGl0ZW1zID0gJChzZWxlY3QpLmZpbmQoXCJ0ci5zZWxlY3RhYmxlLnNlbGVjdGVkXCIpLm1hcChmdW5jdGlvbiAoKSB7XG4gICAgICAgIHJldHVybiAkKHRoaXMpLmF0dHIoXCJ2YWx1ZVwiKTtcbiAgICB9KS5nZXQoKTtcbiAgICByZXR1cm4gaXRlbXM7XG59XG5cbmZ1bmN0aW9uIHNldEFjdGlvbkJ1dHRvblN0YXRlKHNlbGVjdCkge1xuICAgIC8vIGFyZ3VtZW50IHRvIGFsbG93IGNvbmRpdGlvbmFsIHNlbGVjdGlvbiBvZiBhY3Rpb24gYnV0dG9ucy5cbiAgICBpZigkKHNlbGVjdCkuZmluZChcInRyLnNlbGVjdGFibGUuc2VsZWN0ZWRcIikubGVuZ3RoKSB7XG5cbiAgICAgICAgJCgnYnV0dG9uW3ZhbHVlPVwiJytzZWxlY3QrJ1wiXScpLnJlbW92ZUF0dHIoXCJkaXNhYmxlZFwiKS5yZW1vdmVBdHRyKFwidGl0bGVcIik7XG4gICAgfSBlbHNlIHtcbiAgICAgICAgJCgnYnV0dG9uW3ZhbHVlPVwiJytzZWxlY3QrJ1wiXScpLmF0dHIoXCJkaXNhYmxlZFwiLCBcImRpc2FibGVkXCIpO1xuICAgICAgICAkKCdidXR0b25bdmFsdWU9XCInK3NlbGVjdCsnXCJdJykuYXR0cihcInRpdGxlXCIsIFwiWW91IG11c3Qgc2VsZWN0IG9uZSBvciBtb3JlIHJvd3MgZnJvbSB0aGUgdGFibGUgYmVsb3cgYmVmb3JlIHRha2luZyB0aGlzIGFjdGlvbi5cIik7XG4gICAgfVxufVxuXG5mdW5jdGlvbiBzZXRTZWxlY3RBbGxTdGF0ZShzZWxlY3RBbGxJZCkge1xuICAgIHZhciBhbGxDaGVja2VkID0gdHJ1ZTtcbiAgICAvLyBJZiBhbGwgY2hlY2tib3hlcyBzZWxlY3RlZCwgc2V0IHRvIGNoZWNrZWQsIGlmIG5vdCwgc2V0IHRvIHVuY2hlY2tlZFxuICAgIHZhciBib3hlcyA9ICQoc2VsZWN0QWxsSWQpLmZpbmQoJ3Rib2R5JykuZmluZCgnaW5wdXRbdHlwZT1cImNoZWNrYm94XCJdJyk7XG4gICAgXy5lYWNoKGJveGVzLCBmdW5jdGlvbihib3gpIHtcbiAgICAgICAgaWYgKCQoYm94KS5wcm9wKCdjaGVja2VkJykgPT09IGZhbHNlKXtcbiAgICAgICAgICAgIGFsbENoZWNrZWQgPSBmYWxzZTtcbiAgICAgICAgfVxuICAgIH0pO1xuICAgIHZhciBzZWxlY3RBbGxCb3ggPSAkKHNlbGVjdEFsbElkKS5maW5kKCd0aGVhZCcpLmZpbmQoJy5zZWxlY3QtYWxsJyk7XG4gICAgJChzZWxlY3RBbGxCb3gpLnByb3AoXCJjaGVja2VkXCIsIGFsbENoZWNrZWQpO1xufVxuXG4kKGZ1bmN0aW9uKCkge1xuICAgIC8vIG9uIGxvYWQgYWRkIHRoZSBzYW1lIHRpdGxlIHRhZyB0byBhbGwgZGlzYWJsZWQgYnV0dG9ucyBcbiAgICAkKCdidXR0b25bZGlzYWJsZWQ9XCJkaXNhYmxlZFwiXScpLmF0dHIoXCJ0aXRsZVwiLCBcIllvdSBtdXN0IHNlbGVjdCBvbmUgb3IgbW9yZSByb3dzIGZyb20gdGhlIHRhYmxlIGJlbG93IGJlZm9yZSB0YWtpbmcgdGhpcyBhY3Rpb24uXCIpO1xuXG4gICAgJChcIiNncm91cFwiKS5jaGFuZ2UoZnVuY3Rpb24oKXtcbiAgICAgICAgLy8gQ2hhbmdlIHRoZSBVUkwgdG8gdGhlIHNlbGVjdGVkIGdyb3VwLlxuICAgICAgICBHZXRQYXJhbXNbXCJncm91cF9pZFwiXSA9ICQoXCIjZ3JvdXAgb3B0aW9uOnNlbGVjdGVkXCIpLnZhbCgpO1xuICAgICAgICB3aW5kb3cubG9jYXRpb24uaHJlZiA9IGdldF9wYXJhbXMuc2V0R2V0UGFyYW1EaWN0KHdpbmRvdy5sb2NhdGlvbi5ocmVmLCBHZXRQYXJhbXMpO1xuICAgIH0pO1xuXG4gICAgJChcIi5hbGxcIikuY2xpY2soZnVuY3Rpb24oZXZlbnQpe1xuICAgICAgICAvLyBTZWxlY3QgYWxsIGNoZWNrYm94ZXMgd2l0aGluIGxvY2FsIHRhYmxlXG4gICAgICAgIHZhciBlbCA9ICQoZXZlbnQudGFyZ2V0LnZhbHVlKTtcbiAgICAgICAgZWwuZmluZChcInRoZWFkXCIpLmZpbmQoXCJpbnB1dC5zZWxlY3QtYWxsXCIpLnByb3AoXCJjaGVja2VkXCIsIHRydWUpO1xuICAgICAgICBlbC5maW5kKFwidGJvZHlcIikuZmluZChcInRyXCIpLm5vdChcIi5zZWxlY3RlZFwiKS5tb3VzZWRvd24oKTtcbiAgICB9KTtcblxuICAgICQoXCIubm9uZVwiKS5jbGljayhmdW5jdGlvbihldmVudCl7XG4gICAgICAgIC8vIFVuc2VsZWN0IGFsbCBjaGVja2JveGVzIHdpdGhpbiBsb2NhbCB0YWJsZVxuICAgICAgICB2YXIgZWwgPSAkKGV2ZW50LnRhcmdldC52YWx1ZSk7XG4gICAgICAgIGVsLmZpbmQoXCJ0aGVhZFwiKS5maW5kKFwiaW5wdXQuc2VsZWN0LWFsbFwiKS5wcm9wKFwiY2hlY2tlZFwiLCBmYWxzZSk7XG4gICAgICAgIGVsLmZpbmQoXCJ0Ym9keVwiKS5maW5kKFwidHIuc2VsZWN0ZWRcIikubW91c2Vkb3duKCk7XG4gICAgfSk7XG5cbiAgICAkKFwiLm1vdmVncm91cFwiKS5jbGljayhmdW5jdGlvbihldmVudCkge1xuICAgICAgICAvLyBNb3ZlIHVzZXJzIHRvIHRoZSBzZWxlY3RlZCBncm91cFxuICAgICAgICB2YXIgdXNlcnMgPSBnZXRTZWxlY3RlZEl0ZW1zKHRoaXMudmFsdWUpO1xuICAgICAgICB2YXIgZ3JvdXAgPSAkKHRoaXMudmFsdWUpLmZpbmQoJ3NlbGVjdFt2YWx1ZT1cIicrdGhpcy52YWx1ZSsnXCJdIG9wdGlvbjpzZWxlY3RlZCcpLnZhbCgpO1xuXG4gICAgICAgIGlmIChncm91cD09PVwiLS0tLVwiKSB7XG4gICAgICAgICAgICBhbGVydChnZXR0ZXh0KFwiUGxlYXNlIGNob29zZSBhIGdyb3VwIHRvIG1vdmUgdXNlcnMgdG8uXCIpKTtcbiAgICAgICAgfSBlbHNlIGlmICh1c2Vycy5sZW5ndGg9PT0wKSB7XG4gICAgICAgICAgICBhbGVydChnZXR0ZXh0KFwiUGxlYXNlIHNlbGVjdCB1c2VycyBmaXJzdC5cIikpO1xuICAgICAgICB9IGVsc2UgaWYoIWNvbmZpcm0oZ2V0dGV4dChcIllvdSBhcmUgYWJvdXQgdG8gbW92ZSBzZWxlY3RlZCB1c2VycyB0byBhbm90aGVyIGdyb3VwLlwiKSkpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGFwaS5kb1JlcXVlc3Qod2luZG93LlVybHMubW92ZV90b19ncm91cCgpLCB7dXNlcnM6IHVzZXJzLCBncm91cDogZ3JvdXB9KVxuICAgICAgICAgICAgICAgIC5zdWNjZXNzKGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgICAgICBsb2NhdGlvbi5yZWxvYWQoKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH0pO1xuXG4gICAgLy8gQ29kZSBmb3IgY2hlY2tib3hlc1xuICAgICQoXCIuc2VsZWN0LWFsbFwiKS5jbGljayhmdW5jdGlvbihldmVudCl7XG4gICAgICAgIC8vIFNlbGVjdCBhbGwgY2hlY2tib3hlcyB3aXRoaW4gbG9jYWwgdGFibGVcbiAgICAgICAgdmFyIGVsID0gJChldmVudC50YXJnZXQudmFsdWUpO1xuICAgICAgICBpZighZXZlbnQudGFyZ2V0LmNoZWNrZWQpe1xuICAgICAgICAgICAgZWwuZmluZChcInRib2R5XCIpLmZpbmQoXCJpbnB1dDpjaGVja2VkXCIpLm1vdXNlZG93bigpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgZWwuZmluZChcInRib2R5XCIpLmZpbmQoXCJpbnB1dDpjaGVja2JveDpub3QoOmNoZWNrZWQpXCIpLm1vdXNlZG93bigpO1xuICAgICAgICB9XG4gICAgfSk7XG5cbiAgICAkKFwiaW5wdXQ6Y2hlY2tib3hcIikuY2xpY2soZnVuY3Rpb24oZXZlbnQpe1xuICAgICAgICB2YXIgZWwgPSBldmVudC50YXJnZXQudmFsdWU7XG4gICAgICAgIC8vIE9ubHkgc2V0IGFjdGlvbiBidXR0b24gc3RhdGUgb24gcmVsYXRlZCBhY3Rpb24gYnV0dG9ucy5cbiAgICAgICAgc2V0QWN0aW9uQnV0dG9uU3RhdGUoZWwpO1xuICAgIH0pO1xuXG4gICAgJChcImlucHV0OmNoZWNrYm94XCIpLm1vdXNldXAoZnVuY3Rpb24oZXZlbnQpe1xuICAgICAgICB2YXIgZWwgPSBldmVudC50YXJnZXQudmFsdWU7XG4gICAgICAgIC8vIFNldCBzdGF0ZSBvZiBzZWxlY3QgYWxsIGNoZWNrYm94IGJhc2VkIG9uIGNsaWNrcyBcbiAgICAgICAgc2V0U2VsZWN0QWxsU3RhdGUoZWwpO1xuICAgIH0pO1xuXG4gICAgJChcIi5kZWxldGVcIikuY2xpY2soZnVuY3Rpb24oZXZlbnQpIHtcbiAgICAgICAgLy8gRGVsZXRlIHRoZSBzZWxlY3RlZCB1c2Vyc1xuICAgICAgICB2YXIgdXNlcnMgPSBnZXRTZWxlY3RlZEl0ZW1zKHRoaXMudmFsdWUpO1xuXG4gICAgICAgIGlmICh1c2Vycy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgIGFsZXJ0KGdldHRleHQoXCJQbGVhc2Ugc2VsZWN0IHVzZXJzIGZpcnN0LlwiKSk7XG4gICAgICAgIH0gZWxzZSBpZiAoIWNvbmZpcm0oZ2V0dGV4dChcIllvdSBhcmUgYWJvdXQgdG8gZGVsZXRlIHNlbGVjdGVkIHVzZXJzLCB0aGV5IHdpbGwgYmUgcGVybWFuZW50bHkgZGVsZXRlZC5cIikpKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBhcGkuZG9SZXF1ZXN0KHdpbmRvdy5VcmxzLmRlbGV0ZV91c2VycygpLCB7dXNlcnM6IHVzZXJzfSlcbiAgICAgICAgICAgICAgICAuc3VjY2VzcyhmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICAgICAgbG9jYXRpb24ucmVsb2FkKCk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9KTtcblxuICAgICQoXCIuZGVsZXRlLWdyb3VwXCIpLmNsaWNrKGZ1bmN0aW9uKGV2ZW50KSB7XG4gICAgICAgIC8vIERlbGV0ZSB0aGUgc2VsZWN0ZWQgdXNlcnNcbiAgICAgICAgdmFyIGdyb3VwcyA9IGdldFNlbGVjdGVkSXRlbXModGhpcy52YWx1ZSk7XG5cbiAgICAgICAgaWYgKGdyb3Vwcy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgIGFsZXJ0KGdldHRleHQoXCJQbGVhc2Ugc2VsZWN0IGdyb3VwcyBmaXJzdC5cIikpO1xuICAgICAgICB9IGVsc2UgaWYgKCFjb25maXJtKGdldHRleHQoXCJZb3UgYXJlIGFib3V0IHRvIHBlcm1hbmVudGx5IGRlbGV0ZSB0aGUgc2VsZWN0ZWQgZ3JvdXAocykuIE5vdGUgdGhhdCBhbnkgbGVhcm5lcnMgY3VycmVudGx5IGluIHRoaXMgZ3JvdXAgd2lsbCBub3cgYmUgY2hhcmFjdGVyaXplZCBhcyAnVW5ncm91cGVkJyBidXQgdGhlaXIgcHJvZmlsZXMgd2lsbCBub3QgYmUgZGVsZXRlZC5cIikpKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBhcGkuZG9SZXF1ZXN0KHdpbmRvdy5VcmxzLmdyb3VwX2RlbGV0ZSgpLCB7Z3JvdXBzOiBncm91cHN9KVxuICAgICAgICAgICAgICAgIC5zdWNjZXNzKGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgICAgICBsb2NhdGlvbi5yZWxvYWQoKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH0pO1xuXG4gICAgLy8gV2hlbiBtb3VzZSBpcyBwcmVzc2VkIG92ZXIgYSByb3cgaW4gdGhlIHRhYmxlIGJvZHkgKG5vdCB0aGUgaGVhZGVyIHJvdyksIG1ha2UgbW91c2VvdmVycyBzZWxlY3QuXG4gICAgJChcIi5zZWxlY3RhYmxlLXRhYmxlXCIpLmZpbmQoXCJ0Ym9keVwiKS5maW5kKFwidHIuc2VsZWN0YWJsZVwiKS5tb3VzZWRvd24oZnVuY3Rpb24oKXtcbiAgICAgICAgJCh0aGlzKS50b2dnbGVDbGFzcyhcInNlbGVjdGVkXCIpO1xuICAgICAgICB2YXIgY2hlY2tib3ggPSAkKHRoaXMpLmZpbmQoXCJpbnB1dFwiKTtcbiAgICAgICAgaWYgKGNoZWNrYm94LnByb3AoXCJjaGVja2VkXCIpKSB7XG4gICAgICAgICAgICBjaGVja2JveC5wcm9wKFwiY2hlY2tlZFwiLCBmYWxzZSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjaGVja2JveC5wcm9wKFwiY2hlY2tlZFwiLCB0cnVlKTtcbiAgICAgICAgfVxuICAgICAgICB2YXIgZWwgPSBcIiNcIiArICQodGhpcykuYXR0cihcInR5cGVcIik7XG4gICAgICAgIHNldEFjdGlvbkJ1dHRvblN0YXRlKGVsKTtcbiAgICAgICAgc2V0U2VsZWN0QWxsU3RhdGUoZWwpO1xuICAgICAgICBcbiAgICAgICAgLy8gKEN1cnJlbnRseSBkaXNhYmxlZCBkdWUgdG8gYSBiaXQgb2YgYnVnZ2luZXNzIHdpdGggbm90IHJlZ2lzdGVyaW5nIHRoZSBtb3VzZXVwIGV2ZW50LCB3aGljaCBjcmVhdGVkIGEgd2VpcmQgZmxpY2tlcmluZyBlZmZlY3QuIEFsc28sIHRoaXMgd29uJ3Qgd29yayBvbiB0YWJsZXRzLCBzaW5jZSBkcmFnIGlzIHNjcm9sbC4pIFxuICAgICAgICAvLyBUaGlzIGNvZGUgaXMgdG8gYWxsb3cgcm93cyBvZiBhIHNlbGVjdGFibGUtdGFibGUgY2xhc3MgdGFibGUgdG8gYmUgY2xpY2tlZCBmb3Igc2VsZWN0aW9uLFxuICAgICAgICAvLyBhbmQgZHJhZ2dlZCBhY3Jvc3Mgd2l0aCBtb3VzZWRvd24gZm9yIHNlbGVjdGlvbi5cbiAgICAgICAgLy8gJChcIi5zZWxlY3RhYmxlLXRhYmxlXCIpLmZpbmQoXCJ0Ym9keVwiKS5maW5kKFwidHIuc2VsZWN0YWJsZVwiKS5tb3VzZW92ZXIoZnVuY3Rpb24oKXtcbiAgICAgICAgLy8gICAgICQodGhpcykudG9nZ2xlQ2xhc3MoXCJzZWxlY3RlZFwiKTtcbiAgICAgICAgLy8gICAgIHZhciBjaGVja2JveCA9ICQodGhpcykuZmluZChcImlucHV0XCIpO1xuICAgICAgICAvLyAgICAgaWYgKGNoZWNrYm94LnByb3AoXCJjaGVja2VkXCIpKSB7XG4gICAgICAgIC8vICAgICAgICAgY2hlY2tib3gucHJvcChcImNoZWNrZWRcIiwgZmFsc2UpO1xuICAgICAgICAvLyAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gICAgICAgICBjaGVja2JveC5wcm9wKFwiY2hlY2tlZFwiLCB0cnVlKTtcbiAgICAgICAgLy8gICAgIH1cbiAgICAgICAgLy8gICAgIHNldEFjdGlvbkJ1dHRvblN0YXRlKFwiI1wiICsgJCh0aGlzKS5hdHRyKFwidHlwZVwiKSk7XG4gICAgICAgIC8vIH0pO1xuICAgIH0pO1xuXG4gICAgLy8gKEN1cnJlbnRseSBkaXNhYmxlZCBmb3IgdGhlIHNhbWUgcmVhc29ucyBhcyBhYm92ZSlcbiAgICAvLyBVbmJpbmQgdGhlIG1vdXNlb3ZlciBzZWxlY3Rpb24gb25jZSB0aGUgYnV0dG9uIGhhcyBiZWVuIHJlbGVhc2VkLlxuICAgIC8vICQoXCIuc2VsZWN0YWJsZS10YWJsZVwiKS5maW5kKFwidGJvZHlcIikuZmluZChcInRyLnNlbGVjdGFibGVcIikubW91c2V1cChmdW5jdGlvbigpe1xuICAgIC8vICAgICAkKFwiLnNlbGVjdGFibGUtdGFibGVcIikuZmluZChcInRib2R5XCIpLmZpbmQoXCJ0ci5zZWxlY3RhYmxlXCIpLnVuYmluZChcIm1vdXNlb3ZlclwiKTtcbiAgICAvLyB9KTtcblxuICAgIC8vIElmIHRoZSBtb3VzZSBtb3ZlcyBvdXQgb2YgdGhlIHRhYmxlIHdpdGggdGhlIGJ1dHRvbiBzdGlsbCBkZXByZXNzZWQsIHRoZSBhYm92ZSB1bmJpbmQgd2lsbCBub3QgZmlyZS5cbiAgICAvLyBVbmJpbmQgdGhlIG1vdXNlb3ZlciBvbmNlIHRoZSBtb3VzZSBsZWF2ZXMgdGhlIHRhYmxlLlxuICAgIC8vIFRoaXMgbWVhbnMgdGhhdCBtb3ZpbmcgdGhlIG1vdXNlIG91dCBhbmQgdGhlbiBiYWNrIGluIHdpdGggdGhlIGJ1dHRvbiBkZXByZXNzZWQgd2lsbCBub3Qgc2VsZWN0LlxuXG4gICAgLy8gJChcIi5zZWxlY3RhYmxlLXRhYmxlXCIpLm1vdXNlbGVhdmUoZnVuY3Rpb24oKXtcbiAgICAvLyAgICAgJChcIi5zZWxlY3RhYmxlLXRhYmxlXCIpLmZpbmQoXCJ0Ym9keVwiKS5maW5kKFwidHIuc2VsZWN0YWJsZVwiKS51bmJpbmQoXCJtb3VzZW92ZXJcIik7XG4gICAgLy8gfSlcblxuXG4gICAgLy8gUHJldmVudCBwcm9wYWdhdGlvbiBvZiBjbGljayBldmVudHMgb24gbGlua3MgdG8gbGltaXQgY29uZnVzaW5nIGJlaGF2aW91clxuICAgIC8vIG9mIHJvd3MgYmVpbmcgc2VsZWN0ZWQgd2hlbiBsaW5rcyBjbGlja2VkLlxuICAgICQoXCIuc2VsZWN0YWJsZS10YWJsZVwiKS5maW5kKFwiYVwiKS5tb3VzZWRvd24oZnVuY3Rpb24oZXZlbnQpIHtcbiAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9KTtcblxuICAgICQoXCIuc2VsZWN0YWJsZS10YWJsZVwiKS5maW5kKFwidGJvZHlcIikuZmluZChcImlucHV0XCIpLm1vdXNlZG93bihmdW5jdGlvbihldmVudCl7XG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgfSk7XG5cbiAgICAkKFwiLnNlbGVjdGFibGUtdGFibGVcIikuZmluZChcInRib2R5XCIpLmZpbmQoXCJpbnB1dFwiKS5jbGljayhmdW5jdGlvbihldmVudCl7XG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9KTtcblxuICAgICQoJy5zcGFya2xpbmVzJykuc3BhcmtsaW5lKCdodG1sJywgeyBlbmFibGVUYWdPcHRpb25zOiB0cnVlLCBkaXNhYmxlSW50ZXJhY3Rpb246IHRydWUgfSk7XG59KTtcblxubW9kdWxlLmV4cG9ydHMgPSB7XG4gICAgJDogJFxufTsiLCIvKipcbipcbioganF1ZXJ5LnNwYXJrbGluZS5qc1xuKlxuKiB2Mi4xLjNcbiogKGMpIFNwbHVuaywgSW5jXG4qIENvbnRhY3Q6IEdhcmV0aCBXYXR0cyAoZ2FyZXRoQHNwbHVuay5jb20pXG4qIGh0dHA6Ly9vbW5pcG90ZW50Lm5ldC9qcXVlcnkuc3BhcmtsaW5lL1xuKlxuKiBHZW5lcmF0ZXMgaW5saW5lIHNwYXJrbGluZSBjaGFydHMgZnJvbSBkYXRhIHN1cHBsaWVkIGVpdGhlciB0byB0aGUgbWV0aG9kXG4qIG9yIGlubGluZSBpbiBIVE1MXG4qXG4qIENvbXBhdGlibGUgd2l0aCBJbnRlcm5ldCBFeHBsb3JlciA2LjArIGFuZCBtb2Rlcm4gYnJvd3NlcnMgZXF1aXBwZWQgd2l0aCB0aGUgY2FudmFzIHRhZ1xuKiAoRmlyZWZveCAyLjArLCBTYWZhcmksIE9wZXJhLCBldGMpXG4qXG4qIExpY2Vuc2U6IE5ldyBCU0QgTGljZW5zZVxuKlxuKiBDb3B5cmlnaHQgKGMpIDIwMTIsIFNwbHVuayBJbmMuXG4qIEFsbCByaWdodHMgcmVzZXJ2ZWQuXG4qXG4qIFJlZGlzdHJpYnV0aW9uIGFuZCB1c2UgaW4gc291cmNlIGFuZCBiaW5hcnkgZm9ybXMsIHdpdGggb3Igd2l0aG91dCBtb2RpZmljYXRpb24sXG4qIGFyZSBwZXJtaXR0ZWQgcHJvdmlkZWQgdGhhdCB0aGUgZm9sbG93aW5nIGNvbmRpdGlvbnMgYXJlIG1ldDpcbipcbiogICAgICogUmVkaXN0cmlidXRpb25zIG9mIHNvdXJjZSBjb2RlIG11c3QgcmV0YWluIHRoZSBhYm92ZSBjb3B5cmlnaHQgbm90aWNlLFxuKiAgICAgICB0aGlzIGxpc3Qgb2YgY29uZGl0aW9ucyBhbmQgdGhlIGZvbGxvd2luZyBkaXNjbGFpbWVyLlxuKiAgICAgKiBSZWRpc3RyaWJ1dGlvbnMgaW4gYmluYXJ5IGZvcm0gbXVzdCByZXByb2R1Y2UgdGhlIGFib3ZlIGNvcHlyaWdodCBub3RpY2UsXG4qICAgICAgIHRoaXMgbGlzdCBvZiBjb25kaXRpb25zIGFuZCB0aGUgZm9sbG93aW5nIGRpc2NsYWltZXIgaW4gdGhlIGRvY3VtZW50YXRpb25cbiogICAgICAgYW5kL29yIG90aGVyIG1hdGVyaWFscyBwcm92aWRlZCB3aXRoIHRoZSBkaXN0cmlidXRpb24uXG4qICAgICAqIE5laXRoZXIgdGhlIG5hbWUgb2YgU3BsdW5rIEluYyBub3IgdGhlIG5hbWVzIG9mIGl0cyBjb250cmlidXRvcnMgbWF5XG4qICAgICAgIGJlIHVzZWQgdG8gZW5kb3JzZSBvciBwcm9tb3RlIHByb2R1Y3RzIGRlcml2ZWQgZnJvbSB0aGlzIHNvZnR3YXJlIHdpdGhvdXRcbiogICAgICAgc3BlY2lmaWMgcHJpb3Igd3JpdHRlbiBwZXJtaXNzaW9uLlxuKlxuKiBUSElTIFNPRlRXQVJFIElTIFBST1ZJREVEIEJZIFRIRSBDT1BZUklHSFQgSE9MREVSUyBBTkQgQ09OVFJJQlVUT1JTIFwiQVMgSVNcIiBBTkQgQU5ZXG4qIEVYUFJFU1MgT1IgSU1QTElFRCBXQVJSQU5USUVTLCBJTkNMVURJTkcsIEJVVCBOT1QgTElNSVRFRCBUTywgVEhFIElNUExJRUQgV0FSUkFOVElFU1xuKiBPRiBNRVJDSEFOVEFCSUxJVFkgQU5EIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFIEFSRSBESVNDTEFJTUVELiBJTiBOTyBFVkVOVFxuKiBTSEFMTCBUSEUgQ09QWVJJR0hUIE9XTkVSIE9SIENPTlRSSUJVVE9SUyBCRSBMSUFCTEUgRk9SIEFOWSBESVJFQ1QsIElORElSRUNULCBJTkNJREVOVEFMLFxuKiBTUEVDSUFMLCBFWEVNUExBUlksIE9SIENPTlNFUVVFTlRJQUwgREFNQUdFUyAoSU5DTFVESU5HLCBCVVQgTk9UIExJTUlURUQgVE8sIFBST0NVUkVNRU5UXG4qIE9GIFNVQlNUSVRVVEUgR09PRFMgT1IgU0VSVklDRVM7IExPU1MgT0YgVVNFLCBEQVRBLCBPUiBQUk9GSVRTOyBPUiBCVVNJTkVTUyBJTlRFUlJVUFRJT04pXG4qIEhPV0VWRVIgQ0FVU0VEIEFORCBPTiBBTlkgVEhFT1JZIE9GIExJQUJJTElUWSwgV0hFVEhFUiBJTiBDT05UUkFDVCwgU1RSSUNUIExJQUJJTElUWSxcbiogT1IgVE9SVCAoSU5DTFVESU5HIE5FR0xJR0VOQ0UgT1IgT1RIRVJXSVNFKSBBUklTSU5HIElOIEFOWSBXQVkgT1VUIE9GIFRIRSBVU0UgT0YgVEhJU1xuKiBTT0ZUV0FSRSwgRVZFTiBJRiBBRFZJU0VEIE9GIFRIRSBQT1NTSUJJTElUWSBPRiBTVUNIIERBTUFHRS5cbipcbipcbiogVXNhZ2U6XG4qICAkKHNlbGVjdG9yKS5zcGFya2xpbmUodmFsdWVzLCBvcHRpb25zKVxuKlxuKiBJZiB2YWx1ZXMgaXMgdW5kZWZpbmVkIG9yIHNldCB0byAnaHRtbCcgdGhlbiB0aGUgZGF0YSB2YWx1ZXMgYXJlIHJlYWQgZnJvbSB0aGUgc3BlY2lmaWVkIHRhZzpcbiogICA8cD5TcGFya2xpbmU6IDxzcGFuIGNsYXNzPVwic3BhcmtsaW5lXCI+MSw0LDYsNiw4LDUsMyw1PC9zcGFuPjwvcD5cbiogICAkKCcuc3BhcmtsaW5lJykuc3BhcmtsaW5lKCk7XG4qIFRoZXJlIG11c3QgYmUgbm8gc3BhY2VzIGluIHRoZSBlbmNsb3NlZCBkYXRhIHNldFxuKlxuKiBPdGhlcndpc2UgdmFsdWVzIG11c3QgYmUgYW4gYXJyYXkgb2YgbnVtYmVycyBvciBudWxsIHZhbHVlc1xuKiAgICA8cD5TcGFya2xpbmU6IDxzcGFuIGlkPVwic3BhcmtsaW5lMVwiPlRoaXMgdGV4dCByZXBsYWNlZCBpZiB0aGUgYnJvd3NlciBpcyBjb21wYXRpYmxlPC9zcGFuPjwvcD5cbiogICAgJCgnI3NwYXJrbGluZTEnKS5zcGFya2xpbmUoWzEsNCw2LDYsOCw1LDMsNV0pXG4qICAgICQoJyNzcGFya2xpbmUyJykuc3BhcmtsaW5lKFsxLDQsNixudWxsLG51bGwsNSwzLDVdKVxuKlxuKiBWYWx1ZXMgY2FuIGFsc28gYmUgc3BlY2lmaWVkIGluIGFuIEhUTUwgY29tbWVudCwgb3IgYXMgYSB2YWx1ZXMgYXR0cmlidXRlOlxuKiAgICA8cD5TcGFya2xpbmU6IDxzcGFuIGNsYXNzPVwic3BhcmtsaW5lXCI+PCEtLTEsNCw2LDYsOCw1LDMsNSAtLT48L3NwYW4+PC9wPlxuKiAgICA8cD5TcGFya2xpbmU6IDxzcGFuIGNsYXNzPVwic3BhcmtsaW5lXCIgdmFsdWVzPVwiMSw0LDYsNiw4LDUsMyw1XCI+PC9zcGFuPjwvcD5cbiogICAgJCgnLnNwYXJrbGluZScpLnNwYXJrbGluZSgpO1xuKlxuKiBGb3IgbGluZSBjaGFydHMsIHggdmFsdWVzIGNhbiBhbHNvIGJlIHNwZWNpZmllZDpcbiogICA8cD5TcGFya2xpbmU6IDxzcGFuIGNsYXNzPVwic3BhcmtsaW5lXCI+MToxLDIuNzo0LDMuNDo2LDU6Niw2OjgsOC43OjUsOTozLDEwOjU8L3NwYW4+PC9wPlxuKiAgICAkKCcjc3BhcmtsaW5lMScpLnNwYXJrbGluZShbIFsxLDFdLCBbMi43LDRdLCBbMy40LDZdLCBbNSw2XSwgWzYsOF0sIFs4LjcsNV0sIFs5LDNdLCBbMTAsNV0gXSlcbipcbiogQnkgZGVmYXVsdCwgb3B0aW9ucyBzaG91bGQgYmUgcGFzc2VkIGluIGFzIHRoZSBzZWNvbmQgYXJndW1lbnQgdG8gdGhlIHNwYXJrbGluZSBmdW5jdGlvbjpcbiogICAkKCcuc3BhcmtsaW5lJykuc3BhcmtsaW5lKFsxLDIsMyw0XSwge3R5cGU6ICdiYXInfSlcbipcbiogT3B0aW9ucyBjYW4gYWxzbyBiZSBzZXQgYnkgcGFzc2luZyB0aGVtIG9uIHRoZSB0YWcgaXRzZWxmLiAgVGhpcyBmZWF0dXJlIGlzIGRpc2FibGVkIGJ5IGRlZmF1bHQgdGhvdWdoXG4qIGFzIHRoZXJlJ3MgYSBzbGlnaHQgcGVyZm9ybWFuY2Ugb3ZlcmhlYWQ6XG4qICAgJCgnLnNwYXJrbGluZScpLnNwYXJrbGluZShbMSwyLDMsNF0sIHtlbmFibGVUYWdPcHRpb25zOiB0cnVlfSlcbiogICA8cD5TcGFya2xpbmU6IDxzcGFuIGNsYXNzPVwic3BhcmtsaW5lXCIgc3BhcmtUeXBlPVwiYmFyXCIgc3BhcmtCYXJDb2xvcj1cInJlZFwiPmxvYWRpbmc8L3NwYW4+PC9wPlxuKiBQcmVmaXggYWxsIG9wdGlvbnMgc3VwcGxpZWQgYXMgdGFnIGF0dHJpYnV0ZSB3aXRoIFwic3BhcmtcIiAoY29uZmlndXJhYmxlIGJ5IHNldHRpbmcgdGFnT3B0aW9uc1ByZWZpeClcbipcbiogU3VwcG9ydGVkIG9wdGlvbnM6XG4qICAgbGluZUNvbG9yIC0gQ29sb3Igb2YgdGhlIGxpbmUgdXNlZCBmb3IgdGhlIGNoYXJ0XG4qICAgZmlsbENvbG9yIC0gQ29sb3IgdXNlZCB0byBmaWxsIGluIHRoZSBjaGFydCAtIFNldCB0byAnJyBvciBmYWxzZSBmb3IgYSB0cmFuc3BhcmVudCBjaGFydFxuKiAgIHdpZHRoIC0gV2lkdGggb2YgdGhlIGNoYXJ0IC0gRGVmYXVsdHMgdG8gMyB0aW1lcyB0aGUgbnVtYmVyIG9mIHZhbHVlcyBpbiBwaXhlbHNcbiogICBoZWlnaHQgLSBIZWlnaHQgb2YgdGhlIGNoYXJ0IC0gRGVmYXVsdHMgdG8gdGhlIGhlaWdodCBvZiB0aGUgY29udGFpbmluZyBlbGVtZW50XG4qICAgY2hhcnRSYW5nZU1pbiAtIFNwZWNpZnkgdGhlIG1pbmltdW0gdmFsdWUgdG8gdXNlIGZvciB0aGUgWSByYW5nZSBvZiB0aGUgY2hhcnQgLSBEZWZhdWx0cyB0byB0aGUgbWluaW11bSB2YWx1ZSBzdXBwbGllZFxuKiAgIGNoYXJ0UmFuZ2VNYXggLSBTcGVjaWZ5IHRoZSBtYXhpbXVtIHZhbHVlIHRvIHVzZSBmb3IgdGhlIFkgcmFuZ2Ugb2YgdGhlIGNoYXJ0IC0gRGVmYXVsdHMgdG8gdGhlIG1heGltdW0gdmFsdWUgc3VwcGxpZWRcbiogICBjaGFydFJhbmdlQ2xpcCAtIENsaXAgb3V0IG9mIHJhbmdlIHZhbHVlcyB0byB0aGUgbWF4L21pbiBzcGVjaWZpZWQgYnkgY2hhcnRSYW5nZU1pbiBhbmQgY2hhcnRSYW5nZU1heFxuKiAgIGNoYXJ0UmFuZ2VNaW5YIC0gU3BlY2lmeSB0aGUgbWluaW11bSB2YWx1ZSB0byB1c2UgZm9yIHRoZSBYIHJhbmdlIG9mIHRoZSBjaGFydCAtIERlZmF1bHRzIHRvIHRoZSBtaW5pbXVtIHZhbHVlIHN1cHBsaWVkXG4qICAgY2hhcnRSYW5nZU1heFggLSBTcGVjaWZ5IHRoZSBtYXhpbXVtIHZhbHVlIHRvIHVzZSBmb3IgdGhlIFggcmFuZ2Ugb2YgdGhlIGNoYXJ0IC0gRGVmYXVsdHMgdG8gdGhlIG1heGltdW0gdmFsdWUgc3VwcGxpZWRcbiogICBjb21wb3NpdGUgLSBJZiB0cnVlIHRoZW4gZG9uJ3QgZXJhc2UgYW55IGV4aXN0aW5nIGNoYXJ0IGF0dGFjaGVkIHRvIHRoZSB0YWcsIGJ1dCBkcmF3XG4qICAgICAgICAgICBhbm90aGVyIGNoYXJ0IG92ZXIgdGhlIHRvcCAtIE5vdGUgdGhhdCB3aWR0aCBhbmQgaGVpZ2h0IGFyZSBpZ25vcmVkIGlmIGFuXG4qICAgICAgICAgICBleGlzdGluZyBjaGFydCBpcyBkZXRlY3RlZC5cbiogICB0YWdWYWx1ZXNBdHRyaWJ1dGUgLSBOYW1lIG9mIHRhZyBhdHRyaWJ1dGUgdG8gY2hlY2sgZm9yIGRhdGEgdmFsdWVzIC0gRGVmYXVsdHMgdG8gJ3ZhbHVlcydcbiogICBlbmFibGVUYWdPcHRpb25zIC0gV2hldGhlciB0byBjaGVjayB0YWdzIGZvciBzcGFya2xpbmUgb3B0aW9uc1xuKiAgIHRhZ09wdGlvbnNQcmVmaXggLSBQcmVmaXggdXNlZCBmb3Igb3B0aW9ucyBzdXBwbGllZCBhcyB0YWcgYXR0cmlidXRlcyAtIERlZmF1bHRzIHRvICdzcGFyaydcbiogICBkaXNhYmxlSGlkZGVuQ2hlY2sgLSBJZiBzZXQgdG8gdHJ1ZSwgdGhlbiB0aGUgcGx1Z2luIHdpbGwgYXNzdW1lIHRoYXQgY2hhcnRzIHdpbGwgbmV2ZXIgYmUgZHJhd24gaW50byBhXG4qICAgICAgICAgICBoaWRkZW4gZG9tIGVsZW1lbnQsIGF2b2RpbmcgYSBicm93c2VyIHJlZmxvd1xuKiAgIGRpc2FibGVJbnRlcmFjdGlvbiAtIElmIHNldCB0byB0cnVlIHRoZW4gYWxsIG1vdXNlb3Zlci9jbGljayBpbnRlcmFjdGlvbiBiZWhhdmlvdXIgd2lsbCBiZSBkaXNhYmxlZCxcbiogICAgICAgbWFraW5nIHRoZSBwbHVnaW4gcGVyZm9ybSBtdWNoIGxpa2UgaXQgZGlkIGluIDEueFxuKiAgIGRpc2FibGVUb29sdGlwcyAtIElmIHNldCB0byB0cnVlIHRoZW4gdG9vbHRpcHMgd2lsbCBiZSBkaXNhYmxlZCAtIERlZmF1bHRzIHRvIGZhbHNlICh0b29sdGlwcyBlbmFibGVkKVxuKiAgIGRpc2FibGVIaWdobGlnaHQgLSBJZiBzZXQgdG8gdHJ1ZSB0aGVuIGhpZ2hsaWdodGluZyBvZiBzZWxlY3RlZCBjaGFydCBlbGVtZW50cyBvbiBtb3VzZW92ZXIgd2lsbCBiZSBkaXNhYmxlZFxuKiAgICAgICBkZWZhdWx0cyB0byBmYWxzZSAoaGlnaGxpZ2h0cyBlbmFibGVkKVxuKiAgIGhpZ2hsaWdodExpZ2h0ZW4gLSBGYWN0b3IgdG8gbGlnaHRlbi9kYXJrZW4gaGlnaGxpZ2h0ZWQgY2hhcnQgdmFsdWVzIGJ5IC0gRGVmYXVsdHMgdG8gMS40IGZvciBhIDQwJSBpbmNyZWFzZVxuKiAgIHRvb2x0aXBDb250YWluZXIgLSBTcGVjaWZ5IHdoaWNoIERPTSBlbGVtZW50IHRoZSB0b29sdGlwIHNob3VsZCBiZSByZW5kZXJlZCBpbnRvIC0gZGVmYXVsdHMgdG8gZG9jdW1lbnQuYm9keVxuKiAgIHRvb2x0aXBDbGFzc25hbWUgLSBPcHRpb25hbCBDU1MgY2xhc3NuYW1lIHRvIGFwcGx5IHRvIHRvb2x0aXBzIC0gSWYgbm90IHNwZWNpZmllZCB0aGVuIGEgZGVmYXVsdCBzdHlsZSB3aWxsIGJlIGFwcGxpZWRcbiogICB0b29sdGlwT2Zmc2V0WCAtIEhvdyBtYW55IHBpeGVscyBhd2F5IGZyb20gdGhlIG1vdXNlIHBvaW50ZXIgdG8gcmVuZGVyIHRoZSB0b29sdGlwIG9uIHRoZSBYIGF4aXNcbiogICB0b29sdGlwT2Zmc2V0WSAtIEhvdyBtYW55IHBpeGVscyBhd2F5IGZyb20gdGhlIG1vdXNlIHBvaW50ZXIgdG8gcmVuZGVyIHRoZSB0b29sdGlwIG9uIHRoZSByIGF4aXNcbiogICB0b29sdGlwRm9ybWF0dGVyICAtIE9wdGlvbmFsIGNhbGxiYWNrIHRoYXQgYWxsb3dzIHlvdSB0byBvdmVycmlkZSB0aGUgSFRNTCBkaXNwbGF5ZWQgaW4gdGhlIHRvb2x0aXBcbiogICAgICAgY2FsbGJhY2sgaXMgZ2l2ZW4gYXJndW1lbnRzIG9mIChzcGFya2xpbmUsIG9wdGlvbnMsIGZpZWxkcylcbiogICB0b29sdGlwQ2hhcnRUaXRsZSAtIElmIHNwZWNpZmllZCB0aGVuIHRoZSB0b29sdGlwIHVzZXMgdGhlIHN0cmluZyBzcGVjaWZpZWQgYnkgdGhpcyBzZXR0aW5nIGFzIGEgdGl0bGVcbiogICB0b29sdGlwRm9ybWF0IC0gQSBmb3JtYXQgc3RyaW5nIG9yIFNQRm9ybWF0IG9iamVjdCAgKG9yIGFuIGFycmF5IHRoZXJlb2YgZm9yIG11bHRpcGxlIGVudHJpZXMpXG4qICAgICAgIHRvIGNvbnRyb2wgdGhlIGZvcm1hdCBvZiB0aGUgdG9vbHRpcFxuKiAgIHRvb2x0aXBQcmVmaXggLSBBIHN0cmluZyB0byBwcmVwZW5kIHRvIGVhY2ggZmllbGQgZGlzcGxheWVkIGluIGEgdG9vbHRpcFxuKiAgIHRvb2x0aXBTdWZmaXggLSBBIHN0cmluZyB0byBhcHBlbmQgdG8gZWFjaCBmaWVsZCBkaXNwbGF5ZWQgaW4gYSB0b29sdGlwXG4qICAgdG9vbHRpcFNraXBOdWxsIC0gSWYgdHJ1ZSB0aGVuIG51bGwgdmFsdWVzIHdpbGwgbm90IGhhdmUgYSB0b29sdGlwIGRpc3BsYXllZCAoZGVmYXVsdHMgdG8gdHJ1ZSlcbiogICB0b29sdGlwVmFsdWVMb29rdXBzIC0gQW4gb2JqZWN0IG9yIHJhbmdlIG1hcCB0byBtYXAgZmllbGQgdmFsdWVzIHRvIHRvb2x0aXAgc3RyaW5nc1xuKiAgICAgICAoZWcuIHRvIG1hcCAtMSB0byBcIkxvc3RcIiwgMCB0byBcIkRyYXdcIiwgYW5kIDEgdG8gXCJXaW5cIilcbiogICBudW1iZXJGb3JtYXR0ZXIgLSBPcHRpb25hbCBjYWxsYmFjayBmb3IgZm9ybWF0dGluZyBudW1iZXJzIGluIHRvb2x0aXBzXG4qICAgbnVtYmVyRGlnaXRHcm91cFNlcCAtIENoYXJhY3RlciB0byB1c2UgZm9yIGdyb3VwIHNlcGFyYXRvciBpbiBudW1iZXJzIFwiMSwyMzRcIiAtIERlZmF1bHRzIHRvIFwiLFwiXG4qICAgbnVtYmVyRGVjaW1hbE1hcmsgLSBDaGFyYWN0ZXIgdG8gdXNlIGZvciB0aGUgZGVjaW1hbCBwb2ludCB3aGVuIGZvcm1hdHRpbmcgbnVtYmVycyAtIERlZmF1bHRzIHRvIFwiLlwiXG4qICAgbnVtYmVyRGlnaXRHcm91cENvdW50IC0gTnVtYmVyIG9mIGRpZ2l0cyBiZXR3ZWVuIGdyb3VwIHNlcGFyYXRvciAtIERlZmF1bHRzIHRvIDNcbipcbiogVGhlcmUgYXJlIDcgdHlwZXMgb2Ygc3BhcmtsaW5lLCBzZWxlY3RlZCBieSBzdXBwbHlpbmcgYSBcInR5cGVcIiBvcHRpb24gb2YgJ2xpbmUnIChkZWZhdWx0KSxcbiogJ2JhcicsICd0cmlzdGF0ZScsICdidWxsZXQnLCAnZGlzY3JldGUnLCAncGllJyBvciAnYm94J1xuKiAgICBsaW5lIC0gTGluZSBjaGFydC4gIE9wdGlvbnM6XG4qICAgICAgIHNwb3RDb2xvciAtIFNldCB0byAnJyB0byBub3QgZW5kIGVhY2ggbGluZSBpbiBhIGNpcmN1bGFyIHNwb3RcbiogICAgICAgbWluU3BvdENvbG9yIC0gSWYgc2V0LCBjb2xvciBvZiBzcG90IGF0IG1pbmltdW0gdmFsdWVcbiogICAgICAgbWF4U3BvdENvbG9yIC0gSWYgc2V0LCBjb2xvciBvZiBzcG90IGF0IG1heGltdW0gdmFsdWVcbiogICAgICAgc3BvdFJhZGl1cyAtIFJhZGl1cyBpbiBwaXhlbHNcbiogICAgICAgbGluZVdpZHRoIC0gV2lkdGggb2YgbGluZSBpbiBwaXhlbHNcbiogICAgICAgbm9ybWFsUmFuZ2VNaW5cbiogICAgICAgbm9ybWFsUmFuZ2VNYXggLSBJZiBzZXQgZHJhd3MgYSBmaWxsZWQgaG9yaXpvbnRhbCBiYXIgYmV0d2VlbiB0aGVzZSB0d28gdmFsdWVzIG1hcmtpbmcgdGhlIFwibm9ybWFsXCJcbiogICAgICAgICAgICAgICAgICAgICAgb3IgZXhwZWN0ZWQgcmFuZ2Ugb2YgdmFsdWVzXG4qICAgICAgIG5vcm1hbFJhbmdlQ29sb3IgLSBDb2xvciB0byB1c2UgZm9yIHRoZSBhYm92ZSBiYXJcbiogICAgICAgZHJhd05vcm1hbE9uVG9wIC0gRHJhdyB0aGUgbm9ybWFsIHJhbmdlIGFib3ZlIHRoZSBjaGFydCBmaWxsIGNvbG9yIGlmIHRydWVcbiogICAgICAgZGVmYXVsdFBpeGVsc1BlclZhbHVlIC0gRGVmYXVsdHMgdG8gMyBwaXhlbHMgb2Ygd2lkdGggZm9yIGVhY2ggdmFsdWUgaW4gdGhlIGNoYXJ0XG4qICAgICAgIGhpZ2hsaWdodFNwb3RDb2xvciAtIFRoZSBjb2xvciB0byB1c2UgZm9yIGRyYXdpbmcgYSBoaWdobGlnaHQgc3BvdCBvbiBtb3VzZW92ZXIgLSBTZXQgdG8gbnVsbCB0byBkaXNhYmxlXG4qICAgICAgIGhpZ2hsaWdodExpbmVDb2xvciAtIFRoZSBjb2xvciB0byB1c2UgZm9yIGRyYXdpbmcgYSBoaWdobGlnaHQgbGluZSBvbiBtb3VzZW92ZXIgLSBTZXQgdG8gbnVsbCB0byBkaXNhYmxlXG4qICAgICAgIHZhbHVlU3BvdHMgLSBTcGVjaWZ5IHdoaWNoIHBvaW50cyB0byBkcmF3IHNwb3RzIG9uLCBhbmQgaW4gd2hpY2ggY29sb3IuICBBY2NlcHRzIGEgcmFuZ2UgbWFwXG4qXG4qICAgYmFyIC0gQmFyIGNoYXJ0LiAgT3B0aW9uczpcbiogICAgICAgYmFyQ29sb3IgLSBDb2xvciBvZiBiYXJzIGZvciBwb3N0aXZlIHZhbHVlc1xuKiAgICAgICBuZWdCYXJDb2xvciAtIENvbG9yIG9mIGJhcnMgZm9yIG5lZ2F0aXZlIHZhbHVlc1xuKiAgICAgICB6ZXJvQ29sb3IgLSBDb2xvciBvZiBiYXJzIHdpdGggemVybyB2YWx1ZXNcbiogICAgICAgbnVsbENvbG9yIC0gQ29sb3Igb2YgYmFycyB3aXRoIG51bGwgdmFsdWVzIC0gRGVmYXVsdHMgdG8gb21pdHRpbmcgdGhlIGJhciBlbnRpcmVseVxuKiAgICAgICBiYXJXaWR0aCAtIFdpZHRoIG9mIGJhcnMgaW4gcGl4ZWxzXG4qICAgICAgIGNvbG9yTWFwIC0gT3B0aW9uYWwgbWFwcG5pZyBvZiB2YWx1ZXMgdG8gY29sb3JzIHRvIG92ZXJyaWRlIHRoZSAqQmFyQ29sb3IgdmFsdWVzIGFib3ZlXG4qICAgICAgICAgICAgICAgICAgY2FuIGJlIGFuIEFycmF5IG9mIHZhbHVlcyB0byBjb250cm9sIHRoZSBjb2xvciBvZiBpbmRpdmlkdWFsIGJhcnMgb3IgYSByYW5nZSBtYXBcbiogICAgICAgICAgICAgICAgICB0byBzcGVjaWZ5IGNvbG9ycyBmb3IgaW5kaXZpZHVhbCByYW5nZXMgb2YgdmFsdWVzXG4qICAgICAgIGJhclNwYWNpbmcgLSBHYXAgYmV0d2VlbiBiYXJzIGluIHBpeGVsc1xuKiAgICAgICB6ZXJvQXhpcyAtIENlbnRlcnMgdGhlIHktYXhpcyBhcm91bmQgemVybyBpZiB0cnVlXG4qXG4qICAgdHJpc3RhdGUgLSBDaGFydHMgdmFsdWVzIG9mIHdpbiAoPjApLCBsb3NlICg8MCkgb3IgZHJhdyAoPTApXG4qICAgICAgIHBvc0JhckNvbG9yIC0gQ29sb3Igb2Ygd2luIHZhbHVlc1xuKiAgICAgICBuZWdCYXJDb2xvciAtIENvbG9yIG9mIGxvc2UgdmFsdWVzXG4qICAgICAgIHplcm9CYXJDb2xvciAtIENvbG9yIG9mIGRyYXcgdmFsdWVzXG4qICAgICAgIGJhcldpZHRoIC0gV2lkdGggb2YgYmFycyBpbiBwaXhlbHNcbiogICAgICAgYmFyU3BhY2luZyAtIEdhcCBiZXR3ZWVuIGJhcnMgaW4gcGl4ZWxzXG4qICAgICAgIGNvbG9yTWFwIC0gT3B0aW9uYWwgbWFwcG5pZyBvZiB2YWx1ZXMgdG8gY29sb3JzIHRvIG92ZXJyaWRlIHRoZSAqQmFyQ29sb3IgdmFsdWVzIGFib3ZlXG4qICAgICAgICAgICAgICAgICAgY2FuIGJlIGFuIEFycmF5IG9mIHZhbHVlcyB0byBjb250cm9sIHRoZSBjb2xvciBvZiBpbmRpdmlkdWFsIGJhcnMgb3IgYSByYW5nZSBtYXBcbiogICAgICAgICAgICAgICAgICB0byBzcGVjaWZ5IGNvbG9ycyBmb3IgaW5kaXZpZHVhbCByYW5nZXMgb2YgdmFsdWVzXG4qXG4qICAgZGlzY3JldGUgLSBPcHRpb25zOlxuKiAgICAgICBsaW5lSGVpZ2h0IC0gSGVpZ2h0IG9mIGVhY2ggbGluZSBpbiBwaXhlbHMgLSBEZWZhdWx0cyB0byAzMCUgb2YgdGhlIGdyYXBoIGhlaWdodFxuKiAgICAgICB0aGVzaG9sZFZhbHVlIC0gVmFsdWVzIGxlc3MgdGhhbiB0aGlzIHZhbHVlIHdpbGwgYmUgZHJhd24gdXNpbmcgdGhyZXNob2xkQ29sb3IgaW5zdGVhZCBvZiBsaW5lQ29sb3JcbiogICAgICAgdGhyZXNob2xkQ29sb3JcbipcbiogICBidWxsZXQgLSBWYWx1ZXMgZm9yIGJ1bGxldCBncmFwaHMgbXN1dCBiZSBpbiB0aGUgb3JkZXI6IHRhcmdldCwgcGVyZm9ybWFuY2UsIHJhbmdlMSwgcmFuZ2UyLCByYW5nZTMsIC4uLlxuKiAgICAgICBvcHRpb25zOlxuKiAgICAgICB0YXJnZXRDb2xvciAtIFRoZSBjb2xvciBvZiB0aGUgdmVydGljYWwgdGFyZ2V0IG1hcmtlclxuKiAgICAgICB0YXJnZXRXaWR0aCAtIFRoZSB3aWR0aCBvZiB0aGUgdGFyZ2V0IG1hcmtlciBpbiBwaXhlbHNcbiogICAgICAgcGVyZm9ybWFuY2VDb2xvciAtIFRoZSBjb2xvciBvZiB0aGUgcGVyZm9ybWFuY2UgbWVhc3VyZSBob3Jpem9udGFsIGJhclxuKiAgICAgICByYW5nZUNvbG9ycyAtIENvbG9ycyB0byB1c2UgZm9yIGVhY2ggcXVhbGl0YXRpdmUgcmFuZ2UgYmFja2dyb3VuZCBjb2xvclxuKlxuKiAgIHBpZSAtIFBpZSBjaGFydC4gT3B0aW9uczpcbiogICAgICAgc2xpY2VDb2xvcnMgLSBBbiBhcnJheSBvZiBjb2xvcnMgdG8gdXNlIGZvciBwaWUgc2xpY2VzXG4qICAgICAgIG9mZnNldCAtIEFuZ2xlIGluIGRlZ3JlZXMgdG8gb2Zmc2V0IHRoZSBmaXJzdCBzbGljZSAtIFRyeSAtOTAgb3IgKzkwXG4qICAgICAgIGJvcmRlcldpZHRoIC0gV2lkdGggb2YgYm9yZGVyIHRvIGRyYXcgYXJvdW5kIHRoZSBwaWUgY2hhcnQsIGluIHBpeGVscyAtIERlZmF1bHRzIHRvIDAgKG5vIGJvcmRlcilcbiogICAgICAgYm9yZGVyQ29sb3IgLSBDb2xvciB0byB1c2UgZm9yIHRoZSBwaWUgY2hhcnQgYm9yZGVyIC0gRGVmYXVsdHMgdG8gIzAwMFxuKlxuKiAgIGJveCAtIEJveCBwbG90LiBPcHRpb25zOlxuKiAgICAgICByYXcgLSBTZXQgdG8gdHJ1ZSB0byBzdXBwbHkgcHJlLWNvbXB1dGVkIHBsb3QgcG9pbnRzIGFzIHZhbHVlc1xuKiAgICAgICAgICAgICB2YWx1ZXMgc2hvdWxkIGJlOiBsb3dfb3V0bGllciwgbG93X3doaXNrZXIsIHExLCBtZWRpYW4sIHEzLCBoaWdoX3doaXNrZXIsIGhpZ2hfb3V0bGllclxuKiAgICAgICAgICAgICBXaGVuIHNldCB0byBmYWxzZSB5b3UgY2FuIHN1cHBseSBhbnkgbnVtYmVyIG9mIHZhbHVlcyBhbmQgdGhlIGJveCBwbG90IHdpbGxcbiogICAgICAgICAgICAgYmUgY29tcHV0ZWQgZm9yIHlvdS4gIERlZmF1bHQgaXMgZmFsc2UuXG4qICAgICAgIHNob3dPdXRsaWVycyAtIFNldCB0byB0cnVlIChkZWZhdWx0KSB0byBkaXNwbGF5IG91dGxpZXJzIGFzIGNpcmNsZXNcbiogICAgICAgb3V0bGllcklRUiAtIEludGVycXVhcnRpbGUgcmFuZ2UgdXNlZCB0byBkZXRlcm1pbmUgb3V0bGllcnMuICBEZWZhdWx0IDEuNVxuKiAgICAgICBib3hMaW5lQ29sb3IgLSBPdXRsaW5lIGNvbG9yIG9mIHRoZSBib3hcbiogICAgICAgYm94RmlsbENvbG9yIC0gRmlsbCBjb2xvciBmb3IgdGhlIGJveFxuKiAgICAgICB3aGlza2VyQ29sb3IgLSBMaW5lIGNvbG9yIHVzZWQgZm9yIHdoaXNrZXJzXG4qICAgICAgIG91dGxpZXJMaW5lQ29sb3IgLSBPdXRsaW5lIGNvbG9yIG9mIG91dGxpZXIgY2lyY2xlc1xuKiAgICAgICBvdXRsaWVyRmlsbENvbG9yIC0gRmlsbCBjb2xvciBvZiB0aGUgb3V0bGllciBjaXJjbGVzXG4qICAgICAgIHNwb3RSYWRpdXMgLSBSYWRpdXMgb2Ygb3V0bGllciBjaXJjbGVzXG4qICAgICAgIG1lZGlhbkNvbG9yIC0gTGluZSBjb2xvciBvZiB0aGUgbWVkaWFuIGxpbmVcbiogICAgICAgdGFyZ2V0IC0gRHJhdyBhIHRhcmdldCBjcm9zcyBoYWlyIGF0IHRoZSBzdXBwbGllZCB2YWx1ZSAoZGVmYXVsdCB1bmRlZmluZWQpXG4qXG4qXG4qXG4qICAgRXhhbXBsZXM6XG4qICAgJCgnI3NwYXJrbGluZTEnKS5zcGFya2xpbmUobXl2YWx1ZXMsIHsgbGluZUNvbG9yOiAnI2YwMCcsIGZpbGxDb2xvcjogZmFsc2UgfSk7XG4qICAgJCgnLmJhcnNwYXJrcycpLnNwYXJrbGluZSgnaHRtbCcsIHsgdHlwZTonYmFyJywgaGVpZ2h0Oic0MHB4JywgYmFyV2lkdGg6NSB9KTtcbiogICAkKCcjdHJpc3RhdGUnKS5zcGFya2xpbmUoWzEsMSwtMSwxLDAsMCwtMV0sIHsgdHlwZTondHJpc3RhdGUnIH0pOlxuKiAgICQoJyNkaXNjcmV0ZScpLnNwYXJrbGluZShbMSwzLDQsNSw1LDMsNCw1XSwgeyB0eXBlOidkaXNjcmV0ZScgfSk7XG4qICAgJCgnI2J1bGxldCcpLnNwYXJrbGluZShbMTAsMTIsMTIsOSw3XSwgeyB0eXBlOididWxsZXQnIH0pO1xuKiAgICQoJyNwaWUnKS5zcGFya2xpbmUoWzEsMSwyXSwgeyB0eXBlOidwaWUnIH0pO1xuKi9cblxuLypqc2xpbnQgcmVnZXhwOiB0cnVlLCBicm93c2VyOiB0cnVlLCBqcXVlcnk6IHRydWUsIHdoaXRlOiB0cnVlLCBub21lbjogZmFsc2UsIHBsdXNwbHVzOiBmYWxzZSwgbWF4ZXJyOiA1MDAsIGluZGVudDogNCAqL1xuXG4oZnVuY3Rpb24oZG9jdW1lbnQsIE1hdGgsIHVuZGVmaW5lZCkgeyAvLyBwZXJmb3JtYW5jZS9taW5pZmllZC1zaXplIG9wdGltaXphdGlvblxuKGZ1bmN0aW9uKGZhY3RvcnkpIHtcbiAgICBpZih0eXBlb2YgZGVmaW5lID09PSAnZnVuY3Rpb24nICYmIGRlZmluZS5hbWQpIHtcbiAgICAgICAgZGVmaW5lKFsnanF1ZXJ5J10sIGZhY3RvcnkpO1xuICAgIH0gZWxzZSBpZiAoalF1ZXJ5ICYmICFqUXVlcnkuZm4uc3BhcmtsaW5lKSB7XG4gICAgICAgIGZhY3RvcnkoalF1ZXJ5KTtcbiAgICB9XG59XG4oZnVuY3Rpb24oJCkge1xuICAgICd1c2Ugc3RyaWN0JztcblxuICAgIHZhciBVTlNFVF9PUFRJT04gPSB7fSxcbiAgICAgICAgZ2V0RGVmYXVsdHMsIGNyZWF0ZUNsYXNzLCBTUEZvcm1hdCwgY2xpcHZhbCwgcXVhcnRpbGUsIG5vcm1hbGl6ZVZhbHVlLCBub3JtYWxpemVWYWx1ZXMsXG4gICAgICAgIHJlbW92ZSwgaXNOdW1iZXIsIGFsbCwgc3VtLCBhZGRDU1MsIGVuc3VyZUFycmF5LCBmb3JtYXROdW1iZXIsIFJhbmdlTWFwLFxuICAgICAgICBNb3VzZUhhbmRsZXIsIFRvb2x0aXAsIGJhckhpZ2hsaWdodE1peGluLFxuICAgICAgICBsaW5lLCBiYXIsIHRyaXN0YXRlLCBkaXNjcmV0ZSwgYnVsbGV0LCBwaWUsIGJveCwgZGVmYXVsdFN0eWxlcywgaW5pdFN0eWxlcyxcbiAgICAgICAgVlNoYXBlLCBWQ2FudmFzX2Jhc2UsIFZDYW52YXNfY2FudmFzLCBWQ2FudmFzX3ZtbCwgcGVuZGluZywgc2hhcGVDb3VudCA9IDA7XG5cbiAgICAvKipcbiAgICAgKiBEZWZhdWx0IGNvbmZpZ3VyYXRpb24gc2V0dGluZ3NcbiAgICAgKi9cbiAgICBnZXREZWZhdWx0cyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIC8vIFNldHRpbmdzIGNvbW1vbiB0byBtb3N0L2FsbCBjaGFydCB0eXBlc1xuICAgICAgICAgICAgY29tbW9uOiB7XG4gICAgICAgICAgICAgICAgdHlwZTogJ2xpbmUnLFxuICAgICAgICAgICAgICAgIGxpbmVDb2xvcjogJyMwMGYnLFxuICAgICAgICAgICAgICAgIGZpbGxDb2xvcjogJyNjZGYnLFxuICAgICAgICAgICAgICAgIGRlZmF1bHRQaXhlbHNQZXJWYWx1ZTogMyxcbiAgICAgICAgICAgICAgICB3aWR0aDogJ2F1dG8nLFxuICAgICAgICAgICAgICAgIGhlaWdodDogJ2F1dG8nLFxuICAgICAgICAgICAgICAgIGNvbXBvc2l0ZTogZmFsc2UsXG4gICAgICAgICAgICAgICAgdGFnVmFsdWVzQXR0cmlidXRlOiAndmFsdWVzJyxcbiAgICAgICAgICAgICAgICB0YWdPcHRpb25zUHJlZml4OiAnc3BhcmsnLFxuICAgICAgICAgICAgICAgIGVuYWJsZVRhZ09wdGlvbnM6IGZhbHNlLFxuICAgICAgICAgICAgICAgIGVuYWJsZUhpZ2hsaWdodDogdHJ1ZSxcbiAgICAgICAgICAgICAgICBoaWdobGlnaHRMaWdodGVuOiAxLjQsXG4gICAgICAgICAgICAgICAgdG9vbHRpcFNraXBOdWxsOiB0cnVlLFxuICAgICAgICAgICAgICAgIHRvb2x0aXBQcmVmaXg6ICcnLFxuICAgICAgICAgICAgICAgIHRvb2x0aXBTdWZmaXg6ICcnLFxuICAgICAgICAgICAgICAgIGRpc2FibGVIaWRkZW5DaGVjazogZmFsc2UsXG4gICAgICAgICAgICAgICAgbnVtYmVyRm9ybWF0dGVyOiBmYWxzZSxcbiAgICAgICAgICAgICAgICBudW1iZXJEaWdpdEdyb3VwQ291bnQ6IDMsXG4gICAgICAgICAgICAgICAgbnVtYmVyRGlnaXRHcm91cFNlcDogJywnLFxuICAgICAgICAgICAgICAgIG51bWJlckRlY2ltYWxNYXJrOiAnLicsXG4gICAgICAgICAgICAgICAgZGlzYWJsZVRvb2x0aXBzOiBmYWxzZSxcbiAgICAgICAgICAgICAgICBkaXNhYmxlSW50ZXJhY3Rpb246IGZhbHNlXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgLy8gRGVmYXVsdHMgZm9yIGxpbmUgY2hhcnRzXG4gICAgICAgICAgICBsaW5lOiB7XG4gICAgICAgICAgICAgICAgc3BvdENvbG9yOiAnI2Y4MCcsXG4gICAgICAgICAgICAgICAgaGlnaGxpZ2h0U3BvdENvbG9yOiAnIzVmNScsXG4gICAgICAgICAgICAgICAgaGlnaGxpZ2h0TGluZUNvbG9yOiAnI2YyMicsXG4gICAgICAgICAgICAgICAgc3BvdFJhZGl1czogMS41LFxuICAgICAgICAgICAgICAgIG1pblNwb3RDb2xvcjogJyNmODAnLFxuICAgICAgICAgICAgICAgIG1heFNwb3RDb2xvcjogJyNmODAnLFxuICAgICAgICAgICAgICAgIGxpbmVXaWR0aDogMSxcbiAgICAgICAgICAgICAgICBub3JtYWxSYW5nZU1pbjogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgIG5vcm1hbFJhbmdlTWF4OiB1bmRlZmluZWQsXG4gICAgICAgICAgICAgICAgbm9ybWFsUmFuZ2VDb2xvcjogJyNjY2MnLFxuICAgICAgICAgICAgICAgIGRyYXdOb3JtYWxPblRvcDogZmFsc2UsXG4gICAgICAgICAgICAgICAgY2hhcnRSYW5nZU1pbjogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgIGNoYXJ0UmFuZ2VNYXg6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICBjaGFydFJhbmdlTWluWDogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgIGNoYXJ0UmFuZ2VNYXhYOiB1bmRlZmluZWQsXG4gICAgICAgICAgICAgICAgdG9vbHRpcEZvcm1hdDogbmV3IFNQRm9ybWF0KCc8c3BhbiBzdHlsZT1cImNvbG9yOiB7e2NvbG9yfX1cIj4mIzk2Nzk7PC9zcGFuPiB7e3ByZWZpeH19e3t5fX17e3N1ZmZpeH19JylcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAvLyBEZWZhdWx0cyBmb3IgYmFyIGNoYXJ0c1xuICAgICAgICAgICAgYmFyOiB7XG4gICAgICAgICAgICAgICAgYmFyQ29sb3I6ICcjMzM2NmNjJyxcbiAgICAgICAgICAgICAgICBuZWdCYXJDb2xvcjogJyNmNDQnLFxuICAgICAgICAgICAgICAgIHN0YWNrZWRCYXJDb2xvcjogWycjMzM2NmNjJywgJyNkYzM5MTInLCAnI2ZmOTkwMCcsICcjMTA5NjE4JywgJyM2NmFhMDAnLFxuICAgICAgICAgICAgICAgICAgICAnI2RkNDQ3NycsICcjMDA5OWM2JywgJyM5OTAwOTknXSxcbiAgICAgICAgICAgICAgICB6ZXJvQ29sb3I6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICBudWxsQ29sb3I6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICB6ZXJvQXhpczogdHJ1ZSxcbiAgICAgICAgICAgICAgICBiYXJXaWR0aDogNCxcbiAgICAgICAgICAgICAgICBiYXJTcGFjaW5nOiAxLFxuICAgICAgICAgICAgICAgIGNoYXJ0UmFuZ2VNYXg6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICBjaGFydFJhbmdlTWluOiB1bmRlZmluZWQsXG4gICAgICAgICAgICAgICAgY2hhcnRSYW5nZUNsaXA6IGZhbHNlLFxuICAgICAgICAgICAgICAgIGNvbG9yTWFwOiB1bmRlZmluZWQsXG4gICAgICAgICAgICAgICAgdG9vbHRpcEZvcm1hdDogbmV3IFNQRm9ybWF0KCc8c3BhbiBzdHlsZT1cImNvbG9yOiB7e2NvbG9yfX1cIj4mIzk2Nzk7PC9zcGFuPiB7e3ByZWZpeH19e3t2YWx1ZX19e3tzdWZmaXh9fScpXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgLy8gRGVmYXVsdHMgZm9yIHRyaXN0YXRlIGNoYXJ0c1xuICAgICAgICAgICAgdHJpc3RhdGU6IHtcbiAgICAgICAgICAgICAgICBiYXJXaWR0aDogNCxcbiAgICAgICAgICAgICAgICBiYXJTcGFjaW5nOiAxLFxuICAgICAgICAgICAgICAgIHBvc0JhckNvbG9yOiAnIzZmNicsXG4gICAgICAgICAgICAgICAgbmVnQmFyQ29sb3I6ICcjZjQ0JyxcbiAgICAgICAgICAgICAgICB6ZXJvQmFyQ29sb3I6ICcjOTk5JyxcbiAgICAgICAgICAgICAgICBjb2xvck1hcDoge30sXG4gICAgICAgICAgICAgICAgdG9vbHRpcEZvcm1hdDogbmV3IFNQRm9ybWF0KCc8c3BhbiBzdHlsZT1cImNvbG9yOiB7e2NvbG9yfX1cIj4mIzk2Nzk7PC9zcGFuPiB7e3ZhbHVlOm1hcH19JyksXG4gICAgICAgICAgICAgICAgdG9vbHRpcFZhbHVlTG9va3VwczogeyBtYXA6IHsgJy0xJzogJ0xvc3MnLCAnMCc6ICdEcmF3JywgJzEnOiAnV2luJyB9IH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAvLyBEZWZhdWx0cyBmb3IgZGlzY3JldGUgY2hhcnRzXG4gICAgICAgICAgICBkaXNjcmV0ZToge1xuICAgICAgICAgICAgICAgIGxpbmVIZWlnaHQ6ICdhdXRvJyxcbiAgICAgICAgICAgICAgICB0aHJlc2hvbGRDb2xvcjogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgIHRocmVzaG9sZFZhbHVlOiAwLFxuICAgICAgICAgICAgICAgIGNoYXJ0UmFuZ2VNYXg6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICBjaGFydFJhbmdlTWluOiB1bmRlZmluZWQsXG4gICAgICAgICAgICAgICAgY2hhcnRSYW5nZUNsaXA6IGZhbHNlLFxuICAgICAgICAgICAgICAgIHRvb2x0aXBGb3JtYXQ6IG5ldyBTUEZvcm1hdCgne3twcmVmaXh9fXt7dmFsdWV9fXt7c3VmZml4fX0nKVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIC8vIERlZmF1bHRzIGZvciBidWxsZXQgY2hhcnRzXG4gICAgICAgICAgICBidWxsZXQ6IHtcbiAgICAgICAgICAgICAgICB0YXJnZXRDb2xvcjogJyNmMzMnLFxuICAgICAgICAgICAgICAgIHRhcmdldFdpZHRoOiAzLCAvLyB3aWR0aCBvZiB0aGUgdGFyZ2V0IGJhciBpbiBwaXhlbHNcbiAgICAgICAgICAgICAgICBwZXJmb3JtYW5jZUNvbG9yOiAnIzMzZicsXG4gICAgICAgICAgICAgICAgcmFuZ2VDb2xvcnM6IFsnI2QzZGFmZScsICcjYThiNmZmJywgJyM3Zjk0ZmYnXSxcbiAgICAgICAgICAgICAgICBiYXNlOiB1bmRlZmluZWQsIC8vIHNldCB0aGlzIHRvIGEgbnVtYmVyIHRvIGNoYW5nZSB0aGUgYmFzZSBzdGFydCBudW1iZXJcbiAgICAgICAgICAgICAgICB0b29sdGlwRm9ybWF0OiBuZXcgU1BGb3JtYXQoJ3t7ZmllbGRrZXk6ZmllbGRzfX0gLSB7e3ZhbHVlfX0nKSxcbiAgICAgICAgICAgICAgICB0b29sdGlwVmFsdWVMb29rdXBzOiB7IGZpZWxkczoge3I6ICdSYW5nZScsIHA6ICdQZXJmb3JtYW5jZScsIHQ6ICdUYXJnZXQnfSB9XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgLy8gRGVmYXVsdHMgZm9yIHBpZSBjaGFydHNcbiAgICAgICAgICAgIHBpZToge1xuICAgICAgICAgICAgICAgIG9mZnNldDogMCxcbiAgICAgICAgICAgICAgICBzbGljZUNvbG9yczogWycjMzM2NmNjJywgJyNkYzM5MTInLCAnI2ZmOTkwMCcsICcjMTA5NjE4JywgJyM2NmFhMDAnLFxuICAgICAgICAgICAgICAgICAgICAnI2RkNDQ3NycsICcjMDA5OWM2JywgJyM5OTAwOTknXSxcbiAgICAgICAgICAgICAgICBib3JkZXJXaWR0aDogMCxcbiAgICAgICAgICAgICAgICBib3JkZXJDb2xvcjogJyMwMDAnLFxuICAgICAgICAgICAgICAgIHRvb2x0aXBGb3JtYXQ6IG5ldyBTUEZvcm1hdCgnPHNwYW4gc3R5bGU9XCJjb2xvcjoge3tjb2xvcn19XCI+JiM5Njc5Ozwvc3Bhbj4ge3t2YWx1ZX19ICh7e3BlcmNlbnQuMX19JSknKVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIC8vIERlZmF1bHRzIGZvciBib3ggcGxvdHNcbiAgICAgICAgICAgIGJveDoge1xuICAgICAgICAgICAgICAgIHJhdzogZmFsc2UsXG4gICAgICAgICAgICAgICAgYm94TGluZUNvbG9yOiAnIzAwMCcsXG4gICAgICAgICAgICAgICAgYm94RmlsbENvbG9yOiAnI2NkZicsXG4gICAgICAgICAgICAgICAgd2hpc2tlckNvbG9yOiAnIzAwMCcsXG4gICAgICAgICAgICAgICAgb3V0bGllckxpbmVDb2xvcjogJyMzMzMnLFxuICAgICAgICAgICAgICAgIG91dGxpZXJGaWxsQ29sb3I6ICcjZmZmJyxcbiAgICAgICAgICAgICAgICBtZWRpYW5Db2xvcjogJyNmMDAnLFxuICAgICAgICAgICAgICAgIHNob3dPdXRsaWVyczogdHJ1ZSxcbiAgICAgICAgICAgICAgICBvdXRsaWVySVFSOiAxLjUsXG4gICAgICAgICAgICAgICAgc3BvdFJhZGl1czogMS41LFxuICAgICAgICAgICAgICAgIHRhcmdldDogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgIHRhcmdldENvbG9yOiAnIzRhMicsXG4gICAgICAgICAgICAgICAgY2hhcnRSYW5nZU1heDogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgIGNoYXJ0UmFuZ2VNaW46IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICB0b29sdGlwRm9ybWF0OiBuZXcgU1BGb3JtYXQoJ3t7ZmllbGQ6ZmllbGRzfX06IHt7dmFsdWV9fScpLFxuICAgICAgICAgICAgICAgIHRvb2x0aXBGb3JtYXRGaWVsZGxpc3RLZXk6ICdmaWVsZCcsXG4gICAgICAgICAgICAgICAgdG9vbHRpcFZhbHVlTG9va3VwczogeyBmaWVsZHM6IHsgbHE6ICdMb3dlciBRdWFydGlsZScsIG1lZDogJ01lZGlhbicsXG4gICAgICAgICAgICAgICAgICAgIHVxOiAnVXBwZXIgUXVhcnRpbGUnLCBsbzogJ0xlZnQgT3V0bGllcicsIHJvOiAnUmlnaHQgT3V0bGllcicsXG4gICAgICAgICAgICAgICAgICAgIGx3OiAnTGVmdCBXaGlza2VyJywgcnc6ICdSaWdodCBXaGlza2VyJ30gfVxuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgIH07XG5cbiAgICAvLyBZb3UgY2FuIGhhdmUgdG9vbHRpcHMgdXNlIGEgY3NzIGNsYXNzIG90aGVyIHRoYW4ganFzdG9vbHRpcCBieSBzcGVjaWZ5aW5nIHRvb2x0aXBDbGFzc25hbWVcbiAgICBkZWZhdWx0U3R5bGVzID0gJy5qcXN0b29sdGlwIHsgJyArXG4gICAgICAgICAgICAncG9zaXRpb246IGFic29sdXRlOycgK1xuICAgICAgICAgICAgJ2xlZnQ6IDBweDsnICtcbiAgICAgICAgICAgICd0b3A6IDBweDsnICtcbiAgICAgICAgICAgICd2aXNpYmlsaXR5OiBoaWRkZW47JyArXG4gICAgICAgICAgICAnYmFja2dyb3VuZDogcmdiKDAsIDAsIDApIHRyYW5zcGFyZW50OycgK1xuICAgICAgICAgICAgJ2JhY2tncm91bmQtY29sb3I6IHJnYmEoMCwwLDAsMC42KTsnICtcbiAgICAgICAgICAgICdmaWx0ZXI6cHJvZ2lkOkRYSW1hZ2VUcmFuc2Zvcm0uTWljcm9zb2Z0LmdyYWRpZW50KHN0YXJ0Q29sb3JzdHI9Izk5MDAwMDAwLCBlbmRDb2xvcnN0cj0jOTkwMDAwMDApOycgK1xuICAgICAgICAgICAgJy1tcy1maWx0ZXI6IFwicHJvZ2lkOkRYSW1hZ2VUcmFuc2Zvcm0uTWljcm9zb2Z0LmdyYWRpZW50KHN0YXJ0Q29sb3JzdHI9Izk5MDAwMDAwLCBlbmRDb2xvcnN0cj0jOTkwMDAwMDApXCI7JyArXG4gICAgICAgICAgICAnY29sb3I6IHdoaXRlOycgK1xuICAgICAgICAgICAgJ2ZvbnQ6IDEwcHggYXJpYWwsIHNhbiBzZXJpZjsnICtcbiAgICAgICAgICAgICd0ZXh0LWFsaWduOiBsZWZ0OycgK1xuICAgICAgICAgICAgJ3doaXRlLXNwYWNlOiBub3dyYXA7JyArXG4gICAgICAgICAgICAncGFkZGluZzogNXB4OycgK1xuICAgICAgICAgICAgJ2JvcmRlcjogMXB4IHNvbGlkIHdoaXRlOycgK1xuICAgICAgICAgICAgJ2JveC1zaXppbmc6IGNvbnRlbnQtYm94OycgK1xuICAgICAgICAgICAgJ3otaW5kZXg6IDEwMDAwOycgK1xuICAgICAgICAgICAgJ30nICtcbiAgICAgICAgICAgICcuanFzZmllbGQgeyAnICtcbiAgICAgICAgICAgICdjb2xvcjogd2hpdGU7JyArXG4gICAgICAgICAgICAnZm9udDogMTBweCBhcmlhbCwgc2FuIHNlcmlmOycgK1xuICAgICAgICAgICAgJ3RleHQtYWxpZ246IGxlZnQ7JyArXG4gICAgICAgICAgICAnfSc7XG5cbiAgICAvKipcbiAgICAgKiBVdGlsaXRpZXNcbiAgICAgKi9cblxuICAgIGNyZWF0ZUNsYXNzID0gZnVuY3Rpb24gKC8qIFtiYXNlY2xhc3MsIFttaXhpbiwgLi4uXV0sIGRlZmluaXRpb24gKi8pIHtcbiAgICAgICAgdmFyIENsYXNzLCBhcmdzO1xuICAgICAgICBDbGFzcyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHRoaXMuaW5pdC5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICAgICAgICB9O1xuICAgICAgICBpZiAoYXJndW1lbnRzLmxlbmd0aCA+IDEpIHtcbiAgICAgICAgICAgIGlmIChhcmd1bWVudHNbMF0pIHtcbiAgICAgICAgICAgICAgICBDbGFzcy5wcm90b3R5cGUgPSAkLmV4dGVuZChuZXcgYXJndW1lbnRzWzBdKCksIGFyZ3VtZW50c1thcmd1bWVudHMubGVuZ3RoIC0gMV0pO1xuICAgICAgICAgICAgICAgIENsYXNzLl9zdXBlciA9IGFyZ3VtZW50c1swXS5wcm90b3R5cGU7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIENsYXNzLnByb3RvdHlwZSA9IGFyZ3VtZW50c1thcmd1bWVudHMubGVuZ3RoIC0gMV07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoYXJndW1lbnRzLmxlbmd0aCA+IDIpIHtcbiAgICAgICAgICAgICAgICBhcmdzID0gQXJyYXkucHJvdG90eXBlLnNsaWNlLmNhbGwoYXJndW1lbnRzLCAxLCAtMSk7XG4gICAgICAgICAgICAgICAgYXJncy51bnNoaWZ0KENsYXNzLnByb3RvdHlwZSk7XG4gICAgICAgICAgICAgICAgJC5leHRlbmQuYXBwbHkoJCwgYXJncyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBDbGFzcy5wcm90b3R5cGUgPSBhcmd1bWVudHNbMF07XG4gICAgICAgIH1cbiAgICAgICAgQ2xhc3MucHJvdG90eXBlLmNscyA9IENsYXNzO1xuICAgICAgICByZXR1cm4gQ2xhc3M7XG4gICAgfTtcblxuICAgIC8qKlxuICAgICAqIFdyYXBzIGEgZm9ybWF0IHN0cmluZyBmb3IgdG9vbHRpcHNcbiAgICAgKiB7e3h9fVxuICAgICAqIHt7eC4yfVxuICAgICAqIHt7eDptb250aHN9fVxuICAgICAqL1xuICAgICQuU1BGb3JtYXRDbGFzcyA9IFNQRm9ybWF0ID0gY3JlYXRlQ2xhc3Moe1xuICAgICAgICBmcmU6IC9cXHtcXHsoW1xcdy5dKz8pKDooLis/KSk/XFx9XFx9L2csXG4gICAgICAgIHByZWNyZTogLyhcXHcrKVxcLihcXGQrKS8sXG5cbiAgICAgICAgaW5pdDogZnVuY3Rpb24gKGZvcm1hdCwgZmNsYXNzKSB7XG4gICAgICAgICAgICB0aGlzLmZvcm1hdCA9IGZvcm1hdDtcbiAgICAgICAgICAgIHRoaXMuZmNsYXNzID0gZmNsYXNzO1xuICAgICAgICB9LFxuXG4gICAgICAgIHJlbmRlcjogZnVuY3Rpb24gKGZpZWxkc2V0LCBsb29rdXBzLCBvcHRpb25zKSB7XG4gICAgICAgICAgICB2YXIgc2VsZiA9IHRoaXMsXG4gICAgICAgICAgICAgICAgZmllbGRzID0gZmllbGRzZXQsXG4gICAgICAgICAgICAgICAgbWF0Y2gsIHRva2VuLCBsb29rdXBrZXksIGZpZWxkdmFsdWUsIHByZWM7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5mb3JtYXQucmVwbGFjZSh0aGlzLmZyZSwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIHZhciBsb29rdXA7XG4gICAgICAgICAgICAgICAgdG9rZW4gPSBhcmd1bWVudHNbMV07XG4gICAgICAgICAgICAgICAgbG9va3Vwa2V5ID0gYXJndW1lbnRzWzNdO1xuICAgICAgICAgICAgICAgIG1hdGNoID0gc2VsZi5wcmVjcmUuZXhlYyh0b2tlbik7XG4gICAgICAgICAgICAgICAgaWYgKG1hdGNoKSB7XG4gICAgICAgICAgICAgICAgICAgIHByZWMgPSBtYXRjaFsyXTtcbiAgICAgICAgICAgICAgICAgICAgdG9rZW4gPSBtYXRjaFsxXTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBwcmVjID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGZpZWxkdmFsdWUgPSBmaWVsZHNbdG9rZW5dO1xuICAgICAgICAgICAgICAgIGlmIChmaWVsZHZhbHVlID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuICcnO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAobG9va3Vwa2V5ICYmIGxvb2t1cHMgJiYgbG9va3Vwc1tsb29rdXBrZXldKSB7XG4gICAgICAgICAgICAgICAgICAgIGxvb2t1cCA9IGxvb2t1cHNbbG9va3Vwa2V5XTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGxvb2t1cC5nZXQpIHsgLy8gUmFuZ2VNYXBcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBsb29rdXBzW2xvb2t1cGtleV0uZ2V0KGZpZWxkdmFsdWUpIHx8IGZpZWxkdmFsdWU7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gbG9va3Vwc1tsb29rdXBrZXldW2ZpZWxkdmFsdWVdIHx8IGZpZWxkdmFsdWU7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKGlzTnVtYmVyKGZpZWxkdmFsdWUpKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChvcHRpb25zLmdldCgnbnVtYmVyRm9ybWF0dGVyJykpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpZWxkdmFsdWUgPSBvcHRpb25zLmdldCgnbnVtYmVyRm9ybWF0dGVyJykoZmllbGR2YWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBmaWVsZHZhbHVlID0gZm9ybWF0TnVtYmVyKGZpZWxkdmFsdWUsIHByZWMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucy5nZXQoJ251bWJlckRpZ2l0R3JvdXBDb3VudCcpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnMuZ2V0KCdudW1iZXJEaWdpdEdyb3VwU2VwJyksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucy5nZXQoJ251bWJlckRlY2ltYWxNYXJrJykpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiBmaWVsZHZhbHVlO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9KTtcblxuICAgIC8vIGNvbnZpZW5jZSBtZXRob2QgdG8gYXZvaWQgbmVlZGluZyB0aGUgbmV3IG9wZXJhdG9yXG4gICAgJC5zcGZvcm1hdCA9IGZ1bmN0aW9uKGZvcm1hdCwgZmNsYXNzKSB7XG4gICAgICAgIHJldHVybiBuZXcgU1BGb3JtYXQoZm9ybWF0LCBmY2xhc3MpO1xuICAgIH07XG5cbiAgICBjbGlwdmFsID0gZnVuY3Rpb24gKHZhbCwgbWluLCBtYXgpIHtcbiAgICAgICAgaWYgKHZhbCA8IG1pbikge1xuICAgICAgICAgICAgcmV0dXJuIG1pbjtcbiAgICAgICAgfVxuICAgICAgICBpZiAodmFsID4gbWF4KSB7XG4gICAgICAgICAgICByZXR1cm4gbWF4O1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB2YWw7XG4gICAgfTtcblxuICAgIHF1YXJ0aWxlID0gZnVuY3Rpb24gKHZhbHVlcywgcSkge1xuICAgICAgICB2YXIgdmw7XG4gICAgICAgIGlmIChxID09PSAyKSB7XG4gICAgICAgICAgICB2bCA9IE1hdGguZmxvb3IodmFsdWVzLmxlbmd0aCAvIDIpO1xuICAgICAgICAgICAgcmV0dXJuIHZhbHVlcy5sZW5ndGggJSAyID8gdmFsdWVzW3ZsXSA6ICh2YWx1ZXNbdmwtMV0gKyB2YWx1ZXNbdmxdKSAvIDI7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBpZiAodmFsdWVzLmxlbmd0aCAlIDIgKSB7IC8vIG9kZFxuICAgICAgICAgICAgICAgIHZsID0gKHZhbHVlcy5sZW5ndGggKiBxICsgcSkgLyA0O1xuICAgICAgICAgICAgICAgIHJldHVybiB2bCAlIDEgPyAodmFsdWVzW01hdGguZmxvb3IodmwpXSArIHZhbHVlc1tNYXRoLmZsb29yKHZsKSAtIDFdKSAvIDIgOiB2YWx1ZXNbdmwtMV07XG4gICAgICAgICAgICB9IGVsc2UgeyAvL2V2ZW5cbiAgICAgICAgICAgICAgICB2bCA9ICh2YWx1ZXMubGVuZ3RoICogcSArIDIpIC8gNDtcbiAgICAgICAgICAgICAgICByZXR1cm4gdmwgJSAxID8gKHZhbHVlc1tNYXRoLmZsb29yKHZsKV0gKyB2YWx1ZXNbTWF0aC5mbG9vcih2bCkgLSAxXSkgLyAyIDogIHZhbHVlc1t2bC0xXTtcblxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfTtcblxuICAgIG5vcm1hbGl6ZVZhbHVlID0gZnVuY3Rpb24gKHZhbCkge1xuICAgICAgICB2YXIgbmY7XG4gICAgICAgIHN3aXRjaCAodmFsKSB7XG4gICAgICAgICAgICBjYXNlICd1bmRlZmluZWQnOlxuICAgICAgICAgICAgICAgIHZhbCA9IHVuZGVmaW5lZDtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ251bGwnOlxuICAgICAgICAgICAgICAgIHZhbCA9IG51bGw7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICd0cnVlJzpcbiAgICAgICAgICAgICAgICB2YWwgPSB0cnVlO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnZmFsc2UnOlxuICAgICAgICAgICAgICAgIHZhbCA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICBuZiA9IHBhcnNlRmxvYXQodmFsKTtcbiAgICAgICAgICAgICAgICBpZiAodmFsID09IG5mKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhbCA9IG5mO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdmFsO1xuICAgIH07XG5cbiAgICBub3JtYWxpemVWYWx1ZXMgPSBmdW5jdGlvbiAodmFscykge1xuICAgICAgICB2YXIgaSwgcmVzdWx0ID0gW107XG4gICAgICAgIGZvciAoaSA9IHZhbHMubGVuZ3RoOyBpLS07KSB7XG4gICAgICAgICAgICByZXN1bHRbaV0gPSBub3JtYWxpemVWYWx1ZSh2YWxzW2ldKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH07XG5cbiAgICByZW1vdmUgPSBmdW5jdGlvbiAodmFscywgZmlsdGVyKSB7XG4gICAgICAgIHZhciBpLCB2bCwgcmVzdWx0ID0gW107XG4gICAgICAgIGZvciAoaSA9IDAsIHZsID0gdmFscy5sZW5ndGg7IGkgPCB2bDsgaSsrKSB7XG4gICAgICAgICAgICBpZiAodmFsc1tpXSAhPT0gZmlsdGVyKSB7XG4gICAgICAgICAgICAgICAgcmVzdWx0LnB1c2godmFsc1tpXSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9O1xuXG4gICAgaXNOdW1iZXIgPSBmdW5jdGlvbiAobnVtKSB7XG4gICAgICAgIHJldHVybiAhaXNOYU4ocGFyc2VGbG9hdChudW0pKSAmJiBpc0Zpbml0ZShudW0pO1xuICAgIH07XG5cbiAgICBmb3JtYXROdW1iZXIgPSBmdW5jdGlvbiAobnVtLCBwcmVjLCBncm91cHNpemUsIGdyb3Vwc2VwLCBkZWNzZXApIHtcbiAgICAgICAgdmFyIHAsIGk7XG4gICAgICAgIG51bSA9IChwcmVjID09PSBmYWxzZSA/IHBhcnNlRmxvYXQobnVtKS50b1N0cmluZygpIDogbnVtLnRvRml4ZWQocHJlYykpLnNwbGl0KCcnKTtcbiAgICAgICAgcCA9IChwID0gJC5pbkFycmF5KCcuJywgbnVtKSkgPCAwID8gbnVtLmxlbmd0aCA6IHA7XG4gICAgICAgIGlmIChwIDwgbnVtLmxlbmd0aCkge1xuICAgICAgICAgICAgbnVtW3BdID0gZGVjc2VwO1xuICAgICAgICB9XG4gICAgICAgIGZvciAoaSA9IHAgLSBncm91cHNpemU7IGkgPiAwOyBpIC09IGdyb3Vwc2l6ZSkge1xuICAgICAgICAgICAgbnVtLnNwbGljZShpLCAwLCBncm91cHNlcCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG51bS5qb2luKCcnKTtcbiAgICB9O1xuXG4gICAgLy8gZGV0ZXJtaW5lIGlmIGFsbCB2YWx1ZXMgb2YgYW4gYXJyYXkgbWF0Y2ggYSB2YWx1ZVxuICAgIC8vIHJldHVybnMgdHJ1ZSBpZiB0aGUgYXJyYXkgaXMgZW1wdHlcbiAgICBhbGwgPSBmdW5jdGlvbiAodmFsLCBhcnIsIGlnbm9yZU51bGwpIHtcbiAgICAgICAgdmFyIGk7XG4gICAgICAgIGZvciAoaSA9IGFyci5sZW5ndGg7IGktLTsgKSB7XG4gICAgICAgICAgICBpZiAoaWdub3JlTnVsbCAmJiBhcnJbaV0gPT09IG51bGwpIGNvbnRpbnVlO1xuICAgICAgICAgICAgaWYgKGFycltpXSAhPT0gdmFsKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH07XG5cbiAgICAvLyBzdW1zIHRoZSBudW1lcmljIHZhbHVlcyBpbiBhbiBhcnJheSwgaWdub3Jpbmcgb3RoZXIgdmFsdWVzXG4gICAgc3VtID0gZnVuY3Rpb24gKHZhbHMpIHtcbiAgICAgICAgdmFyIHRvdGFsID0gMCwgaTtcbiAgICAgICAgZm9yIChpID0gdmFscy5sZW5ndGg7IGktLTspIHtcbiAgICAgICAgICAgIHRvdGFsICs9IHR5cGVvZiB2YWxzW2ldID09PSAnbnVtYmVyJyA/IHZhbHNbaV0gOiAwO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0b3RhbDtcbiAgICB9O1xuXG4gICAgZW5zdXJlQXJyYXkgPSBmdW5jdGlvbiAodmFsKSB7XG4gICAgICAgIHJldHVybiAkLmlzQXJyYXkodmFsKSA/IHZhbCA6IFt2YWxdO1xuICAgIH07XG5cbiAgICAvLyBodHRwOi8vcGF1bGlyaXNoLmNvbS8yMDA4L2Jvb2ttYXJrbGV0LWluamVjdC1uZXctY3NzLXJ1bGVzL1xuICAgIGFkZENTUyA9IGZ1bmN0aW9uKGNzcykge1xuICAgICAgICB2YXIgdGFnLCBpZWZhaWw7XG4gICAgICAgIGlmIChkb2N1bWVudC5jcmVhdGVTdHlsZVNoZWV0KSB7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGRvY3VtZW50LmNyZWF0ZVN0eWxlU2hlZXQoKS5jc3NUZXh0ID0gY3NzO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICAvLyBJRSA8PSA5IG1heGVzIG91dCBhdCAzMSBzdHlsZXNoZWV0czsgaW5qZWN0IGludG8gcGFnZSBpbnN0ZWFkLlxuICAgICAgICAgICAgICAgIGllZmFpbCA9IHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdGFnID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3R5bGUnKTtcbiAgICAgICAgdGFnLnR5cGUgPSAndGV4dC9jc3MnO1xuICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50c0J5VGFnTmFtZSgnaGVhZCcpWzBdLmFwcGVuZENoaWxkKHRhZyk7XG4gICAgICAgIGlmIChpZWZhaWwpIHtcbiAgICAgICAgICAgIGRvY3VtZW50LnN0eWxlU2hlZXRzW2RvY3VtZW50LnN0eWxlU2hlZXRzLmxlbmd0aCAtIDFdLmNzc1RleHQgPSBjc3M7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0YWdbKHR5cGVvZiBkb2N1bWVudC5ib2R5LnN0eWxlLldlYmtpdEFwcGVhcmFuY2UgPT0gJ3N0cmluZycpIC8qIHdlYmtpdCBvbmx5ICovID8gJ2lubmVyVGV4dCcgOiAnaW5uZXJIVE1MJ10gPSBjc3M7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgLy8gUHJvdmlkZSBhIGNyb3NzLWJyb3dzZXIgaW50ZXJmYWNlIHRvIGEgZmV3IHNpbXBsZSBkcmF3aW5nIHByaW1pdGl2ZXNcbiAgICAkLmZuLnNpbXBsZWRyYXcgPSBmdW5jdGlvbiAod2lkdGgsIGhlaWdodCwgdXNlRXhpc3RpbmcsIGludGVyYWN0KSB7XG4gICAgICAgIHZhciB0YXJnZXQsIG1oYW5kbGVyO1xuICAgICAgICBpZiAodXNlRXhpc3RpbmcgJiYgKHRhcmdldCA9IHRoaXMuZGF0YSgnX2pxc192Y2FudmFzJykpKSB7XG4gICAgICAgICAgICByZXR1cm4gdGFyZ2V0O1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKCQuZm4uc3BhcmtsaW5lLmNhbnZhcyA9PT0gZmFsc2UpIHtcbiAgICAgICAgICAgIC8vIFdlJ3ZlIGFscmVhZHkgZGV0ZXJtaW5lZCB0aGF0IG5laXRoZXIgQ2FudmFzIG5vciBWTUwgYXJlIGF2YWlsYWJsZVxuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuXG4gICAgICAgIH0gZWxzZSBpZiAoJC5mbi5zcGFya2xpbmUuY2FudmFzID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIC8vIE5vIGZ1bmN0aW9uIGRlZmluZWQgeWV0IC0tIG5lZWQgdG8gc2VlIGlmIHdlIHN1cHBvcnQgQ2FudmFzIG9yIFZNTFxuICAgICAgICAgICAgdmFyIGVsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnY2FudmFzJyk7XG4gICAgICAgICAgICBpZiAoISEoZWwuZ2V0Q29udGV4dCAmJiBlbC5nZXRDb250ZXh0KCcyZCcpKSkge1xuICAgICAgICAgICAgICAgIC8vIENhbnZhcyBpcyBhdmFpbGFibGVcbiAgICAgICAgICAgICAgICAkLmZuLnNwYXJrbGluZS5jYW52YXMgPSBmdW5jdGlvbih3aWR0aCwgaGVpZ2h0LCB0YXJnZXQsIGludGVyYWN0KSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBuZXcgVkNhbnZhc19jYW52YXMod2lkdGgsIGhlaWdodCwgdGFyZ2V0LCBpbnRlcmFjdCk7XG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoZG9jdW1lbnQubmFtZXNwYWNlcyAmJiAhZG9jdW1lbnQubmFtZXNwYWNlcy52KSB7XG4gICAgICAgICAgICAgICAgLy8gVk1MIGlzIGF2YWlsYWJsZVxuICAgICAgICAgICAgICAgIGRvY3VtZW50Lm5hbWVzcGFjZXMuYWRkKCd2JywgJ3VybjpzY2hlbWFzLW1pY3Jvc29mdC1jb206dm1sJywgJyNkZWZhdWx0I1ZNTCcpO1xuICAgICAgICAgICAgICAgICQuZm4uc3BhcmtsaW5lLmNhbnZhcyA9IGZ1bmN0aW9uKHdpZHRoLCBoZWlnaHQsIHRhcmdldCwgaW50ZXJhY3QpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBWQ2FudmFzX3ZtbCh3aWR0aCwgaGVpZ2h0LCB0YXJnZXQpO1xuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIC8vIE5laXRoZXIgQ2FudmFzIG5vciBWTUwgYXJlIGF2YWlsYWJsZVxuICAgICAgICAgICAgICAgICQuZm4uc3BhcmtsaW5lLmNhbnZhcyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGlmICh3aWR0aCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICB3aWR0aCA9ICQodGhpcykuaW5uZXJXaWR0aCgpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChoZWlnaHQgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgaGVpZ2h0ID0gJCh0aGlzKS5pbm5lckhlaWdodCgpO1xuICAgICAgICB9XG5cbiAgICAgICAgdGFyZ2V0ID0gJC5mbi5zcGFya2xpbmUuY2FudmFzKHdpZHRoLCBoZWlnaHQsIHRoaXMsIGludGVyYWN0KTtcblxuICAgICAgICBtaGFuZGxlciA9ICQodGhpcykuZGF0YSgnX2pxc19taGFuZGxlcicpO1xuICAgICAgICBpZiAobWhhbmRsZXIpIHtcbiAgICAgICAgICAgIG1oYW5kbGVyLnJlZ2lzdGVyQ2FudmFzKHRhcmdldCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRhcmdldDtcbiAgICB9O1xuXG4gICAgJC5mbi5jbGVhcmRyYXcgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciB0YXJnZXQgPSB0aGlzLmRhdGEoJ19qcXNfdmNhbnZhcycpO1xuICAgICAgICBpZiAodGFyZ2V0KSB7XG4gICAgICAgICAgICB0YXJnZXQucmVzZXQoKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICAkLlJhbmdlTWFwQ2xhc3MgPSBSYW5nZU1hcCA9IGNyZWF0ZUNsYXNzKHtcbiAgICAgICAgaW5pdDogZnVuY3Rpb24gKG1hcCkge1xuICAgICAgICAgICAgdmFyIGtleSwgcmFuZ2UsIHJhbmdlbGlzdCA9IFtdO1xuICAgICAgICAgICAgZm9yIChrZXkgaW4gbWFwKSB7XG4gICAgICAgICAgICAgICAgaWYgKG1hcC5oYXNPd25Qcm9wZXJ0eShrZXkpICYmIHR5cGVvZiBrZXkgPT09ICdzdHJpbmcnICYmIGtleS5pbmRleE9mKCc6JykgPiAtMSkge1xuICAgICAgICAgICAgICAgICAgICByYW5nZSA9IGtleS5zcGxpdCgnOicpO1xuICAgICAgICAgICAgICAgICAgICByYW5nZVswXSA9IHJhbmdlWzBdLmxlbmd0aCA9PT0gMCA/IC1JbmZpbml0eSA6IHBhcnNlRmxvYXQocmFuZ2VbMF0pO1xuICAgICAgICAgICAgICAgICAgICByYW5nZVsxXSA9IHJhbmdlWzFdLmxlbmd0aCA9PT0gMCA/IEluZmluaXR5IDogcGFyc2VGbG9hdChyYW5nZVsxXSk7XG4gICAgICAgICAgICAgICAgICAgIHJhbmdlWzJdID0gbWFwW2tleV07XG4gICAgICAgICAgICAgICAgICAgIHJhbmdlbGlzdC5wdXNoKHJhbmdlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLm1hcCA9IG1hcDtcbiAgICAgICAgICAgIHRoaXMucmFuZ2VsaXN0ID0gcmFuZ2VsaXN0IHx8IGZhbHNlO1xuICAgICAgICB9LFxuXG4gICAgICAgIGdldDogZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICB2YXIgcmFuZ2VsaXN0ID0gdGhpcy5yYW5nZWxpc3QsXG4gICAgICAgICAgICAgICAgaSwgcmFuZ2UsIHJlc3VsdDtcbiAgICAgICAgICAgIGlmICgocmVzdWx0ID0gdGhpcy5tYXBbdmFsdWVdKSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChyYW5nZWxpc3QpIHtcbiAgICAgICAgICAgICAgICBmb3IgKGkgPSByYW5nZWxpc3QubGVuZ3RoOyBpLS07KSB7XG4gICAgICAgICAgICAgICAgICAgIHJhbmdlID0gcmFuZ2VsaXN0W2ldO1xuICAgICAgICAgICAgICAgICAgICBpZiAocmFuZ2VbMF0gPD0gdmFsdWUgJiYgcmFuZ2VbMV0gPj0gdmFsdWUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiByYW5nZVsyXTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgICAgIH1cbiAgICB9KTtcblxuICAgIC8vIENvbnZlbmllbmNlIGZ1bmN0aW9uXG4gICAgJC5yYW5nZV9tYXAgPSBmdW5jdGlvbihtYXApIHtcbiAgICAgICAgcmV0dXJuIG5ldyBSYW5nZU1hcChtYXApO1xuICAgIH07XG5cbiAgICBNb3VzZUhhbmRsZXIgPSBjcmVhdGVDbGFzcyh7XG4gICAgICAgIGluaXQ6IGZ1bmN0aW9uIChlbCwgb3B0aW9ucykge1xuICAgICAgICAgICAgdmFyICRlbCA9ICQoZWwpO1xuICAgICAgICAgICAgdGhpcy4kZWwgPSAkZWw7XG4gICAgICAgICAgICB0aGlzLm9wdGlvbnMgPSBvcHRpb25zO1xuICAgICAgICAgICAgdGhpcy5jdXJyZW50UGFnZVggPSAwO1xuICAgICAgICAgICAgdGhpcy5jdXJyZW50UGFnZVkgPSAwO1xuICAgICAgICAgICAgdGhpcy5lbCA9IGVsO1xuICAgICAgICAgICAgdGhpcy5zcGxpc3QgPSBbXTtcbiAgICAgICAgICAgIHRoaXMudG9vbHRpcCA9IG51bGw7XG4gICAgICAgICAgICB0aGlzLm92ZXIgPSBmYWxzZTtcbiAgICAgICAgICAgIHRoaXMuZGlzcGxheVRvb2x0aXBzID0gIW9wdGlvbnMuZ2V0KCdkaXNhYmxlVG9vbHRpcHMnKTtcbiAgICAgICAgICAgIHRoaXMuaGlnaGxpZ2h0RW5hYmxlZCA9ICFvcHRpb25zLmdldCgnZGlzYWJsZUhpZ2hsaWdodCcpO1xuICAgICAgICB9LFxuXG4gICAgICAgIHJlZ2lzdGVyU3BhcmtsaW5lOiBmdW5jdGlvbiAoc3ApIHtcbiAgICAgICAgICAgIHRoaXMuc3BsaXN0LnB1c2goc3ApO1xuICAgICAgICAgICAgaWYgKHRoaXMub3Zlcikge1xuICAgICAgICAgICAgICAgIHRoaXMudXBkYXRlRGlzcGxheSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9LFxuXG4gICAgICAgIHJlZ2lzdGVyQ2FudmFzOiBmdW5jdGlvbiAoY2FudmFzKSB7XG4gICAgICAgICAgICB2YXIgJGNhbnZhcyA9ICQoY2FudmFzLmNhbnZhcyk7XG4gICAgICAgICAgICB0aGlzLmNhbnZhcyA9IGNhbnZhcztcbiAgICAgICAgICAgIHRoaXMuJGNhbnZhcyA9ICRjYW52YXM7XG4gICAgICAgICAgICAkY2FudmFzLm1vdXNlZW50ZXIoJC5wcm94eSh0aGlzLm1vdXNlZW50ZXIsIHRoaXMpKTtcbiAgICAgICAgICAgICRjYW52YXMubW91c2VsZWF2ZSgkLnByb3h5KHRoaXMubW91c2VsZWF2ZSwgdGhpcykpO1xuICAgICAgICAgICAgJGNhbnZhcy5jbGljaygkLnByb3h5KHRoaXMubW91c2VjbGljaywgdGhpcykpO1xuICAgICAgICB9LFxuXG4gICAgICAgIHJlc2V0OiBmdW5jdGlvbiAocmVtb3ZlVG9vbHRpcCkge1xuICAgICAgICAgICAgdGhpcy5zcGxpc3QgPSBbXTtcbiAgICAgICAgICAgIGlmICh0aGlzLnRvb2x0aXAgJiYgcmVtb3ZlVG9vbHRpcCkge1xuICAgICAgICAgICAgICAgIHRoaXMudG9vbHRpcC5yZW1vdmUoKTtcbiAgICAgICAgICAgICAgICB0aGlzLnRvb2x0aXAgPSB1bmRlZmluZWQ7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0sXG5cbiAgICAgICAgbW91c2VjbGljazogZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgICAgIHZhciBjbGlja0V2ZW50ID0gJC5FdmVudCgnc3BhcmtsaW5lQ2xpY2snKTtcbiAgICAgICAgICAgIGNsaWNrRXZlbnQub3JpZ2luYWxFdmVudCA9IGU7XG4gICAgICAgICAgICBjbGlja0V2ZW50LnNwYXJrbGluZXMgPSB0aGlzLnNwbGlzdDtcbiAgICAgICAgICAgIHRoaXMuJGVsLnRyaWdnZXIoY2xpY2tFdmVudCk7XG4gICAgICAgIH0sXG5cbiAgICAgICAgbW91c2VlbnRlcjogZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgICAgICQoZG9jdW1lbnQuYm9keSkudW5iaW5kKCdtb3VzZW1vdmUuanFzJyk7XG4gICAgICAgICAgICAkKGRvY3VtZW50LmJvZHkpLmJpbmQoJ21vdXNlbW92ZS5qcXMnLCAkLnByb3h5KHRoaXMubW91c2Vtb3ZlLCB0aGlzKSk7XG4gICAgICAgICAgICB0aGlzLm92ZXIgPSB0cnVlO1xuICAgICAgICAgICAgdGhpcy5jdXJyZW50UGFnZVggPSBlLnBhZ2VYO1xuICAgICAgICAgICAgdGhpcy5jdXJyZW50UGFnZVkgPSBlLnBhZ2VZO1xuICAgICAgICAgICAgdGhpcy5jdXJyZW50RWwgPSBlLnRhcmdldDtcbiAgICAgICAgICAgIGlmICghdGhpcy50b29sdGlwICYmIHRoaXMuZGlzcGxheVRvb2x0aXBzKSB7XG4gICAgICAgICAgICAgICAgdGhpcy50b29sdGlwID0gbmV3IFRvb2x0aXAodGhpcy5vcHRpb25zKTtcbiAgICAgICAgICAgICAgICB0aGlzLnRvb2x0aXAudXBkYXRlUG9zaXRpb24oZS5wYWdlWCwgZS5wYWdlWSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLnVwZGF0ZURpc3BsYXkoKTtcbiAgICAgICAgfSxcblxuICAgICAgICBtb3VzZWxlYXZlOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAkKGRvY3VtZW50LmJvZHkpLnVuYmluZCgnbW91c2Vtb3ZlLmpxcycpO1xuICAgICAgICAgICAgdmFyIHNwbGlzdCA9IHRoaXMuc3BsaXN0LFxuICAgICAgICAgICAgICAgICBzcGNvdW50ID0gc3BsaXN0Lmxlbmd0aCxcbiAgICAgICAgICAgICAgICAgbmVlZHNSZWZyZXNoID0gZmFsc2UsXG4gICAgICAgICAgICAgICAgIHNwLCBpO1xuICAgICAgICAgICAgdGhpcy5vdmVyID0gZmFsc2U7XG4gICAgICAgICAgICB0aGlzLmN1cnJlbnRFbCA9IG51bGw7XG5cbiAgICAgICAgICAgIGlmICh0aGlzLnRvb2x0aXApIHtcbiAgICAgICAgICAgICAgICB0aGlzLnRvb2x0aXAucmVtb3ZlKCk7XG4gICAgICAgICAgICAgICAgdGhpcy50b29sdGlwID0gbnVsbDtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgZm9yIChpID0gMDsgaSA8IHNwY291bnQ7IGkrKykge1xuICAgICAgICAgICAgICAgIHNwID0gc3BsaXN0W2ldO1xuICAgICAgICAgICAgICAgIGlmIChzcC5jbGVhclJlZ2lvbkhpZ2hsaWdodCgpKSB7XG4gICAgICAgICAgICAgICAgICAgIG5lZWRzUmVmcmVzaCA9IHRydWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAobmVlZHNSZWZyZXNoKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5jYW52YXMucmVuZGVyKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0sXG5cbiAgICAgICAgbW91c2Vtb3ZlOiBmdW5jdGlvbiAoZSkge1xuICAgICAgICAgICAgdGhpcy5jdXJyZW50UGFnZVggPSBlLnBhZ2VYO1xuICAgICAgICAgICAgdGhpcy5jdXJyZW50UGFnZVkgPSBlLnBhZ2VZO1xuICAgICAgICAgICAgdGhpcy5jdXJyZW50RWwgPSBlLnRhcmdldDtcbiAgICAgICAgICAgIGlmICh0aGlzLnRvb2x0aXApIHtcbiAgICAgICAgICAgICAgICB0aGlzLnRvb2x0aXAudXBkYXRlUG9zaXRpb24oZS5wYWdlWCwgZS5wYWdlWSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLnVwZGF0ZURpc3BsYXkoKTtcbiAgICAgICAgfSxcblxuICAgICAgICB1cGRhdGVEaXNwbGF5OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB2YXIgc3BsaXN0ID0gdGhpcy5zcGxpc3QsXG4gICAgICAgICAgICAgICAgIHNwY291bnQgPSBzcGxpc3QubGVuZ3RoLFxuICAgICAgICAgICAgICAgICBuZWVkc1JlZnJlc2ggPSBmYWxzZSxcbiAgICAgICAgICAgICAgICAgb2Zmc2V0ID0gdGhpcy4kY2FudmFzLm9mZnNldCgpLFxuICAgICAgICAgICAgICAgICBsb2NhbFggPSB0aGlzLmN1cnJlbnRQYWdlWCAtIG9mZnNldC5sZWZ0LFxuICAgICAgICAgICAgICAgICBsb2NhbFkgPSB0aGlzLmN1cnJlbnRQYWdlWSAtIG9mZnNldC50b3AsXG4gICAgICAgICAgICAgICAgIHRvb2x0aXBodG1sLCBzcCwgaSwgcmVzdWx0LCBjaGFuZ2VFdmVudDtcbiAgICAgICAgICAgIGlmICghdGhpcy5vdmVyKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZm9yIChpID0gMDsgaSA8IHNwY291bnQ7IGkrKykge1xuICAgICAgICAgICAgICAgIHNwID0gc3BsaXN0W2ldO1xuICAgICAgICAgICAgICAgIHJlc3VsdCA9IHNwLnNldFJlZ2lvbkhpZ2hsaWdodCh0aGlzLmN1cnJlbnRFbCwgbG9jYWxYLCBsb2NhbFkpO1xuICAgICAgICAgICAgICAgIGlmIChyZXN1bHQpIHtcbiAgICAgICAgICAgICAgICAgICAgbmVlZHNSZWZyZXNoID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAobmVlZHNSZWZyZXNoKSB7XG4gICAgICAgICAgICAgICAgY2hhbmdlRXZlbnQgPSAkLkV2ZW50KCdzcGFya2xpbmVSZWdpb25DaGFuZ2UnKTtcbiAgICAgICAgICAgICAgICBjaGFuZ2VFdmVudC5zcGFya2xpbmVzID0gdGhpcy5zcGxpc3Q7XG4gICAgICAgICAgICAgICAgdGhpcy4kZWwudHJpZ2dlcihjaGFuZ2VFdmVudCk7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMudG9vbHRpcCkge1xuICAgICAgICAgICAgICAgICAgICB0b29sdGlwaHRtbCA9ICcnO1xuICAgICAgICAgICAgICAgICAgICBmb3IgKGkgPSAwOyBpIDwgc3Bjb3VudDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzcCA9IHNwbGlzdFtpXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRvb2x0aXBodG1sICs9IHNwLmdldEN1cnJlbnRSZWdpb25Ub29sdGlwKCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgdGhpcy50b29sdGlwLnNldENvbnRlbnQodG9vbHRpcGh0bWwpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAoIXRoaXMuZGlzYWJsZUhpZ2hsaWdodCkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmNhbnZhcy5yZW5kZXIoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAocmVzdWx0ID09PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5tb3VzZWxlYXZlKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9KTtcblxuXG4gICAgVG9vbHRpcCA9IGNyZWF0ZUNsYXNzKHtcbiAgICAgICAgc2l6ZVN0eWxlOiAncG9zaXRpb246IHN0YXRpYyAhaW1wb3J0YW50OycgK1xuICAgICAgICAgICAgJ2Rpc3BsYXk6IGJsb2NrICFpbXBvcnRhbnQ7JyArXG4gICAgICAgICAgICAndmlzaWJpbGl0eTogaGlkZGVuICFpbXBvcnRhbnQ7JyArXG4gICAgICAgICAgICAnZmxvYXQ6IGxlZnQgIWltcG9ydGFudDsnLFxuXG4gICAgICAgIGluaXQ6IGZ1bmN0aW9uIChvcHRpb25zKSB7XG4gICAgICAgICAgICB2YXIgdG9vbHRpcENsYXNzbmFtZSA9IG9wdGlvbnMuZ2V0KCd0b29sdGlwQ2xhc3NuYW1lJywgJ2pxc3Rvb2x0aXAnKSxcbiAgICAgICAgICAgICAgICBzaXpldGlwU3R5bGUgPSB0aGlzLnNpemVTdHlsZSxcbiAgICAgICAgICAgICAgICBvZmZzZXQ7XG4gICAgICAgICAgICB0aGlzLmNvbnRhaW5lciA9IG9wdGlvbnMuZ2V0KCd0b29sdGlwQ29udGFpbmVyJykgfHwgZG9jdW1lbnQuYm9keTtcbiAgICAgICAgICAgIHRoaXMudG9vbHRpcE9mZnNldFggPSBvcHRpb25zLmdldCgndG9vbHRpcE9mZnNldFgnLCAxMCk7XG4gICAgICAgICAgICB0aGlzLnRvb2x0aXBPZmZzZXRZID0gb3B0aW9ucy5nZXQoJ3Rvb2x0aXBPZmZzZXRZJywgMTIpO1xuICAgICAgICAgICAgLy8gcmVtb3ZlIGFueSBwcmV2aW91cyBsaW5nZXJpbmcgdG9vbHRpcFxuICAgICAgICAgICAgJCgnI2pxc3NpemV0aXAnKS5yZW1vdmUoKTtcbiAgICAgICAgICAgICQoJyNqcXN0b29sdGlwJykucmVtb3ZlKCk7XG4gICAgICAgICAgICB0aGlzLnNpemV0aXAgPSAkKCc8ZGl2Lz4nLCB7XG4gICAgICAgICAgICAgICAgaWQ6ICdqcXNzaXpldGlwJyxcbiAgICAgICAgICAgICAgICBzdHlsZTogc2l6ZXRpcFN0eWxlLFxuICAgICAgICAgICAgICAgICdjbGFzcyc6IHRvb2x0aXBDbGFzc25hbWVcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdGhpcy50b29sdGlwID0gJCgnPGRpdi8+Jywge1xuICAgICAgICAgICAgICAgIGlkOiAnanFzdG9vbHRpcCcsXG4gICAgICAgICAgICAgICAgJ2NsYXNzJzogdG9vbHRpcENsYXNzbmFtZVxuICAgICAgICAgICAgfSkuYXBwZW5kVG8odGhpcy5jb250YWluZXIpO1xuICAgICAgICAgICAgLy8gYWNjb3VudCBmb3IgdGhlIGNvbnRhaW5lcidzIGxvY2F0aW9uXG4gICAgICAgICAgICBvZmZzZXQgPSB0aGlzLnRvb2x0aXAub2Zmc2V0KCk7XG4gICAgICAgICAgICB0aGlzLm9mZnNldExlZnQgPSBvZmZzZXQubGVmdDtcbiAgICAgICAgICAgIHRoaXMub2Zmc2V0VG9wID0gb2Zmc2V0LnRvcDtcbiAgICAgICAgICAgIHRoaXMuaGlkZGVuID0gdHJ1ZTtcbiAgICAgICAgICAgICQod2luZG93KS51bmJpbmQoJ3Jlc2l6ZS5qcXMgc2Nyb2xsLmpxcycpO1xuICAgICAgICAgICAgJCh3aW5kb3cpLmJpbmQoJ3Jlc2l6ZS5qcXMgc2Nyb2xsLmpxcycsICQucHJveHkodGhpcy51cGRhdGVXaW5kb3dEaW1zLCB0aGlzKSk7XG4gICAgICAgICAgICB0aGlzLnVwZGF0ZVdpbmRvd0RpbXMoKTtcbiAgICAgICAgfSxcblxuICAgICAgICB1cGRhdGVXaW5kb3dEaW1zOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB0aGlzLnNjcm9sbFRvcCA9ICQod2luZG93KS5zY3JvbGxUb3AoKTtcbiAgICAgICAgICAgIHRoaXMuc2Nyb2xsTGVmdCA9ICQod2luZG93KS5zY3JvbGxMZWZ0KCk7XG4gICAgICAgICAgICB0aGlzLnNjcm9sbFJpZ2h0ID0gdGhpcy5zY3JvbGxMZWZ0ICsgJCh3aW5kb3cpLndpZHRoKCk7XG4gICAgICAgICAgICB0aGlzLnVwZGF0ZVBvc2l0aW9uKCk7XG4gICAgICAgIH0sXG5cbiAgICAgICAgZ2V0U2l6ZTogZnVuY3Rpb24gKGNvbnRlbnQpIHtcbiAgICAgICAgICAgIHRoaXMuc2l6ZXRpcC5odG1sKGNvbnRlbnQpLmFwcGVuZFRvKHRoaXMuY29udGFpbmVyKTtcbiAgICAgICAgICAgIHRoaXMud2lkdGggPSB0aGlzLnNpemV0aXAud2lkdGgoKSArIDE7XG4gICAgICAgICAgICB0aGlzLmhlaWdodCA9IHRoaXMuc2l6ZXRpcC5oZWlnaHQoKTtcbiAgICAgICAgICAgIHRoaXMuc2l6ZXRpcC5yZW1vdmUoKTtcbiAgICAgICAgfSxcblxuICAgICAgICBzZXRDb250ZW50OiBmdW5jdGlvbiAoY29udGVudCkge1xuICAgICAgICAgICAgaWYgKCFjb250ZW50KSB7XG4gICAgICAgICAgICAgICAgdGhpcy50b29sdGlwLmNzcygndmlzaWJpbGl0eScsICdoaWRkZW4nKTtcbiAgICAgICAgICAgICAgICB0aGlzLmhpZGRlbiA9IHRydWU7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5nZXRTaXplKGNvbnRlbnQpO1xuICAgICAgICAgICAgdGhpcy50b29sdGlwLmh0bWwoY29udGVudClcbiAgICAgICAgICAgICAgICAuY3NzKHtcbiAgICAgICAgICAgICAgICAgICAgJ3dpZHRoJzogdGhpcy53aWR0aCxcbiAgICAgICAgICAgICAgICAgICAgJ2hlaWdodCc6IHRoaXMuaGVpZ2h0LFxuICAgICAgICAgICAgICAgICAgICAndmlzaWJpbGl0eSc6ICd2aXNpYmxlJ1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgaWYgKHRoaXMuaGlkZGVuKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5oaWRkZW4gPSBmYWxzZTtcbiAgICAgICAgICAgICAgICB0aGlzLnVwZGF0ZVBvc2l0aW9uKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0sXG5cbiAgICAgICAgdXBkYXRlUG9zaXRpb246IGZ1bmN0aW9uICh4LCB5KSB7XG4gICAgICAgICAgICBpZiAoeCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubW91c2V4ID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB4ID0gdGhpcy5tb3VzZXggLSB0aGlzLm9mZnNldExlZnQ7XG4gICAgICAgICAgICAgICAgeSA9IHRoaXMubW91c2V5IC0gdGhpcy5vZmZzZXRUb3A7XG5cbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhpcy5tb3VzZXggPSB4ID0geCAtIHRoaXMub2Zmc2V0TGVmdDtcbiAgICAgICAgICAgICAgICB0aGlzLm1vdXNleSA9IHkgPSB5IC0gdGhpcy5vZmZzZXRUb3A7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoIXRoaXMuaGVpZ2h0IHx8ICF0aGlzLndpZHRoIHx8IHRoaXMuaGlkZGVuKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB5IC09IHRoaXMuaGVpZ2h0ICsgdGhpcy50b29sdGlwT2Zmc2V0WTtcbiAgICAgICAgICAgIHggKz0gdGhpcy50b29sdGlwT2Zmc2V0WDtcblxuICAgICAgICAgICAgaWYgKHkgPCB0aGlzLnNjcm9sbFRvcCkge1xuICAgICAgICAgICAgICAgIHkgPSB0aGlzLnNjcm9sbFRvcDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICh4IDwgdGhpcy5zY3JvbGxMZWZ0KSB7XG4gICAgICAgICAgICAgICAgeCA9IHRoaXMuc2Nyb2xsTGVmdDtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoeCArIHRoaXMud2lkdGggPiB0aGlzLnNjcm9sbFJpZ2h0KSB7XG4gICAgICAgICAgICAgICAgeCA9IHRoaXMuc2Nyb2xsUmlnaHQgLSB0aGlzLndpZHRoO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB0aGlzLnRvb2x0aXAuY3NzKHtcbiAgICAgICAgICAgICAgICAnbGVmdCc6IHgsXG4gICAgICAgICAgICAgICAgJ3RvcCc6IHlcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9LFxuXG4gICAgICAgIHJlbW92ZTogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdGhpcy50b29sdGlwLnJlbW92ZSgpO1xuICAgICAgICAgICAgdGhpcy5zaXpldGlwLnJlbW92ZSgpO1xuICAgICAgICAgICAgdGhpcy5zaXpldGlwID0gdGhpcy50b29sdGlwID0gdW5kZWZpbmVkO1xuICAgICAgICAgICAgJCh3aW5kb3cpLnVuYmluZCgncmVzaXplLmpxcyBzY3JvbGwuanFzJyk7XG4gICAgICAgIH1cbiAgICB9KTtcblxuICAgIGluaXRTdHlsZXMgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgYWRkQ1NTKGRlZmF1bHRTdHlsZXMpO1xuICAgIH07XG5cbiAgICAkKGluaXRTdHlsZXMpO1xuXG4gICAgcGVuZGluZyA9IFtdO1xuICAgICQuZm4uc3BhcmtsaW5lID0gZnVuY3Rpb24gKHVzZXJWYWx1ZXMsIHVzZXJPcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmVhY2goZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdmFyIG9wdGlvbnMgPSBuZXcgJC5mbi5zcGFya2xpbmUub3B0aW9ucyh0aGlzLCB1c2VyT3B0aW9ucyksXG4gICAgICAgICAgICAgICAgICR0aGlzID0gJCh0aGlzKSxcbiAgICAgICAgICAgICAgICAgcmVuZGVyLCBpO1xuICAgICAgICAgICAgcmVuZGVyID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIHZhciB2YWx1ZXMsIHdpZHRoLCBoZWlnaHQsIHRtcCwgbWhhbmRsZXIsIHNwLCB2YWxzO1xuICAgICAgICAgICAgICAgIGlmICh1c2VyVmFsdWVzID09PSAnaHRtbCcgfHwgdXNlclZhbHVlcyA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhbHMgPSB0aGlzLmdldEF0dHJpYnV0ZShvcHRpb25zLmdldCgndGFnVmFsdWVzQXR0cmlidXRlJykpO1xuICAgICAgICAgICAgICAgICAgICBpZiAodmFscyA9PT0gdW5kZWZpbmVkIHx8IHZhbHMgPT09IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHMgPSAkdGhpcy5odG1sKCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgdmFsdWVzID0gdmFscy5yZXBsYWNlKC8oXlxccyo8IS0tKXwoLS0+XFxzKiQpfFxccysvZywgJycpLnNwbGl0KCcsJyk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgdmFsdWVzID0gdXNlclZhbHVlcztcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICB3aWR0aCA9IG9wdGlvbnMuZ2V0KCd3aWR0aCcpID09PSAnYXV0bycgPyB2YWx1ZXMubGVuZ3RoICogb3B0aW9ucy5nZXQoJ2RlZmF1bHRQaXhlbHNQZXJWYWx1ZScpIDogb3B0aW9ucy5nZXQoJ3dpZHRoJyk7XG4gICAgICAgICAgICAgICAgaWYgKG9wdGlvbnMuZ2V0KCdoZWlnaHQnKSA9PT0gJ2F1dG8nKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICghb3B0aW9ucy5nZXQoJ2NvbXBvc2l0ZScpIHx8ICEkLmRhdGEodGhpcywgJ19qcXNfdmNhbnZhcycpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBtdXN0IGJlIGEgYmV0dGVyIHdheSB0byBnZXQgdGhlIGxpbmUgaGVpZ2h0XG4gICAgICAgICAgICAgICAgICAgICAgICB0bXAgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0bXAuaW5uZXJIVE1MID0gJ2EnO1xuICAgICAgICAgICAgICAgICAgICAgICAgJHRoaXMuaHRtbCh0bXApO1xuICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0ID0gJCh0bXApLmlubmVySGVpZ2h0KCkgfHwgJCh0bXApLmhlaWdodCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgJCh0bXApLnJlbW92ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdG1wID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGhlaWdodCA9IG9wdGlvbnMuZ2V0KCdoZWlnaHQnKTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBpZiAoIW9wdGlvbnMuZ2V0KCdkaXNhYmxlSW50ZXJhY3Rpb24nKSkge1xuICAgICAgICAgICAgICAgICAgICBtaGFuZGxlciA9ICQuZGF0YSh0aGlzLCAnX2pxc19taGFuZGxlcicpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoIW1oYW5kbGVyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBtaGFuZGxlciA9IG5ldyBNb3VzZUhhbmRsZXIodGhpcywgb3B0aW9ucyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAkLmRhdGEodGhpcywgJ19qcXNfbWhhbmRsZXInLCBtaGFuZGxlcik7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoIW9wdGlvbnMuZ2V0KCdjb21wb3NpdGUnKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgbWhhbmRsZXIucmVzZXQoKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIG1oYW5kbGVyID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgaWYgKG9wdGlvbnMuZ2V0KCdjb21wb3NpdGUnKSAmJiAhJC5kYXRhKHRoaXMsICdfanFzX3ZjYW52YXMnKSkge1xuICAgICAgICAgICAgICAgICAgICBpZiAoISQuZGF0YSh0aGlzLCAnX2pxc19lcnJub3RpZnknKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgYWxlcnQoJ0F0dGVtcHRlZCB0byBhdHRhY2ggYSBjb21wb3NpdGUgc3BhcmtsaW5lIHRvIGFuIGVsZW1lbnQgd2l0aCBubyBleGlzdGluZyBzcGFya2xpbmUnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICQuZGF0YSh0aGlzLCAnX2pxc19lcnJub3RpZnknLCB0cnVlKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgc3AgPSBuZXcgJC5mbi5zcGFya2xpbmVbb3B0aW9ucy5nZXQoJ3R5cGUnKV0odGhpcywgdmFsdWVzLCBvcHRpb25zLCB3aWR0aCwgaGVpZ2h0KTtcblxuICAgICAgICAgICAgICAgIHNwLnJlbmRlcigpO1xuXG4gICAgICAgICAgICAgICAgaWYgKG1oYW5kbGVyKSB7XG4gICAgICAgICAgICAgICAgICAgIG1oYW5kbGVyLnJlZ2lzdGVyU3BhcmtsaW5lKHNwKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgaWYgKCgkKHRoaXMpLmh0bWwoKSAmJiAhb3B0aW9ucy5nZXQoJ2Rpc2FibGVIaWRkZW5DaGVjaycpICYmICQodGhpcykuaXMoJzpoaWRkZW4nKSkgfHwgISQodGhpcykucGFyZW50cygnYm9keScpLmxlbmd0aCkge1xuICAgICAgICAgICAgICAgIGlmICghb3B0aW9ucy5nZXQoJ2NvbXBvc2l0ZScpICYmICQuZGF0YSh0aGlzLCAnX2pxc19wZW5kaW5nJykpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gcmVtb3ZlIGFueSBleGlzdGluZyByZWZlcmVuY2VzIHRvIHRoZSBlbGVtZW50XG4gICAgICAgICAgICAgICAgICAgIGZvciAoaSA9IHBlbmRpbmcubGVuZ3RoOyBpOyBpLS0pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwZW5kaW5nW2kgLSAxXVswXSA9PSB0aGlzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGVuZGluZy5zcGxpY2UoaSAtIDEsIDEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHBlbmRpbmcucHVzaChbdGhpcywgcmVuZGVyXSk7XG4gICAgICAgICAgICAgICAgJC5kYXRhKHRoaXMsICdfanFzX3BlbmRpbmcnLCB0cnVlKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgcmVuZGVyLmNhbGwodGhpcyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH07XG5cbiAgICAkLmZuLnNwYXJrbGluZS5kZWZhdWx0cyA9IGdldERlZmF1bHRzKCk7XG5cblxuICAgICQuc3BhcmtsaW5lX2Rpc3BsYXlfdmlzaWJsZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIGVsLCBpLCBwbDtcbiAgICAgICAgdmFyIGRvbmUgPSBbXTtcbiAgICAgICAgZm9yIChpID0gMCwgcGwgPSBwZW5kaW5nLmxlbmd0aDsgaSA8IHBsOyBpKyspIHtcbiAgICAgICAgICAgIGVsID0gcGVuZGluZ1tpXVswXTtcbiAgICAgICAgICAgIGlmICgkKGVsKS5pcygnOnZpc2libGUnKSAmJiAhJChlbCkucGFyZW50cygpLmlzKCc6aGlkZGVuJykpIHtcbiAgICAgICAgICAgICAgICBwZW5kaW5nW2ldWzFdLmNhbGwoZWwpO1xuICAgICAgICAgICAgICAgICQuZGF0YShwZW5kaW5nW2ldWzBdLCAnX2pxc19wZW5kaW5nJywgZmFsc2UpO1xuICAgICAgICAgICAgICAgIGRvbmUucHVzaChpKTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoISQoZWwpLmNsb3Nlc3QoJ2h0bWwnKS5sZW5ndGggJiYgISQuZGF0YShlbCwgJ19qcXNfcGVuZGluZycpKSB7XG4gICAgICAgICAgICAgICAgLy8gZWxlbWVudCBoYXMgYmVlbiBpbnNlcnRlZCBhbmQgcmVtb3ZlZCBmcm9tIHRoZSBET01cbiAgICAgICAgICAgICAgICAvLyBJZiBpdCB3YXMgbm90IHlldCBpbnNlcnRlZCBpbnRvIHRoZSBkb20gdGhlbiB0aGUgLmRhdGEgcmVxdWVzdFxuICAgICAgICAgICAgICAgIC8vIHdpbGwgcmV0dXJuIHRydWUuXG4gICAgICAgICAgICAgICAgLy8gcmVtb3ZpbmcgZnJvbSB0aGUgZG9tIGNhdXNlcyB0aGUgZGF0YSB0byBiZSByZW1vdmVkLlxuICAgICAgICAgICAgICAgICQuZGF0YShwZW5kaW5nW2ldWzBdLCAnX2pxc19wZW5kaW5nJywgZmFsc2UpO1xuICAgICAgICAgICAgICAgIGRvbmUucHVzaChpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBmb3IgKGkgPSBkb25lLmxlbmd0aDsgaTsgaS0tKSB7XG4gICAgICAgICAgICBwZW5kaW5nLnNwbGljZShkb25lW2kgLSAxXSwgMSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG5cbiAgICAvKipcbiAgICAgKiBVc2VyIG9wdGlvbiBoYW5kbGVyXG4gICAgICovXG4gICAgJC5mbi5zcGFya2xpbmUub3B0aW9ucyA9IGNyZWF0ZUNsYXNzKHtcbiAgICAgICAgaW5pdDogZnVuY3Rpb24gKHRhZywgdXNlck9wdGlvbnMpIHtcbiAgICAgICAgICAgIHZhciBleHRlbmRlZE9wdGlvbnMsIGRlZmF1bHRzLCBiYXNlLCB0YWdPcHRpb25UeXBlO1xuICAgICAgICAgICAgdGhpcy51c2VyT3B0aW9ucyA9IHVzZXJPcHRpb25zID0gdXNlck9wdGlvbnMgfHwge307XG4gICAgICAgICAgICB0aGlzLnRhZyA9IHRhZztcbiAgICAgICAgICAgIHRoaXMudGFnVmFsQ2FjaGUgPSB7fTtcbiAgICAgICAgICAgIGRlZmF1bHRzID0gJC5mbi5zcGFya2xpbmUuZGVmYXVsdHM7XG4gICAgICAgICAgICBiYXNlID0gZGVmYXVsdHMuY29tbW9uO1xuICAgICAgICAgICAgdGhpcy50YWdPcHRpb25zUHJlZml4ID0gdXNlck9wdGlvbnMuZW5hYmxlVGFnT3B0aW9ucyAmJiAodXNlck9wdGlvbnMudGFnT3B0aW9uc1ByZWZpeCB8fCBiYXNlLnRhZ09wdGlvbnNQcmVmaXgpO1xuXG4gICAgICAgICAgICB0YWdPcHRpb25UeXBlID0gdGhpcy5nZXRUYWdTZXR0aW5nKCd0eXBlJyk7XG4gICAgICAgICAgICBpZiAodGFnT3B0aW9uVHlwZSA9PT0gVU5TRVRfT1BUSU9OKSB7XG4gICAgICAgICAgICAgICAgZXh0ZW5kZWRPcHRpb25zID0gZGVmYXVsdHNbdXNlck9wdGlvbnMudHlwZSB8fCBiYXNlLnR5cGVdO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBleHRlbmRlZE9wdGlvbnMgPSBkZWZhdWx0c1t0YWdPcHRpb25UeXBlXTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMubWVyZ2VkT3B0aW9ucyA9ICQuZXh0ZW5kKHt9LCBiYXNlLCBleHRlbmRlZE9wdGlvbnMsIHVzZXJPcHRpb25zKTtcbiAgICAgICAgfSxcblxuXG4gICAgICAgIGdldFRhZ1NldHRpbmc6IGZ1bmN0aW9uIChrZXkpIHtcbiAgICAgICAgICAgIHZhciBwcmVmaXggPSB0aGlzLnRhZ09wdGlvbnNQcmVmaXgsXG4gICAgICAgICAgICAgICAgdmFsLCBpLCBwYWlycywga2V5dmFsO1xuICAgICAgICAgICAgaWYgKHByZWZpeCA9PT0gZmFsc2UgfHwgcHJlZml4ID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gVU5TRVRfT1BUSU9OO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHRoaXMudGFnVmFsQ2FjaGUuaGFzT3duUHJvcGVydHkoa2V5KSkge1xuICAgICAgICAgICAgICAgIHZhbCA9IHRoaXMudGFnVmFsQ2FjaGUua2V5O1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB2YWwgPSB0aGlzLnRhZy5nZXRBdHRyaWJ1dGUocHJlZml4ICsga2V5KTtcbiAgICAgICAgICAgICAgICBpZiAodmFsID09PSB1bmRlZmluZWQgfHwgdmFsID09PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhbCA9IFVOU0VUX09QVElPTjtcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKHZhbC5zdWJzdHIoMCwgMSkgPT09ICdbJykge1xuICAgICAgICAgICAgICAgICAgICB2YWwgPSB2YWwuc3Vic3RyKDEsIHZhbC5sZW5ndGggLSAyKS5zcGxpdCgnLCcpO1xuICAgICAgICAgICAgICAgICAgICBmb3IgKGkgPSB2YWwubGVuZ3RoOyBpLS07KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YWxbaV0gPSBub3JtYWxpemVWYWx1ZSh2YWxbaV0ucmVwbGFjZSgvKF5cXHMqKXwoXFxzKiQpL2csICcnKSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKHZhbC5zdWJzdHIoMCwgMSkgPT09ICd7Jykge1xuICAgICAgICAgICAgICAgICAgICBwYWlycyA9IHZhbC5zdWJzdHIoMSwgdmFsLmxlbmd0aCAtIDIpLnNwbGl0KCcsJyk7XG4gICAgICAgICAgICAgICAgICAgIHZhbCA9IHt9O1xuICAgICAgICAgICAgICAgICAgICBmb3IgKGkgPSBwYWlycy5sZW5ndGg7IGktLTspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleXZhbCA9IHBhaXJzW2ldLnNwbGl0KCc6JywgMik7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YWxba2V5dmFsWzBdLnJlcGxhY2UoLyheXFxzKil8KFxccyokKS9nLCAnJyldID0gbm9ybWFsaXplVmFsdWUoa2V5dmFsWzFdLnJlcGxhY2UoLyheXFxzKil8KFxccyokKS9nLCAnJykpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgdmFsID0gbm9ybWFsaXplVmFsdWUodmFsKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgdGhpcy50YWdWYWxDYWNoZS5rZXkgPSB2YWw7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gdmFsO1xuICAgICAgICB9LFxuXG4gICAgICAgIGdldDogZnVuY3Rpb24gKGtleSwgZGVmYXVsdHZhbCkge1xuICAgICAgICAgICAgdmFyIHRhZ09wdGlvbiA9IHRoaXMuZ2V0VGFnU2V0dGluZyhrZXkpLFxuICAgICAgICAgICAgICAgIHJlc3VsdDtcbiAgICAgICAgICAgIGlmICh0YWdPcHRpb24gIT09IFVOU0VUX09QVElPTikge1xuICAgICAgICAgICAgICAgIHJldHVybiB0YWdPcHRpb247XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gKHJlc3VsdCA9IHRoaXMubWVyZ2VkT3B0aW9uc1trZXldKSA9PT0gdW5kZWZpbmVkID8gZGVmYXVsdHZhbCA6IHJlc3VsdDtcbiAgICAgICAgfVxuICAgIH0pO1xuXG5cbiAgICAkLmZuLnNwYXJrbGluZS5fYmFzZSA9IGNyZWF0ZUNsYXNzKHtcbiAgICAgICAgZGlzYWJsZWQ6IGZhbHNlLFxuXG4gICAgICAgIGluaXQ6IGZ1bmN0aW9uIChlbCwgdmFsdWVzLCBvcHRpb25zLCB3aWR0aCwgaGVpZ2h0KSB7XG4gICAgICAgICAgICB0aGlzLmVsID0gZWw7XG4gICAgICAgICAgICB0aGlzLiRlbCA9ICQoZWwpO1xuICAgICAgICAgICAgdGhpcy52YWx1ZXMgPSB2YWx1ZXM7XG4gICAgICAgICAgICB0aGlzLm9wdGlvbnMgPSBvcHRpb25zO1xuICAgICAgICAgICAgdGhpcy53aWR0aCA9IHdpZHRoO1xuICAgICAgICAgICAgdGhpcy5oZWlnaHQgPSBoZWlnaHQ7XG4gICAgICAgICAgICB0aGlzLmN1cnJlbnRSZWdpb24gPSB1bmRlZmluZWQ7XG4gICAgICAgIH0sXG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFNldHVwIHRoZSBjYW52YXNcbiAgICAgICAgICovXG4gICAgICAgIGluaXRUYXJnZXQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHZhciBpbnRlcmFjdGl2ZSA9ICF0aGlzLm9wdGlvbnMuZ2V0KCdkaXNhYmxlSW50ZXJhY3Rpb24nKTtcbiAgICAgICAgICAgIGlmICghKHRoaXMudGFyZ2V0ID0gdGhpcy4kZWwuc2ltcGxlZHJhdyh0aGlzLndpZHRoLCB0aGlzLmhlaWdodCwgdGhpcy5vcHRpb25zLmdldCgnY29tcG9zaXRlJyksIGludGVyYWN0aXZlKSkpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmRpc2FibGVkID0gdHJ1ZTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhpcy5jYW52YXNXaWR0aCA9IHRoaXMudGFyZ2V0LnBpeGVsV2lkdGg7XG4gICAgICAgICAgICAgICAgdGhpcy5jYW52YXNIZWlnaHQgPSB0aGlzLnRhcmdldC5waXhlbEhlaWdodDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSxcblxuICAgICAgICAvKipcbiAgICAgICAgICogQWN0dWFsbHkgcmVuZGVyIHRoZSBjaGFydCB0byB0aGUgY2FudmFzXG4gICAgICAgICAqL1xuICAgICAgICByZW5kZXI6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGlmICh0aGlzLmRpc2FibGVkKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5lbC5pbm5lckhUTUwgPSAnJztcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfSxcblxuICAgICAgICAvKipcbiAgICAgICAgICogUmV0dXJuIGEgcmVnaW9uIGlkIGZvciBhIGdpdmVuIHgveSBjby1vcmRpbmF0ZVxuICAgICAgICAgKi9cbiAgICAgICAgZ2V0UmVnaW9uOiBmdW5jdGlvbiAoeCwgeSkge1xuICAgICAgICB9LFxuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBIaWdobGlnaHQgYW4gaXRlbSBiYXNlZCBvbiB0aGUgbW91c2VkLW92ZXIgeCx5IGNvLW9yZGluYXRlXG4gICAgICAgICAqL1xuICAgICAgICBzZXRSZWdpb25IaWdobGlnaHQ6IGZ1bmN0aW9uIChlbCwgeCwgeSkge1xuICAgICAgICAgICAgdmFyIGN1cnJlbnRSZWdpb24gPSB0aGlzLmN1cnJlbnRSZWdpb24sXG4gICAgICAgICAgICAgICAgaGlnaGxpZ2h0RW5hYmxlZCA9ICF0aGlzLm9wdGlvbnMuZ2V0KCdkaXNhYmxlSGlnaGxpZ2h0JyksXG4gICAgICAgICAgICAgICAgbmV3UmVnaW9uO1xuICAgICAgICAgICAgaWYgKHggPiB0aGlzLmNhbnZhc1dpZHRoIHx8IHkgPiB0aGlzLmNhbnZhc0hlaWdodCB8fCB4IDwgMCB8fCB5IDwgMCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbmV3UmVnaW9uID0gdGhpcy5nZXRSZWdpb24oZWwsIHgsIHkpO1xuICAgICAgICAgICAgaWYgKGN1cnJlbnRSZWdpb24gIT09IG5ld1JlZ2lvbikge1xuICAgICAgICAgICAgICAgIGlmIChjdXJyZW50UmVnaW9uICE9PSB1bmRlZmluZWQgJiYgaGlnaGxpZ2h0RW5hYmxlZCkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnJlbW92ZUhpZ2hsaWdodCgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB0aGlzLmN1cnJlbnRSZWdpb24gPSBuZXdSZWdpb247XG4gICAgICAgICAgICAgICAgaWYgKG5ld1JlZ2lvbiAhPT0gdW5kZWZpbmVkICYmIGhpZ2hsaWdodEVuYWJsZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5yZW5kZXJIaWdobGlnaHQoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH0sXG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFJlc2V0IGFueSBjdXJyZW50bHkgaGlnaGxpZ2h0ZWQgaXRlbVxuICAgICAgICAgKi9cbiAgICAgICAgY2xlYXJSZWdpb25IaWdobGlnaHQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGlmICh0aGlzLmN1cnJlbnRSZWdpb24gIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgIHRoaXMucmVtb3ZlSGlnaGxpZ2h0KCk7XG4gICAgICAgICAgICAgICAgdGhpcy5jdXJyZW50UmVnaW9uID0gdW5kZWZpbmVkO1xuICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9LFxuXG4gICAgICAgIHJlbmRlckhpZ2hsaWdodDogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdGhpcy5jaGFuZ2VIaWdobGlnaHQodHJ1ZSk7XG4gICAgICAgIH0sXG5cbiAgICAgICAgcmVtb3ZlSGlnaGxpZ2h0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB0aGlzLmNoYW5nZUhpZ2hsaWdodChmYWxzZSk7XG4gICAgICAgIH0sXG5cbiAgICAgICAgY2hhbmdlSGlnaGxpZ2h0OiBmdW5jdGlvbiAoaGlnaGxpZ2h0KSAge30sXG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIEZldGNoIHRoZSBIVE1MIHRvIGRpc3BsYXkgYXMgYSB0b29sdGlwXG4gICAgICAgICAqL1xuICAgICAgICBnZXRDdXJyZW50UmVnaW9uVG9vbHRpcDogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdmFyIG9wdGlvbnMgPSB0aGlzLm9wdGlvbnMsXG4gICAgICAgICAgICAgICAgaGVhZGVyID0gJycsXG4gICAgICAgICAgICAgICAgZW50cmllcyA9IFtdLFxuICAgICAgICAgICAgICAgIGZpZWxkcywgZm9ybWF0cywgZm9ybWF0bGVuLCBmY2xhc3MsIHRleHQsIGksXG4gICAgICAgICAgICAgICAgc2hvd0ZpZWxkcywgc2hvd0ZpZWxkc0tleSwgbmV3RmllbGRzLCBmdixcbiAgICAgICAgICAgICAgICBmb3JtYXR0ZXIsIGZvcm1hdCwgZmllbGRsZW4sIGo7XG4gICAgICAgICAgICBpZiAodGhpcy5jdXJyZW50UmVnaW9uID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gJyc7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBmaWVsZHMgPSB0aGlzLmdldEN1cnJlbnRSZWdpb25GaWVsZHMoKTtcbiAgICAgICAgICAgIGZvcm1hdHRlciA9IG9wdGlvbnMuZ2V0KCd0b29sdGlwRm9ybWF0dGVyJyk7XG4gICAgICAgICAgICBpZiAoZm9ybWF0dGVyKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGZvcm1hdHRlcih0aGlzLCBvcHRpb25zLCBmaWVsZHMpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKG9wdGlvbnMuZ2V0KCd0b29sdGlwQ2hhcnRUaXRsZScpKSB7XG4gICAgICAgICAgICAgICAgaGVhZGVyICs9ICc8ZGl2IGNsYXNzPVwianFzIGpxc3RpdGxlXCI+JyArIG9wdGlvbnMuZ2V0KCd0b29sdGlwQ2hhcnRUaXRsZScpICsgJzwvZGl2Plxcbic7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBmb3JtYXRzID0gdGhpcy5vcHRpb25zLmdldCgndG9vbHRpcEZvcm1hdCcpO1xuICAgICAgICAgICAgaWYgKCFmb3JtYXRzKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuICcnO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKCEkLmlzQXJyYXkoZm9ybWF0cykpIHtcbiAgICAgICAgICAgICAgICBmb3JtYXRzID0gW2Zvcm1hdHNdO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKCEkLmlzQXJyYXkoZmllbGRzKSkge1xuICAgICAgICAgICAgICAgIGZpZWxkcyA9IFtmaWVsZHNdO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc2hvd0ZpZWxkcyA9IHRoaXMub3B0aW9ucy5nZXQoJ3Rvb2x0aXBGb3JtYXRGaWVsZGxpc3QnKTtcbiAgICAgICAgICAgIHNob3dGaWVsZHNLZXkgPSB0aGlzLm9wdGlvbnMuZ2V0KCd0b29sdGlwRm9ybWF0RmllbGRsaXN0S2V5Jyk7XG4gICAgICAgICAgICBpZiAoc2hvd0ZpZWxkcyAmJiBzaG93RmllbGRzS2V5KSB7XG4gICAgICAgICAgICAgICAgLy8gdXNlci1zZWxlY3RlZCBvcmRlcmluZyBvZiBmaWVsZHNcbiAgICAgICAgICAgICAgICBuZXdGaWVsZHMgPSBbXTtcbiAgICAgICAgICAgICAgICBmb3IgKGkgPSBmaWVsZHMubGVuZ3RoOyBpLS07KSB7XG4gICAgICAgICAgICAgICAgICAgIGZ2ID0gZmllbGRzW2ldW3Nob3dGaWVsZHNLZXldO1xuICAgICAgICAgICAgICAgICAgICBpZiAoKGogPSAkLmluQXJyYXkoZnYsIHNob3dGaWVsZHMpKSAhPSAtMSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgbmV3RmllbGRzW2pdID0gZmllbGRzW2ldO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGZpZWxkcyA9IG5ld0ZpZWxkcztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGZvcm1hdGxlbiA9IGZvcm1hdHMubGVuZ3RoO1xuICAgICAgICAgICAgZmllbGRsZW4gPSBmaWVsZHMubGVuZ3RoO1xuICAgICAgICAgICAgZm9yIChpID0gMDsgaSA8IGZvcm1hdGxlbjsgaSsrKSB7XG4gICAgICAgICAgICAgICAgZm9ybWF0ID0gZm9ybWF0c1tpXTtcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGZvcm1hdCA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAgICAgICAgICAgZm9ybWF0ID0gbmV3IFNQRm9ybWF0KGZvcm1hdCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGZjbGFzcyA9IGZvcm1hdC5mY2xhc3MgfHwgJ2pxc2ZpZWxkJztcbiAgICAgICAgICAgICAgICBmb3IgKGogPSAwOyBqIDwgZmllbGRsZW47IGorKykge1xuICAgICAgICAgICAgICAgICAgICBpZiAoIWZpZWxkc1tqXS5pc051bGwgfHwgIW9wdGlvbnMuZ2V0KCd0b29sdGlwU2tpcE51bGwnKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgJC5leHRlbmQoZmllbGRzW2pdLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJlZml4OiBvcHRpb25zLmdldCgndG9vbHRpcFByZWZpeCcpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN1ZmZpeDogb3B0aW9ucy5nZXQoJ3Rvb2x0aXBTdWZmaXgnKVxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0ZXh0ID0gZm9ybWF0LnJlbmRlcihmaWVsZHNbal0sIG9wdGlvbnMuZ2V0KCd0b29sdGlwVmFsdWVMb29rdXBzJyksIG9wdGlvbnMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgZW50cmllcy5wdXNoKCc8ZGl2IGNsYXNzPVwiJyArIGZjbGFzcyArICdcIj4nICsgdGV4dCArICc8L2Rpdj4nKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChlbnRyaWVzLmxlbmd0aCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBoZWFkZXIgKyBlbnRyaWVzLmpvaW4oJ1xcbicpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuICcnO1xuICAgICAgICB9LFxuXG4gICAgICAgIGdldEN1cnJlbnRSZWdpb25GaWVsZHM6IGZ1bmN0aW9uICgpIHt9LFxuXG4gICAgICAgIGNhbGNIaWdobGlnaHRDb2xvcjogZnVuY3Rpb24gKGNvbG9yLCBvcHRpb25zKSB7XG4gICAgICAgICAgICB2YXIgaGlnaGxpZ2h0Q29sb3IgPSBvcHRpb25zLmdldCgnaGlnaGxpZ2h0Q29sb3InKSxcbiAgICAgICAgICAgICAgICBsaWdodGVuID0gb3B0aW9ucy5nZXQoJ2hpZ2hsaWdodExpZ2h0ZW4nKSxcbiAgICAgICAgICAgICAgICBwYXJzZSwgbXVsdCwgcmdibmV3LCBpO1xuICAgICAgICAgICAgaWYgKGhpZ2hsaWdodENvbG9yKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGhpZ2hsaWdodENvbG9yO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGxpZ2h0ZW4pIHtcbiAgICAgICAgICAgICAgICAvLyBleHRyYWN0IFJHQiB2YWx1ZXNcbiAgICAgICAgICAgICAgICBwYXJzZSA9IC9eIyhbMC05YS1mXSkoWzAtOWEtZl0pKFswLTlhLWZdKSQvaS5leGVjKGNvbG9yKSB8fCAvXiMoWzAtOWEtZl17Mn0pKFswLTlhLWZdezJ9KShbMC05YS1mXXsyfSkkL2kuZXhlYyhjb2xvcik7XG4gICAgICAgICAgICAgICAgaWYgKHBhcnNlKSB7XG4gICAgICAgICAgICAgICAgICAgIHJnYm5ldyA9IFtdO1xuICAgICAgICAgICAgICAgICAgICBtdWx0ID0gY29sb3IubGVuZ3RoID09PSA0ID8gMTYgOiAxO1xuICAgICAgICAgICAgICAgICAgICBmb3IgKGkgPSAwOyBpIDwgMzsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZ2JuZXdbaV0gPSBjbGlwdmFsKE1hdGgucm91bmQocGFyc2VJbnQocGFyc2VbaSArIDFdLCAxNikgKiBtdWx0ICogbGlnaHRlbiksIDAsIDI1NSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuICdyZ2IoJyArIHJnYm5ldy5qb2luKCcsJykgKyAnKSc7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gY29sb3I7XG4gICAgICAgIH1cblxuICAgIH0pO1xuXG4gICAgYmFySGlnaGxpZ2h0TWl4aW4gPSB7XG4gICAgICAgIGNoYW5nZUhpZ2hsaWdodDogZnVuY3Rpb24gKGhpZ2hsaWdodCkge1xuICAgICAgICAgICAgdmFyIGN1cnJlbnRSZWdpb24gPSB0aGlzLmN1cnJlbnRSZWdpb24sXG4gICAgICAgICAgICAgICAgdGFyZ2V0ID0gdGhpcy50YXJnZXQsXG4gICAgICAgICAgICAgICAgc2hhcGVpZHMgPSB0aGlzLnJlZ2lvblNoYXBlc1tjdXJyZW50UmVnaW9uXSxcbiAgICAgICAgICAgICAgICBuZXdTaGFwZXM7XG4gICAgICAgICAgICAvLyB3aWxsIGJlIG51bGwgaWYgdGhlIHJlZ2lvbiB2YWx1ZSB3YXMgbnVsbFxuICAgICAgICAgICAgaWYgKHNoYXBlaWRzKSB7XG4gICAgICAgICAgICAgICAgbmV3U2hhcGVzID0gdGhpcy5yZW5kZXJSZWdpb24oY3VycmVudFJlZ2lvbiwgaGlnaGxpZ2h0KTtcbiAgICAgICAgICAgICAgICBpZiAoJC5pc0FycmF5KG5ld1NoYXBlcykgfHwgJC5pc0FycmF5KHNoYXBlaWRzKSkge1xuICAgICAgICAgICAgICAgICAgICB0YXJnZXQucmVwbGFjZVdpdGhTaGFwZXMoc2hhcGVpZHMsIG5ld1NoYXBlcyk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMucmVnaW9uU2hhcGVzW2N1cnJlbnRSZWdpb25dID0gJC5tYXAobmV3U2hhcGVzLCBmdW5jdGlvbiAobmV3U2hhcGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBuZXdTaGFwZS5pZDtcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgdGFyZ2V0LnJlcGxhY2VXaXRoU2hhcGUoc2hhcGVpZHMsIG5ld1NoYXBlcyk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMucmVnaW9uU2hhcGVzW2N1cnJlbnRSZWdpb25dID0gbmV3U2hhcGVzLmlkO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSxcblxuICAgICAgICByZW5kZXI6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHZhciB2YWx1ZXMgPSB0aGlzLnZhbHVlcyxcbiAgICAgICAgICAgICAgICB0YXJnZXQgPSB0aGlzLnRhcmdldCxcbiAgICAgICAgICAgICAgICByZWdpb25TaGFwZXMgPSB0aGlzLnJlZ2lvblNoYXBlcyxcbiAgICAgICAgICAgICAgICBzaGFwZXMsIGlkcywgaSwgajtcblxuICAgICAgICAgICAgaWYgKCF0aGlzLmNscy5fc3VwZXIucmVuZGVyLmNhbGwodGhpcykpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBmb3IgKGkgPSB2YWx1ZXMubGVuZ3RoOyBpLS07KSB7XG4gICAgICAgICAgICAgICAgc2hhcGVzID0gdGhpcy5yZW5kZXJSZWdpb24oaSk7XG4gICAgICAgICAgICAgICAgaWYgKHNoYXBlcykge1xuICAgICAgICAgICAgICAgICAgICBpZiAoJC5pc0FycmF5KHNoYXBlcykpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkcyA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChqID0gc2hhcGVzLmxlbmd0aDsgai0tOykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNoYXBlc1tqXS5hcHBlbmQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZHMucHVzaChzaGFwZXNbal0uaWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgcmVnaW9uU2hhcGVzW2ldID0gaWRzO1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2hhcGVzLmFwcGVuZCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVnaW9uU2hhcGVzW2ldID0gc2hhcGVzLmlkOyAvLyBzdG9yZSBqdXN0IHRoZSBzaGFwZWlkXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAvLyBudWxsIHZhbHVlXG4gICAgICAgICAgICAgICAgICAgIHJlZ2lvblNoYXBlc1tpXSA9IG51bGw7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGFyZ2V0LnJlbmRlcigpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIC8qKlxuICAgICAqIExpbmUgY2hhcnRzXG4gICAgICovXG4gICAgJC5mbi5zcGFya2xpbmUubGluZSA9IGxpbmUgPSBjcmVhdGVDbGFzcygkLmZuLnNwYXJrbGluZS5fYmFzZSwge1xuICAgICAgICB0eXBlOiAnbGluZScsXG5cbiAgICAgICAgaW5pdDogZnVuY3Rpb24gKGVsLCB2YWx1ZXMsIG9wdGlvbnMsIHdpZHRoLCBoZWlnaHQpIHtcbiAgICAgICAgICAgIGxpbmUuX3N1cGVyLmluaXQuY2FsbCh0aGlzLCBlbCwgdmFsdWVzLCBvcHRpb25zLCB3aWR0aCwgaGVpZ2h0KTtcbiAgICAgICAgICAgIHRoaXMudmVydGljZXMgPSBbXTtcbiAgICAgICAgICAgIHRoaXMucmVnaW9uTWFwID0gW107XG4gICAgICAgICAgICB0aGlzLnh2YWx1ZXMgPSBbXTtcbiAgICAgICAgICAgIHRoaXMueXZhbHVlcyA9IFtdO1xuICAgICAgICAgICAgdGhpcy55bWlubWF4ID0gW107XG4gICAgICAgICAgICB0aGlzLmhpZ2h0bGlnaHRTcG90SWQgPSBudWxsO1xuICAgICAgICAgICAgdGhpcy5sYXN0U2hhcGVJZCA9IG51bGw7XG4gICAgICAgICAgICB0aGlzLmluaXRUYXJnZXQoKTtcbiAgICAgICAgfSxcblxuICAgICAgICBnZXRSZWdpb246IGZ1bmN0aW9uIChlbCwgeCwgeSkge1xuICAgICAgICAgICAgdmFyIGksXG4gICAgICAgICAgICAgICAgcmVnaW9uTWFwID0gdGhpcy5yZWdpb25NYXA7IC8vIG1hcHMgcmVnaW9ucyB0byB2YWx1ZSBwb3NpdGlvbnNcbiAgICAgICAgICAgIGZvciAoaSA9IHJlZ2lvbk1hcC5sZW5ndGg7IGktLTspIHtcbiAgICAgICAgICAgICAgICBpZiAocmVnaW9uTWFwW2ldICE9PSBudWxsICYmIHggPj0gcmVnaW9uTWFwW2ldWzBdICYmIHggPD0gcmVnaW9uTWFwW2ldWzFdKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiByZWdpb25NYXBbaV1bMl07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICAgICAgfSxcblxuICAgICAgICBnZXRDdXJyZW50UmVnaW9uRmllbGRzOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB2YXIgY3VycmVudFJlZ2lvbiA9IHRoaXMuY3VycmVudFJlZ2lvbjtcbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgaXNOdWxsOiB0aGlzLnl2YWx1ZXNbY3VycmVudFJlZ2lvbl0gPT09IG51bGwsXG4gICAgICAgICAgICAgICAgeDogdGhpcy54dmFsdWVzW2N1cnJlbnRSZWdpb25dLFxuICAgICAgICAgICAgICAgIHk6IHRoaXMueXZhbHVlc1tjdXJyZW50UmVnaW9uXSxcbiAgICAgICAgICAgICAgICBjb2xvcjogdGhpcy5vcHRpb25zLmdldCgnbGluZUNvbG9yJyksXG4gICAgICAgICAgICAgICAgZmlsbENvbG9yOiB0aGlzLm9wdGlvbnMuZ2V0KCdmaWxsQ29sb3InKSxcbiAgICAgICAgICAgICAgICBvZmZzZXQ6IGN1cnJlbnRSZWdpb25cbiAgICAgICAgICAgIH07XG4gICAgICAgIH0sXG5cbiAgICAgICAgcmVuZGVySGlnaGxpZ2h0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB2YXIgY3VycmVudFJlZ2lvbiA9IHRoaXMuY3VycmVudFJlZ2lvbixcbiAgICAgICAgICAgICAgICB0YXJnZXQgPSB0aGlzLnRhcmdldCxcbiAgICAgICAgICAgICAgICB2ZXJ0ZXggPSB0aGlzLnZlcnRpY2VzW2N1cnJlbnRSZWdpb25dLFxuICAgICAgICAgICAgICAgIG9wdGlvbnMgPSB0aGlzLm9wdGlvbnMsXG4gICAgICAgICAgICAgICAgc3BvdFJhZGl1cyA9IG9wdGlvbnMuZ2V0KCdzcG90UmFkaXVzJyksXG4gICAgICAgICAgICAgICAgaGlnaGxpZ2h0U3BvdENvbG9yID0gb3B0aW9ucy5nZXQoJ2hpZ2hsaWdodFNwb3RDb2xvcicpLFxuICAgICAgICAgICAgICAgIGhpZ2hsaWdodExpbmVDb2xvciA9IG9wdGlvbnMuZ2V0KCdoaWdobGlnaHRMaW5lQ29sb3InKSxcbiAgICAgICAgICAgICAgICBoaWdobGlnaHRTcG90LCBoaWdobGlnaHRMaW5lO1xuXG4gICAgICAgICAgICBpZiAoIXZlcnRleCkge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChzcG90UmFkaXVzICYmIGhpZ2hsaWdodFNwb3RDb2xvcikge1xuICAgICAgICAgICAgICAgIGhpZ2hsaWdodFNwb3QgPSB0YXJnZXQuZHJhd0NpcmNsZSh2ZXJ0ZXhbMF0sIHZlcnRleFsxXSxcbiAgICAgICAgICAgICAgICAgICAgc3BvdFJhZGl1cywgdW5kZWZpbmVkLCBoaWdobGlnaHRTcG90Q29sb3IpO1xuICAgICAgICAgICAgICAgIHRoaXMuaGlnaGxpZ2h0U3BvdElkID0gaGlnaGxpZ2h0U3BvdC5pZDtcbiAgICAgICAgICAgICAgICB0YXJnZXQuaW5zZXJ0QWZ0ZXJTaGFwZSh0aGlzLmxhc3RTaGFwZUlkLCBoaWdobGlnaHRTcG90KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChoaWdobGlnaHRMaW5lQ29sb3IpIHtcbiAgICAgICAgICAgICAgICBoaWdobGlnaHRMaW5lID0gdGFyZ2V0LmRyYXdMaW5lKHZlcnRleFswXSwgdGhpcy5jYW52YXNUb3AsIHZlcnRleFswXSxcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jYW52YXNUb3AgKyB0aGlzLmNhbnZhc0hlaWdodCwgaGlnaGxpZ2h0TGluZUNvbG9yKTtcbiAgICAgICAgICAgICAgICB0aGlzLmhpZ2hsaWdodExpbmVJZCA9IGhpZ2hsaWdodExpbmUuaWQ7XG4gICAgICAgICAgICAgICAgdGFyZ2V0Lmluc2VydEFmdGVyU2hhcGUodGhpcy5sYXN0U2hhcGVJZCwgaGlnaGxpZ2h0TGluZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0sXG5cbiAgICAgICAgcmVtb3ZlSGlnaGxpZ2h0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB2YXIgdGFyZ2V0ID0gdGhpcy50YXJnZXQ7XG4gICAgICAgICAgICBpZiAodGhpcy5oaWdobGlnaHRTcG90SWQpIHtcbiAgICAgICAgICAgICAgICB0YXJnZXQucmVtb3ZlU2hhcGVJZCh0aGlzLmhpZ2hsaWdodFNwb3RJZCk7XG4gICAgICAgICAgICAgICAgdGhpcy5oaWdobGlnaHRTcG90SWQgPSBudWxsO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHRoaXMuaGlnaGxpZ2h0TGluZUlkKSB7XG4gICAgICAgICAgICAgICAgdGFyZ2V0LnJlbW92ZVNoYXBlSWQodGhpcy5oaWdobGlnaHRMaW5lSWQpO1xuICAgICAgICAgICAgICAgIHRoaXMuaGlnaGxpZ2h0TGluZUlkID0gbnVsbDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSxcblxuICAgICAgICBzY2FuVmFsdWVzOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB2YXIgdmFsdWVzID0gdGhpcy52YWx1ZXMsXG4gICAgICAgICAgICAgICAgdmFsY291bnQgPSB2YWx1ZXMubGVuZ3RoLFxuICAgICAgICAgICAgICAgIHh2YWx1ZXMgPSB0aGlzLnh2YWx1ZXMsXG4gICAgICAgICAgICAgICAgeXZhbHVlcyA9IHRoaXMueXZhbHVlcyxcbiAgICAgICAgICAgICAgICB5bWlubWF4ID0gdGhpcy55bWlubWF4LFxuICAgICAgICAgICAgICAgIGksIHZhbCwgaXNTdHIsIGlzQXJyYXksIHNwO1xuICAgICAgICAgICAgZm9yIChpID0gMDsgaSA8IHZhbGNvdW50OyBpKyspIHtcbiAgICAgICAgICAgICAgICB2YWwgPSB2YWx1ZXNbaV07XG4gICAgICAgICAgICAgICAgaXNTdHIgPSB0eXBlb2YodmFsdWVzW2ldKSA9PT0gJ3N0cmluZyc7XG4gICAgICAgICAgICAgICAgaXNBcnJheSA9IHR5cGVvZih2YWx1ZXNbaV0pID09PSAnb2JqZWN0JyAmJiB2YWx1ZXNbaV0gaW5zdGFuY2VvZiBBcnJheTtcbiAgICAgICAgICAgICAgICBzcCA9IGlzU3RyICYmIHZhbHVlc1tpXS5zcGxpdCgnOicpO1xuICAgICAgICAgICAgICAgIGlmIChpc1N0ciAmJiBzcC5sZW5ndGggPT09IDIpIHsgLy8geDp5XG4gICAgICAgICAgICAgICAgICAgIHh2YWx1ZXMucHVzaChOdW1iZXIoc3BbMF0pKTtcbiAgICAgICAgICAgICAgICAgICAgeXZhbHVlcy5wdXNoKE51bWJlcihzcFsxXSkpO1xuICAgICAgICAgICAgICAgICAgICB5bWlubWF4LnB1c2goTnVtYmVyKHNwWzFdKSk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmIChpc0FycmF5KSB7XG4gICAgICAgICAgICAgICAgICAgIHh2YWx1ZXMucHVzaCh2YWxbMF0pO1xuICAgICAgICAgICAgICAgICAgICB5dmFsdWVzLnB1c2godmFsWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgeW1pbm1heC5wdXNoKHZhbFsxXSk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgeHZhbHVlcy5wdXNoKGkpO1xuICAgICAgICAgICAgICAgICAgICBpZiAodmFsdWVzW2ldID09PSBudWxsIHx8IHZhbHVlc1tpXSA9PT0gJ251bGwnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB5dmFsdWVzLnB1c2gobnVsbCk7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB5dmFsdWVzLnB1c2goTnVtYmVyKHZhbCkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgeW1pbm1heC5wdXNoKE51bWJlcih2YWwpKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICh0aGlzLm9wdGlvbnMuZ2V0KCd4dmFsdWVzJykpIHtcbiAgICAgICAgICAgICAgICB4dmFsdWVzID0gdGhpcy5vcHRpb25zLmdldCgneHZhbHVlcycpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB0aGlzLm1heHkgPSB0aGlzLm1heHlvcmcgPSBNYXRoLm1heC5hcHBseShNYXRoLCB5bWlubWF4KTtcbiAgICAgICAgICAgIHRoaXMubWlueSA9IHRoaXMubWlueW9yZyA9IE1hdGgubWluLmFwcGx5KE1hdGgsIHltaW5tYXgpO1xuXG4gICAgICAgICAgICB0aGlzLm1heHggPSBNYXRoLm1heC5hcHBseShNYXRoLCB4dmFsdWVzKTtcbiAgICAgICAgICAgIHRoaXMubWlueCA9IE1hdGgubWluLmFwcGx5KE1hdGgsIHh2YWx1ZXMpO1xuXG4gICAgICAgICAgICB0aGlzLnh2YWx1ZXMgPSB4dmFsdWVzO1xuICAgICAgICAgICAgdGhpcy55dmFsdWVzID0geXZhbHVlcztcbiAgICAgICAgICAgIHRoaXMueW1pbm1heCA9IHltaW5tYXg7XG5cbiAgICAgICAgfSxcblxuICAgICAgICBwcm9jZXNzUmFuZ2VPcHRpb25zOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB2YXIgb3B0aW9ucyA9IHRoaXMub3B0aW9ucyxcbiAgICAgICAgICAgICAgICBub3JtYWxSYW5nZU1pbiA9IG9wdGlvbnMuZ2V0KCdub3JtYWxSYW5nZU1pbicpLFxuICAgICAgICAgICAgICAgIG5vcm1hbFJhbmdlTWF4ID0gb3B0aW9ucy5nZXQoJ25vcm1hbFJhbmdlTWF4Jyk7XG5cbiAgICAgICAgICAgIGlmIChub3JtYWxSYW5nZU1pbiAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgaWYgKG5vcm1hbFJhbmdlTWluIDwgdGhpcy5taW55KSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMubWlueSA9IG5vcm1hbFJhbmdlTWluO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAobm9ybWFsUmFuZ2VNYXggPiB0aGlzLm1heHkpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tYXh5ID0gbm9ybWFsUmFuZ2VNYXg7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKG9wdGlvbnMuZ2V0KCdjaGFydFJhbmdlTWluJykgIT09IHVuZGVmaW5lZCAmJiAob3B0aW9ucy5nZXQoJ2NoYXJ0UmFuZ2VDbGlwJykgfHwgb3B0aW9ucy5nZXQoJ2NoYXJ0UmFuZ2VNaW4nKSA8IHRoaXMubWlueSkpIHtcbiAgICAgICAgICAgICAgICB0aGlzLm1pbnkgPSBvcHRpb25zLmdldCgnY2hhcnRSYW5nZU1pbicpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKG9wdGlvbnMuZ2V0KCdjaGFydFJhbmdlTWF4JykgIT09IHVuZGVmaW5lZCAmJiAob3B0aW9ucy5nZXQoJ2NoYXJ0UmFuZ2VDbGlwJykgfHwgb3B0aW9ucy5nZXQoJ2NoYXJ0UmFuZ2VNYXgnKSA+IHRoaXMubWF4eSkpIHtcbiAgICAgICAgICAgICAgICB0aGlzLm1heHkgPSBvcHRpb25zLmdldCgnY2hhcnRSYW5nZU1heCcpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKG9wdGlvbnMuZ2V0KCdjaGFydFJhbmdlTWluWCcpICE9PSB1bmRlZmluZWQgJiYgKG9wdGlvbnMuZ2V0KCdjaGFydFJhbmdlQ2xpcFgnKSB8fCBvcHRpb25zLmdldCgnY2hhcnRSYW5nZU1pblgnKSA8IHRoaXMubWlueCkpIHtcbiAgICAgICAgICAgICAgICB0aGlzLm1pbnggPSBvcHRpb25zLmdldCgnY2hhcnRSYW5nZU1pblgnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChvcHRpb25zLmdldCgnY2hhcnRSYW5nZU1heFgnKSAhPT0gdW5kZWZpbmVkICYmIChvcHRpb25zLmdldCgnY2hhcnRSYW5nZUNsaXBYJykgfHwgb3B0aW9ucy5nZXQoJ2NoYXJ0UmFuZ2VNYXhYJykgPiB0aGlzLm1heHgpKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5tYXh4ID0gb3B0aW9ucy5nZXQoJ2NoYXJ0UmFuZ2VNYXhYJyk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgfSxcblxuICAgICAgICBkcmF3Tm9ybWFsUmFuZ2U6IGZ1bmN0aW9uIChjYW52YXNMZWZ0LCBjYW52YXNUb3AsIGNhbnZhc0hlaWdodCwgY2FudmFzV2lkdGgsIHJhbmdleSkge1xuICAgICAgICAgICAgdmFyIG5vcm1hbFJhbmdlTWluID0gdGhpcy5vcHRpb25zLmdldCgnbm9ybWFsUmFuZ2VNaW4nKSxcbiAgICAgICAgICAgICAgICBub3JtYWxSYW5nZU1heCA9IHRoaXMub3B0aW9ucy5nZXQoJ25vcm1hbFJhbmdlTWF4JyksXG4gICAgICAgICAgICAgICAgeXRvcCA9IGNhbnZhc1RvcCArIE1hdGgucm91bmQoY2FudmFzSGVpZ2h0IC0gKGNhbnZhc0hlaWdodCAqICgobm9ybWFsUmFuZ2VNYXggLSB0aGlzLm1pbnkpIC8gcmFuZ2V5KSkpLFxuICAgICAgICAgICAgICAgIGhlaWdodCA9IE1hdGgucm91bmQoKGNhbnZhc0hlaWdodCAqIChub3JtYWxSYW5nZU1heCAtIG5vcm1hbFJhbmdlTWluKSkgLyByYW5nZXkpO1xuICAgICAgICAgICAgdGhpcy50YXJnZXQuZHJhd1JlY3QoY2FudmFzTGVmdCwgeXRvcCwgY2FudmFzV2lkdGgsIGhlaWdodCwgdW5kZWZpbmVkLCB0aGlzLm9wdGlvbnMuZ2V0KCdub3JtYWxSYW5nZUNvbG9yJykpLmFwcGVuZCgpO1xuICAgICAgICB9LFxuXG4gICAgICAgIHJlbmRlcjogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdmFyIG9wdGlvbnMgPSB0aGlzLm9wdGlvbnMsXG4gICAgICAgICAgICAgICAgdGFyZ2V0ID0gdGhpcy50YXJnZXQsXG4gICAgICAgICAgICAgICAgY2FudmFzV2lkdGggPSB0aGlzLmNhbnZhc1dpZHRoLFxuICAgICAgICAgICAgICAgIGNhbnZhc0hlaWdodCA9IHRoaXMuY2FudmFzSGVpZ2h0LFxuICAgICAgICAgICAgICAgIHZlcnRpY2VzID0gdGhpcy52ZXJ0aWNlcyxcbiAgICAgICAgICAgICAgICBzcG90UmFkaXVzID0gb3B0aW9ucy5nZXQoJ3Nwb3RSYWRpdXMnKSxcbiAgICAgICAgICAgICAgICByZWdpb25NYXAgPSB0aGlzLnJlZ2lvbk1hcCxcbiAgICAgICAgICAgICAgICByYW5nZXgsIHJhbmdleSwgeXZhbGxhc3QsXG4gICAgICAgICAgICAgICAgY2FudmFzVG9wLCBjYW52YXNMZWZ0LFxuICAgICAgICAgICAgICAgIHZlcnRleCwgcGF0aCwgcGF0aHMsIHgsIHksIHhuZXh0LCB4cG9zLCB4cG9zbmV4dCxcbiAgICAgICAgICAgICAgICBsYXN0LCBuZXh0LCB5dmFsY291bnQsIGxpbmVTaGFwZXMsIGZpbGxTaGFwZXMsIHBsZW4sXG4gICAgICAgICAgICAgICAgdmFsdWVTcG90cywgaGxTcG90c0VuYWJsZWQsIGNvbG9yLCB4dmFsdWVzLCB5dmFsdWVzLCBpO1xuXG4gICAgICAgICAgICBpZiAoIWxpbmUuX3N1cGVyLnJlbmRlci5jYWxsKHRoaXMpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB0aGlzLnNjYW5WYWx1ZXMoKTtcbiAgICAgICAgICAgIHRoaXMucHJvY2Vzc1JhbmdlT3B0aW9ucygpO1xuXG4gICAgICAgICAgICB4dmFsdWVzID0gdGhpcy54dmFsdWVzO1xuICAgICAgICAgICAgeXZhbHVlcyA9IHRoaXMueXZhbHVlcztcblxuICAgICAgICAgICAgaWYgKCF0aGlzLnltaW5tYXgubGVuZ3RoIHx8IHRoaXMueXZhbHVlcy5sZW5ndGggPCAyKSB7XG4gICAgICAgICAgICAgICAgLy8gZW1wdHkgb3IgYWxsIG51bGwgdmFsdWVzc1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgY2FudmFzVG9wID0gY2FudmFzTGVmdCA9IDA7XG5cbiAgICAgICAgICAgIHJhbmdleCA9IHRoaXMubWF4eCAtIHRoaXMubWlueCA9PT0gMCA/IDEgOiB0aGlzLm1heHggLSB0aGlzLm1pbng7XG4gICAgICAgICAgICByYW5nZXkgPSB0aGlzLm1heHkgLSB0aGlzLm1pbnkgPT09IDAgPyAxIDogdGhpcy5tYXh5IC0gdGhpcy5taW55O1xuICAgICAgICAgICAgeXZhbGxhc3QgPSB0aGlzLnl2YWx1ZXMubGVuZ3RoIC0gMTtcblxuICAgICAgICAgICAgaWYgKHNwb3RSYWRpdXMgJiYgKGNhbnZhc1dpZHRoIDwgKHNwb3RSYWRpdXMgKiA0KSB8fCBjYW52YXNIZWlnaHQgPCAoc3BvdFJhZGl1cyAqIDQpKSkge1xuICAgICAgICAgICAgICAgIHNwb3RSYWRpdXMgPSAwO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHNwb3RSYWRpdXMpIHtcbiAgICAgICAgICAgICAgICAvLyBhZGp1c3QgdGhlIGNhbnZhcyBzaXplIGFzIHJlcXVpcmVkIHNvIHRoYXQgc3BvdHMgd2lsbCBmaXRcbiAgICAgICAgICAgICAgICBobFNwb3RzRW5hYmxlZCA9IG9wdGlvbnMuZ2V0KCdoaWdobGlnaHRTcG90Q29sb3InKSAmJiAgIW9wdGlvbnMuZ2V0KCdkaXNhYmxlSW50ZXJhY3Rpb24nKTtcbiAgICAgICAgICAgICAgICBpZiAoaGxTcG90c0VuYWJsZWQgfHwgb3B0aW9ucy5nZXQoJ21pblNwb3RDb2xvcicpIHx8IChvcHRpb25zLmdldCgnc3BvdENvbG9yJykgJiYgeXZhbHVlc1t5dmFsbGFzdF0gPT09IHRoaXMubWlueSkpIHtcbiAgICAgICAgICAgICAgICAgICAgY2FudmFzSGVpZ2h0IC09IE1hdGguY2VpbChzcG90UmFkaXVzKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKGhsU3BvdHNFbmFibGVkIHx8IG9wdGlvbnMuZ2V0KCdtYXhTcG90Q29sb3InKSB8fCAob3B0aW9ucy5nZXQoJ3Nwb3RDb2xvcicpICYmIHl2YWx1ZXNbeXZhbGxhc3RdID09PSB0aGlzLm1heHkpKSB7XG4gICAgICAgICAgICAgICAgICAgIGNhbnZhc0hlaWdodCAtPSBNYXRoLmNlaWwoc3BvdFJhZGl1cyk7XG4gICAgICAgICAgICAgICAgICAgIGNhbnZhc1RvcCArPSBNYXRoLmNlaWwoc3BvdFJhZGl1cyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChobFNwb3RzRW5hYmxlZCB8fFxuICAgICAgICAgICAgICAgICAgICAgKChvcHRpb25zLmdldCgnbWluU3BvdENvbG9yJykgfHwgb3B0aW9ucy5nZXQoJ21heFNwb3RDb2xvcicpKSAmJiAoeXZhbHVlc1swXSA9PT0gdGhpcy5taW55IHx8IHl2YWx1ZXNbMF0gPT09IHRoaXMubWF4eSkpKSB7XG4gICAgICAgICAgICAgICAgICAgIGNhbnZhc0xlZnQgKz0gTWF0aC5jZWlsKHNwb3RSYWRpdXMpO1xuICAgICAgICAgICAgICAgICAgICBjYW52YXNXaWR0aCAtPSBNYXRoLmNlaWwoc3BvdFJhZGl1cyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChobFNwb3RzRW5hYmxlZCB8fCBvcHRpb25zLmdldCgnc3BvdENvbG9yJykgfHxcbiAgICAgICAgICAgICAgICAgICAgKG9wdGlvbnMuZ2V0KCdtaW5TcG90Q29sb3InKSB8fCBvcHRpb25zLmdldCgnbWF4U3BvdENvbG9yJykgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICh5dmFsdWVzW3l2YWxsYXN0XSA9PT0gdGhpcy5taW55IHx8IHl2YWx1ZXNbeXZhbGxhc3RdID09PSB0aGlzLm1heHkpKSkge1xuICAgICAgICAgICAgICAgICAgICBjYW52YXNXaWR0aCAtPSBNYXRoLmNlaWwoc3BvdFJhZGl1cyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG5cbiAgICAgICAgICAgIGNhbnZhc0hlaWdodC0tO1xuXG4gICAgICAgICAgICBpZiAob3B0aW9ucy5nZXQoJ25vcm1hbFJhbmdlTWluJykgIT09IHVuZGVmaW5lZCAmJiAhb3B0aW9ucy5nZXQoJ2RyYXdOb3JtYWxPblRvcCcpKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5kcmF3Tm9ybWFsUmFuZ2UoY2FudmFzTGVmdCwgY2FudmFzVG9wLCBjYW52YXNIZWlnaHQsIGNhbnZhc1dpZHRoLCByYW5nZXkpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBwYXRoID0gW107XG4gICAgICAgICAgICBwYXRocyA9IFtwYXRoXTtcbiAgICAgICAgICAgIGxhc3QgPSBuZXh0ID0gbnVsbDtcbiAgICAgICAgICAgIHl2YWxjb3VudCA9IHl2YWx1ZXMubGVuZ3RoO1xuICAgICAgICAgICAgZm9yIChpID0gMDsgaSA8IHl2YWxjb3VudDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgeCA9IHh2YWx1ZXNbaV07XG4gICAgICAgICAgICAgICAgeG5leHQgPSB4dmFsdWVzW2kgKyAxXTtcbiAgICAgICAgICAgICAgICB5ID0geXZhbHVlc1tpXTtcbiAgICAgICAgICAgICAgICB4cG9zID0gY2FudmFzTGVmdCArIE1hdGgucm91bmQoKHggLSB0aGlzLm1pbngpICogKGNhbnZhc1dpZHRoIC8gcmFuZ2V4KSk7XG4gICAgICAgICAgICAgICAgeHBvc25leHQgPSBpIDwgeXZhbGNvdW50IC0gMSA/IGNhbnZhc0xlZnQgKyBNYXRoLnJvdW5kKCh4bmV4dCAtIHRoaXMubWlueCkgKiAoY2FudmFzV2lkdGggLyByYW5nZXgpKSA6IGNhbnZhc1dpZHRoO1xuICAgICAgICAgICAgICAgIG5leHQgPSB4cG9zICsgKCh4cG9zbmV4dCAtIHhwb3MpIC8gMik7XG4gICAgICAgICAgICAgICAgcmVnaW9uTWFwW2ldID0gW2xhc3QgfHwgMCwgbmV4dCwgaV07XG4gICAgICAgICAgICAgICAgbGFzdCA9IG5leHQ7XG4gICAgICAgICAgICAgICAgaWYgKHkgPT09IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh5dmFsdWVzW2kgLSAxXSAhPT0gbnVsbCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhdGggPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXRocy5wdXNoKHBhdGgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgdmVydGljZXMucHVzaChudWxsKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICh5IDwgdGhpcy5taW55KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB5ID0gdGhpcy5taW55O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmICh5ID4gdGhpcy5tYXh5KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB5ID0gdGhpcy5tYXh5O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmICghcGF0aC5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHByZXZpb3VzIHZhbHVlIHdhcyBudWxsXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXRoLnB1c2goW3hwb3MsIGNhbnZhc1RvcCArIGNhbnZhc0hlaWdodF0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHZlcnRleCA9IFt4cG9zLCBjYW52YXNUb3AgKyBNYXRoLnJvdW5kKGNhbnZhc0hlaWdodCAtIChjYW52YXNIZWlnaHQgKiAoKHkgLSB0aGlzLm1pbnkpIC8gcmFuZ2V5KSkpXTtcbiAgICAgICAgICAgICAgICAgICAgcGF0aC5wdXNoKHZlcnRleCk7XG4gICAgICAgICAgICAgICAgICAgIHZlcnRpY2VzLnB1c2godmVydGV4KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGxpbmVTaGFwZXMgPSBbXTtcbiAgICAgICAgICAgIGZpbGxTaGFwZXMgPSBbXTtcbiAgICAgICAgICAgIHBsZW4gPSBwYXRocy5sZW5ndGg7XG4gICAgICAgICAgICBmb3IgKGkgPSAwOyBpIDwgcGxlbjsgaSsrKSB7XG4gICAgICAgICAgICAgICAgcGF0aCA9IHBhdGhzW2ldO1xuICAgICAgICAgICAgICAgIGlmIChwYXRoLmxlbmd0aCkge1xuICAgICAgICAgICAgICAgICAgICBpZiAob3B0aW9ucy5nZXQoJ2ZpbGxDb2xvcicpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBwYXRoLnB1c2goW3BhdGhbcGF0aC5sZW5ndGggLSAxXVswXSwgKGNhbnZhc1RvcCArIGNhbnZhc0hlaWdodCldKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpbGxTaGFwZXMucHVzaChwYXRoLnNsaWNlKDApKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhdGgucG9wKCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgLy8gaWYgdGhlcmUncyBvbmx5IGEgc2luZ2xlIHBvaW50IGluIHRoaXMgcGF0aCwgdGhlbiB3ZSB3YW50IHRvIGRpc3BsYXkgaXRcbiAgICAgICAgICAgICAgICAgICAgLy8gYXMgYSB2ZXJ0aWNhbCBsaW5lIHdoaWNoIG1lYW5zIHdlIGtlZXAgcGF0aFswXSAgYXMgaXNcbiAgICAgICAgICAgICAgICAgICAgaWYgKHBhdGgubGVuZ3RoID4gMikge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gZWxzZSB3ZSB3YW50IHRoZSBmaXJzdCB2YWx1ZVxuICAgICAgICAgICAgICAgICAgICAgICAgcGF0aFswXSA9IFtwYXRoWzBdWzBdLCBwYXRoWzFdWzFdXTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBsaW5lU2hhcGVzLnB1c2gocGF0aCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyBkcmF3IHRoZSBmaWxsIGZpcnN0LCB0aGVuIG9wdGlvbmFsbHkgdGhlIG5vcm1hbCByYW5nZSwgdGhlbiB0aGUgbGluZSBvbiB0b3Agb2YgdGhhdFxuICAgICAgICAgICAgcGxlbiA9IGZpbGxTaGFwZXMubGVuZ3RoO1xuICAgICAgICAgICAgZm9yIChpID0gMDsgaSA8IHBsZW47IGkrKykge1xuICAgICAgICAgICAgICAgIHRhcmdldC5kcmF3U2hhcGUoZmlsbFNoYXBlc1tpXSxcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9ucy5nZXQoJ2ZpbGxDb2xvcicpLCBvcHRpb25zLmdldCgnZmlsbENvbG9yJykpLmFwcGVuZCgpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAob3B0aW9ucy5nZXQoJ25vcm1hbFJhbmdlTWluJykgIT09IHVuZGVmaW5lZCAmJiBvcHRpb25zLmdldCgnZHJhd05vcm1hbE9uVG9wJykpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmRyYXdOb3JtYWxSYW5nZShjYW52YXNMZWZ0LCBjYW52YXNUb3AsIGNhbnZhc0hlaWdodCwgY2FudmFzV2lkdGgsIHJhbmdleSk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHBsZW4gPSBsaW5lU2hhcGVzLmxlbmd0aDtcbiAgICAgICAgICAgIGZvciAoaSA9IDA7IGkgPCBwbGVuOyBpKyspIHtcbiAgICAgICAgICAgICAgICB0YXJnZXQuZHJhd1NoYXBlKGxpbmVTaGFwZXNbaV0sIG9wdGlvbnMuZ2V0KCdsaW5lQ29sb3InKSwgdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgICAgICBvcHRpb25zLmdldCgnbGluZVdpZHRoJykpLmFwcGVuZCgpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAoc3BvdFJhZGl1cyAmJiBvcHRpb25zLmdldCgndmFsdWVTcG90cycpKSB7XG4gICAgICAgICAgICAgICAgdmFsdWVTcG90cyA9IG9wdGlvbnMuZ2V0KCd2YWx1ZVNwb3RzJyk7XG4gICAgICAgICAgICAgICAgaWYgKHZhbHVlU3BvdHMuZ2V0ID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgdmFsdWVTcG90cyA9IG5ldyBSYW5nZU1hcCh2YWx1ZVNwb3RzKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZm9yIChpID0gMDsgaSA8IHl2YWxjb3VudDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbG9yID0gdmFsdWVTcG90cy5nZXQoeXZhbHVlc1tpXSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChjb2xvcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0LmRyYXdDaXJjbGUoY2FudmFzTGVmdCArIE1hdGgucm91bmQoKHh2YWx1ZXNbaV0gLSB0aGlzLm1pbngpICogKGNhbnZhc1dpZHRoIC8gcmFuZ2V4KSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FudmFzVG9wICsgTWF0aC5yb3VuZChjYW52YXNIZWlnaHQgLSAoY2FudmFzSGVpZ2h0ICogKCh5dmFsdWVzW2ldIC0gdGhpcy5taW55KSAvIHJhbmdleSkpKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcG90UmFkaXVzLCB1bmRlZmluZWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3IpLmFwcGVuZCgpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoc3BvdFJhZGl1cyAmJiBvcHRpb25zLmdldCgnc3BvdENvbG9yJykgJiYgeXZhbHVlc1t5dmFsbGFzdF0gIT09IG51bGwpIHtcbiAgICAgICAgICAgICAgICB0YXJnZXQuZHJhd0NpcmNsZShjYW52YXNMZWZ0ICsgTWF0aC5yb3VuZCgoeHZhbHVlc1t4dmFsdWVzLmxlbmd0aCAtIDFdIC0gdGhpcy5taW54KSAqIChjYW52YXNXaWR0aCAvIHJhbmdleCkpLFxuICAgICAgICAgICAgICAgICAgICBjYW52YXNUb3AgKyBNYXRoLnJvdW5kKGNhbnZhc0hlaWdodCAtIChjYW52YXNIZWlnaHQgKiAoKHl2YWx1ZXNbeXZhbGxhc3RdIC0gdGhpcy5taW55KSAvIHJhbmdleSkpKSxcbiAgICAgICAgICAgICAgICAgICAgc3BvdFJhZGl1cywgdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgICAgICBvcHRpb25zLmdldCgnc3BvdENvbG9yJykpLmFwcGVuZCgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHRoaXMubWF4eSAhPT0gdGhpcy5taW55b3JnKSB7XG4gICAgICAgICAgICAgICAgaWYgKHNwb3RSYWRpdXMgJiYgb3B0aW9ucy5nZXQoJ21pblNwb3RDb2xvcicpKSB7XG4gICAgICAgICAgICAgICAgICAgIHggPSB4dmFsdWVzWyQuaW5BcnJheSh0aGlzLm1pbnlvcmcsIHl2YWx1ZXMpXTtcbiAgICAgICAgICAgICAgICAgICAgdGFyZ2V0LmRyYXdDaXJjbGUoY2FudmFzTGVmdCArIE1hdGgucm91bmQoKHggLSB0aGlzLm1pbngpICogKGNhbnZhc1dpZHRoIC8gcmFuZ2V4KSksXG4gICAgICAgICAgICAgICAgICAgICAgICBjYW52YXNUb3AgKyBNYXRoLnJvdW5kKGNhbnZhc0hlaWdodCAtIChjYW52YXNIZWlnaHQgKiAoKHRoaXMubWlueW9yZyAtIHRoaXMubWlueSkgLyByYW5nZXkpKSksXG4gICAgICAgICAgICAgICAgICAgICAgICBzcG90UmFkaXVzLCB1bmRlZmluZWQsXG4gICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zLmdldCgnbWluU3BvdENvbG9yJykpLmFwcGVuZCgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAoc3BvdFJhZGl1cyAmJiBvcHRpb25zLmdldCgnbWF4U3BvdENvbG9yJykpIHtcbiAgICAgICAgICAgICAgICAgICAgeCA9IHh2YWx1ZXNbJC5pbkFycmF5KHRoaXMubWF4eW9yZywgeXZhbHVlcyldO1xuICAgICAgICAgICAgICAgICAgICB0YXJnZXQuZHJhd0NpcmNsZShjYW52YXNMZWZ0ICsgTWF0aC5yb3VuZCgoeCAtIHRoaXMubWlueCkgKiAoY2FudmFzV2lkdGggLyByYW5nZXgpKSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhbnZhc1RvcCArIE1hdGgucm91bmQoY2FudmFzSGVpZ2h0IC0gKGNhbnZhc0hlaWdodCAqICgodGhpcy5tYXh5b3JnIC0gdGhpcy5taW55KSAvIHJhbmdleSkpKSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHNwb3RSYWRpdXMsIHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnMuZ2V0KCdtYXhTcG90Q29sb3InKSkuYXBwZW5kKCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB0aGlzLmxhc3RTaGFwZUlkID0gdGFyZ2V0LmdldExhc3RTaGFwZUlkKCk7XG4gICAgICAgICAgICB0aGlzLmNhbnZhc1RvcCA9IGNhbnZhc1RvcDtcbiAgICAgICAgICAgIHRhcmdldC5yZW5kZXIoKTtcbiAgICAgICAgfVxuICAgIH0pO1xuXG4gICAgLyoqXG4gICAgICogQmFyIGNoYXJ0c1xuICAgICAqL1xuICAgICQuZm4uc3BhcmtsaW5lLmJhciA9IGJhciA9IGNyZWF0ZUNsYXNzKCQuZm4uc3BhcmtsaW5lLl9iYXNlLCBiYXJIaWdobGlnaHRNaXhpbiwge1xuICAgICAgICB0eXBlOiAnYmFyJyxcblxuICAgICAgICBpbml0OiBmdW5jdGlvbiAoZWwsIHZhbHVlcywgb3B0aW9ucywgd2lkdGgsIGhlaWdodCkge1xuICAgICAgICAgICAgdmFyIGJhcldpZHRoID0gcGFyc2VJbnQob3B0aW9ucy5nZXQoJ2JhcldpZHRoJyksIDEwKSxcbiAgICAgICAgICAgICAgICBiYXJTcGFjaW5nID0gcGFyc2VJbnQob3B0aW9ucy5nZXQoJ2JhclNwYWNpbmcnKSwgMTApLFxuICAgICAgICAgICAgICAgIGNoYXJ0UmFuZ2VNaW4gPSBvcHRpb25zLmdldCgnY2hhcnRSYW5nZU1pbicpLFxuICAgICAgICAgICAgICAgIGNoYXJ0UmFuZ2VNYXggPSBvcHRpb25zLmdldCgnY2hhcnRSYW5nZU1heCcpLFxuICAgICAgICAgICAgICAgIGNoYXJ0UmFuZ2VDbGlwID0gb3B0aW9ucy5nZXQoJ2NoYXJ0UmFuZ2VDbGlwJyksXG4gICAgICAgICAgICAgICAgc3RhY2tNaW4gPSBJbmZpbml0eSxcbiAgICAgICAgICAgICAgICBzdGFja01heCA9IC1JbmZpbml0eSxcbiAgICAgICAgICAgICAgICBpc1N0YWNrU3RyaW5nLCBncm91cE1pbiwgZ3JvdXBNYXgsIHN0YWNrUmFuZ2VzLFxuICAgICAgICAgICAgICAgIG51bVZhbHVlcywgaSwgdmxlbiwgcmFuZ2UsIHplcm9BeGlzLCB4YXhpc09mZnNldCwgbWluLCBtYXgsIGNsaXBNaW4sIGNsaXBNYXgsXG4gICAgICAgICAgICAgICAgc3RhY2tlZCwgdmxpc3QsIGosIHNsZW4sIHN2YWxzLCB2YWwsIHlvZmZzZXQsIHlNYXhDYWxjLCBjYW52YXNIZWlnaHRFZjtcbiAgICAgICAgICAgIGJhci5fc3VwZXIuaW5pdC5jYWxsKHRoaXMsIGVsLCB2YWx1ZXMsIG9wdGlvbnMsIHdpZHRoLCBoZWlnaHQpO1xuXG4gICAgICAgICAgICAvLyBzY2FuIHZhbHVlcyB0byBkZXRlcm1pbmUgd2hldGhlciB0byBzdGFjayBiYXJzXG4gICAgICAgICAgICBmb3IgKGkgPSAwLCB2bGVuID0gdmFsdWVzLmxlbmd0aDsgaSA8IHZsZW47IGkrKykge1xuICAgICAgICAgICAgICAgIHZhbCA9IHZhbHVlc1tpXTtcbiAgICAgICAgICAgICAgICBpc1N0YWNrU3RyaW5nID0gdHlwZW9mKHZhbCkgPT09ICdzdHJpbmcnICYmIHZhbC5pbmRleE9mKCc6JykgPiAtMTtcbiAgICAgICAgICAgICAgICBpZiAoaXNTdGFja1N0cmluZyB8fCAkLmlzQXJyYXkodmFsKSkge1xuICAgICAgICAgICAgICAgICAgICBzdGFja2VkID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGlzU3RhY2tTdHJpbmcpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbCA9IHZhbHVlc1tpXSA9IG5vcm1hbGl6ZVZhbHVlcyh2YWwuc3BsaXQoJzonKSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgdmFsID0gcmVtb3ZlKHZhbCwgbnVsbCk7IC8vIG1pbi9tYXggd2lsbCB0cmVhdCBudWxsIGFzIHplcm9cbiAgICAgICAgICAgICAgICAgICAgZ3JvdXBNaW4gPSBNYXRoLm1pbi5hcHBseShNYXRoLCB2YWwpO1xuICAgICAgICAgICAgICAgICAgICBncm91cE1heCA9IE1hdGgubWF4LmFwcGx5KE1hdGgsIHZhbCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChncm91cE1pbiA8IHN0YWNrTWluKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzdGFja01pbiA9IGdyb3VwTWluO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmIChncm91cE1heCA+IHN0YWNrTWF4KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzdGFja01heCA9IGdyb3VwTWF4O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB0aGlzLnN0YWNrZWQgPSBzdGFja2VkO1xuICAgICAgICAgICAgdGhpcy5yZWdpb25TaGFwZXMgPSB7fTtcbiAgICAgICAgICAgIHRoaXMuYmFyV2lkdGggPSBiYXJXaWR0aDtcbiAgICAgICAgICAgIHRoaXMuYmFyU3BhY2luZyA9IGJhclNwYWNpbmc7XG4gICAgICAgICAgICB0aGlzLnRvdGFsQmFyV2lkdGggPSBiYXJXaWR0aCArIGJhclNwYWNpbmc7XG4gICAgICAgICAgICB0aGlzLndpZHRoID0gd2lkdGggPSAodmFsdWVzLmxlbmd0aCAqIGJhcldpZHRoKSArICgodmFsdWVzLmxlbmd0aCAtIDEpICogYmFyU3BhY2luZyk7XG5cbiAgICAgICAgICAgIHRoaXMuaW5pdFRhcmdldCgpO1xuXG4gICAgICAgICAgICBpZiAoY2hhcnRSYW5nZUNsaXApIHtcbiAgICAgICAgICAgICAgICBjbGlwTWluID0gY2hhcnRSYW5nZU1pbiA9PT0gdW5kZWZpbmVkID8gLUluZmluaXR5IDogY2hhcnRSYW5nZU1pbjtcbiAgICAgICAgICAgICAgICBjbGlwTWF4ID0gY2hhcnRSYW5nZU1heCA9PT0gdW5kZWZpbmVkID8gSW5maW5pdHkgOiBjaGFydFJhbmdlTWF4O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBudW1WYWx1ZXMgPSBbXTtcbiAgICAgICAgICAgIHN0YWNrUmFuZ2VzID0gc3RhY2tlZCA/IFtdIDogbnVtVmFsdWVzO1xuICAgICAgICAgICAgdmFyIHN0YWNrVG90YWxzID0gW107XG4gICAgICAgICAgICB2YXIgc3RhY2tSYW5nZXNOZWcgPSBbXTtcbiAgICAgICAgICAgIGZvciAoaSA9IDAsIHZsZW4gPSB2YWx1ZXMubGVuZ3RoOyBpIDwgdmxlbjsgaSsrKSB7XG4gICAgICAgICAgICAgICAgaWYgKHN0YWNrZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgdmxpc3QgPSB2YWx1ZXNbaV07XG4gICAgICAgICAgICAgICAgICAgIHZhbHVlc1tpXSA9IHN2YWxzID0gW107XG4gICAgICAgICAgICAgICAgICAgIHN0YWNrVG90YWxzW2ldID0gMDtcbiAgICAgICAgICAgICAgICAgICAgc3RhY2tSYW5nZXNbaV0gPSBzdGFja1Jhbmdlc05lZ1tpXSA9IDA7XG4gICAgICAgICAgICAgICAgICAgIGZvciAoaiA9IDAsIHNsZW4gPSB2bGlzdC5sZW5ndGg7IGogPCBzbGVuOyBqKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbCA9IHN2YWxzW2pdID0gY2hhcnRSYW5nZUNsaXAgPyBjbGlwdmFsKHZsaXN0W2pdLCBjbGlwTWluLCBjbGlwTWF4KSA6IHZsaXN0W2pdO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHZhbCAhPT0gbnVsbCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2YWwgPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0YWNrVG90YWxzW2ldICs9IHZhbDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHN0YWNrTWluIDwgMCAmJiBzdGFja01heCA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHZhbCA8IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0YWNrUmFuZ2VzTmVnW2ldICs9IE1hdGguYWJzKHZhbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGFja1Jhbmdlc1tpXSArPSB2YWw7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGFja1Jhbmdlc1tpXSArPSBNYXRoLmFicyh2YWwgLSAodmFsIDwgMCA/IHN0YWNrTWF4IDogc3RhY2tNaW4pKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbnVtVmFsdWVzLnB1c2godmFsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHZhbCA9IGNoYXJ0UmFuZ2VDbGlwID8gY2xpcHZhbCh2YWx1ZXNbaV0sIGNsaXBNaW4sIGNsaXBNYXgpIDogdmFsdWVzW2ldO1xuICAgICAgICAgICAgICAgICAgICB2YWwgPSB2YWx1ZXNbaV0gPSBub3JtYWxpemVWYWx1ZSh2YWwpO1xuICAgICAgICAgICAgICAgICAgICBpZiAodmFsICE9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBudW1WYWx1ZXMucHVzaCh2YWwpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5tYXggPSBtYXggPSBNYXRoLm1heC5hcHBseShNYXRoLCBudW1WYWx1ZXMpO1xuICAgICAgICAgICAgdGhpcy5taW4gPSBtaW4gPSBNYXRoLm1pbi5hcHBseShNYXRoLCBudW1WYWx1ZXMpO1xuICAgICAgICAgICAgdGhpcy5zdGFja01heCA9IHN0YWNrTWF4ID0gc3RhY2tlZCA/IE1hdGgubWF4LmFwcGx5KE1hdGgsIHN0YWNrVG90YWxzKSA6IG1heDtcbiAgICAgICAgICAgIHRoaXMuc3RhY2tNaW4gPSBzdGFja01pbiA9IHN0YWNrZWQgPyBNYXRoLm1pbi5hcHBseShNYXRoLCBudW1WYWx1ZXMpIDogbWluO1xuXG4gICAgICAgICAgICBpZiAob3B0aW9ucy5nZXQoJ2NoYXJ0UmFuZ2VNaW4nKSAhPT0gdW5kZWZpbmVkICYmIChvcHRpb25zLmdldCgnY2hhcnRSYW5nZUNsaXAnKSB8fCBvcHRpb25zLmdldCgnY2hhcnRSYW5nZU1pbicpIDwgbWluKSkge1xuICAgICAgICAgICAgICAgIG1pbiA9IG9wdGlvbnMuZ2V0KCdjaGFydFJhbmdlTWluJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAob3B0aW9ucy5nZXQoJ2NoYXJ0UmFuZ2VNYXgnKSAhPT0gdW5kZWZpbmVkICYmIChvcHRpb25zLmdldCgnY2hhcnRSYW5nZUNsaXAnKSB8fCBvcHRpb25zLmdldCgnY2hhcnRSYW5nZU1heCcpID4gbWF4KSkge1xuICAgICAgICAgICAgICAgIG1heCA9IG9wdGlvbnMuZ2V0KCdjaGFydFJhbmdlTWF4Jyk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHRoaXMuemVyb0F4aXMgPSB6ZXJvQXhpcyA9IG9wdGlvbnMuZ2V0KCd6ZXJvQXhpcycsIHRydWUpO1xuICAgICAgICAgICAgaWYgKG1pbiA8PSAwICYmIG1heCA+PSAwICYmIHplcm9BeGlzKSB7XG4gICAgICAgICAgICAgICAgeGF4aXNPZmZzZXQgPSAwO1xuICAgICAgICAgICAgfSBlbHNlIGlmICh6ZXJvQXhpcyA9PSBmYWxzZSkge1xuICAgICAgICAgICAgICAgIHhheGlzT2Zmc2V0ID0gbWluO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChtaW4gPiAwKSB7XG4gICAgICAgICAgICAgICAgeGF4aXNPZmZzZXQgPSBtaW47XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHhheGlzT2Zmc2V0ID0gbWF4O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy54YXhpc09mZnNldCA9IHhheGlzT2Zmc2V0O1xuXG4gICAgICAgICAgICByYW5nZSA9IHN0YWNrZWQgPyAoTWF0aC5tYXguYXBwbHkoTWF0aCwgc3RhY2tSYW5nZXMpICsgTWF0aC5tYXguYXBwbHkoTWF0aCwgc3RhY2tSYW5nZXNOZWcpKSA6IG1heCAtIG1pbjtcblxuICAgICAgICAgICAgLy8gYXMgd2UgcGxvdCB6ZXJvL21pbiB2YWx1ZXMgYSBzaW5nbGUgcGl4ZWwgbGluZSwgd2UgYWRkIGEgcGl4ZWwgdG8gYWxsIG90aGVyXG4gICAgICAgICAgICAvLyB2YWx1ZXMgLSBSZWR1Y2UgdGhlIGVmZmVjdGl2ZSBjYW52YXMgc2l6ZSB0byBzdWl0XG4gICAgICAgICAgICB0aGlzLmNhbnZhc0hlaWdodEVmID0gKHplcm9BeGlzICYmIG1pbiA8IDApID8gdGhpcy5jYW52YXNIZWlnaHQgLSAyIDogdGhpcy5jYW52YXNIZWlnaHQgLSAxO1xuXG4gICAgICAgICAgICBpZiAobWluIDwgeGF4aXNPZmZzZXQpIHtcbiAgICAgICAgICAgICAgICB5TWF4Q2FsYyA9IChzdGFja2VkICYmIG1heCA+PSAwKSA/IHN0YWNrTWF4IDogbWF4O1xuICAgICAgICAgICAgICAgIHlvZmZzZXQgPSAoeU1heENhbGMgLSB4YXhpc09mZnNldCkgLyByYW5nZSAqIHRoaXMuY2FudmFzSGVpZ2h0O1xuICAgICAgICAgICAgICAgIGlmICh5b2Zmc2V0ICE9PSBNYXRoLmNlaWwoeW9mZnNldCkpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jYW52YXNIZWlnaHRFZiAtPSAyO1xuICAgICAgICAgICAgICAgICAgICB5b2Zmc2V0ID0gTWF0aC5jZWlsKHlvZmZzZXQpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgeW9mZnNldCA9IHRoaXMuY2FudmFzSGVpZ2h0O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy55b2Zmc2V0ID0geW9mZnNldDtcblxuICAgICAgICAgICAgaWYgKCQuaXNBcnJheShvcHRpb25zLmdldCgnY29sb3JNYXAnKSkpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmNvbG9yTWFwQnlJbmRleCA9IG9wdGlvbnMuZ2V0KCdjb2xvck1hcCcpO1xuICAgICAgICAgICAgICAgIHRoaXMuY29sb3JNYXBCeVZhbHVlID0gbnVsbDtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhpcy5jb2xvck1hcEJ5SW5kZXggPSBudWxsO1xuICAgICAgICAgICAgICAgIHRoaXMuY29sb3JNYXBCeVZhbHVlID0gb3B0aW9ucy5nZXQoJ2NvbG9yTWFwJyk7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY29sb3JNYXBCeVZhbHVlICYmIHRoaXMuY29sb3JNYXBCeVZhbHVlLmdldCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY29sb3JNYXBCeVZhbHVlID0gbmV3IFJhbmdlTWFwKHRoaXMuY29sb3JNYXBCeVZhbHVlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHRoaXMucmFuZ2UgPSByYW5nZTtcbiAgICAgICAgfSxcblxuICAgICAgICBnZXRSZWdpb246IGZ1bmN0aW9uIChlbCwgeCwgeSkge1xuICAgICAgICAgICAgdmFyIHJlc3VsdCA9IE1hdGguZmxvb3IoeCAvIHRoaXMudG90YWxCYXJXaWR0aCk7XG4gICAgICAgICAgICByZXR1cm4gKHJlc3VsdCA8IDAgfHwgcmVzdWx0ID49IHRoaXMudmFsdWVzLmxlbmd0aCkgPyB1bmRlZmluZWQgOiByZXN1bHQ7XG4gICAgICAgIH0sXG5cbiAgICAgICAgZ2V0Q3VycmVudFJlZ2lvbkZpZWxkczogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdmFyIGN1cnJlbnRSZWdpb24gPSB0aGlzLmN1cnJlbnRSZWdpb24sXG4gICAgICAgICAgICAgICAgdmFsdWVzID0gZW5zdXJlQXJyYXkodGhpcy52YWx1ZXNbY3VycmVudFJlZ2lvbl0pLFxuICAgICAgICAgICAgICAgIHJlc3VsdCA9IFtdLFxuICAgICAgICAgICAgICAgIHZhbHVlLCBpO1xuICAgICAgICAgICAgZm9yIChpID0gdmFsdWVzLmxlbmd0aDsgaS0tOykge1xuICAgICAgICAgICAgICAgIHZhbHVlID0gdmFsdWVzW2ldO1xuICAgICAgICAgICAgICAgIHJlc3VsdC5wdXNoKHtcbiAgICAgICAgICAgICAgICAgICAgaXNOdWxsOiB2YWx1ZSA9PT0gbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU6IHZhbHVlLFxuICAgICAgICAgICAgICAgICAgICBjb2xvcjogdGhpcy5jYWxjQ29sb3IoaSwgdmFsdWUsIGN1cnJlbnRSZWdpb24pLFxuICAgICAgICAgICAgICAgICAgICBvZmZzZXQ6IGN1cnJlbnRSZWdpb25cbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICAgIH0sXG5cbiAgICAgICAgY2FsY0NvbG9yOiBmdW5jdGlvbiAoc3RhY2tudW0sIHZhbHVlLCB2YWx1ZW51bSkge1xuICAgICAgICAgICAgdmFyIGNvbG9yTWFwQnlJbmRleCA9IHRoaXMuY29sb3JNYXBCeUluZGV4LFxuICAgICAgICAgICAgICAgIGNvbG9yTWFwQnlWYWx1ZSA9IHRoaXMuY29sb3JNYXBCeVZhbHVlLFxuICAgICAgICAgICAgICAgIG9wdGlvbnMgPSB0aGlzLm9wdGlvbnMsXG4gICAgICAgICAgICAgICAgY29sb3IsIG5ld0NvbG9yO1xuICAgICAgICAgICAgaWYgKHRoaXMuc3RhY2tlZCkge1xuICAgICAgICAgICAgICAgIGNvbG9yID0gb3B0aW9ucy5nZXQoJ3N0YWNrZWRCYXJDb2xvcicpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBjb2xvciA9ICh2YWx1ZSA8IDApID8gb3B0aW9ucy5nZXQoJ25lZ0JhckNvbG9yJykgOiBvcHRpb25zLmdldCgnYmFyQ29sb3InKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICh2YWx1ZSA9PT0gMCAmJiBvcHRpb25zLmdldCgnemVyb0NvbG9yJykgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgIGNvbG9yID0gb3B0aW9ucy5nZXQoJ3plcm9Db2xvcicpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGNvbG9yTWFwQnlWYWx1ZSAmJiAobmV3Q29sb3IgPSBjb2xvck1hcEJ5VmFsdWUuZ2V0KHZhbHVlKSkpIHtcbiAgICAgICAgICAgICAgICBjb2xvciA9IG5ld0NvbG9yO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChjb2xvck1hcEJ5SW5kZXggJiYgY29sb3JNYXBCeUluZGV4Lmxlbmd0aCA+IHZhbHVlbnVtKSB7XG4gICAgICAgICAgICAgICAgY29sb3IgPSBjb2xvck1hcEJ5SW5kZXhbdmFsdWVudW1dO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuICQuaXNBcnJheShjb2xvcikgPyBjb2xvcltzdGFja251bSAlIGNvbG9yLmxlbmd0aF0gOiBjb2xvcjtcbiAgICAgICAgfSxcblxuICAgICAgICAvKipcbiAgICAgICAgICogUmVuZGVyIGJhcihzKSBmb3IgYSByZWdpb25cbiAgICAgICAgICovXG4gICAgICAgIHJlbmRlclJlZ2lvbjogZnVuY3Rpb24gKHZhbHVlbnVtLCBoaWdobGlnaHQpIHtcbiAgICAgICAgICAgIHZhciB2YWxzID0gdGhpcy52YWx1ZXNbdmFsdWVudW1dLFxuICAgICAgICAgICAgICAgIG9wdGlvbnMgPSB0aGlzLm9wdGlvbnMsXG4gICAgICAgICAgICAgICAgeGF4aXNPZmZzZXQgPSB0aGlzLnhheGlzT2Zmc2V0LFxuICAgICAgICAgICAgICAgIHJlc3VsdCA9IFtdLFxuICAgICAgICAgICAgICAgIHJhbmdlID0gdGhpcy5yYW5nZSxcbiAgICAgICAgICAgICAgICBzdGFja2VkID0gdGhpcy5zdGFja2VkLFxuICAgICAgICAgICAgICAgIHRhcmdldCA9IHRoaXMudGFyZ2V0LFxuICAgICAgICAgICAgICAgIHggPSB2YWx1ZW51bSAqIHRoaXMudG90YWxCYXJXaWR0aCxcbiAgICAgICAgICAgICAgICBjYW52YXNIZWlnaHRFZiA9IHRoaXMuY2FudmFzSGVpZ2h0RWYsXG4gICAgICAgICAgICAgICAgeW9mZnNldCA9IHRoaXMueW9mZnNldCxcbiAgICAgICAgICAgICAgICB5LCBoZWlnaHQsIGNvbG9yLCBpc051bGwsIHlvZmZzZXROZWcsIGksIHZhbGNvdW50LCB2YWwsIG1pblBsb3R0ZWQsIGFsbE1pbjtcblxuICAgICAgICAgICAgdmFscyA9ICQuaXNBcnJheSh2YWxzKSA/IHZhbHMgOiBbdmFsc107XG4gICAgICAgICAgICB2YWxjb3VudCA9IHZhbHMubGVuZ3RoO1xuICAgICAgICAgICAgdmFsID0gdmFsc1swXTtcbiAgICAgICAgICAgIGlzTnVsbCA9IGFsbChudWxsLCB2YWxzKTtcbiAgICAgICAgICAgIGFsbE1pbiA9IGFsbCh4YXhpc09mZnNldCwgdmFscywgdHJ1ZSk7XG5cbiAgICAgICAgICAgIGlmIChpc051bGwpIHtcbiAgICAgICAgICAgICAgICBpZiAob3B0aW9ucy5nZXQoJ251bGxDb2xvcicpKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbG9yID0gaGlnaGxpZ2h0ID8gb3B0aW9ucy5nZXQoJ251bGxDb2xvcicpIDogdGhpcy5jYWxjSGlnaGxpZ2h0Q29sb3Iob3B0aW9ucy5nZXQoJ251bGxDb2xvcicpLCBvcHRpb25zKTtcbiAgICAgICAgICAgICAgICAgICAgeSA9ICh5b2Zmc2V0ID4gMCkgPyB5b2Zmc2V0IC0gMSA6IHlvZmZzZXQ7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0YXJnZXQuZHJhd1JlY3QoeCwgeSwgdGhpcy5iYXJXaWR0aCAtIDEsIDAsIGNvbG9yLCBjb2xvcik7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB5b2Zmc2V0TmVnID0geW9mZnNldDtcbiAgICAgICAgICAgIGZvciAoaSA9IDA7IGkgPCB2YWxjb3VudDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgdmFsID0gdmFsc1tpXTtcblxuICAgICAgICAgICAgICAgIGlmIChzdGFja2VkICYmIHZhbCA9PT0geGF4aXNPZmZzZXQpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFhbGxNaW4gfHwgbWluUGxvdHRlZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgbWluUGxvdHRlZCA9IHRydWU7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgaWYgKHJhbmdlID4gMCkge1xuICAgICAgICAgICAgICAgICAgICBoZWlnaHQgPSBNYXRoLmZsb29yKGNhbnZhc0hlaWdodEVmICogKChNYXRoLmFicyh2YWwgLSB4YXhpc09mZnNldCkgLyByYW5nZSkpKSArIDE7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgaGVpZ2h0ID0gMTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKHZhbCA8IHhheGlzT2Zmc2V0IHx8ICh2YWwgPT09IHhheGlzT2Zmc2V0ICYmIHlvZmZzZXQgPT09IDApKSB7XG4gICAgICAgICAgICAgICAgICAgIHkgPSB5b2Zmc2V0TmVnO1xuICAgICAgICAgICAgICAgICAgICB5b2Zmc2V0TmVnICs9IGhlaWdodDtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICB5ID0geW9mZnNldCAtIGhlaWdodDtcbiAgICAgICAgICAgICAgICAgICAgeW9mZnNldCAtPSBoZWlnaHQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbG9yID0gdGhpcy5jYWxjQ29sb3IoaSwgdmFsLCB2YWx1ZW51bSk7XG4gICAgICAgICAgICAgICAgaWYgKGhpZ2hsaWdodCkge1xuICAgICAgICAgICAgICAgICAgICBjb2xvciA9IHRoaXMuY2FsY0hpZ2hsaWdodENvbG9yKGNvbG9yLCBvcHRpb25zKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmVzdWx0LnB1c2godGFyZ2V0LmRyYXdSZWN0KHgsIHksIHRoaXMuYmFyV2lkdGggLSAxLCBoZWlnaHQgLSAxLCBjb2xvciwgY29sb3IpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChyZXN1bHQubGVuZ3RoID09PSAxKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlc3VsdFswXTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICAgIH1cbiAgICB9KTtcblxuICAgIC8qKlxuICAgICAqIFRyaXN0YXRlIGNoYXJ0c1xuICAgICAqL1xuICAgICQuZm4uc3BhcmtsaW5lLnRyaXN0YXRlID0gdHJpc3RhdGUgPSBjcmVhdGVDbGFzcygkLmZuLnNwYXJrbGluZS5fYmFzZSwgYmFySGlnaGxpZ2h0TWl4aW4sIHtcbiAgICAgICAgdHlwZTogJ3RyaXN0YXRlJyxcblxuICAgICAgICBpbml0OiBmdW5jdGlvbiAoZWwsIHZhbHVlcywgb3B0aW9ucywgd2lkdGgsIGhlaWdodCkge1xuICAgICAgICAgICAgdmFyIGJhcldpZHRoID0gcGFyc2VJbnQob3B0aW9ucy5nZXQoJ2JhcldpZHRoJyksIDEwKSxcbiAgICAgICAgICAgICAgICBiYXJTcGFjaW5nID0gcGFyc2VJbnQob3B0aW9ucy5nZXQoJ2JhclNwYWNpbmcnKSwgMTApO1xuICAgICAgICAgICAgdHJpc3RhdGUuX3N1cGVyLmluaXQuY2FsbCh0aGlzLCBlbCwgdmFsdWVzLCBvcHRpb25zLCB3aWR0aCwgaGVpZ2h0KTtcblxuICAgICAgICAgICAgdGhpcy5yZWdpb25TaGFwZXMgPSB7fTtcbiAgICAgICAgICAgIHRoaXMuYmFyV2lkdGggPSBiYXJXaWR0aDtcbiAgICAgICAgICAgIHRoaXMuYmFyU3BhY2luZyA9IGJhclNwYWNpbmc7XG4gICAgICAgICAgICB0aGlzLnRvdGFsQmFyV2lkdGggPSBiYXJXaWR0aCArIGJhclNwYWNpbmc7XG4gICAgICAgICAgICB0aGlzLnZhbHVlcyA9ICQubWFwKHZhbHVlcywgTnVtYmVyKTtcbiAgICAgICAgICAgIHRoaXMud2lkdGggPSB3aWR0aCA9ICh2YWx1ZXMubGVuZ3RoICogYmFyV2lkdGgpICsgKCh2YWx1ZXMubGVuZ3RoIC0gMSkgKiBiYXJTcGFjaW5nKTtcblxuICAgICAgICAgICAgaWYgKCQuaXNBcnJheShvcHRpb25zLmdldCgnY29sb3JNYXAnKSkpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmNvbG9yTWFwQnlJbmRleCA9IG9wdGlvbnMuZ2V0KCdjb2xvck1hcCcpO1xuICAgICAgICAgICAgICAgIHRoaXMuY29sb3JNYXBCeVZhbHVlID0gbnVsbDtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhpcy5jb2xvck1hcEJ5SW5kZXggPSBudWxsO1xuICAgICAgICAgICAgICAgIHRoaXMuY29sb3JNYXBCeVZhbHVlID0gb3B0aW9ucy5nZXQoJ2NvbG9yTWFwJyk7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY29sb3JNYXBCeVZhbHVlICYmIHRoaXMuY29sb3JNYXBCeVZhbHVlLmdldCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY29sb3JNYXBCeVZhbHVlID0gbmV3IFJhbmdlTWFwKHRoaXMuY29sb3JNYXBCeVZhbHVlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLmluaXRUYXJnZXQoKTtcbiAgICAgICAgfSxcblxuICAgICAgICBnZXRSZWdpb246IGZ1bmN0aW9uIChlbCwgeCwgeSkge1xuICAgICAgICAgICAgcmV0dXJuIE1hdGguZmxvb3IoeCAvIHRoaXMudG90YWxCYXJXaWR0aCk7XG4gICAgICAgIH0sXG5cbiAgICAgICAgZ2V0Q3VycmVudFJlZ2lvbkZpZWxkczogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdmFyIGN1cnJlbnRSZWdpb24gPSB0aGlzLmN1cnJlbnRSZWdpb247XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIGlzTnVsbDogdGhpcy52YWx1ZXNbY3VycmVudFJlZ2lvbl0gPT09IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICB2YWx1ZTogdGhpcy52YWx1ZXNbY3VycmVudFJlZ2lvbl0sXG4gICAgICAgICAgICAgICAgY29sb3I6IHRoaXMuY2FsY0NvbG9yKHRoaXMudmFsdWVzW2N1cnJlbnRSZWdpb25dLCBjdXJyZW50UmVnaW9uKSxcbiAgICAgICAgICAgICAgICBvZmZzZXQ6IGN1cnJlbnRSZWdpb25cbiAgICAgICAgICAgIH07XG4gICAgICAgIH0sXG5cbiAgICAgICAgY2FsY0NvbG9yOiBmdW5jdGlvbiAodmFsdWUsIHZhbHVlbnVtKSB7XG4gICAgICAgICAgICB2YXIgdmFsdWVzID0gdGhpcy52YWx1ZXMsXG4gICAgICAgICAgICAgICAgb3B0aW9ucyA9IHRoaXMub3B0aW9ucyxcbiAgICAgICAgICAgICAgICBjb2xvck1hcEJ5SW5kZXggPSB0aGlzLmNvbG9yTWFwQnlJbmRleCxcbiAgICAgICAgICAgICAgICBjb2xvck1hcEJ5VmFsdWUgPSB0aGlzLmNvbG9yTWFwQnlWYWx1ZSxcbiAgICAgICAgICAgICAgICBjb2xvciwgbmV3Q29sb3I7XG5cbiAgICAgICAgICAgIGlmIChjb2xvck1hcEJ5VmFsdWUgJiYgKG5ld0NvbG9yID0gY29sb3JNYXBCeVZhbHVlLmdldCh2YWx1ZSkpKSB7XG4gICAgICAgICAgICAgICAgY29sb3IgPSBuZXdDb2xvcjtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoY29sb3JNYXBCeUluZGV4ICYmIGNvbG9yTWFwQnlJbmRleC5sZW5ndGggPiB2YWx1ZW51bSkge1xuICAgICAgICAgICAgICAgIGNvbG9yID0gY29sb3JNYXBCeUluZGV4W3ZhbHVlbnVtXTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAodmFsdWVzW3ZhbHVlbnVtXSA8IDApIHtcbiAgICAgICAgICAgICAgICBjb2xvciA9IG9wdGlvbnMuZ2V0KCduZWdCYXJDb2xvcicpO1xuICAgICAgICAgICAgfSBlbHNlIGlmICh2YWx1ZXNbdmFsdWVudW1dID4gMCkge1xuICAgICAgICAgICAgICAgIGNvbG9yID0gb3B0aW9ucy5nZXQoJ3Bvc0JhckNvbG9yJyk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGNvbG9yID0gb3B0aW9ucy5nZXQoJ3plcm9CYXJDb2xvcicpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIGNvbG9yO1xuICAgICAgICB9LFxuXG4gICAgICAgIHJlbmRlclJlZ2lvbjogZnVuY3Rpb24gKHZhbHVlbnVtLCBoaWdobGlnaHQpIHtcbiAgICAgICAgICAgIHZhciB2YWx1ZXMgPSB0aGlzLnZhbHVlcyxcbiAgICAgICAgICAgICAgICBvcHRpb25zID0gdGhpcy5vcHRpb25zLFxuICAgICAgICAgICAgICAgIHRhcmdldCA9IHRoaXMudGFyZ2V0LFxuICAgICAgICAgICAgICAgIGNhbnZhc0hlaWdodCwgaGVpZ2h0LCBoYWxmSGVpZ2h0LFxuICAgICAgICAgICAgICAgIHgsIHksIGNvbG9yO1xuXG4gICAgICAgICAgICBjYW52YXNIZWlnaHQgPSB0YXJnZXQucGl4ZWxIZWlnaHQ7XG4gICAgICAgICAgICBoYWxmSGVpZ2h0ID0gTWF0aC5yb3VuZChjYW52YXNIZWlnaHQgLyAyKTtcblxuICAgICAgICAgICAgeCA9IHZhbHVlbnVtICogdGhpcy50b3RhbEJhcldpZHRoO1xuICAgICAgICAgICAgaWYgKHZhbHVlc1t2YWx1ZW51bV0gPCAwKSB7XG4gICAgICAgICAgICAgICAgeSA9IGhhbGZIZWlnaHQ7XG4gICAgICAgICAgICAgICAgaGVpZ2h0ID0gaGFsZkhlaWdodCAtIDE7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKHZhbHVlc1t2YWx1ZW51bV0gPiAwKSB7XG4gICAgICAgICAgICAgICAgeSA9IDA7XG4gICAgICAgICAgICAgICAgaGVpZ2h0ID0gaGFsZkhlaWdodCAtIDE7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHkgPSBoYWxmSGVpZ2h0IC0gMTtcbiAgICAgICAgICAgICAgICBoZWlnaHQgPSAyO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29sb3IgPSB0aGlzLmNhbGNDb2xvcih2YWx1ZXNbdmFsdWVudW1dLCB2YWx1ZW51bSk7XG4gICAgICAgICAgICBpZiAoY29sb3IgPT09IG51bGwpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoaGlnaGxpZ2h0KSB7XG4gICAgICAgICAgICAgICAgY29sb3IgPSB0aGlzLmNhbGNIaWdobGlnaHRDb2xvcihjb2xvciwgb3B0aW9ucyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gdGFyZ2V0LmRyYXdSZWN0KHgsIHksIHRoaXMuYmFyV2lkdGggLSAxLCBoZWlnaHQgLSAxLCBjb2xvciwgY29sb3IpO1xuICAgICAgICB9XG4gICAgfSk7XG5cbiAgICAvKipcbiAgICAgKiBEaXNjcmV0ZSBjaGFydHNcbiAgICAgKi9cbiAgICAkLmZuLnNwYXJrbGluZS5kaXNjcmV0ZSA9IGRpc2NyZXRlID0gY3JlYXRlQ2xhc3MoJC5mbi5zcGFya2xpbmUuX2Jhc2UsIGJhckhpZ2hsaWdodE1peGluLCB7XG4gICAgICAgIHR5cGU6ICdkaXNjcmV0ZScsXG5cbiAgICAgICAgaW5pdDogZnVuY3Rpb24gKGVsLCB2YWx1ZXMsIG9wdGlvbnMsIHdpZHRoLCBoZWlnaHQpIHtcbiAgICAgICAgICAgIGRpc2NyZXRlLl9zdXBlci5pbml0LmNhbGwodGhpcywgZWwsIHZhbHVlcywgb3B0aW9ucywgd2lkdGgsIGhlaWdodCk7XG5cbiAgICAgICAgICAgIHRoaXMucmVnaW9uU2hhcGVzID0ge307XG4gICAgICAgICAgICB0aGlzLnZhbHVlcyA9IHZhbHVlcyA9ICQubWFwKHZhbHVlcywgTnVtYmVyKTtcbiAgICAgICAgICAgIHRoaXMubWluID0gTWF0aC5taW4uYXBwbHkoTWF0aCwgdmFsdWVzKTtcbiAgICAgICAgICAgIHRoaXMubWF4ID0gTWF0aC5tYXguYXBwbHkoTWF0aCwgdmFsdWVzKTtcbiAgICAgICAgICAgIHRoaXMucmFuZ2UgPSB0aGlzLm1heCAtIHRoaXMubWluO1xuICAgICAgICAgICAgdGhpcy53aWR0aCA9IHdpZHRoID0gb3B0aW9ucy5nZXQoJ3dpZHRoJykgPT09ICdhdXRvJyA/IHZhbHVlcy5sZW5ndGggKiAyIDogdGhpcy53aWR0aDtcbiAgICAgICAgICAgIHRoaXMuaW50ZXJ2YWwgPSBNYXRoLmZsb29yKHdpZHRoIC8gdmFsdWVzLmxlbmd0aCk7XG4gICAgICAgICAgICB0aGlzLml0ZW1XaWR0aCA9IHdpZHRoIC8gdmFsdWVzLmxlbmd0aDtcbiAgICAgICAgICAgIGlmIChvcHRpb25zLmdldCgnY2hhcnRSYW5nZU1pbicpICE9PSB1bmRlZmluZWQgJiYgKG9wdGlvbnMuZ2V0KCdjaGFydFJhbmdlQ2xpcCcpIHx8IG9wdGlvbnMuZ2V0KCdjaGFydFJhbmdlTWluJykgPCB0aGlzLm1pbikpIHtcbiAgICAgICAgICAgICAgICB0aGlzLm1pbiA9IG9wdGlvbnMuZ2V0KCdjaGFydFJhbmdlTWluJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAob3B0aW9ucy5nZXQoJ2NoYXJ0UmFuZ2VNYXgnKSAhPT0gdW5kZWZpbmVkICYmIChvcHRpb25zLmdldCgnY2hhcnRSYW5nZUNsaXAnKSB8fCBvcHRpb25zLmdldCgnY2hhcnRSYW5nZU1heCcpID4gdGhpcy5tYXgpKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5tYXggPSBvcHRpb25zLmdldCgnY2hhcnRSYW5nZU1heCcpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5pbml0VGFyZ2V0KCk7XG4gICAgICAgICAgICBpZiAodGhpcy50YXJnZXQpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmxpbmVIZWlnaHQgPSBvcHRpb25zLmdldCgnbGluZUhlaWdodCcpID09PSAnYXV0bycgPyBNYXRoLnJvdW5kKHRoaXMuY2FudmFzSGVpZ2h0ICogMC4zKSA6IG9wdGlvbnMuZ2V0KCdsaW5lSGVpZ2h0Jyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0sXG5cbiAgICAgICAgZ2V0UmVnaW9uOiBmdW5jdGlvbiAoZWwsIHgsIHkpIHtcbiAgICAgICAgICAgIHJldHVybiBNYXRoLmZsb29yKHggLyB0aGlzLml0ZW1XaWR0aCk7XG4gICAgICAgIH0sXG5cbiAgICAgICAgZ2V0Q3VycmVudFJlZ2lvbkZpZWxkczogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdmFyIGN1cnJlbnRSZWdpb24gPSB0aGlzLmN1cnJlbnRSZWdpb247XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIGlzTnVsbDogdGhpcy52YWx1ZXNbY3VycmVudFJlZ2lvbl0gPT09IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICB2YWx1ZTogdGhpcy52YWx1ZXNbY3VycmVudFJlZ2lvbl0sXG4gICAgICAgICAgICAgICAgb2Zmc2V0OiBjdXJyZW50UmVnaW9uXG4gICAgICAgICAgICB9O1xuICAgICAgICB9LFxuXG4gICAgICAgIHJlbmRlclJlZ2lvbjogZnVuY3Rpb24gKHZhbHVlbnVtLCBoaWdobGlnaHQpIHtcbiAgICAgICAgICAgIHZhciB2YWx1ZXMgPSB0aGlzLnZhbHVlcyxcbiAgICAgICAgICAgICAgICBvcHRpb25zID0gdGhpcy5vcHRpb25zLFxuICAgICAgICAgICAgICAgIG1pbiA9IHRoaXMubWluLFxuICAgICAgICAgICAgICAgIG1heCA9IHRoaXMubWF4LFxuICAgICAgICAgICAgICAgIHJhbmdlID0gdGhpcy5yYW5nZSxcbiAgICAgICAgICAgICAgICBpbnRlcnZhbCA9IHRoaXMuaW50ZXJ2YWwsXG4gICAgICAgICAgICAgICAgdGFyZ2V0ID0gdGhpcy50YXJnZXQsXG4gICAgICAgICAgICAgICAgY2FudmFzSGVpZ2h0ID0gdGhpcy5jYW52YXNIZWlnaHQsXG4gICAgICAgICAgICAgICAgbGluZUhlaWdodCA9IHRoaXMubGluZUhlaWdodCxcbiAgICAgICAgICAgICAgICBwaGVpZ2h0ID0gY2FudmFzSGVpZ2h0IC0gbGluZUhlaWdodCxcbiAgICAgICAgICAgICAgICB5dG9wLCB2YWwsIGNvbG9yLCB4O1xuXG4gICAgICAgICAgICB2YWwgPSBjbGlwdmFsKHZhbHVlc1t2YWx1ZW51bV0sIG1pbiwgbWF4KTtcbiAgICAgICAgICAgIHggPSB2YWx1ZW51bSAqIGludGVydmFsO1xuICAgICAgICAgICAgeXRvcCA9IE1hdGgucm91bmQocGhlaWdodCAtIHBoZWlnaHQgKiAoKHZhbCAtIG1pbikgLyByYW5nZSkpO1xuICAgICAgICAgICAgY29sb3IgPSAob3B0aW9ucy5nZXQoJ3RocmVzaG9sZENvbG9yJykgJiYgdmFsIDwgb3B0aW9ucy5nZXQoJ3RocmVzaG9sZFZhbHVlJykpID8gb3B0aW9ucy5nZXQoJ3RocmVzaG9sZENvbG9yJykgOiBvcHRpb25zLmdldCgnbGluZUNvbG9yJyk7XG4gICAgICAgICAgICBpZiAoaGlnaGxpZ2h0KSB7XG4gICAgICAgICAgICAgICAgY29sb3IgPSB0aGlzLmNhbGNIaWdobGlnaHRDb2xvcihjb2xvciwgb3B0aW9ucyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gdGFyZ2V0LmRyYXdMaW5lKHgsIHl0b3AsIHgsIHl0b3AgKyBsaW5lSGVpZ2h0LCBjb2xvcik7XG4gICAgICAgIH1cbiAgICB9KTtcblxuICAgIC8qKlxuICAgICAqIEJ1bGxldCBjaGFydHNcbiAgICAgKi9cbiAgICAkLmZuLnNwYXJrbGluZS5idWxsZXQgPSBidWxsZXQgPSBjcmVhdGVDbGFzcygkLmZuLnNwYXJrbGluZS5fYmFzZSwge1xuICAgICAgICB0eXBlOiAnYnVsbGV0JyxcblxuICAgICAgICBpbml0OiBmdW5jdGlvbiAoZWwsIHZhbHVlcywgb3B0aW9ucywgd2lkdGgsIGhlaWdodCkge1xuICAgICAgICAgICAgdmFyIG1pbiwgbWF4LCB2YWxzO1xuICAgICAgICAgICAgYnVsbGV0Ll9zdXBlci5pbml0LmNhbGwodGhpcywgZWwsIHZhbHVlcywgb3B0aW9ucywgd2lkdGgsIGhlaWdodCk7XG5cbiAgICAgICAgICAgIC8vIHZhbHVlczogdGFyZ2V0LCBwZXJmb3JtYW5jZSwgcmFuZ2UxLCByYW5nZTIsIHJhbmdlM1xuICAgICAgICAgICAgdGhpcy52YWx1ZXMgPSB2YWx1ZXMgPSBub3JtYWxpemVWYWx1ZXModmFsdWVzKTtcbiAgICAgICAgICAgIC8vIHRhcmdldCBvciBwZXJmb3JtYW5jZSBjb3VsZCBiZSBudWxsXG4gICAgICAgICAgICB2YWxzID0gdmFsdWVzLnNsaWNlKCk7XG4gICAgICAgICAgICB2YWxzWzBdID0gdmFsc1swXSA9PT0gbnVsbCA/IHZhbHNbMl0gOiB2YWxzWzBdO1xuICAgICAgICAgICAgdmFsc1sxXSA9IHZhbHVlc1sxXSA9PT0gbnVsbCA/IHZhbHNbMl0gOiB2YWxzWzFdO1xuICAgICAgICAgICAgbWluID0gTWF0aC5taW4uYXBwbHkoTWF0aCwgdmFsdWVzKTtcbiAgICAgICAgICAgIG1heCA9IE1hdGgubWF4LmFwcGx5KE1hdGgsIHZhbHVlcyk7XG4gICAgICAgICAgICBpZiAob3B0aW9ucy5nZXQoJ2Jhc2UnKSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgbWluID0gbWluIDwgMCA/IG1pbiA6IDA7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIG1pbiA9IG9wdGlvbnMuZ2V0KCdiYXNlJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLm1pbiA9IG1pbjtcbiAgICAgICAgICAgIHRoaXMubWF4ID0gbWF4O1xuICAgICAgICAgICAgdGhpcy5yYW5nZSA9IG1heCAtIG1pbjtcbiAgICAgICAgICAgIHRoaXMuc2hhcGVzID0ge307XG4gICAgICAgICAgICB0aGlzLnZhbHVlU2hhcGVzID0ge307XG4gICAgICAgICAgICB0aGlzLnJlZ2lvbmRhdGEgPSB7fTtcbiAgICAgICAgICAgIHRoaXMud2lkdGggPSB3aWR0aCA9IG9wdGlvbnMuZ2V0KCd3aWR0aCcpID09PSAnYXV0bycgPyAnNC4wZW0nIDogd2lkdGg7XG4gICAgICAgICAgICB0aGlzLnRhcmdldCA9IHRoaXMuJGVsLnNpbXBsZWRyYXcod2lkdGgsIGhlaWdodCwgb3B0aW9ucy5nZXQoJ2NvbXBvc2l0ZScpKTtcbiAgICAgICAgICAgIGlmICghdmFsdWVzLmxlbmd0aCkge1xuICAgICAgICAgICAgICAgIHRoaXMuZGlzYWJsZWQgPSB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5pbml0VGFyZ2V0KCk7XG4gICAgICAgIH0sXG5cbiAgICAgICAgZ2V0UmVnaW9uOiBmdW5jdGlvbiAoZWwsIHgsIHkpIHtcbiAgICAgICAgICAgIHZhciBzaGFwZWlkID0gdGhpcy50YXJnZXQuZ2V0U2hhcGVBdChlbCwgeCwgeSk7XG4gICAgICAgICAgICByZXR1cm4gKHNoYXBlaWQgIT09IHVuZGVmaW5lZCAmJiB0aGlzLnNoYXBlc1tzaGFwZWlkXSAhPT0gdW5kZWZpbmVkKSA/IHRoaXMuc2hhcGVzW3NoYXBlaWRdIDogdW5kZWZpbmVkO1xuICAgICAgICB9LFxuXG4gICAgICAgIGdldEN1cnJlbnRSZWdpb25GaWVsZHM6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHZhciBjdXJyZW50UmVnaW9uID0gdGhpcy5jdXJyZW50UmVnaW9uO1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICBmaWVsZGtleTogY3VycmVudFJlZ2lvbi5zdWJzdHIoMCwgMSksXG4gICAgICAgICAgICAgICAgdmFsdWU6IHRoaXMudmFsdWVzW2N1cnJlbnRSZWdpb24uc3Vic3RyKDEpXSxcbiAgICAgICAgICAgICAgICByZWdpb246IGN1cnJlbnRSZWdpb25cbiAgICAgICAgICAgIH07XG4gICAgICAgIH0sXG5cbiAgICAgICAgY2hhbmdlSGlnaGxpZ2h0OiBmdW5jdGlvbiAoaGlnaGxpZ2h0KSB7XG4gICAgICAgICAgICB2YXIgY3VycmVudFJlZ2lvbiA9IHRoaXMuY3VycmVudFJlZ2lvbixcbiAgICAgICAgICAgICAgICBzaGFwZWlkID0gdGhpcy52YWx1ZVNoYXBlc1tjdXJyZW50UmVnaW9uXSxcbiAgICAgICAgICAgICAgICBzaGFwZTtcbiAgICAgICAgICAgIGRlbGV0ZSB0aGlzLnNoYXBlc1tzaGFwZWlkXTtcbiAgICAgICAgICAgIHN3aXRjaCAoY3VycmVudFJlZ2lvbi5zdWJzdHIoMCwgMSkpIHtcbiAgICAgICAgICAgICAgICBjYXNlICdyJzpcbiAgICAgICAgICAgICAgICAgICAgc2hhcGUgPSB0aGlzLnJlbmRlclJhbmdlKGN1cnJlbnRSZWdpb24uc3Vic3RyKDEpLCBoaWdobGlnaHQpO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICBjYXNlICdwJzpcbiAgICAgICAgICAgICAgICAgICAgc2hhcGUgPSB0aGlzLnJlbmRlclBlcmZvcm1hbmNlKGhpZ2hsaWdodCk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgJ3QnOlxuICAgICAgICAgICAgICAgICAgICBzaGFwZSA9IHRoaXMucmVuZGVyVGFyZ2V0KGhpZ2hsaWdodCk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy52YWx1ZVNoYXBlc1tjdXJyZW50UmVnaW9uXSA9IHNoYXBlLmlkO1xuICAgICAgICAgICAgdGhpcy5zaGFwZXNbc2hhcGUuaWRdID0gY3VycmVudFJlZ2lvbjtcbiAgICAgICAgICAgIHRoaXMudGFyZ2V0LnJlcGxhY2VXaXRoU2hhcGUoc2hhcGVpZCwgc2hhcGUpO1xuICAgICAgICB9LFxuXG4gICAgICAgIHJlbmRlclJhbmdlOiBmdW5jdGlvbiAocm4sIGhpZ2hsaWdodCkge1xuICAgICAgICAgICAgdmFyIHJhbmdldmFsID0gdGhpcy52YWx1ZXNbcm5dLFxuICAgICAgICAgICAgICAgIHJhbmdld2lkdGggPSBNYXRoLnJvdW5kKHRoaXMuY2FudmFzV2lkdGggKiAoKHJhbmdldmFsIC0gdGhpcy5taW4pIC8gdGhpcy5yYW5nZSkpLFxuICAgICAgICAgICAgICAgIGNvbG9yID0gdGhpcy5vcHRpb25zLmdldCgncmFuZ2VDb2xvcnMnKVtybiAtIDJdO1xuICAgICAgICAgICAgaWYgKGhpZ2hsaWdodCkge1xuICAgICAgICAgICAgICAgIGNvbG9yID0gdGhpcy5jYWxjSGlnaGxpZ2h0Q29sb3IoY29sb3IsIHRoaXMub3B0aW9ucyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gdGhpcy50YXJnZXQuZHJhd1JlY3QoMCwgMCwgcmFuZ2V3aWR0aCAtIDEsIHRoaXMuY2FudmFzSGVpZ2h0IC0gMSwgY29sb3IsIGNvbG9yKTtcbiAgICAgICAgfSxcblxuICAgICAgICByZW5kZXJQZXJmb3JtYW5jZTogZnVuY3Rpb24gKGhpZ2hsaWdodCkge1xuICAgICAgICAgICAgdmFyIHBlcmZ2YWwgPSB0aGlzLnZhbHVlc1sxXSxcbiAgICAgICAgICAgICAgICBwZXJmd2lkdGggPSBNYXRoLnJvdW5kKHRoaXMuY2FudmFzV2lkdGggKiAoKHBlcmZ2YWwgLSB0aGlzLm1pbikgLyB0aGlzLnJhbmdlKSksXG4gICAgICAgICAgICAgICAgY29sb3IgPSB0aGlzLm9wdGlvbnMuZ2V0KCdwZXJmb3JtYW5jZUNvbG9yJyk7XG4gICAgICAgICAgICBpZiAoaGlnaGxpZ2h0KSB7XG4gICAgICAgICAgICAgICAgY29sb3IgPSB0aGlzLmNhbGNIaWdobGlnaHRDb2xvcihjb2xvciwgdGhpcy5vcHRpb25zKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiB0aGlzLnRhcmdldC5kcmF3UmVjdCgwLCBNYXRoLnJvdW5kKHRoaXMuY2FudmFzSGVpZ2h0ICogMC4zKSwgcGVyZndpZHRoIC0gMSxcbiAgICAgICAgICAgICAgICBNYXRoLnJvdW5kKHRoaXMuY2FudmFzSGVpZ2h0ICogMC40KSAtIDEsIGNvbG9yLCBjb2xvcik7XG4gICAgICAgIH0sXG5cbiAgICAgICAgcmVuZGVyVGFyZ2V0OiBmdW5jdGlvbiAoaGlnaGxpZ2h0KSB7XG4gICAgICAgICAgICB2YXIgdGFyZ2V0dmFsID0gdGhpcy52YWx1ZXNbMF0sXG4gICAgICAgICAgICAgICAgeCA9IE1hdGgucm91bmQodGhpcy5jYW52YXNXaWR0aCAqICgodGFyZ2V0dmFsIC0gdGhpcy5taW4pIC8gdGhpcy5yYW5nZSkgLSAodGhpcy5vcHRpb25zLmdldCgndGFyZ2V0V2lkdGgnKSAvIDIpKSxcbiAgICAgICAgICAgICAgICB0YXJnZXR0b3AgPSBNYXRoLnJvdW5kKHRoaXMuY2FudmFzSGVpZ2h0ICogMC4xMCksXG4gICAgICAgICAgICAgICAgdGFyZ2V0aGVpZ2h0ID0gdGhpcy5jYW52YXNIZWlnaHQgLSAodGFyZ2V0dG9wICogMiksXG4gICAgICAgICAgICAgICAgY29sb3IgPSB0aGlzLm9wdGlvbnMuZ2V0KCd0YXJnZXRDb2xvcicpO1xuICAgICAgICAgICAgaWYgKGhpZ2hsaWdodCkge1xuICAgICAgICAgICAgICAgIGNvbG9yID0gdGhpcy5jYWxjSGlnaGxpZ2h0Q29sb3IoY29sb3IsIHRoaXMub3B0aW9ucyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gdGhpcy50YXJnZXQuZHJhd1JlY3QoeCwgdGFyZ2V0dG9wLCB0aGlzLm9wdGlvbnMuZ2V0KCd0YXJnZXRXaWR0aCcpIC0gMSwgdGFyZ2V0aGVpZ2h0IC0gMSwgY29sb3IsIGNvbG9yKTtcbiAgICAgICAgfSxcblxuICAgICAgICByZW5kZXI6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHZhciB2bGVuID0gdGhpcy52YWx1ZXMubGVuZ3RoLFxuICAgICAgICAgICAgICAgIHRhcmdldCA9IHRoaXMudGFyZ2V0LFxuICAgICAgICAgICAgICAgIGksIHNoYXBlO1xuICAgICAgICAgICAgaWYgKCFidWxsZXQuX3N1cGVyLnJlbmRlci5jYWxsKHRoaXMpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZm9yIChpID0gMjsgaSA8IHZsZW47IGkrKykge1xuICAgICAgICAgICAgICAgIHNoYXBlID0gdGhpcy5yZW5kZXJSYW5nZShpKS5hcHBlbmQoKTtcbiAgICAgICAgICAgICAgICB0aGlzLnNoYXBlc1tzaGFwZS5pZF0gPSAncicgKyBpO1xuICAgICAgICAgICAgICAgIHRoaXMudmFsdWVTaGFwZXNbJ3InICsgaV0gPSBzaGFwZS5pZDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICh0aGlzLnZhbHVlc1sxXSAhPT0gbnVsbCkge1xuICAgICAgICAgICAgICAgIHNoYXBlID0gdGhpcy5yZW5kZXJQZXJmb3JtYW5jZSgpLmFwcGVuZCgpO1xuICAgICAgICAgICAgICAgIHRoaXMuc2hhcGVzW3NoYXBlLmlkXSA9ICdwMSc7XG4gICAgICAgICAgICAgICAgdGhpcy52YWx1ZVNoYXBlcy5wMSA9IHNoYXBlLmlkO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHRoaXMudmFsdWVzWzBdICE9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgc2hhcGUgPSB0aGlzLnJlbmRlclRhcmdldCgpLmFwcGVuZCgpO1xuICAgICAgICAgICAgICAgIHRoaXMuc2hhcGVzW3NoYXBlLmlkXSA9ICd0MCc7XG4gICAgICAgICAgICAgICAgdGhpcy52YWx1ZVNoYXBlcy50MCA9IHNoYXBlLmlkO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGFyZ2V0LnJlbmRlcigpO1xuICAgICAgICB9XG4gICAgfSk7XG5cbiAgICAvKipcbiAgICAgKiBQaWUgY2hhcnRzXG4gICAgICovXG4gICAgJC5mbi5zcGFya2xpbmUucGllID0gcGllID0gY3JlYXRlQ2xhc3MoJC5mbi5zcGFya2xpbmUuX2Jhc2UsIHtcbiAgICAgICAgdHlwZTogJ3BpZScsXG5cbiAgICAgICAgaW5pdDogZnVuY3Rpb24gKGVsLCB2YWx1ZXMsIG9wdGlvbnMsIHdpZHRoLCBoZWlnaHQpIHtcbiAgICAgICAgICAgIHZhciB0b3RhbCA9IDAsIGk7XG5cbiAgICAgICAgICAgIHBpZS5fc3VwZXIuaW5pdC5jYWxsKHRoaXMsIGVsLCB2YWx1ZXMsIG9wdGlvbnMsIHdpZHRoLCBoZWlnaHQpO1xuXG4gICAgICAgICAgICB0aGlzLnNoYXBlcyA9IHt9OyAvLyBtYXAgc2hhcGUgaWRzIHRvIHZhbHVlIG9mZnNldHNcbiAgICAgICAgICAgIHRoaXMudmFsdWVTaGFwZXMgPSB7fTsgLy8gbWFwcyB2YWx1ZSBvZmZzZXRzIHRvIHNoYXBlIGlkc1xuICAgICAgICAgICAgdGhpcy52YWx1ZXMgPSB2YWx1ZXMgPSAkLm1hcCh2YWx1ZXMsIE51bWJlcik7XG5cbiAgICAgICAgICAgIGlmIChvcHRpb25zLmdldCgnd2lkdGgnKSA9PT0gJ2F1dG8nKSB7XG4gICAgICAgICAgICAgICAgdGhpcy53aWR0aCA9IHRoaXMuaGVpZ2h0O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAodmFsdWVzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICBmb3IgKGkgPSB2YWx1ZXMubGVuZ3RoOyBpLS07KSB7XG4gICAgICAgICAgICAgICAgICAgIHRvdGFsICs9IHZhbHVlc1tpXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLnRvdGFsID0gdG90YWw7XG4gICAgICAgICAgICB0aGlzLmluaXRUYXJnZXQoKTtcbiAgICAgICAgICAgIHRoaXMucmFkaXVzID0gTWF0aC5mbG9vcihNYXRoLm1pbih0aGlzLmNhbnZhc1dpZHRoLCB0aGlzLmNhbnZhc0hlaWdodCkgLyAyKTtcbiAgICAgICAgfSxcblxuICAgICAgICBnZXRSZWdpb246IGZ1bmN0aW9uIChlbCwgeCwgeSkge1xuICAgICAgICAgICAgdmFyIHNoYXBlaWQgPSB0aGlzLnRhcmdldC5nZXRTaGFwZUF0KGVsLCB4LCB5KTtcbiAgICAgICAgICAgIHJldHVybiAoc2hhcGVpZCAhPT0gdW5kZWZpbmVkICYmIHRoaXMuc2hhcGVzW3NoYXBlaWRdICE9PSB1bmRlZmluZWQpID8gdGhpcy5zaGFwZXNbc2hhcGVpZF0gOiB1bmRlZmluZWQ7XG4gICAgICAgIH0sXG5cbiAgICAgICAgZ2V0Q3VycmVudFJlZ2lvbkZpZWxkczogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdmFyIGN1cnJlbnRSZWdpb24gPSB0aGlzLmN1cnJlbnRSZWdpb247XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIGlzTnVsbDogdGhpcy52YWx1ZXNbY3VycmVudFJlZ2lvbl0gPT09IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICB2YWx1ZTogdGhpcy52YWx1ZXNbY3VycmVudFJlZ2lvbl0sXG4gICAgICAgICAgICAgICAgcGVyY2VudDogdGhpcy52YWx1ZXNbY3VycmVudFJlZ2lvbl0gLyB0aGlzLnRvdGFsICogMTAwLFxuICAgICAgICAgICAgICAgIGNvbG9yOiB0aGlzLm9wdGlvbnMuZ2V0KCdzbGljZUNvbG9ycycpW2N1cnJlbnRSZWdpb24gJSB0aGlzLm9wdGlvbnMuZ2V0KCdzbGljZUNvbG9ycycpLmxlbmd0aF0sXG4gICAgICAgICAgICAgICAgb2Zmc2V0OiBjdXJyZW50UmVnaW9uXG4gICAgICAgICAgICB9O1xuICAgICAgICB9LFxuXG4gICAgICAgIGNoYW5nZUhpZ2hsaWdodDogZnVuY3Rpb24gKGhpZ2hsaWdodCkge1xuICAgICAgICAgICAgdmFyIGN1cnJlbnRSZWdpb24gPSB0aGlzLmN1cnJlbnRSZWdpb24sXG4gICAgICAgICAgICAgICAgIG5ld3NsaWNlID0gdGhpcy5yZW5kZXJTbGljZShjdXJyZW50UmVnaW9uLCBoaWdobGlnaHQpLFxuICAgICAgICAgICAgICAgICBzaGFwZWlkID0gdGhpcy52YWx1ZVNoYXBlc1tjdXJyZW50UmVnaW9uXTtcbiAgICAgICAgICAgIGRlbGV0ZSB0aGlzLnNoYXBlc1tzaGFwZWlkXTtcbiAgICAgICAgICAgIHRoaXMudGFyZ2V0LnJlcGxhY2VXaXRoU2hhcGUoc2hhcGVpZCwgbmV3c2xpY2UpO1xuICAgICAgICAgICAgdGhpcy52YWx1ZVNoYXBlc1tjdXJyZW50UmVnaW9uXSA9IG5ld3NsaWNlLmlkO1xuICAgICAgICAgICAgdGhpcy5zaGFwZXNbbmV3c2xpY2UuaWRdID0gY3VycmVudFJlZ2lvbjtcbiAgICAgICAgfSxcblxuICAgICAgICByZW5kZXJTbGljZTogZnVuY3Rpb24gKHZhbHVlbnVtLCBoaWdobGlnaHQpIHtcbiAgICAgICAgICAgIHZhciB0YXJnZXQgPSB0aGlzLnRhcmdldCxcbiAgICAgICAgICAgICAgICBvcHRpb25zID0gdGhpcy5vcHRpb25zLFxuICAgICAgICAgICAgICAgIHJhZGl1cyA9IHRoaXMucmFkaXVzLFxuICAgICAgICAgICAgICAgIGJvcmRlcldpZHRoID0gb3B0aW9ucy5nZXQoJ2JvcmRlcldpZHRoJyksXG4gICAgICAgICAgICAgICAgb2Zmc2V0ID0gb3B0aW9ucy5nZXQoJ29mZnNldCcpLFxuICAgICAgICAgICAgICAgIGNpcmNsZSA9IDIgKiBNYXRoLlBJLFxuICAgICAgICAgICAgICAgIHZhbHVlcyA9IHRoaXMudmFsdWVzLFxuICAgICAgICAgICAgICAgIHRvdGFsID0gdGhpcy50b3RhbCxcbiAgICAgICAgICAgICAgICBuZXh0ID0gb2Zmc2V0ID8gKDIqTWF0aC5QSSkqKG9mZnNldC8zNjApIDogMCxcbiAgICAgICAgICAgICAgICBzdGFydCwgZW5kLCBpLCB2bGVuLCBjb2xvcjtcblxuICAgICAgICAgICAgdmxlbiA9IHZhbHVlcy5sZW5ndGg7XG4gICAgICAgICAgICBmb3IgKGkgPSAwOyBpIDwgdmxlbjsgaSsrKSB7XG4gICAgICAgICAgICAgICAgc3RhcnQgPSBuZXh0O1xuICAgICAgICAgICAgICAgIGVuZCA9IG5leHQ7XG4gICAgICAgICAgICAgICAgaWYgKHRvdGFsID4gMCkgeyAgLy8gYXZvaWQgZGl2aWRlIGJ5IHplcm9cbiAgICAgICAgICAgICAgICAgICAgZW5kID0gbmV4dCArIChjaXJjbGUgKiAodmFsdWVzW2ldIC8gdG90YWwpKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKHZhbHVlbnVtID09PSBpKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbG9yID0gb3B0aW9ucy5nZXQoJ3NsaWNlQ29sb3JzJylbaSAlIG9wdGlvbnMuZ2V0KCdzbGljZUNvbG9ycycpLmxlbmd0aF07XG4gICAgICAgICAgICAgICAgICAgIGlmIChoaWdobGlnaHQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yID0gdGhpcy5jYWxjSGlnaGxpZ2h0Q29sb3IoY29sb3IsIG9wdGlvbnMpO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRhcmdldC5kcmF3UGllU2xpY2UocmFkaXVzLCByYWRpdXMsIHJhZGl1cyAtIGJvcmRlcldpZHRoLCBzdGFydCwgZW5kLCB1bmRlZmluZWQsIGNvbG9yKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgbmV4dCA9IGVuZDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSxcblxuICAgICAgICByZW5kZXI6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHZhciB0YXJnZXQgPSB0aGlzLnRhcmdldCxcbiAgICAgICAgICAgICAgICB2YWx1ZXMgPSB0aGlzLnZhbHVlcyxcbiAgICAgICAgICAgICAgICBvcHRpb25zID0gdGhpcy5vcHRpb25zLFxuICAgICAgICAgICAgICAgIHJhZGl1cyA9IHRoaXMucmFkaXVzLFxuICAgICAgICAgICAgICAgIGJvcmRlcldpZHRoID0gb3B0aW9ucy5nZXQoJ2JvcmRlcldpZHRoJyksXG4gICAgICAgICAgICAgICAgc2hhcGUsIGk7XG5cbiAgICAgICAgICAgIGlmICghcGllLl9zdXBlci5yZW5kZXIuY2FsbCh0aGlzKSkge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChib3JkZXJXaWR0aCkge1xuICAgICAgICAgICAgICAgIHRhcmdldC5kcmF3Q2lyY2xlKHJhZGl1cywgcmFkaXVzLCBNYXRoLmZsb29yKHJhZGl1cyAtIChib3JkZXJXaWR0aCAvIDIpKSxcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9ucy5nZXQoJ2JvcmRlckNvbG9yJyksIHVuZGVmaW5lZCwgYm9yZGVyV2lkdGgpLmFwcGVuZCgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZm9yIChpID0gdmFsdWVzLmxlbmd0aDsgaS0tOykge1xuICAgICAgICAgICAgICAgIGlmICh2YWx1ZXNbaV0pIHsgLy8gZG9uJ3QgcmVuZGVyIHplcm8gdmFsdWVzXG4gICAgICAgICAgICAgICAgICAgIHNoYXBlID0gdGhpcy5yZW5kZXJTbGljZShpKS5hcHBlbmQoKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy52YWx1ZVNoYXBlc1tpXSA9IHNoYXBlLmlkOyAvLyBzdG9yZSBqdXN0IHRoZSBzaGFwZWlkXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2hhcGVzW3NoYXBlLmlkXSA9IGk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGFyZ2V0LnJlbmRlcigpO1xuICAgICAgICB9XG4gICAgfSk7XG5cbiAgICAvKipcbiAgICAgKiBCb3ggcGxvdHNcbiAgICAgKi9cbiAgICAkLmZuLnNwYXJrbGluZS5ib3ggPSBib3ggPSBjcmVhdGVDbGFzcygkLmZuLnNwYXJrbGluZS5fYmFzZSwge1xuICAgICAgICB0eXBlOiAnYm94JyxcblxuICAgICAgICBpbml0OiBmdW5jdGlvbiAoZWwsIHZhbHVlcywgb3B0aW9ucywgd2lkdGgsIGhlaWdodCkge1xuICAgICAgICAgICAgYm94Ll9zdXBlci5pbml0LmNhbGwodGhpcywgZWwsIHZhbHVlcywgb3B0aW9ucywgd2lkdGgsIGhlaWdodCk7XG4gICAgICAgICAgICB0aGlzLnZhbHVlcyA9ICQubWFwKHZhbHVlcywgTnVtYmVyKTtcbiAgICAgICAgICAgIHRoaXMud2lkdGggPSBvcHRpb25zLmdldCgnd2lkdGgnKSA9PT0gJ2F1dG8nID8gJzQuMGVtJyA6IHdpZHRoO1xuICAgICAgICAgICAgdGhpcy5pbml0VGFyZ2V0KCk7XG4gICAgICAgICAgICBpZiAoIXRoaXMudmFsdWVzLmxlbmd0aCkge1xuICAgICAgICAgICAgICAgIHRoaXMuZGlzYWJsZWQgPSAxO1xuICAgICAgICAgICAgfVxuICAgICAgICB9LFxuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBTaW11bGF0ZSBhIHNpbmdsZSByZWdpb25cbiAgICAgICAgICovXG4gICAgICAgIGdldFJlZ2lvbjogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgcmV0dXJuIDE7XG4gICAgICAgIH0sXG5cbiAgICAgICAgZ2V0Q3VycmVudFJlZ2lvbkZpZWxkczogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdmFyIHJlc3VsdCA9IFtcbiAgICAgICAgICAgICAgICB7IGZpZWxkOiAnbHEnLCB2YWx1ZTogdGhpcy5xdWFydGlsZXNbMF0gfSxcbiAgICAgICAgICAgICAgICB7IGZpZWxkOiAnbWVkJywgdmFsdWU6IHRoaXMucXVhcnRpbGVzWzFdIH0sXG4gICAgICAgICAgICAgICAgeyBmaWVsZDogJ3VxJywgdmFsdWU6IHRoaXMucXVhcnRpbGVzWzJdIH1cbiAgICAgICAgICAgIF07XG4gICAgICAgICAgICBpZiAodGhpcy5sb3V0bGllciAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgcmVzdWx0LnB1c2goeyBmaWVsZDogJ2xvJywgdmFsdWU6IHRoaXMubG91dGxpZXJ9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICh0aGlzLnJvdXRsaWVyICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICByZXN1bHQucHVzaCh7IGZpZWxkOiAncm8nLCB2YWx1ZTogdGhpcy5yb3V0bGllcn0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHRoaXMubHdoaXNrZXIgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgIHJlc3VsdC5wdXNoKHsgZmllbGQ6ICdsdycsIHZhbHVlOiB0aGlzLmx3aGlza2VyfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAodGhpcy5yd2hpc2tlciAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgcmVzdWx0LnB1c2goeyBmaWVsZDogJ3J3JywgdmFsdWU6IHRoaXMucndoaXNrZXJ9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICAgIH0sXG5cbiAgICAgICAgcmVuZGVyOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB2YXIgdGFyZ2V0ID0gdGhpcy50YXJnZXQsXG4gICAgICAgICAgICAgICAgdmFsdWVzID0gdGhpcy52YWx1ZXMsXG4gICAgICAgICAgICAgICAgdmxlbiA9IHZhbHVlcy5sZW5ndGgsXG4gICAgICAgICAgICAgICAgb3B0aW9ucyA9IHRoaXMub3B0aW9ucyxcbiAgICAgICAgICAgICAgICBjYW52YXNXaWR0aCA9IHRoaXMuY2FudmFzV2lkdGgsXG4gICAgICAgICAgICAgICAgY2FudmFzSGVpZ2h0ID0gdGhpcy5jYW52YXNIZWlnaHQsXG4gICAgICAgICAgICAgICAgbWluVmFsdWUgPSBvcHRpb25zLmdldCgnY2hhcnRSYW5nZU1pbicpID09PSB1bmRlZmluZWQgPyBNYXRoLm1pbi5hcHBseShNYXRoLCB2YWx1ZXMpIDogb3B0aW9ucy5nZXQoJ2NoYXJ0UmFuZ2VNaW4nKSxcbiAgICAgICAgICAgICAgICBtYXhWYWx1ZSA9IG9wdGlvbnMuZ2V0KCdjaGFydFJhbmdlTWF4JykgPT09IHVuZGVmaW5lZCA/IE1hdGgubWF4LmFwcGx5KE1hdGgsIHZhbHVlcykgOiBvcHRpb25zLmdldCgnY2hhcnRSYW5nZU1heCcpLFxuICAgICAgICAgICAgICAgIGNhbnZhc0xlZnQgPSAwLFxuICAgICAgICAgICAgICAgIGx3aGlza2VyLCBsb3V0bGllciwgaXFyLCBxMSwgcTIsIHEzLCByd2hpc2tlciwgcm91dGxpZXIsIGksXG4gICAgICAgICAgICAgICAgc2l6ZSwgdW5pdFNpemU7XG5cbiAgICAgICAgICAgIGlmICghYm94Ll9zdXBlci5yZW5kZXIuY2FsbCh0aGlzKSkge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKG9wdGlvbnMuZ2V0KCdyYXcnKSkge1xuICAgICAgICAgICAgICAgIGlmIChvcHRpb25zLmdldCgnc2hvd091dGxpZXJzJykgJiYgdmFsdWVzLmxlbmd0aCA+IDUpIHtcbiAgICAgICAgICAgICAgICAgICAgbG91dGxpZXIgPSB2YWx1ZXNbMF07XG4gICAgICAgICAgICAgICAgICAgIGx3aGlza2VyID0gdmFsdWVzWzFdO1xuICAgICAgICAgICAgICAgICAgICBxMSA9IHZhbHVlc1syXTtcbiAgICAgICAgICAgICAgICAgICAgcTIgPSB2YWx1ZXNbM107XG4gICAgICAgICAgICAgICAgICAgIHEzID0gdmFsdWVzWzRdO1xuICAgICAgICAgICAgICAgICAgICByd2hpc2tlciA9IHZhbHVlc1s1XTtcbiAgICAgICAgICAgICAgICAgICAgcm91dGxpZXIgPSB2YWx1ZXNbNl07XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgbHdoaXNrZXIgPSB2YWx1ZXNbMF07XG4gICAgICAgICAgICAgICAgICAgIHExID0gdmFsdWVzWzFdO1xuICAgICAgICAgICAgICAgICAgICBxMiA9IHZhbHVlc1syXTtcbiAgICAgICAgICAgICAgICAgICAgcTMgPSB2YWx1ZXNbM107XG4gICAgICAgICAgICAgICAgICAgIHJ3aGlza2VyID0gdmFsdWVzWzRdO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdmFsdWVzLnNvcnQoZnVuY3Rpb24gKGEsIGIpIHsgcmV0dXJuIGEgLSBiOyB9KTtcbiAgICAgICAgICAgICAgICBxMSA9IHF1YXJ0aWxlKHZhbHVlcywgMSk7XG4gICAgICAgICAgICAgICAgcTIgPSBxdWFydGlsZSh2YWx1ZXMsIDIpO1xuICAgICAgICAgICAgICAgIHEzID0gcXVhcnRpbGUodmFsdWVzLCAzKTtcbiAgICAgICAgICAgICAgICBpcXIgPSBxMyAtIHExO1xuICAgICAgICAgICAgICAgIGlmIChvcHRpb25zLmdldCgnc2hvd091dGxpZXJzJykpIHtcbiAgICAgICAgICAgICAgICAgICAgbHdoaXNrZXIgPSByd2hpc2tlciA9IHVuZGVmaW5lZDtcbiAgICAgICAgICAgICAgICAgICAgZm9yIChpID0gMDsgaSA8IHZsZW47IGkrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGx3aGlza2VyID09PSB1bmRlZmluZWQgJiYgdmFsdWVzW2ldID4gcTEgLSAoaXFyICogb3B0aW9ucy5nZXQoJ291dGxpZXJJUVInKSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsd2hpc2tlciA9IHZhbHVlc1tpXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2YWx1ZXNbaV0gPCBxMyArIChpcXIgKiBvcHRpb25zLmdldCgnb3V0bGllcklRUicpKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJ3aGlza2VyID0gdmFsdWVzW2ldO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGxvdXRsaWVyID0gdmFsdWVzWzBdO1xuICAgICAgICAgICAgICAgICAgICByb3V0bGllciA9IHZhbHVlc1t2bGVuIC0gMV07XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgbHdoaXNrZXIgPSB2YWx1ZXNbMF07XG4gICAgICAgICAgICAgICAgICAgIHJ3aGlza2VyID0gdmFsdWVzW3ZsZW4gLSAxXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLnF1YXJ0aWxlcyA9IFtxMSwgcTIsIHEzXTtcbiAgICAgICAgICAgIHRoaXMubHdoaXNrZXIgPSBsd2hpc2tlcjtcbiAgICAgICAgICAgIHRoaXMucndoaXNrZXIgPSByd2hpc2tlcjtcbiAgICAgICAgICAgIHRoaXMubG91dGxpZXIgPSBsb3V0bGllcjtcbiAgICAgICAgICAgIHRoaXMucm91dGxpZXIgPSByb3V0bGllcjtcblxuICAgICAgICAgICAgdW5pdFNpemUgPSBjYW52YXNXaWR0aCAvIChtYXhWYWx1ZSAtIG1pblZhbHVlICsgMSk7XG4gICAgICAgICAgICBpZiAob3B0aW9ucy5nZXQoJ3Nob3dPdXRsaWVycycpKSB7XG4gICAgICAgICAgICAgICAgY2FudmFzTGVmdCA9IE1hdGguY2VpbChvcHRpb25zLmdldCgnc3BvdFJhZGl1cycpKTtcbiAgICAgICAgICAgICAgICBjYW52YXNXaWR0aCAtPSAyICogTWF0aC5jZWlsKG9wdGlvbnMuZ2V0KCdzcG90UmFkaXVzJykpO1xuICAgICAgICAgICAgICAgIHVuaXRTaXplID0gY2FudmFzV2lkdGggLyAobWF4VmFsdWUgLSBtaW5WYWx1ZSArIDEpO1xuICAgICAgICAgICAgICAgIGlmIChsb3V0bGllciA8IGx3aGlza2VyKSB7XG4gICAgICAgICAgICAgICAgICAgIHRhcmdldC5kcmF3Q2lyY2xlKChsb3V0bGllciAtIG1pblZhbHVlKSAqIHVuaXRTaXplICsgY2FudmFzTGVmdCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhbnZhc0hlaWdodCAvIDIsXG4gICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zLmdldCgnc3BvdFJhZGl1cycpLFxuICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucy5nZXQoJ291dGxpZXJMaW5lQ29sb3InKSxcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnMuZ2V0KCdvdXRsaWVyRmlsbENvbG9yJykpLmFwcGVuZCgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAocm91dGxpZXIgPiByd2hpc2tlcikge1xuICAgICAgICAgICAgICAgICAgICB0YXJnZXQuZHJhd0NpcmNsZSgocm91dGxpZXIgLSBtaW5WYWx1ZSkgKiB1bml0U2l6ZSArIGNhbnZhc0xlZnQsXG4gICAgICAgICAgICAgICAgICAgICAgICBjYW52YXNIZWlnaHQgLyAyLFxuICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucy5nZXQoJ3Nwb3RSYWRpdXMnKSxcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnMuZ2V0KCdvdXRsaWVyTGluZUNvbG9yJyksXG4gICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zLmdldCgnb3V0bGllckZpbGxDb2xvcicpKS5hcHBlbmQoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIGJveFxuICAgICAgICAgICAgdGFyZ2V0LmRyYXdSZWN0KFxuICAgICAgICAgICAgICAgIE1hdGgucm91bmQoKHExIC0gbWluVmFsdWUpICogdW5pdFNpemUgKyBjYW52YXNMZWZ0KSxcbiAgICAgICAgICAgICAgICBNYXRoLnJvdW5kKGNhbnZhc0hlaWdodCAqIDAuMSksXG4gICAgICAgICAgICAgICAgTWF0aC5yb3VuZCgocTMgLSBxMSkgKiB1bml0U2l6ZSksXG4gICAgICAgICAgICAgICAgTWF0aC5yb3VuZChjYW52YXNIZWlnaHQgKiAwLjgpLFxuICAgICAgICAgICAgICAgIG9wdGlvbnMuZ2V0KCdib3hMaW5lQ29sb3InKSxcbiAgICAgICAgICAgICAgICBvcHRpb25zLmdldCgnYm94RmlsbENvbG9yJykpLmFwcGVuZCgpO1xuICAgICAgICAgICAgLy8gbGVmdCB3aGlza2VyXG4gICAgICAgICAgICB0YXJnZXQuZHJhd0xpbmUoXG4gICAgICAgICAgICAgICAgTWF0aC5yb3VuZCgobHdoaXNrZXIgLSBtaW5WYWx1ZSkgKiB1bml0U2l6ZSArIGNhbnZhc0xlZnQpLFxuICAgICAgICAgICAgICAgIE1hdGgucm91bmQoY2FudmFzSGVpZ2h0IC8gMiksXG4gICAgICAgICAgICAgICAgTWF0aC5yb3VuZCgocTEgLSBtaW5WYWx1ZSkgKiB1bml0U2l6ZSArIGNhbnZhc0xlZnQpLFxuICAgICAgICAgICAgICAgIE1hdGgucm91bmQoY2FudmFzSGVpZ2h0IC8gMiksXG4gICAgICAgICAgICAgICAgb3B0aW9ucy5nZXQoJ2xpbmVDb2xvcicpKS5hcHBlbmQoKTtcbiAgICAgICAgICAgIHRhcmdldC5kcmF3TGluZShcbiAgICAgICAgICAgICAgICBNYXRoLnJvdW5kKChsd2hpc2tlciAtIG1pblZhbHVlKSAqIHVuaXRTaXplICsgY2FudmFzTGVmdCksXG4gICAgICAgICAgICAgICAgTWF0aC5yb3VuZChjYW52YXNIZWlnaHQgLyA0KSxcbiAgICAgICAgICAgICAgICBNYXRoLnJvdW5kKChsd2hpc2tlciAtIG1pblZhbHVlKSAqIHVuaXRTaXplICsgY2FudmFzTGVmdCksXG4gICAgICAgICAgICAgICAgTWF0aC5yb3VuZChjYW52YXNIZWlnaHQgLSBjYW52YXNIZWlnaHQgLyA0KSxcbiAgICAgICAgICAgICAgICBvcHRpb25zLmdldCgnd2hpc2tlckNvbG9yJykpLmFwcGVuZCgpO1xuICAgICAgICAgICAgLy8gcmlnaHQgd2hpc2tlclxuICAgICAgICAgICAgdGFyZ2V0LmRyYXdMaW5lKE1hdGgucm91bmQoKHJ3aGlza2VyIC0gbWluVmFsdWUpICogdW5pdFNpemUgKyBjYW52YXNMZWZ0KSxcbiAgICAgICAgICAgICAgICBNYXRoLnJvdW5kKGNhbnZhc0hlaWdodCAvIDIpLFxuICAgICAgICAgICAgICAgIE1hdGgucm91bmQoKHEzIC0gbWluVmFsdWUpICogdW5pdFNpemUgKyBjYW52YXNMZWZ0KSxcbiAgICAgICAgICAgICAgICBNYXRoLnJvdW5kKGNhbnZhc0hlaWdodCAvIDIpLFxuICAgICAgICAgICAgICAgIG9wdGlvbnMuZ2V0KCdsaW5lQ29sb3InKSkuYXBwZW5kKCk7XG4gICAgICAgICAgICB0YXJnZXQuZHJhd0xpbmUoXG4gICAgICAgICAgICAgICAgTWF0aC5yb3VuZCgocndoaXNrZXIgLSBtaW5WYWx1ZSkgKiB1bml0U2l6ZSArIGNhbnZhc0xlZnQpLFxuICAgICAgICAgICAgICAgIE1hdGgucm91bmQoY2FudmFzSGVpZ2h0IC8gNCksXG4gICAgICAgICAgICAgICAgTWF0aC5yb3VuZCgocndoaXNrZXIgLSBtaW5WYWx1ZSkgKiB1bml0U2l6ZSArIGNhbnZhc0xlZnQpLFxuICAgICAgICAgICAgICAgIE1hdGgucm91bmQoY2FudmFzSGVpZ2h0IC0gY2FudmFzSGVpZ2h0IC8gNCksXG4gICAgICAgICAgICAgICAgb3B0aW9ucy5nZXQoJ3doaXNrZXJDb2xvcicpKS5hcHBlbmQoKTtcbiAgICAgICAgICAgIC8vIG1lZGlhbiBsaW5lXG4gICAgICAgICAgICB0YXJnZXQuZHJhd0xpbmUoXG4gICAgICAgICAgICAgICAgTWF0aC5yb3VuZCgocTIgLSBtaW5WYWx1ZSkgKiB1bml0U2l6ZSArIGNhbnZhc0xlZnQpLFxuICAgICAgICAgICAgICAgIE1hdGgucm91bmQoY2FudmFzSGVpZ2h0ICogMC4xKSxcbiAgICAgICAgICAgICAgICBNYXRoLnJvdW5kKChxMiAtIG1pblZhbHVlKSAqIHVuaXRTaXplICsgY2FudmFzTGVmdCksXG4gICAgICAgICAgICAgICAgTWF0aC5yb3VuZChjYW52YXNIZWlnaHQgKiAwLjkpLFxuICAgICAgICAgICAgICAgIG9wdGlvbnMuZ2V0KCdtZWRpYW5Db2xvcicpKS5hcHBlbmQoKTtcbiAgICAgICAgICAgIGlmIChvcHRpb25zLmdldCgndGFyZ2V0JykpIHtcbiAgICAgICAgICAgICAgICBzaXplID0gTWF0aC5jZWlsKG9wdGlvbnMuZ2V0KCdzcG90UmFkaXVzJykpO1xuICAgICAgICAgICAgICAgIHRhcmdldC5kcmF3TGluZShcbiAgICAgICAgICAgICAgICAgICAgTWF0aC5yb3VuZCgob3B0aW9ucy5nZXQoJ3RhcmdldCcpIC0gbWluVmFsdWUpICogdW5pdFNpemUgKyBjYW52YXNMZWZ0KSxcbiAgICAgICAgICAgICAgICAgICAgTWF0aC5yb3VuZCgoY2FudmFzSGVpZ2h0IC8gMikgLSBzaXplKSxcbiAgICAgICAgICAgICAgICAgICAgTWF0aC5yb3VuZCgob3B0aW9ucy5nZXQoJ3RhcmdldCcpIC0gbWluVmFsdWUpICogdW5pdFNpemUgKyBjYW52YXNMZWZ0KSxcbiAgICAgICAgICAgICAgICAgICAgTWF0aC5yb3VuZCgoY2FudmFzSGVpZ2h0IC8gMikgKyBzaXplKSxcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9ucy5nZXQoJ3RhcmdldENvbG9yJykpLmFwcGVuZCgpO1xuICAgICAgICAgICAgICAgIHRhcmdldC5kcmF3TGluZShcbiAgICAgICAgICAgICAgICAgICAgTWF0aC5yb3VuZCgob3B0aW9ucy5nZXQoJ3RhcmdldCcpIC0gbWluVmFsdWUpICogdW5pdFNpemUgKyBjYW52YXNMZWZ0IC0gc2l6ZSksXG4gICAgICAgICAgICAgICAgICAgIE1hdGgucm91bmQoY2FudmFzSGVpZ2h0IC8gMiksXG4gICAgICAgICAgICAgICAgICAgIE1hdGgucm91bmQoKG9wdGlvbnMuZ2V0KCd0YXJnZXQnKSAtIG1pblZhbHVlKSAqIHVuaXRTaXplICsgY2FudmFzTGVmdCArIHNpemUpLFxuICAgICAgICAgICAgICAgICAgICBNYXRoLnJvdW5kKGNhbnZhc0hlaWdodCAvIDIpLFxuICAgICAgICAgICAgICAgICAgICBvcHRpb25zLmdldCgndGFyZ2V0Q29sb3InKSkuYXBwZW5kKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0YXJnZXQucmVuZGVyKCk7XG4gICAgICAgIH1cbiAgICB9KTtcblxuICAgIC8vIFNldHVwIGEgdmVyeSBzaW1wbGUgXCJ2aXJ0dWFsIGNhbnZhc1wiIHRvIG1ha2UgZHJhd2luZyB0aGUgZmV3IHNoYXBlcyB3ZSBuZWVkIGVhc2llclxuICAgIC8vIFRoaXMgaXMgYWNjZXNzaWJsZSBhcyAkKGZvbykuc2ltcGxlZHJhdygpXG5cbiAgICBWU2hhcGUgPSBjcmVhdGVDbGFzcyh7XG4gICAgICAgIGluaXQ6IGZ1bmN0aW9uICh0YXJnZXQsIGlkLCB0eXBlLCBhcmdzKSB7XG4gICAgICAgICAgICB0aGlzLnRhcmdldCA9IHRhcmdldDtcbiAgICAgICAgICAgIHRoaXMuaWQgPSBpZDtcbiAgICAgICAgICAgIHRoaXMudHlwZSA9IHR5cGU7XG4gICAgICAgICAgICB0aGlzLmFyZ3MgPSBhcmdzO1xuICAgICAgICB9LFxuICAgICAgICBhcHBlbmQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHRoaXMudGFyZ2V0LmFwcGVuZFNoYXBlKHRoaXMpO1xuICAgICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgIH1cbiAgICB9KTtcblxuICAgIFZDYW52YXNfYmFzZSA9IGNyZWF0ZUNsYXNzKHtcbiAgICAgICAgX3B4cmVnZXg6IC8oXFxkKykocHgpP1xccyokL2ksXG5cbiAgICAgICAgaW5pdDogZnVuY3Rpb24gKHdpZHRoLCBoZWlnaHQsIHRhcmdldCkge1xuICAgICAgICAgICAgaWYgKCF3aWR0aCkge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMud2lkdGggPSB3aWR0aDtcbiAgICAgICAgICAgIHRoaXMuaGVpZ2h0ID0gaGVpZ2h0O1xuICAgICAgICAgICAgdGhpcy50YXJnZXQgPSB0YXJnZXQ7XG4gICAgICAgICAgICB0aGlzLmxhc3RTaGFwZUlkID0gbnVsbDtcbiAgICAgICAgICAgIGlmICh0YXJnZXRbMF0pIHtcbiAgICAgICAgICAgICAgICB0YXJnZXQgPSB0YXJnZXRbMF07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAkLmRhdGEodGFyZ2V0LCAnX2pxc192Y2FudmFzJywgdGhpcyk7XG4gICAgICAgIH0sXG5cbiAgICAgICAgZHJhd0xpbmU6IGZ1bmN0aW9uICh4MSwgeTEsIHgyLCB5MiwgbGluZUNvbG9yLCBsaW5lV2lkdGgpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmRyYXdTaGFwZShbW3gxLCB5MV0sIFt4MiwgeTJdXSwgbGluZUNvbG9yLCBsaW5lV2lkdGgpO1xuICAgICAgICB9LFxuXG4gICAgICAgIGRyYXdTaGFwZTogZnVuY3Rpb24gKHBhdGgsIGxpbmVDb2xvciwgZmlsbENvbG9yLCBsaW5lV2lkdGgpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9nZW5TaGFwZSgnU2hhcGUnLCBbcGF0aCwgbGluZUNvbG9yLCBmaWxsQ29sb3IsIGxpbmVXaWR0aF0pO1xuICAgICAgICB9LFxuXG4gICAgICAgIGRyYXdDaXJjbGU6IGZ1bmN0aW9uICh4LCB5LCByYWRpdXMsIGxpbmVDb2xvciwgZmlsbENvbG9yLCBsaW5lV2lkdGgpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9nZW5TaGFwZSgnQ2lyY2xlJywgW3gsIHksIHJhZGl1cywgbGluZUNvbG9yLCBmaWxsQ29sb3IsIGxpbmVXaWR0aF0pO1xuICAgICAgICB9LFxuXG4gICAgICAgIGRyYXdQaWVTbGljZTogZnVuY3Rpb24gKHgsIHksIHJhZGl1cywgc3RhcnRBbmdsZSwgZW5kQW5nbGUsIGxpbmVDb2xvciwgZmlsbENvbG9yKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fZ2VuU2hhcGUoJ1BpZVNsaWNlJywgW3gsIHksIHJhZGl1cywgc3RhcnRBbmdsZSwgZW5kQW5nbGUsIGxpbmVDb2xvciwgZmlsbENvbG9yXSk7XG4gICAgICAgIH0sXG5cbiAgICAgICAgZHJhd1JlY3Q6IGZ1bmN0aW9uICh4LCB5LCB3aWR0aCwgaGVpZ2h0LCBsaW5lQ29sb3IsIGZpbGxDb2xvcikge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2dlblNoYXBlKCdSZWN0JywgW3gsIHksIHdpZHRoLCBoZWlnaHQsIGxpbmVDb2xvciwgZmlsbENvbG9yXSk7XG4gICAgICAgIH0sXG5cbiAgICAgICAgZ2V0RWxlbWVudDogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuY2FudmFzO1xuICAgICAgICB9LFxuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBSZXR1cm4gdGhlIG1vc3QgcmVjZW50bHkgaW5zZXJ0ZWQgc2hhcGUgaWRcbiAgICAgICAgICovXG4gICAgICAgIGdldExhc3RTaGFwZUlkOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5sYXN0U2hhcGVJZDtcbiAgICAgICAgfSxcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ2xlYXIgYW5kIHJlc2V0IHRoZSBjYW52YXNcbiAgICAgICAgICovXG4gICAgICAgIHJlc2V0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBhbGVydCgncmVzZXQgbm90IGltcGxlbWVudGVkJyk7XG4gICAgICAgIH0sXG5cbiAgICAgICAgX2luc2VydDogZnVuY3Rpb24gKGVsLCB0YXJnZXQpIHtcbiAgICAgICAgICAgICQodGFyZ2V0KS5odG1sKGVsKTtcbiAgICAgICAgfSxcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ2FsY3VsYXRlIHRoZSBwaXhlbCBkaW1lbnNpb25zIG9mIHRoZSBjYW52YXNcbiAgICAgICAgICovXG4gICAgICAgIF9jYWxjdWxhdGVQaXhlbERpbXM6IGZ1bmN0aW9uICh3aWR0aCwgaGVpZ2h0LCBjYW52YXMpIHtcbiAgICAgICAgICAgIC8vIFhYWCBUaGlzIHNob3VsZCBwcm9iYWJseSBiZSBhIGNvbmZpZ3VyYWJsZSBvcHRpb25cbiAgICAgICAgICAgIHZhciBtYXRjaDtcbiAgICAgICAgICAgIG1hdGNoID0gdGhpcy5fcHhyZWdleC5leGVjKGhlaWdodCk7XG4gICAgICAgICAgICBpZiAobWF0Y2gpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnBpeGVsSGVpZ2h0ID0gbWF0Y2hbMV07XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRoaXMucGl4ZWxIZWlnaHQgPSAkKGNhbnZhcykuaGVpZ2h0KCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBtYXRjaCA9IHRoaXMuX3B4cmVnZXguZXhlYyh3aWR0aCk7XG4gICAgICAgICAgICBpZiAobWF0Y2gpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnBpeGVsV2lkdGggPSBtYXRjaFsxXTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhpcy5waXhlbFdpZHRoID0gJChjYW52YXMpLndpZHRoKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0sXG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIEdlbmVyYXRlIGEgc2hhcGUgb2JqZWN0IGFuZCBpZCBmb3IgbGF0ZXIgcmVuZGVyaW5nXG4gICAgICAgICAqL1xuICAgICAgICBfZ2VuU2hhcGU6IGZ1bmN0aW9uIChzaGFwZXR5cGUsIHNoYXBlYXJncykge1xuICAgICAgICAgICAgdmFyIGlkID0gc2hhcGVDb3VudCsrO1xuICAgICAgICAgICAgc2hhcGVhcmdzLnVuc2hpZnQoaWQpO1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBWU2hhcGUodGhpcywgaWQsIHNoYXBldHlwZSwgc2hhcGVhcmdzKTtcbiAgICAgICAgfSxcblxuICAgICAgICAvKipcbiAgICAgICAgICogQWRkIGEgc2hhcGUgdG8gdGhlIGVuZCBvZiB0aGUgcmVuZGVyIHF1ZXVlXG4gICAgICAgICAqL1xuICAgICAgICBhcHBlbmRTaGFwZTogZnVuY3Rpb24gKHNoYXBlKSB7XG4gICAgICAgICAgICBhbGVydCgnYXBwZW5kU2hhcGUgbm90IGltcGxlbWVudGVkJyk7XG4gICAgICAgIH0sXG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFJlcGxhY2Ugb25lIHNoYXBlIHdpdGggYW5vdGhlclxuICAgICAgICAgKi9cbiAgICAgICAgcmVwbGFjZVdpdGhTaGFwZTogZnVuY3Rpb24gKHNoYXBlaWQsIHNoYXBlKSB7XG4gICAgICAgICAgICBhbGVydCgncmVwbGFjZVdpdGhTaGFwZSBub3QgaW1wbGVtZW50ZWQnKTtcbiAgICAgICAgfSxcblxuICAgICAgICAvKipcbiAgICAgICAgICogSW5zZXJ0IG9uZSBzaGFwZSBhZnRlciBhbm90aGVyIGluIHRoZSByZW5kZXIgcXVldWVcbiAgICAgICAgICovXG4gICAgICAgIGluc2VydEFmdGVyU2hhcGU6IGZ1bmN0aW9uIChzaGFwZWlkLCBzaGFwZSkge1xuICAgICAgICAgICAgYWxlcnQoJ2luc2VydEFmdGVyU2hhcGUgbm90IGltcGxlbWVudGVkJyk7XG4gICAgICAgIH0sXG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFJlbW92ZSBhIHNoYXBlIGZyb20gdGhlIHF1ZXVlXG4gICAgICAgICAqL1xuICAgICAgICByZW1vdmVTaGFwZUlkOiBmdW5jdGlvbiAoc2hhcGVpZCkge1xuICAgICAgICAgICAgYWxlcnQoJ3JlbW92ZVNoYXBlSWQgbm90IGltcGxlbWVudGVkJyk7XG4gICAgICAgIH0sXG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIEZpbmQgYSBzaGFwZSBhdCB0aGUgc3BlY2lmaWVkIHgveSBjby1vcmRpbmF0ZXNcbiAgICAgICAgICovXG4gICAgICAgIGdldFNoYXBlQXQ6IGZ1bmN0aW9uIChlbCwgeCwgeSkge1xuICAgICAgICAgICAgYWxlcnQoJ2dldFNoYXBlQXQgbm90IGltcGxlbWVudGVkJyk7XG4gICAgICAgIH0sXG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFJlbmRlciBhbGwgcXVldWVkIHNoYXBlcyBvbnRvIHRoZSBjYW52YXNcbiAgICAgICAgICovXG4gICAgICAgIHJlbmRlcjogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgYWxlcnQoJ3JlbmRlciBub3QgaW1wbGVtZW50ZWQnKTtcbiAgICAgICAgfVxuICAgIH0pO1xuXG4gICAgVkNhbnZhc19jYW52YXMgPSBjcmVhdGVDbGFzcyhWQ2FudmFzX2Jhc2UsIHtcbiAgICAgICAgaW5pdDogZnVuY3Rpb24gKHdpZHRoLCBoZWlnaHQsIHRhcmdldCwgaW50ZXJhY3QpIHtcbiAgICAgICAgICAgIFZDYW52YXNfY2FudmFzLl9zdXBlci5pbml0LmNhbGwodGhpcywgd2lkdGgsIGhlaWdodCwgdGFyZ2V0KTtcbiAgICAgICAgICAgIHRoaXMuY2FudmFzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnY2FudmFzJyk7XG4gICAgICAgICAgICBpZiAodGFyZ2V0WzBdKSB7XG4gICAgICAgICAgICAgICAgdGFyZ2V0ID0gdGFyZ2V0WzBdO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgJC5kYXRhKHRhcmdldCwgJ19qcXNfdmNhbnZhcycsIHRoaXMpO1xuICAgICAgICAgICAgJCh0aGlzLmNhbnZhcykuY3NzKHsgZGlzcGxheTogJ2lubGluZS1ibG9jaycsIHdpZHRoOiB3aWR0aCwgaGVpZ2h0OiBoZWlnaHQsIHZlcnRpY2FsQWxpZ246ICd0b3AnIH0pO1xuICAgICAgICAgICAgdGhpcy5faW5zZXJ0KHRoaXMuY2FudmFzLCB0YXJnZXQpO1xuICAgICAgICAgICAgdGhpcy5fY2FsY3VsYXRlUGl4ZWxEaW1zKHdpZHRoLCBoZWlnaHQsIHRoaXMuY2FudmFzKTtcbiAgICAgICAgICAgIHRoaXMuY2FudmFzLndpZHRoID0gdGhpcy5waXhlbFdpZHRoO1xuICAgICAgICAgICAgdGhpcy5jYW52YXMuaGVpZ2h0ID0gdGhpcy5waXhlbEhlaWdodDtcbiAgICAgICAgICAgIHRoaXMuaW50ZXJhY3QgPSBpbnRlcmFjdDtcbiAgICAgICAgICAgIHRoaXMuc2hhcGVzID0ge307XG4gICAgICAgICAgICB0aGlzLnNoYXBlc2VxID0gW107XG4gICAgICAgICAgICB0aGlzLmN1cnJlbnRUYXJnZXRTaGFwZUlkID0gdW5kZWZpbmVkO1xuICAgICAgICAgICAgJCh0aGlzLmNhbnZhcykuY3NzKHt3aWR0aDogdGhpcy5waXhlbFdpZHRoLCBoZWlnaHQ6IHRoaXMucGl4ZWxIZWlnaHR9KTtcbiAgICAgICAgfSxcblxuICAgICAgICBfZ2V0Q29udGV4dDogZnVuY3Rpb24gKGxpbmVDb2xvciwgZmlsbENvbG9yLCBsaW5lV2lkdGgpIHtcbiAgICAgICAgICAgIHZhciBjb250ZXh0ID0gdGhpcy5jYW52YXMuZ2V0Q29udGV4dCgnMmQnKTtcbiAgICAgICAgICAgIGlmIChsaW5lQ29sb3IgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgIGNvbnRleHQuc3Ryb2tlU3R5bGUgPSBsaW5lQ29sb3I7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb250ZXh0LmxpbmVXaWR0aCA9IGxpbmVXaWR0aCA9PT0gdW5kZWZpbmVkID8gMSA6IGxpbmVXaWR0aDtcbiAgICAgICAgICAgIGlmIChmaWxsQ29sb3IgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgIGNvbnRleHQuZmlsbFN0eWxlID0gZmlsbENvbG9yO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIGNvbnRleHQ7XG4gICAgICAgIH0sXG5cbiAgICAgICAgcmVzZXQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHZhciBjb250ZXh0ID0gdGhpcy5fZ2V0Q29udGV4dCgpO1xuICAgICAgICAgICAgY29udGV4dC5jbGVhclJlY3QoMCwgMCwgdGhpcy5waXhlbFdpZHRoLCB0aGlzLnBpeGVsSGVpZ2h0KTtcbiAgICAgICAgICAgIHRoaXMuc2hhcGVzID0ge307XG4gICAgICAgICAgICB0aGlzLnNoYXBlc2VxID0gW107XG4gICAgICAgICAgICB0aGlzLmN1cnJlbnRUYXJnZXRTaGFwZUlkID0gdW5kZWZpbmVkO1xuICAgICAgICB9LFxuXG4gICAgICAgIF9kcmF3U2hhcGU6IGZ1bmN0aW9uIChzaGFwZWlkLCBwYXRoLCBsaW5lQ29sb3IsIGZpbGxDb2xvciwgbGluZVdpZHRoKSB7XG4gICAgICAgICAgICB2YXIgY29udGV4dCA9IHRoaXMuX2dldENvbnRleHQobGluZUNvbG9yLCBmaWxsQ29sb3IsIGxpbmVXaWR0aCksXG4gICAgICAgICAgICAgICAgaSwgcGxlbjtcbiAgICAgICAgICAgIGNvbnRleHQuYmVnaW5QYXRoKCk7XG4gICAgICAgICAgICBjb250ZXh0Lm1vdmVUbyhwYXRoWzBdWzBdICsgMC41LCBwYXRoWzBdWzFdICsgMC41KTtcbiAgICAgICAgICAgIGZvciAoaSA9IDEsIHBsZW4gPSBwYXRoLmxlbmd0aDsgaSA8IHBsZW47IGkrKykge1xuICAgICAgICAgICAgICAgIGNvbnRleHQubGluZVRvKHBhdGhbaV1bMF0gKyAwLjUsIHBhdGhbaV1bMV0gKyAwLjUpOyAvLyB0aGUgMC41IG9mZnNldCBnaXZlcyB1cyBjcmlzcCBwaXhlbC13aWR0aCBsaW5lc1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGxpbmVDb2xvciAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgY29udGV4dC5zdHJva2UoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChmaWxsQ29sb3IgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgIGNvbnRleHQuZmlsbCgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHRoaXMudGFyZ2V0WCAhPT0gdW5kZWZpbmVkICYmIHRoaXMudGFyZ2V0WSAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgICAgICAgY29udGV4dC5pc1BvaW50SW5QYXRoKHRoaXMudGFyZ2V0WCwgdGhpcy50YXJnZXRZKSkge1xuICAgICAgICAgICAgICAgIHRoaXMuY3VycmVudFRhcmdldFNoYXBlSWQgPSBzaGFwZWlkO1xuICAgICAgICAgICAgfVxuICAgICAgICB9LFxuXG4gICAgICAgIF9kcmF3Q2lyY2xlOiBmdW5jdGlvbiAoc2hhcGVpZCwgeCwgeSwgcmFkaXVzLCBsaW5lQ29sb3IsIGZpbGxDb2xvciwgbGluZVdpZHRoKSB7XG4gICAgICAgICAgICB2YXIgY29udGV4dCA9IHRoaXMuX2dldENvbnRleHQobGluZUNvbG9yLCBmaWxsQ29sb3IsIGxpbmVXaWR0aCk7XG4gICAgICAgICAgICBjb250ZXh0LmJlZ2luUGF0aCgpO1xuICAgICAgICAgICAgY29udGV4dC5hcmMoeCwgeSwgcmFkaXVzLCAwLCAyICogTWF0aC5QSSwgZmFsc2UpO1xuICAgICAgICAgICAgaWYgKHRoaXMudGFyZ2V0WCAhPT0gdW5kZWZpbmVkICYmIHRoaXMudGFyZ2V0WSAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgICAgICAgY29udGV4dC5pc1BvaW50SW5QYXRoKHRoaXMudGFyZ2V0WCwgdGhpcy50YXJnZXRZKSkge1xuICAgICAgICAgICAgICAgIHRoaXMuY3VycmVudFRhcmdldFNoYXBlSWQgPSBzaGFwZWlkO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGxpbmVDb2xvciAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgY29udGV4dC5zdHJva2UoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChmaWxsQ29sb3IgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgIGNvbnRleHQuZmlsbCgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9LFxuXG4gICAgICAgIF9kcmF3UGllU2xpY2U6IGZ1bmN0aW9uIChzaGFwZWlkLCB4LCB5LCByYWRpdXMsIHN0YXJ0QW5nbGUsIGVuZEFuZ2xlLCBsaW5lQ29sb3IsIGZpbGxDb2xvcikge1xuICAgICAgICAgICAgdmFyIGNvbnRleHQgPSB0aGlzLl9nZXRDb250ZXh0KGxpbmVDb2xvciwgZmlsbENvbG9yKTtcbiAgICAgICAgICAgIGNvbnRleHQuYmVnaW5QYXRoKCk7XG4gICAgICAgICAgICBjb250ZXh0Lm1vdmVUbyh4LCB5KTtcbiAgICAgICAgICAgIGNvbnRleHQuYXJjKHgsIHksIHJhZGl1cywgc3RhcnRBbmdsZSwgZW5kQW5nbGUsIGZhbHNlKTtcbiAgICAgICAgICAgIGNvbnRleHQubGluZVRvKHgsIHkpO1xuICAgICAgICAgICAgY29udGV4dC5jbG9zZVBhdGgoKTtcbiAgICAgICAgICAgIGlmIChsaW5lQ29sb3IgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgIGNvbnRleHQuc3Ryb2tlKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoZmlsbENvbG9yKSB7XG4gICAgICAgICAgICAgICAgY29udGV4dC5maWxsKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAodGhpcy50YXJnZXRYICE9PSB1bmRlZmluZWQgJiYgdGhpcy50YXJnZXRZICE9PSB1bmRlZmluZWQgJiZcbiAgICAgICAgICAgICAgICBjb250ZXh0LmlzUG9pbnRJblBhdGgodGhpcy50YXJnZXRYLCB0aGlzLnRhcmdldFkpKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5jdXJyZW50VGFyZ2V0U2hhcGVJZCA9IHNoYXBlaWQ7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0sXG5cbiAgICAgICAgX2RyYXdSZWN0OiBmdW5jdGlvbiAoc2hhcGVpZCwgeCwgeSwgd2lkdGgsIGhlaWdodCwgbGluZUNvbG9yLCBmaWxsQ29sb3IpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9kcmF3U2hhcGUoc2hhcGVpZCwgW1t4LCB5XSwgW3ggKyB3aWR0aCwgeV0sIFt4ICsgd2lkdGgsIHkgKyBoZWlnaHRdLCBbeCwgeSArIGhlaWdodF0sIFt4LCB5XV0sIGxpbmVDb2xvciwgZmlsbENvbG9yKTtcbiAgICAgICAgfSxcblxuICAgICAgICBhcHBlbmRTaGFwZTogZnVuY3Rpb24gKHNoYXBlKSB7XG4gICAgICAgICAgICB0aGlzLnNoYXBlc1tzaGFwZS5pZF0gPSBzaGFwZTtcbiAgICAgICAgICAgIHRoaXMuc2hhcGVzZXEucHVzaChzaGFwZS5pZCk7XG4gICAgICAgICAgICB0aGlzLmxhc3RTaGFwZUlkID0gc2hhcGUuaWQ7XG4gICAgICAgICAgICByZXR1cm4gc2hhcGUuaWQ7XG4gICAgICAgIH0sXG5cbiAgICAgICAgcmVwbGFjZVdpdGhTaGFwZTogZnVuY3Rpb24gKHNoYXBlaWQsIHNoYXBlKSB7XG4gICAgICAgICAgICB2YXIgc2hhcGVzZXEgPSB0aGlzLnNoYXBlc2VxLFxuICAgICAgICAgICAgICAgIGk7XG4gICAgICAgICAgICB0aGlzLnNoYXBlc1tzaGFwZS5pZF0gPSBzaGFwZTtcbiAgICAgICAgICAgIGZvciAoaSA9IHNoYXBlc2VxLmxlbmd0aDsgaS0tOykge1xuICAgICAgICAgICAgICAgIGlmIChzaGFwZXNlcVtpXSA9PSBzaGFwZWlkKSB7XG4gICAgICAgICAgICAgICAgICAgIHNoYXBlc2VxW2ldID0gc2hhcGUuaWQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZGVsZXRlIHRoaXMuc2hhcGVzW3NoYXBlaWRdO1xuICAgICAgICB9LFxuXG4gICAgICAgIHJlcGxhY2VXaXRoU2hhcGVzOiBmdW5jdGlvbiAoc2hhcGVpZHMsIHNoYXBlcykge1xuICAgICAgICAgICAgdmFyIHNoYXBlc2VxID0gdGhpcy5zaGFwZXNlcSxcbiAgICAgICAgICAgICAgICBzaGFwZW1hcCA9IHt9LFxuICAgICAgICAgICAgICAgIHNpZCwgaSwgZmlyc3Q7XG5cbiAgICAgICAgICAgIGZvciAoaSA9IHNoYXBlaWRzLmxlbmd0aDsgaS0tOykge1xuICAgICAgICAgICAgICAgIHNoYXBlbWFwW3NoYXBlaWRzW2ldXSA9IHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBmb3IgKGkgPSBzaGFwZXNlcS5sZW5ndGg7IGktLTspIHtcbiAgICAgICAgICAgICAgICBzaWQgPSBzaGFwZXNlcVtpXTtcbiAgICAgICAgICAgICAgICBpZiAoc2hhcGVtYXBbc2lkXSkge1xuICAgICAgICAgICAgICAgICAgICBzaGFwZXNlcS5zcGxpY2UoaSwgMSk7XG4gICAgICAgICAgICAgICAgICAgIGRlbGV0ZSB0aGlzLnNoYXBlc1tzaWRdO1xuICAgICAgICAgICAgICAgICAgICBmaXJzdCA9IGk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZm9yIChpID0gc2hhcGVzLmxlbmd0aDsgaS0tOykge1xuICAgICAgICAgICAgICAgIHNoYXBlc2VxLnNwbGljZShmaXJzdCwgMCwgc2hhcGVzW2ldLmlkKTtcbiAgICAgICAgICAgICAgICB0aGlzLnNoYXBlc1tzaGFwZXNbaV0uaWRdID0gc2hhcGVzW2ldO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgIH0sXG5cbiAgICAgICAgaW5zZXJ0QWZ0ZXJTaGFwZTogZnVuY3Rpb24gKHNoYXBlaWQsIHNoYXBlKSB7XG4gICAgICAgICAgICB2YXIgc2hhcGVzZXEgPSB0aGlzLnNoYXBlc2VxLFxuICAgICAgICAgICAgICAgIGk7XG4gICAgICAgICAgICBmb3IgKGkgPSBzaGFwZXNlcS5sZW5ndGg7IGktLTspIHtcbiAgICAgICAgICAgICAgICBpZiAoc2hhcGVzZXFbaV0gPT09IHNoYXBlaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgc2hhcGVzZXEuc3BsaWNlKGkgKyAxLCAwLCBzaGFwZS5pZCk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2hhcGVzW3NoYXBlLmlkXSA9IHNoYXBlO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9LFxuXG4gICAgICAgIHJlbW92ZVNoYXBlSWQ6IGZ1bmN0aW9uIChzaGFwZWlkKSB7XG4gICAgICAgICAgICB2YXIgc2hhcGVzZXEgPSB0aGlzLnNoYXBlc2VxLFxuICAgICAgICAgICAgICAgIGk7XG4gICAgICAgICAgICBmb3IgKGkgPSBzaGFwZXNlcS5sZW5ndGg7IGktLTspIHtcbiAgICAgICAgICAgICAgICBpZiAoc2hhcGVzZXFbaV0gPT09IHNoYXBlaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgc2hhcGVzZXEuc3BsaWNlKGksIDEpO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBkZWxldGUgdGhpcy5zaGFwZXNbc2hhcGVpZF07XG4gICAgICAgIH0sXG5cbiAgICAgICAgZ2V0U2hhcGVBdDogZnVuY3Rpb24gKGVsLCB4LCB5KSB7XG4gICAgICAgICAgICB0aGlzLnRhcmdldFggPSB4O1xuICAgICAgICAgICAgdGhpcy50YXJnZXRZID0geTtcbiAgICAgICAgICAgIHRoaXMucmVuZGVyKCk7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5jdXJyZW50VGFyZ2V0U2hhcGVJZDtcbiAgICAgICAgfSxcblxuICAgICAgICByZW5kZXI6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHZhciBzaGFwZXNlcSA9IHRoaXMuc2hhcGVzZXEsXG4gICAgICAgICAgICAgICAgc2hhcGVzID0gdGhpcy5zaGFwZXMsXG4gICAgICAgICAgICAgICAgc2hhcGVDb3VudCA9IHNoYXBlc2VxLmxlbmd0aCxcbiAgICAgICAgICAgICAgICBjb250ZXh0ID0gdGhpcy5fZ2V0Q29udGV4dCgpLFxuICAgICAgICAgICAgICAgIHNoYXBlaWQsIHNoYXBlLCBpO1xuICAgICAgICAgICAgY29udGV4dC5jbGVhclJlY3QoMCwgMCwgdGhpcy5waXhlbFdpZHRoLCB0aGlzLnBpeGVsSGVpZ2h0KTtcbiAgICAgICAgICAgIGZvciAoaSA9IDA7IGkgPCBzaGFwZUNvdW50OyBpKyspIHtcbiAgICAgICAgICAgICAgICBzaGFwZWlkID0gc2hhcGVzZXFbaV07XG4gICAgICAgICAgICAgICAgc2hhcGUgPSBzaGFwZXNbc2hhcGVpZF07XG4gICAgICAgICAgICAgICAgdGhpc1snX2RyYXcnICsgc2hhcGUudHlwZV0uYXBwbHkodGhpcywgc2hhcGUuYXJncyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoIXRoaXMuaW50ZXJhY3QpIHtcbiAgICAgICAgICAgICAgICAvLyBub3QgaW50ZXJhY3RpdmUgc28gbm8gbmVlZCB0byBrZWVwIHRoZSBzaGFwZXMgYXJyYXlcbiAgICAgICAgICAgICAgICB0aGlzLnNoYXBlcyA9IHt9O1xuICAgICAgICAgICAgICAgIHRoaXMuc2hhcGVzZXEgPSBbXTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgfSk7XG5cbiAgICBWQ2FudmFzX3ZtbCA9IGNyZWF0ZUNsYXNzKFZDYW52YXNfYmFzZSwge1xuICAgICAgICBpbml0OiBmdW5jdGlvbiAod2lkdGgsIGhlaWdodCwgdGFyZ2V0KSB7XG4gICAgICAgICAgICB2YXIgZ3JvdXBlbDtcbiAgICAgICAgICAgIFZDYW52YXNfdm1sLl9zdXBlci5pbml0LmNhbGwodGhpcywgd2lkdGgsIGhlaWdodCwgdGFyZ2V0KTtcbiAgICAgICAgICAgIGlmICh0YXJnZXRbMF0pIHtcbiAgICAgICAgICAgICAgICB0YXJnZXQgPSB0YXJnZXRbMF07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAkLmRhdGEodGFyZ2V0LCAnX2pxc192Y2FudmFzJywgdGhpcyk7XG4gICAgICAgICAgICB0aGlzLmNhbnZhcyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgICAgICAgICAgICQodGhpcy5jYW52YXMpLmNzcyh7IGRpc3BsYXk6ICdpbmxpbmUtYmxvY2snLCBwb3NpdGlvbjogJ3JlbGF0aXZlJywgb3ZlcmZsb3c6ICdoaWRkZW4nLCB3aWR0aDogd2lkdGgsIGhlaWdodDogaGVpZ2h0LCBtYXJnaW46ICcwcHgnLCBwYWRkaW5nOiAnMHB4JywgdmVydGljYWxBbGlnbjogJ3RvcCd9KTtcbiAgICAgICAgICAgIHRoaXMuX2luc2VydCh0aGlzLmNhbnZhcywgdGFyZ2V0KTtcbiAgICAgICAgICAgIHRoaXMuX2NhbGN1bGF0ZVBpeGVsRGltcyh3aWR0aCwgaGVpZ2h0LCB0aGlzLmNhbnZhcyk7XG4gICAgICAgICAgICB0aGlzLmNhbnZhcy53aWR0aCA9IHRoaXMucGl4ZWxXaWR0aDtcbiAgICAgICAgICAgIHRoaXMuY2FudmFzLmhlaWdodCA9IHRoaXMucGl4ZWxIZWlnaHQ7XG4gICAgICAgICAgICBncm91cGVsID0gJzx2Omdyb3VwIGNvb3Jkb3JpZ2luPVwiMCAwXCIgY29vcmRzaXplPVwiJyArIHRoaXMucGl4ZWxXaWR0aCArICcgJyArIHRoaXMucGl4ZWxIZWlnaHQgKyAnXCInICtcbiAgICAgICAgICAgICAgICAgICAgJyBzdHlsZT1cInBvc2l0aW9uOmFic29sdXRlO3RvcDowO2xlZnQ6MDt3aWR0aDonICsgdGhpcy5waXhlbFdpZHRoICsgJ3B4O2hlaWdodD0nICsgdGhpcy5waXhlbEhlaWdodCArICdweDtcIj48L3Y6Z3JvdXA+JztcbiAgICAgICAgICAgIHRoaXMuY2FudmFzLmluc2VydEFkamFjZW50SFRNTCgnYmVmb3JlRW5kJywgZ3JvdXBlbCk7XG4gICAgICAgICAgICB0aGlzLmdyb3VwID0gJCh0aGlzLmNhbnZhcykuY2hpbGRyZW4oKVswXTtcbiAgICAgICAgICAgIHRoaXMucmVuZGVyZWQgPSBmYWxzZTtcbiAgICAgICAgICAgIHRoaXMucHJlcmVuZGVyID0gJyc7XG4gICAgICAgIH0sXG5cbiAgICAgICAgX2RyYXdTaGFwZTogZnVuY3Rpb24gKHNoYXBlaWQsIHBhdGgsIGxpbmVDb2xvciwgZmlsbENvbG9yLCBsaW5lV2lkdGgpIHtcbiAgICAgICAgICAgIHZhciB2cGF0aCA9IFtdLFxuICAgICAgICAgICAgICAgIGluaXRpYWwsIHN0cm9rZSwgZmlsbCwgY2xvc2VkLCB2ZWwsIHBsZW4sIGk7XG4gICAgICAgICAgICBmb3IgKGkgPSAwLCBwbGVuID0gcGF0aC5sZW5ndGg7IGkgPCBwbGVuOyBpKyspIHtcbiAgICAgICAgICAgICAgICB2cGF0aFtpXSA9ICcnICsgKHBhdGhbaV1bMF0pICsgJywnICsgKHBhdGhbaV1bMV0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaW5pdGlhbCA9IHZwYXRoLnNwbGljZSgwLCAxKTtcbiAgICAgICAgICAgIGxpbmVXaWR0aCA9IGxpbmVXaWR0aCA9PT0gdW5kZWZpbmVkID8gMSA6IGxpbmVXaWR0aDtcbiAgICAgICAgICAgIHN0cm9rZSA9IGxpbmVDb2xvciA9PT0gdW5kZWZpbmVkID8gJyBzdHJva2VkPVwiZmFsc2VcIiAnIDogJyBzdHJva2VXZWlnaHQ9XCInICsgbGluZVdpZHRoICsgJ3B4XCIgc3Ryb2tlQ29sb3I9XCInICsgbGluZUNvbG9yICsgJ1wiICc7XG4gICAgICAgICAgICBmaWxsID0gZmlsbENvbG9yID09PSB1bmRlZmluZWQgPyAnIGZpbGxlZD1cImZhbHNlXCInIDogJyBmaWxsQ29sb3I9XCInICsgZmlsbENvbG9yICsgJ1wiIGZpbGxlZD1cInRydWVcIiAnO1xuICAgICAgICAgICAgY2xvc2VkID0gdnBhdGhbMF0gPT09IHZwYXRoW3ZwYXRoLmxlbmd0aCAtIDFdID8gJ3ggJyA6ICcnO1xuICAgICAgICAgICAgdmVsID0gJzx2OnNoYXBlIGNvb3Jkb3JpZ2luPVwiMCAwXCIgY29vcmRzaXplPVwiJyArIHRoaXMucGl4ZWxXaWR0aCArICcgJyArIHRoaXMucGl4ZWxIZWlnaHQgKyAnXCIgJyArXG4gICAgICAgICAgICAgICAgICcgaWQ9XCJqcXNzaGFwZScgKyBzaGFwZWlkICsgJ1wiICcgK1xuICAgICAgICAgICAgICAgICBzdHJva2UgK1xuICAgICAgICAgICAgICAgICBmaWxsICtcbiAgICAgICAgICAgICAgICAnIHN0eWxlPVwicG9zaXRpb246YWJzb2x1dGU7bGVmdDowcHg7dG9wOjBweDtoZWlnaHQ6JyArIHRoaXMucGl4ZWxIZWlnaHQgKyAncHg7d2lkdGg6JyArIHRoaXMucGl4ZWxXaWR0aCArICdweDtwYWRkaW5nOjBweDttYXJnaW46MHB4O1wiICcgK1xuICAgICAgICAgICAgICAgICcgcGF0aD1cIm0gJyArIGluaXRpYWwgKyAnIGwgJyArIHZwYXRoLmpvaW4oJywgJykgKyAnICcgKyBjbG9zZWQgKyAnZVwiPicgK1xuICAgICAgICAgICAgICAgICcgPC92OnNoYXBlPic7XG4gICAgICAgICAgICByZXR1cm4gdmVsO1xuICAgICAgICB9LFxuXG4gICAgICAgIF9kcmF3Q2lyY2xlOiBmdW5jdGlvbiAoc2hhcGVpZCwgeCwgeSwgcmFkaXVzLCBsaW5lQ29sb3IsIGZpbGxDb2xvciwgbGluZVdpZHRoKSB7XG4gICAgICAgICAgICB2YXIgc3Ryb2tlLCBmaWxsLCB2ZWw7XG4gICAgICAgICAgICB4IC09IHJhZGl1cztcbiAgICAgICAgICAgIHkgLT0gcmFkaXVzO1xuICAgICAgICAgICAgc3Ryb2tlID0gbGluZUNvbG9yID09PSB1bmRlZmluZWQgPyAnIHN0cm9rZWQ9XCJmYWxzZVwiICcgOiAnIHN0cm9rZVdlaWdodD1cIicgKyBsaW5lV2lkdGggKyAncHhcIiBzdHJva2VDb2xvcj1cIicgKyBsaW5lQ29sb3IgKyAnXCIgJztcbiAgICAgICAgICAgIGZpbGwgPSBmaWxsQ29sb3IgPT09IHVuZGVmaW5lZCA/ICcgZmlsbGVkPVwiZmFsc2VcIicgOiAnIGZpbGxDb2xvcj1cIicgKyBmaWxsQ29sb3IgKyAnXCIgZmlsbGVkPVwidHJ1ZVwiICc7XG4gICAgICAgICAgICB2ZWwgPSAnPHY6b3ZhbCAnICtcbiAgICAgICAgICAgICAgICAgJyBpZD1cImpxc3NoYXBlJyArIHNoYXBlaWQgKyAnXCIgJyArXG4gICAgICAgICAgICAgICAgc3Ryb2tlICtcbiAgICAgICAgICAgICAgICBmaWxsICtcbiAgICAgICAgICAgICAgICAnIHN0eWxlPVwicG9zaXRpb246YWJzb2x1dGU7dG9wOicgKyB5ICsgJ3B4OyBsZWZ0OicgKyB4ICsgJ3B4OyB3aWR0aDonICsgKHJhZGl1cyAqIDIpICsgJ3B4OyBoZWlnaHQ6JyArIChyYWRpdXMgKiAyKSArICdweFwiPjwvdjpvdmFsPic7XG4gICAgICAgICAgICByZXR1cm4gdmVsO1xuXG4gICAgICAgIH0sXG5cbiAgICAgICAgX2RyYXdQaWVTbGljZTogZnVuY3Rpb24gKHNoYXBlaWQsIHgsIHksIHJhZGl1cywgc3RhcnRBbmdsZSwgZW5kQW5nbGUsIGxpbmVDb2xvciwgZmlsbENvbG9yKSB7XG4gICAgICAgICAgICB2YXIgdnBhdGgsIHN0YXJ0eCwgc3RhcnR5LCBlbmR4LCBlbmR5LCBzdHJva2UsIGZpbGwsIHZlbDtcbiAgICAgICAgICAgIGlmIChzdGFydEFuZ2xlID09PSBlbmRBbmdsZSkge1xuICAgICAgICAgICAgICAgIHJldHVybiAnJzsgIC8vIFZNTCBzZWVtcyB0byBoYXZlIHByb2JsZW0gd2hlbiBzdGFydCBhbmdsZSBlcXVhbHMgZW5kIGFuZ2xlLlxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKChlbmRBbmdsZSAtIHN0YXJ0QW5nbGUpID09PSAoMiAqIE1hdGguUEkpKSB7XG4gICAgICAgICAgICAgICAgc3RhcnRBbmdsZSA9IDAuMDsgIC8vIFZNTCBzZWVtcyB0byBoYXZlIGEgcHJvYmxlbSB3aGVuIGRyYXdpbmcgYSBmdWxsIGNpcmNsZSB0aGF0IGRvZXNuJ3Qgc3RhcnQgMFxuICAgICAgICAgICAgICAgIGVuZEFuZ2xlID0gKDIgKiBNYXRoLlBJKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgc3RhcnR4ID0geCArIE1hdGgucm91bmQoTWF0aC5jb3Moc3RhcnRBbmdsZSkgKiByYWRpdXMpO1xuICAgICAgICAgICAgc3RhcnR5ID0geSArIE1hdGgucm91bmQoTWF0aC5zaW4oc3RhcnRBbmdsZSkgKiByYWRpdXMpO1xuICAgICAgICAgICAgZW5keCA9IHggKyBNYXRoLnJvdW5kKE1hdGguY29zKGVuZEFuZ2xlKSAqIHJhZGl1cyk7XG4gICAgICAgICAgICBlbmR5ID0geSArIE1hdGgucm91bmQoTWF0aC5zaW4oZW5kQW5nbGUpICogcmFkaXVzKTtcblxuICAgICAgICAgICAgaWYgKHN0YXJ0eCA9PT0gZW5keCAmJiBzdGFydHkgPT09IGVuZHkpIHtcbiAgICAgICAgICAgICAgICBpZiAoKGVuZEFuZ2xlIC0gc3RhcnRBbmdsZSkgPCBNYXRoLlBJKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIFByZXZlbnQgdmVyeSBzbWFsbCBzbGljZXMgZnJvbSBiZWluZyBtaXN0YWtlbiBhcyBhIHdob2xlIHBpZVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gJyc7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC8vIGVzc2VudGlhbGx5IGdvaW5nIHRvIGJlIHRoZSBlbnRpcmUgY2lyY2xlLCBzbyBpZ25vcmUgc3RhcnRBbmdsZVxuICAgICAgICAgICAgICAgIHN0YXJ0eCA9IGVuZHggPSB4ICsgcmFkaXVzO1xuICAgICAgICAgICAgICAgIHN0YXJ0eSA9IGVuZHkgPSB5O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAoc3RhcnR4ID09PSBlbmR4ICYmIHN0YXJ0eSA9PT0gZW5keSAmJiAoZW5kQW5nbGUgLSBzdGFydEFuZ2xlKSA8IE1hdGguUEkpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gJyc7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHZwYXRoID0gW3ggLSByYWRpdXMsIHkgLSByYWRpdXMsIHggKyByYWRpdXMsIHkgKyByYWRpdXMsIHN0YXJ0eCwgc3RhcnR5LCBlbmR4LCBlbmR5XTtcbiAgICAgICAgICAgIHN0cm9rZSA9IGxpbmVDb2xvciA9PT0gdW5kZWZpbmVkID8gJyBzdHJva2VkPVwiZmFsc2VcIiAnIDogJyBzdHJva2VXZWlnaHQ9XCIxcHhcIiBzdHJva2VDb2xvcj1cIicgKyBsaW5lQ29sb3IgKyAnXCIgJztcbiAgICAgICAgICAgIGZpbGwgPSBmaWxsQ29sb3IgPT09IHVuZGVmaW5lZCA/ICcgZmlsbGVkPVwiZmFsc2VcIicgOiAnIGZpbGxDb2xvcj1cIicgKyBmaWxsQ29sb3IgKyAnXCIgZmlsbGVkPVwidHJ1ZVwiICc7XG4gICAgICAgICAgICB2ZWwgPSAnPHY6c2hhcGUgY29vcmRvcmlnaW49XCIwIDBcIiBjb29yZHNpemU9XCInICsgdGhpcy5waXhlbFdpZHRoICsgJyAnICsgdGhpcy5waXhlbEhlaWdodCArICdcIiAnICtcbiAgICAgICAgICAgICAgICAgJyBpZD1cImpxc3NoYXBlJyArIHNoYXBlaWQgKyAnXCIgJyArXG4gICAgICAgICAgICAgICAgIHN0cm9rZSArXG4gICAgICAgICAgICAgICAgIGZpbGwgK1xuICAgICAgICAgICAgICAgICcgc3R5bGU9XCJwb3NpdGlvbjphYnNvbHV0ZTtsZWZ0OjBweDt0b3A6MHB4O2hlaWdodDonICsgdGhpcy5waXhlbEhlaWdodCArICdweDt3aWR0aDonICsgdGhpcy5waXhlbFdpZHRoICsgJ3B4O3BhZGRpbmc6MHB4O21hcmdpbjowcHg7XCIgJyArXG4gICAgICAgICAgICAgICAgJyBwYXRoPVwibSAnICsgeCArICcsJyArIHkgKyAnIHdhICcgKyB2cGF0aC5qb2luKCcsICcpICsgJyB4IGVcIj4nICtcbiAgICAgICAgICAgICAgICAnIDwvdjpzaGFwZT4nO1xuICAgICAgICAgICAgcmV0dXJuIHZlbDtcbiAgICAgICAgfSxcblxuICAgICAgICBfZHJhd1JlY3Q6IGZ1bmN0aW9uIChzaGFwZWlkLCB4LCB5LCB3aWR0aCwgaGVpZ2h0LCBsaW5lQ29sb3IsIGZpbGxDb2xvcikge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2RyYXdTaGFwZShzaGFwZWlkLCBbW3gsIHldLCBbeCwgeSArIGhlaWdodF0sIFt4ICsgd2lkdGgsIHkgKyBoZWlnaHRdLCBbeCArIHdpZHRoLCB5XSwgW3gsIHldXSwgbGluZUNvbG9yLCBmaWxsQ29sb3IpO1xuICAgICAgICB9LFxuXG4gICAgICAgIHJlc2V0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB0aGlzLmdyb3VwLmlubmVySFRNTCA9ICcnO1xuICAgICAgICB9LFxuXG4gICAgICAgIGFwcGVuZFNoYXBlOiBmdW5jdGlvbiAoc2hhcGUpIHtcbiAgICAgICAgICAgIHZhciB2ZWwgPSB0aGlzWydfZHJhdycgKyBzaGFwZS50eXBlXS5hcHBseSh0aGlzLCBzaGFwZS5hcmdzKTtcbiAgICAgICAgICAgIGlmICh0aGlzLnJlbmRlcmVkKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5ncm91cC5pbnNlcnRBZGphY2VudEhUTUwoJ2JlZm9yZUVuZCcsIHZlbCk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRoaXMucHJlcmVuZGVyICs9IHZlbDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMubGFzdFNoYXBlSWQgPSBzaGFwZS5pZDtcbiAgICAgICAgICAgIHJldHVybiBzaGFwZS5pZDtcbiAgICAgICAgfSxcblxuICAgICAgICByZXBsYWNlV2l0aFNoYXBlOiBmdW5jdGlvbiAoc2hhcGVpZCwgc2hhcGUpIHtcbiAgICAgICAgICAgIHZhciBleGlzdGluZyA9ICQoJyNqcXNzaGFwZScgKyBzaGFwZWlkKSxcbiAgICAgICAgICAgICAgICB2ZWwgPSB0aGlzWydfZHJhdycgKyBzaGFwZS50eXBlXS5hcHBseSh0aGlzLCBzaGFwZS5hcmdzKTtcbiAgICAgICAgICAgIGV4aXN0aW5nWzBdLm91dGVySFRNTCA9IHZlbDtcbiAgICAgICAgfSxcblxuICAgICAgICByZXBsYWNlV2l0aFNoYXBlczogZnVuY3Rpb24gKHNoYXBlaWRzLCBzaGFwZXMpIHtcbiAgICAgICAgICAgIC8vIHJlcGxhY2UgdGhlIGZpcnN0IHNoYXBlaWQgd2l0aCBhbGwgdGhlIG5ldyBzaGFwZXMgdGhlbiB0b2FzdCB0aGUgcmVtYWluaW5nIG9sZCBzaGFwZXNcbiAgICAgICAgICAgIHZhciBleGlzdGluZyA9ICQoJyNqcXNzaGFwZScgKyBzaGFwZWlkc1swXSksXG4gICAgICAgICAgICAgICAgcmVwbGFjZSA9ICcnLFxuICAgICAgICAgICAgICAgIHNsZW4gPSBzaGFwZXMubGVuZ3RoLFxuICAgICAgICAgICAgICAgIGk7XG4gICAgICAgICAgICBmb3IgKGkgPSAwOyBpIDwgc2xlbjsgaSsrKSB7XG4gICAgICAgICAgICAgICAgcmVwbGFjZSArPSB0aGlzWydfZHJhdycgKyBzaGFwZXNbaV0udHlwZV0uYXBwbHkodGhpcywgc2hhcGVzW2ldLmFyZ3MpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZXhpc3RpbmdbMF0ub3V0ZXJIVE1MID0gcmVwbGFjZTtcbiAgICAgICAgICAgIGZvciAoaSA9IDE7IGkgPCBzaGFwZWlkcy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgICQoJyNqcXNzaGFwZScgKyBzaGFwZWlkc1tpXSkucmVtb3ZlKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0sXG5cbiAgICAgICAgaW5zZXJ0QWZ0ZXJTaGFwZTogZnVuY3Rpb24gKHNoYXBlaWQsIHNoYXBlKSB7XG4gICAgICAgICAgICB2YXIgZXhpc3RpbmcgPSAkKCcjanFzc2hhcGUnICsgc2hhcGVpZCksXG4gICAgICAgICAgICAgICAgIHZlbCA9IHRoaXNbJ19kcmF3JyArIHNoYXBlLnR5cGVdLmFwcGx5KHRoaXMsIHNoYXBlLmFyZ3MpO1xuICAgICAgICAgICAgZXhpc3RpbmdbMF0uaW5zZXJ0QWRqYWNlbnRIVE1MKCdhZnRlckVuZCcsIHZlbCk7XG4gICAgICAgIH0sXG5cbiAgICAgICAgcmVtb3ZlU2hhcGVJZDogZnVuY3Rpb24gKHNoYXBlaWQpIHtcbiAgICAgICAgICAgIHZhciBleGlzdGluZyA9ICQoJyNqcXNzaGFwZScgKyBzaGFwZWlkKTtcbiAgICAgICAgICAgIHRoaXMuZ3JvdXAucmVtb3ZlQ2hpbGQoZXhpc3RpbmdbMF0pO1xuICAgICAgICB9LFxuXG4gICAgICAgIGdldFNoYXBlQXQ6IGZ1bmN0aW9uIChlbCwgeCwgeSkge1xuICAgICAgICAgICAgdmFyIHNoYXBlaWQgPSBlbC5pZC5zdWJzdHIoOCk7XG4gICAgICAgICAgICByZXR1cm4gc2hhcGVpZDtcbiAgICAgICAgfSxcblxuICAgICAgICByZW5kZXI6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGlmICghdGhpcy5yZW5kZXJlZCkge1xuICAgICAgICAgICAgICAgIC8vIGJhdGNoIHRoZSBpbnRpYWwgcmVuZGVyIGludG8gYSBzaW5nbGUgcmVwYWludFxuICAgICAgICAgICAgICAgIHRoaXMuZ3JvdXAuaW5uZXJIVE1MID0gdGhpcy5wcmVyZW5kZXI7XG4gICAgICAgICAgICAgICAgdGhpcy5yZW5kZXJlZCA9IHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9KTtcblxufSkpfShkb2N1bWVudCwgTWF0aCkpO1xuIl19
