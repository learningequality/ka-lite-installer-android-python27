require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"homepage":[function(require,module,exports){
var $ = require("../base/jQuery");
var content_rec_views = require("../contentrec/views");
var user = require("../user/views");

require("../../../css/distributed/homepage.less");

$(function() {
    if (ds.distributed.front_page_welcome_message) {
        show_message("success", ds.distributed.front_page_welcome_message);
    }
    var content_rec_load = function() {
        if (window.statusModel.is_student() && !window.hpwrapper) {
            window.hpwrapper = new content_rec_views.HomepageWrapper({
                el:"#content-area"
            });
        }
    };
    window.statusModel.listenTo(window.statusModel, "change", content_rec_load);

    window.statusModel.listenTo(window.statusModel, "change:has_superuser", function () {
        if (!window.statusModel.get("has_superuser")) { // "has_superuser" is true if an admin user exists.
            window.super_user_create_modal = new user.SuperUserCreateModalView();
        } else if ( typeof window.super_user_create_modal !== "undefined" ) {
            window.super_user_create_modal.remove();
        }
    });
});
},{"../../../css/distributed/homepage.less":33,"../base/jQuery":45,"../contentrec/views":58,"../user/views":123}],58:[function(require,module,exports){
// Views
var _ = require("underscore");
var models = require("./models");
var BaseView = require("../base/baseview");

require("../../../css/distributed/content_recommendation.less");

/*All 3 cards go into this wrapper, which makes the page responsive*/
var HomepageWrapper = BaseView.extend({

    template: require("./hbtemplates/content-rec-wrapper.handlebars"),
    
    initialize: function() {
        _.bindAll(this, "set_collection", "data_load");
        this.set_collection();
        this.listenTo(window.statusModel, "change:user_id", this.set_collection);
    },

    set_collection: function() {
        this.collection = new models.SuggestedContentCollection([], {
            resume: true,
            next: true,
            explore: true
        });
        this.listenTo(this.collection, "sync", this.data_load);
        this.collection.fetch();
    },

    render: function() {
        if (this.collection.length > 0) {
            this.$el.html(this.template());

            if (this.content_resume) {
                this.$("#resume").append(this.content_resume.el);
            }

            if (this.content_nextsteps) {
                this.$("#nextsteps").append(this.content_nextsteps.el);
            }

            if (this.content_explore) {
                this.$("#explore").append(this.content_explore.el);
            }
        }
    },

    data_load: function() {
        var resumeCollection = new models.SuggestedContentCollection(this.collection.where({resume:true}));
        
        var nextStepsCollection = new models.SuggestedContentCollection(this.collection.where({next:true}));
        
        var exploreCollection = new models.SuggestedContentCollection(this.collection.where({explore:true}));
        
        if (resumeCollection.length > 0) {
            this.content_resume = new ContentResumeView({
                collection:resumeCollection
            });
        }

        if (nextStepsCollection.length > 0) {
            this.content_nextsteps = new ContentNextStepsView({
                collection:nextStepsCollection
            });
        }

        if (exploreCollection.length > 0) {
            this.content_explore = new ContentExploreView({
                collection:exploreCollection
            });
        }
                
        this.render();
    }
});

/**
 * View that wraps the resume card on the home page
 */
window.ContentResumeView = BaseView.extend({

    template: require("./hbtemplates/content-resume.handlebars"),
    
    initialize: function() {
        _.bindAll(this, "render");

        if (typeof this.collection === "undefined") {
            this.collection = new models.SuggestedContentCollection([], {resume: true});
            this.listenTo(this.collection, "sync", this.render);
            this.collection.fetch();
        } else {
            this.render();
        }
    },

    render: function() {
        this.model = this.collection.at(0);
        this.$el.html(this.template(this.model.attributes));
    }

});

/**
 * View that wraps a lesson on the next steps card on the home page
 */
window.ContentNextStepsLessonView = BaseView.extend({

    template: require("./hbtemplates/content-nextsteps-lesson.handlebars"),

    initialize: function() {
        this.render();
    },

    render: function() {
        this.$el.html(this.template(this.model.attributes));
    }

});

/**
 * View that wraps all the next steps cards on the home page
 */
window.ContentNextStepsView = BaseView.extend({

    template: require("./hbtemplates/content-nextsteps.handlebars"),
    
    initialize: function() {
        _.bindAll(this, "render");
        
        if (typeof this.collection === "undefined") {
            this.collection = new models.SuggestedContentCollection([], {next: true});
            this.listenTo(this.collection, "sync", this.render);
            this.collection.fetch();
        } else {
            this.render();
        }
    },

    render: function() {

        this.$el.html(this.template());
        var container = document.createDocumentFragment();

        for(i = 0; i < this.collection.length; i++) {
            var name = 'content_nextsteps_lesson_'+ i;
            this[name] = this.add_subview(ContentNextStepsLessonView, {
                model: this.collection.models[i]
            });
            container.appendChild(this[name].el);
        }

        this.$("#content-nextsteps-lessons").append(container);
    }

});

/**
 * View that wraps a topic on the content explore card on the home page
 */
window.ContentExploreTopicView = BaseView.extend({

    template: require("./hbtemplates/content-explore-topic.handlebars"),

    initialize: function() {
        this.render();
    },

    render: function() {
        this.$el.html(this.template(this.model.attributes));
    }

});

/**
 * View that wraps all the content explore cards on the home page
 */
window.ContentExploreView = BaseView.extend({

    template: require("./hbtemplates/content-explore.handlebars"),

    initialize: function() {
        _.bindAll(this, "render");
        if (typeof this.collection === "undefined") {
            this.collection = new models.SuggestedContentCollection([], {explore: true});
            this.listenTo(this.collection, "sync", this.render);
            this.collection.fetch();
        } else {
            this.render();
        }

    },

    render: function() {

        this.$el.html(this.template());
        var container = document.createDocumentFragment();

        for(i = 0; i < this.collection.length; i++) {
            var name = 'content_explore_topic_' + i;
            this[name] = this.add_subview(ContentExploreTopicView, {
                model: this.collection.models[i]
            });
            container.appendChild(this[name].el);
        }

        this.$("#content-explore-topics").append(container);
    }

});

module.exports = {
    HomepageWrapper: HomepageWrapper,
    ContentExploreView: ContentExploreView,
    ContentResumeView: ContentResumeView,
    ContentNextStepsView: ContentNextStepsView,
    ContentExploreTopicView: ContentExploreTopicView,
    ContentNextStepsLessonView: ContentNextStepsLessonView
};

},{"../../../css/distributed/content_recommendation.less":31,"../base/baseview":43,"./hbtemplates/content-explore-topic.handlebars":51,"./hbtemplates/content-explore.handlebars":52,"./hbtemplates/content-nextsteps-lesson.handlebars":53,"./hbtemplates/content-nextsteps.handlebars":54,"./hbtemplates/content-rec-wrapper.handlebars":55,"./hbtemplates/content-resume.handlebars":56,"./models":57,"underscore":582}],57:[function(require,module,exports){
var $ = require("../base/jQuery");
var Backbone = require("../base/backbone");


//Models

var SuggestedContentModel = Backbone.Model.extend({});


//Collections

var SuggestedContentCollection = Backbone.Collection.extend({
	initialize: function(models, options) {
		this.filters = $.extend({
			"user": window.statusModel.get("user_id")
		}, options);
	},

	url: function() {
		return window.Urls.content_recommender()+ "?" + $.param(this.filters, true);
	},

	model: SuggestedContentModel
});

module.exports = {
	SuggestedContentModel: SuggestedContentModel,
	SuggestedContentCollection: SuggestedContentCollection
};
},{"../base/backbone":42,"../base/jQuery":45}],56:[function(require,module,exports){
// hbsfy compiled Handlebars template
var HandlebarsCompiler = require('hbsfy/runtime');
module.exports = HandlebarsCompiler.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, options, helperMissing=helpers.helperMissing, escapeExpression=this.escapeExpression, functionType="function", self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n      <div class=\"row\">\n        <center>\n          <div class=\"col-xs-12\">\n            <h2 class=\"h4\">";
  if (helper = helpers.title) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.title); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</h2>\n          </div>\n        </center>\n      </div>\n      <div class=\"row\">\n        <div class=\"col-xs-12\">\n          <center>\n          <!--ALT for image gets read from 'description' so it doesn't need to be read twice-->\n            <img src=\""
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.content_urls)),stack1 == null || stack1 === false ? stack1 : stack1.thumbnail)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" class=\"img-responsive\"\n                 ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.description), {hash:{},inverse:self.program(4, program4, data),fn:self.program(2, program2, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += ">\n          </center>\n        </div>\n      </div>\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.description), {hash:{},inverse:self.noop,fn:self.program(6, program6, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += " \n      ";
  return buffer;
  }
function program2(depth0,data) {
  
  
  return "\n                     aria-hidden=\"true\" role=\"presentation\"\n                 ";
  }

function program4(depth0,data) {
  
  var buffer = "", helper, options;
  buffer += "\n                     alt=\""
    + escapeExpression((helper = helpers.truncate || (depth0 && depth0.truncate),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.description), 150, options) : helperMissing.call(depth0, "truncate", (depth0 && depth0.description), 150, options)))
    + "\"\n                 ";
  return buffer;
  }

function program6(depth0,data) {
  
  var buffer = "", helper, options;
  buffer += "\n        <div class=\"row\">\n          <div class=\"col-xs-12\">\n            <p class=\"h3\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "Description", options) : helperMissing.call(depth0, "_", "Description", options)))
    + ":</p>\n          </div>\n        </div>\n        <div class=\"row\">\n          <div class=\"col-xs-12\">\n            <p>"
    + escapeExpression((helper = helpers.truncate || (depth0 && depth0.truncate),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.description), 100, options) : helperMissing.call(depth0, "truncate", (depth0 && depth0.description), 100, options)))
    + "</p>\n          </div>\n        </div>\n        ";
  return buffer;
  }

function program8(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n      <div class=\"row\">\n        <div class=\"col-xs-3\">\n          <center>\n            <span aria-hidden=\"true\" role=\"presentation\"><i id=\"exercise-icon\" class=\"icon-";
  if (helper = helpers.kind) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.kind); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " glyphicon glyphicon-pencil gly-h1\"></i></span>\n          </center>\n        </div> \n        \n        <div class=\"col-xs-9\">\n          <h2 class=\"h4\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.kind), options) : helperMissing.call(depth0, "_", (depth0 && depth0.kind), options)))
    + ":<br />\n          ";
  if (helper = helpers.title) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.title); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</h2>\n        </div>\n        \n<!-- NO descriptions for excercise? Is it necessary?\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.description), {hash:{},inverse:self.noop,fn:self.program(9, program9, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n-->\n        \n      </div>\n      ";
  return buffer;
  }
function program9(depth0,data) {
  
  var buffer = "", helper, options;
  buffer += "\n          <div class=\"col-xs-12\">\n            <h3><small>Description:</small></h3>\n            <p>"
    + escapeExpression((helper = helpers.truncate || (depth0 && depth0.truncate),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.description), 100, options) : helperMissing.call(depth0, "truncate", (depth0 && depth0.description), 100, options)))
    + "</p>\n          </div>\n        ";
  return buffer;
  }

  buffer += "<div class=\"container card\">\n  <!--This is where the card title is-->\n  <div class=\"row card-title\">\n    <div class=\"col-xs-9\">\n      <h1>"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "Resume", options) : helperMissing.call(depth0, "_", "Resume", options)))
    + "</h1>\n    </div>\n    <div class=\"col-xs-3\">\n      <span aria-hidden=\"true\" role=\"presentation\"><i class=\"glyphicon glyphicon-play-circle gly-h1\"></i></span>\n    </div>\n    <hr class=\"module_divider\" />\n  </div>\n  <a href=\"/learn/";
  if (helper = helpers.path) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.path); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" class=\"content-resume-topic-link\">\n    <!--Where the video thumbnail and description go-->\n    <div id=\"content-resume-thumbnail\">\n      ";
  stack1 = helpers['if'].call(depth0, ((stack1 = (depth0 && depth0.content_urls)),stack1 == null || stack1 === false ? stack1 : stack1.thumbnail), {hash:{},inverse:self.program(8, program8, data),fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    </div>\n  </a>\n</div>\n";
  return buffer;
  });

},{"hbsfy/runtime":354}],55:[function(require,module,exports){
// hbsfy compiled Handlebars template
var HandlebarsCompiler = require('hbsfy/runtime');
module.exports = HandlebarsCompiler.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"container\" id=\"content-rec-wrapper\">\n    <div class=\"row\">\n        <div class=\"col-md-4\" id=\"resume\">\n        </div>\n        \n        <div class=\"col-md-4\" id=\"nextsteps\">\n        </div>\n        \n        <div class=\"col-md-4\" id=\"explore\">\n        </div>\n\n    </div>\n</div>";
  });

},{"hbsfy/runtime":354}],54:[function(require,module,exports){
// hbsfy compiled Handlebars template
var HandlebarsCompiler = require('hbsfy/runtime');
module.exports = HandlebarsCompiler.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", helper, options, helperMissing=helpers.helperMissing, escapeExpression=this.escapeExpression;


  buffer += "<div class=\"container card\">\n  <!--This is where the title to the card goes-->\n  <div class=\"row card-title\">\n      <div class=\"col-xs-9\">\n          <h1>"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "Next Steps", options) : helperMissing.call(depth0, "_", "Next Steps", options)))
    + "</h1>\n      </div>\n      <div class=\"col-xs-3\">\n          <span aria-hidden=\"true\" role=\"presentation\"><i class=\"glyphicon glyphicon-ok gly-h1\"></i></span>\n      </div>\n    <hr class=\"module_divider\"/>\n  </div>\n\n  <!--Where all the 'lessons' are being injected-->\n  <div id=\"content-nextsteps-lessons\">\n  </div>\n\n  <!-- See All commented out until we have functionality for it -->\n  <!--Link to all of the topics the student has started-->\n  <!-- <div class=\"row\">\n    <div class=\"col-xs-12\">\n      <h3><a href=\"\">See All...</a></h3>\n    </div>\n  </div> -->\n</div>\n";
  return buffer;
  });

},{"hbsfy/runtime":354}],53:[function(require,module,exports){
// hbsfy compiled Handlebars template
var HandlebarsCompiler = require('hbsfy/runtime');
module.exports = HandlebarsCompiler.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, options, helperMissing=helpers.helperMissing, escapeExpression=this.escapeExpression, functionType="function", self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n          <img src=\""
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.content_urls)),stack1 == null || stack1 === false ? stack1 : stack1.thumbnail)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" class=\"img-responsive\"\n              ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.description), {hash:{},inverse:self.program(4, program4, data),fn:self.program(2, program2, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += ">\n          ";
  return buffer;
  }
function program2(depth0,data) {
  
  
  return "\n                  aria-hidden=\"true\" role=\"presentation\"\n              ";
  }

function program4(depth0,data) {
  
  var buffer = "", helper, options;
  buffer += "\n                  alt=\""
    + escapeExpression((helper = helpers.truncate || (depth0 && depth0.truncate),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.description), 150, options) : helperMissing.call(depth0, "truncate", (depth0 && depth0.description), 150, options)))
    + "\"\n              ";
  return buffer;
  }

function program6(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n          <span aria-hidden=\"true\" role=\"presentation\"><i class=\"icon-";
  if (helper = helpers.kind) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.kind); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " glyphicon glyphicon-expand gly-h1\"></i></span>\n          ";
  return buffer;
  }

  buffer += "\n<div class=\"row\" class=\"content-nextsteps-lesson\">\n	<a href=\"/learn/";
  if (helper = helpers.path) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.path); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" class=\"content-nextsteps-lesson-link\">\n      <div class=\"col-xs-3\">\n        <center>\n        <!--ALT for image gets read from 'description' so it doesn't need to be read twice-->\n          ";
  stack1 = helpers['if'].call(depth0, ((stack1 = (depth0 && depth0.content_urls)),stack1 == null || stack1 === false ? stack1 : stack1.thumbnail), {hash:{},inverse:self.program(6, program6, data),fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        </center>\n      </div>\n\n      <div class=\"col-xs-6\">\n          <h2 class=\"h4\">\n            <span class=\"small\">"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.topic)),stack1 == null || stack1 === false ? stack1 : stack1.title)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + ":</span>\n            <br />\n            ";
  if (helper = helpers.title) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.title); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n          </h2>\n      </div>\n    </a>\n    <!--The URL without the specific video, so that we see the path\n    along the nav and show them the entire series-->\n    <a href=\"/learn/"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.topic)),stack1 == null || stack1 === false ? stack1 : stack1.path)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" class=\"content-nextsteps-topic-link\">\n      <div class=\"col-xs-3\">\n          <p class=\"h4\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "Topic", options) : helperMissing.call(depth0, "_", "Topic", options)))
    + ":</p>\n          <span aria-hidden=\"true\" role=\"presentation\"><i class=\"ns_series_arrow glyphicon glyphicon-arrow-right\"></i></span>\n          <!--Radina: Since glyph is invisible, adding 'sr-only' topic title-->\n          <span class=\"sr-only\">"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.topic)),stack1 == null || stack1 === false ? stack1 : stack1.title)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</span>\n      </div>\n    </a>\n<hr class=\"module_divider\">\n</div>\n";
  return buffer;
  });

},{"hbsfy/runtime":354}],52:[function(require,module,exports){
// hbsfy compiled Handlebars template
var HandlebarsCompiler = require('hbsfy/runtime');
module.exports = HandlebarsCompiler.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", helper, options, helperMissing=helpers.helperMissing, escapeExpression=this.escapeExpression;


  buffer += "<div class=\"container card\">\n  <!--This is where the card title is-->\n  <div class=\"row card-title\">\n      <div class=\"col-xs-9\">\n        <h1 class=\"card-title\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "Explore", options) : helperMissing.call(depth0, "_", "Explore", options)))
    + "</h1>\n      </div>\n      <div class=\"col-xs-3\">\n          <span aria-hidden=\"true\" role=\"presentation\"><i class=\"glyphicon glyphicon-road gly-h1\"></i></span>\n      </div>\n      <hr class=\"module_divider\"/>\n  </div>\n\n  <!--Card body-->\n  <div class=\"row\">\n    <div class=\"col-xs-12\">\n      <div id=\"content-explore-topics\"></div>\n    </div>\n  </div>\n\n</div>\n";
  return buffer;
  });

},{"hbsfy/runtime":354}],51:[function(require,module,exports){
// hbsfy compiled Handlebars template
var HandlebarsCompiler = require('hbsfy/runtime');
module.exports = HandlebarsCompiler.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, options, helperMissing=helpers.helperMissing, escapeExpression=this.escapeExpression, functionType="function", self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n      <div class=\"col-xs-7\">\n        <p class=\"h4\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "Description", options) : helperMissing.call(depth0, "_", "Description", options)))
    + ":</p>\n        <p aria-hidden=\"true\">"
    + escapeExpression((helper = helpers.truncate || (depth0 && depth0.truncate),options={hash:{},data:data},helper ? helper.call(depth0, ((stack1 = (depth0 && depth0.suggested_topic)),stack1 == null || stack1 === false ? stack1 : stack1.description), 70, options) : helperMissing.call(depth0, "truncate", ((stack1 = (depth0 && depth0.suggested_topic)),stack1 == null || stack1 === false ? stack1 : stack1.description), 70, options)))
    + "</p>\n        <span class=\"sr-only\">"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.suggested_topic)),stack1 == null || stack1 === false ? stack1 : stack1.description)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</span>\n      </div>\n      ";
  return buffer;
  }

  buffer += "<!--likely to be a link to the subject in the sidenav tree-->\n<a href=\"/learn/"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.suggested_topic)),stack1 == null || stack1 === false ? stack1 : stack1.path)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" class=\"content-explore-topic-link\">\n  <div class=\"content-explore-topic\">\n    <div class=\"row\">\n      <div class=\"col-xs-12\">\n          <p class=\"up10\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "Based on your interest in", options) : helperMissing.call(depth0, "_", "Based on your interest in", options)))
    + " <b>"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.interest_topic)),stack1 == null || stack1 === false ? stack1 : stack1.title)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</b><span class=\"sr-only\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, ", we recommend you", options) : helperMissing.call(depth0, "_", ", we recommend you", options)))
    + "</span>:</p>\n      </div>\n    </div>\n    <div class=\"row\">\n      <div class=\"col-xs-5\">\n          <h2 class=\"h3\">"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.suggested_topic)),stack1 == null || stack1 === false ? stack1 : stack1.title)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + ":</h2>\n      </div>\n      ";
  stack1 = helpers['if'].call(depth0, ((stack1 = (depth0 && depth0.suggested_topic)),stack1 == null || stack1 === false ? stack1 : stack1.description), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n      <hr class=\"module_divider\" />\n    </div>\n\n  </div>\n</a>\n";
  return buffer;
  });

},{"hbsfy/runtime":354}],33:[function(require,module,exports){
(function() { var head = document.getElementsByTagName('head')[0]; var style = document.createElement('style'); style.type = 'text/css';var css = ".suggested-action{background-color:#f7f7f7;color:#444 !important;display:block;margin-bottom:0;padding:14px;position:relative;float:left;margin-right:25px;min-height:221px}.suggested-actions{padding-top:124px}.suggested-action:hover{border-color:#c3ca7d;-webkit-box-shadow:0 0 6px 3px #5aa685;-moz-box-shadow:0 0 6px 3px #5aa685;box-shadow:0 0 6px 3px #5aa685}.suggested-action a:hover{text-decoration:none !important;color:#005987}#suggested-action-image-link-homepage{margin:auto}.suggested-action-title{color:#005987;text-decoration:none;font-size:21px}.suggested-action-big-button{border-top-right-radius:15px;border-top-left-radius:5px}.suggested-action-big-button h1{color:white;text-align:center}.message{margin-left:7px}.main-headline{font-size:26px;margin:10px 0 20px 0;padding:0}.topic-list{padding:7px 0 0 0;margin:0;font-size:24px;font-family:\"MuseoSans500\",sans-serif}.topic a{padding:0 0 8px 40px;font-size:18px;line-height:40px}a:hover,a:hover .suggested-action-title{color:#2f92a5 !important}.front-page{padding-left:7px}.float-center{display:table;margin-left:auto;margin-right:auto}.table{width:100%}.block{display:block}td div{text-align:center}#playlists .cell-content{color:#305884;margin-bottom:10px;height:60px}.pull-right{float:right}.pull-left{float:left}.playlist-list-item{font-size:15px;display:inline-block;width:20%;border:1px solid black;font-family:museosans500;height:100px;padding:10px;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box}.playlist-list-item:hover{background-color:#d5d5d5}.playlist-list-header{padding:10px;background-color:#8fc475;color:white}";if (style.styleSheet){ style.styleSheet.cssText = css; } else { style.appendChild(document.createTextNode(css)); } head.appendChild(style);}())
},{}],31:[function(require,module,exports){
(function() { var head = document.getElementsByTagName('head')[0]; var style = document.createElement('style'); style.type = 'text/css';var css = ".content-nextsteps-topic-link div{background-color:#5aa685;color:white}";if (style.styleSheet){ style.styleSheet.cssText = css; } else { style.appendChild(document.createTextNode(css)); } head.appendChild(style);}())
},{}]},{},["homepage"])
//# sourceMappingURL=data:application/json;charset:utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9mYWN0b3ItYnVuZGxlL25vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJrYWxpdGUvZGlzdHJpYnV0ZWQvc3RhdGljL2pzL2Rpc3RyaWJ1dGVkL2J1bmRsZV9tb2R1bGVzL2hvbWVwYWdlLmpzIiwia2FsaXRlL2Rpc3RyaWJ1dGVkL3N0YXRpYy9qcy9kaXN0cmlidXRlZC9jb250ZW50cmVjL3ZpZXdzLmpzIiwia2FsaXRlL2Rpc3RyaWJ1dGVkL3N0YXRpYy9qcy9kaXN0cmlidXRlZC9jb250ZW50cmVjL21vZGVscy5qcyIsImthbGl0ZS9kaXN0cmlidXRlZC9zdGF0aWMvanMvZGlzdHJpYnV0ZWQvY29udGVudHJlYy9oYnRlbXBsYXRlcy9jb250ZW50LXJlc3VtZS5oYW5kbGViYXJzIiwia2FsaXRlL2Rpc3RyaWJ1dGVkL3N0YXRpYy9qcy9kaXN0cmlidXRlZC9jb250ZW50cmVjL2hidGVtcGxhdGVzL2NvbnRlbnQtcmVjLXdyYXBwZXIuaGFuZGxlYmFycyIsImthbGl0ZS9kaXN0cmlidXRlZC9zdGF0aWMvanMvZGlzdHJpYnV0ZWQvY29udGVudHJlYy9oYnRlbXBsYXRlcy9jb250ZW50LW5leHRzdGVwcy5oYW5kbGViYXJzIiwia2FsaXRlL2Rpc3RyaWJ1dGVkL3N0YXRpYy9qcy9kaXN0cmlidXRlZC9jb250ZW50cmVjL2hidGVtcGxhdGVzL2NvbnRlbnQtbmV4dHN0ZXBzLWxlc3Nvbi5oYW5kbGViYXJzIiwia2FsaXRlL2Rpc3RyaWJ1dGVkL3N0YXRpYy9qcy9kaXN0cmlidXRlZC9jb250ZW50cmVjL2hidGVtcGxhdGVzL2NvbnRlbnQtZXhwbG9yZS5oYW5kbGViYXJzIiwia2FsaXRlL2Rpc3RyaWJ1dGVkL3N0YXRpYy9qcy9kaXN0cmlidXRlZC9jb250ZW50cmVjL2hidGVtcGxhdGVzL2NvbnRlbnQtZXhwbG9yZS10b3BpYy5oYW5kbGViYXJzIiwia2FsaXRlL2Rpc3RyaWJ1dGVkL3N0YXRpYy9jc3MvZGlzdHJpYnV0ZWQvaG9tZXBhZ2UubGVzcyIsImthbGl0ZS9kaXN0cmlidXRlZC9zdGF0aWMvY3NzL2Rpc3RyaWJ1dGVkL2NvbnRlbnRfcmVjb21tZW5kYXRpb24ubGVzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUMxQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN6TkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUM1QkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUMzRkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNWQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2xFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3BDQTs7QUNBQSIsImZpbGUiOiJnZW5lcmF0ZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsiKGZ1bmN0aW9uIGUodCxuLHIpe2Z1bmN0aW9uIHMobyx1KXtpZighbltvXSl7aWYoIXRbb10pe3ZhciBhPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7aWYoIXUmJmEpcmV0dXJuIGEobywhMCk7aWYoaSlyZXR1cm4gaShvLCEwKTt2YXIgZj1uZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBtb2R1bGUgJ1wiK28rXCInXCIpO3Rocm93IGYuY29kZT1cIk1PRFVMRV9OT1RfRk9VTkRcIixmfXZhciBsPW5bb109e2V4cG9ydHM6e319O3Rbb11bMF0uY2FsbChsLmV4cG9ydHMsZnVuY3Rpb24oZSl7dmFyIG49dFtvXVsxXVtlXTtyZXR1cm4gcyhuP246ZSl9LGwsbC5leHBvcnRzLGUsdCxuLHIpfXJldHVybiBuW29dLmV4cG9ydHN9dmFyIGk9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtmb3IodmFyIG89MDtvPHIubGVuZ3RoO28rKylzKHJbb10pO3JldHVybiBzfSkiLCJ2YXIgJCA9IHJlcXVpcmUoXCIuLi9iYXNlL2pRdWVyeVwiKTtcbnZhciBjb250ZW50X3JlY192aWV3cyA9IHJlcXVpcmUoXCIuLi9jb250ZW50cmVjL3ZpZXdzXCIpO1xudmFyIHVzZXIgPSByZXF1aXJlKFwiLi4vdXNlci92aWV3c1wiKTtcblxucmVxdWlyZShcIi4uLy4uLy4uL2Nzcy9kaXN0cmlidXRlZC9ob21lcGFnZS5sZXNzXCIpO1xuXG4kKGZ1bmN0aW9uKCkge1xuICAgIGlmIChkcy5kaXN0cmlidXRlZC5mcm9udF9wYWdlX3dlbGNvbWVfbWVzc2FnZSkge1xuICAgICAgICBzaG93X21lc3NhZ2UoXCJzdWNjZXNzXCIsIGRzLmRpc3RyaWJ1dGVkLmZyb250X3BhZ2Vfd2VsY29tZV9tZXNzYWdlKTtcbiAgICB9XG4gICAgdmFyIGNvbnRlbnRfcmVjX2xvYWQgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgaWYgKHdpbmRvdy5zdGF0dXNNb2RlbC5pc19zdHVkZW50KCkgJiYgIXdpbmRvdy5ocHdyYXBwZXIpIHtcbiAgICAgICAgICAgIHdpbmRvdy5ocHdyYXBwZXIgPSBuZXcgY29udGVudF9yZWNfdmlld3MuSG9tZXBhZ2VXcmFwcGVyKHtcbiAgICAgICAgICAgICAgICBlbDpcIiNjb250ZW50LWFyZWFcIlxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIHdpbmRvdy5zdGF0dXNNb2RlbC5saXN0ZW5Ubyh3aW5kb3cuc3RhdHVzTW9kZWwsIFwiY2hhbmdlXCIsIGNvbnRlbnRfcmVjX2xvYWQpO1xuXG4gICAgd2luZG93LnN0YXR1c01vZGVsLmxpc3RlblRvKHdpbmRvdy5zdGF0dXNNb2RlbCwgXCJjaGFuZ2U6aGFzX3N1cGVydXNlclwiLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgIGlmICghd2luZG93LnN0YXR1c01vZGVsLmdldChcImhhc19zdXBlcnVzZXJcIikpIHsgLy8gXCJoYXNfc3VwZXJ1c2VyXCIgaXMgdHJ1ZSBpZiBhbiBhZG1pbiB1c2VyIGV4aXN0cy5cbiAgICAgICAgICAgIHdpbmRvdy5zdXBlcl91c2VyX2NyZWF0ZV9tb2RhbCA9IG5ldyB1c2VyLlN1cGVyVXNlckNyZWF0ZU1vZGFsVmlldygpO1xuICAgICAgICB9IGVsc2UgaWYgKCB0eXBlb2Ygd2luZG93LnN1cGVyX3VzZXJfY3JlYXRlX21vZGFsICE9PSBcInVuZGVmaW5lZFwiICkge1xuICAgICAgICAgICAgd2luZG93LnN1cGVyX3VzZXJfY3JlYXRlX21vZGFsLnJlbW92ZSgpO1xuICAgICAgICB9XG4gICAgfSk7XG59KTsiLCIvLyBWaWV3c1xudmFyIF8gPSByZXF1aXJlKFwidW5kZXJzY29yZVwiKTtcbnZhciBtb2RlbHMgPSByZXF1aXJlKFwiLi9tb2RlbHNcIik7XG52YXIgQmFzZVZpZXcgPSByZXF1aXJlKFwiLi4vYmFzZS9iYXNldmlld1wiKTtcblxucmVxdWlyZShcIi4uLy4uLy4uL2Nzcy9kaXN0cmlidXRlZC9jb250ZW50X3JlY29tbWVuZGF0aW9uLmxlc3NcIik7XG5cbi8qQWxsIDMgY2FyZHMgZ28gaW50byB0aGlzIHdyYXBwZXIsIHdoaWNoIG1ha2VzIHRoZSBwYWdlIHJlc3BvbnNpdmUqL1xudmFyIEhvbWVwYWdlV3JhcHBlciA9IEJhc2VWaWV3LmV4dGVuZCh7XG5cbiAgICB0ZW1wbGF0ZTogcmVxdWlyZShcIi4vaGJ0ZW1wbGF0ZXMvY29udGVudC1yZWMtd3JhcHBlci5oYW5kbGViYXJzXCIpLFxuICAgIFxuICAgIGluaXRpYWxpemU6IGZ1bmN0aW9uKCkge1xuICAgICAgICBfLmJpbmRBbGwodGhpcywgXCJzZXRfY29sbGVjdGlvblwiLCBcImRhdGFfbG9hZFwiKTtcbiAgICAgICAgdGhpcy5zZXRfY29sbGVjdGlvbigpO1xuICAgICAgICB0aGlzLmxpc3RlblRvKHdpbmRvdy5zdGF0dXNNb2RlbCwgXCJjaGFuZ2U6dXNlcl9pZFwiLCB0aGlzLnNldF9jb2xsZWN0aW9uKTtcbiAgICB9LFxuXG4gICAgc2V0X2NvbGxlY3Rpb246IGZ1bmN0aW9uKCkge1xuICAgICAgICB0aGlzLmNvbGxlY3Rpb24gPSBuZXcgbW9kZWxzLlN1Z2dlc3RlZENvbnRlbnRDb2xsZWN0aW9uKFtdLCB7XG4gICAgICAgICAgICByZXN1bWU6IHRydWUsXG4gICAgICAgICAgICBuZXh0OiB0cnVlLFxuICAgICAgICAgICAgZXhwbG9yZTogdHJ1ZVxuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5saXN0ZW5Ubyh0aGlzLmNvbGxlY3Rpb24sIFwic3luY1wiLCB0aGlzLmRhdGFfbG9hZCk7XG4gICAgICAgIHRoaXMuY29sbGVjdGlvbi5mZXRjaCgpO1xuICAgIH0sXG5cbiAgICByZW5kZXI6IGZ1bmN0aW9uKCkge1xuICAgICAgICBpZiAodGhpcy5jb2xsZWN0aW9uLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIHRoaXMuJGVsLmh0bWwodGhpcy50ZW1wbGF0ZSgpKTtcblxuICAgICAgICAgICAgaWYgKHRoaXMuY29udGVudF9yZXN1bWUpIHtcbiAgICAgICAgICAgICAgICB0aGlzLiQoXCIjcmVzdW1lXCIpLmFwcGVuZCh0aGlzLmNvbnRlbnRfcmVzdW1lLmVsKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKHRoaXMuY29udGVudF9uZXh0c3RlcHMpIHtcbiAgICAgICAgICAgICAgICB0aGlzLiQoXCIjbmV4dHN0ZXBzXCIpLmFwcGVuZCh0aGlzLmNvbnRlbnRfbmV4dHN0ZXBzLmVsKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKHRoaXMuY29udGVudF9leHBsb3JlKSB7XG4gICAgICAgICAgICAgICAgdGhpcy4kKFwiI2V4cGxvcmVcIikuYXBwZW5kKHRoaXMuY29udGVudF9leHBsb3JlLmVsKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICBkYXRhX2xvYWQ6IGZ1bmN0aW9uKCkge1xuICAgICAgICB2YXIgcmVzdW1lQ29sbGVjdGlvbiA9IG5ldyBtb2RlbHMuU3VnZ2VzdGVkQ29udGVudENvbGxlY3Rpb24odGhpcy5jb2xsZWN0aW9uLndoZXJlKHtyZXN1bWU6dHJ1ZX0pKTtcbiAgICAgICAgXG4gICAgICAgIHZhciBuZXh0U3RlcHNDb2xsZWN0aW9uID0gbmV3IG1vZGVscy5TdWdnZXN0ZWRDb250ZW50Q29sbGVjdGlvbih0aGlzLmNvbGxlY3Rpb24ud2hlcmUoe25leHQ6dHJ1ZX0pKTtcbiAgICAgICAgXG4gICAgICAgIHZhciBleHBsb3JlQ29sbGVjdGlvbiA9IG5ldyBtb2RlbHMuU3VnZ2VzdGVkQ29udGVudENvbGxlY3Rpb24odGhpcy5jb2xsZWN0aW9uLndoZXJlKHtleHBsb3JlOnRydWV9KSk7XG4gICAgICAgIFxuICAgICAgICBpZiAocmVzdW1lQ29sbGVjdGlvbi5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICB0aGlzLmNvbnRlbnRfcmVzdW1lID0gbmV3IENvbnRlbnRSZXN1bWVWaWV3KHtcbiAgICAgICAgICAgICAgICBjb2xsZWN0aW9uOnJlc3VtZUNvbGxlY3Rpb25cbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKG5leHRTdGVwc0NvbGxlY3Rpb24ubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgdGhpcy5jb250ZW50X25leHRzdGVwcyA9IG5ldyBDb250ZW50TmV4dFN0ZXBzVmlldyh7XG4gICAgICAgICAgICAgICAgY29sbGVjdGlvbjpuZXh0U3RlcHNDb2xsZWN0aW9uXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChleHBsb3JlQ29sbGVjdGlvbi5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICB0aGlzLmNvbnRlbnRfZXhwbG9yZSA9IG5ldyBDb250ZW50RXhwbG9yZVZpZXcoe1xuICAgICAgICAgICAgICAgIGNvbGxlY3Rpb246ZXhwbG9yZUNvbGxlY3Rpb25cbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgICAgICAgICAgXG4gICAgICAgIHRoaXMucmVuZGVyKCk7XG4gICAgfVxufSk7XG5cbi8qKlxuICogVmlldyB0aGF0IHdyYXBzIHRoZSByZXN1bWUgY2FyZCBvbiB0aGUgaG9tZSBwYWdlXG4gKi9cbndpbmRvdy5Db250ZW50UmVzdW1lVmlldyA9IEJhc2VWaWV3LmV4dGVuZCh7XG5cbiAgICB0ZW1wbGF0ZTogcmVxdWlyZShcIi4vaGJ0ZW1wbGF0ZXMvY29udGVudC1yZXN1bWUuaGFuZGxlYmFyc1wiKSxcbiAgICBcbiAgICBpbml0aWFsaXplOiBmdW5jdGlvbigpIHtcbiAgICAgICAgXy5iaW5kQWxsKHRoaXMsIFwicmVuZGVyXCIpO1xuXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5jb2xsZWN0aW9uID09PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICAgICAgICB0aGlzLmNvbGxlY3Rpb24gPSBuZXcgbW9kZWxzLlN1Z2dlc3RlZENvbnRlbnRDb2xsZWN0aW9uKFtdLCB7cmVzdW1lOiB0cnVlfSk7XG4gICAgICAgICAgICB0aGlzLmxpc3RlblRvKHRoaXMuY29sbGVjdGlvbiwgXCJzeW5jXCIsIHRoaXMucmVuZGVyKTtcbiAgICAgICAgICAgIHRoaXMuY29sbGVjdGlvbi5mZXRjaCgpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5yZW5kZXIoKTtcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICByZW5kZXI6IGZ1bmN0aW9uKCkge1xuICAgICAgICB0aGlzLm1vZGVsID0gdGhpcy5jb2xsZWN0aW9uLmF0KDApO1xuICAgICAgICB0aGlzLiRlbC5odG1sKHRoaXMudGVtcGxhdGUodGhpcy5tb2RlbC5hdHRyaWJ1dGVzKSk7XG4gICAgfVxuXG59KTtcblxuLyoqXG4gKiBWaWV3IHRoYXQgd3JhcHMgYSBsZXNzb24gb24gdGhlIG5leHQgc3RlcHMgY2FyZCBvbiB0aGUgaG9tZSBwYWdlXG4gKi9cbndpbmRvdy5Db250ZW50TmV4dFN0ZXBzTGVzc29uVmlldyA9IEJhc2VWaWV3LmV4dGVuZCh7XG5cbiAgICB0ZW1wbGF0ZTogcmVxdWlyZShcIi4vaGJ0ZW1wbGF0ZXMvY29udGVudC1uZXh0c3RlcHMtbGVzc29uLmhhbmRsZWJhcnNcIiksXG5cbiAgICBpbml0aWFsaXplOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdGhpcy5yZW5kZXIoKTtcbiAgICB9LFxuXG4gICAgcmVuZGVyOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdGhpcy4kZWwuaHRtbCh0aGlzLnRlbXBsYXRlKHRoaXMubW9kZWwuYXR0cmlidXRlcykpO1xuICAgIH1cblxufSk7XG5cbi8qKlxuICogVmlldyB0aGF0IHdyYXBzIGFsbCB0aGUgbmV4dCBzdGVwcyBjYXJkcyBvbiB0aGUgaG9tZSBwYWdlXG4gKi9cbndpbmRvdy5Db250ZW50TmV4dFN0ZXBzVmlldyA9IEJhc2VWaWV3LmV4dGVuZCh7XG5cbiAgICB0ZW1wbGF0ZTogcmVxdWlyZShcIi4vaGJ0ZW1wbGF0ZXMvY29udGVudC1uZXh0c3RlcHMuaGFuZGxlYmFyc1wiKSxcbiAgICBcbiAgICBpbml0aWFsaXplOiBmdW5jdGlvbigpIHtcbiAgICAgICAgXy5iaW5kQWxsKHRoaXMsIFwicmVuZGVyXCIpO1xuICAgICAgICBcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbGxlY3Rpb24gPT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgICAgICAgIHRoaXMuY29sbGVjdGlvbiA9IG5ldyBtb2RlbHMuU3VnZ2VzdGVkQ29udGVudENvbGxlY3Rpb24oW10sIHtuZXh0OiB0cnVlfSk7XG4gICAgICAgICAgICB0aGlzLmxpc3RlblRvKHRoaXMuY29sbGVjdGlvbiwgXCJzeW5jXCIsIHRoaXMucmVuZGVyKTtcbiAgICAgICAgICAgIHRoaXMuY29sbGVjdGlvbi5mZXRjaCgpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5yZW5kZXIoKTtcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICByZW5kZXI6IGZ1bmN0aW9uKCkge1xuXG4gICAgICAgIHRoaXMuJGVsLmh0bWwodGhpcy50ZW1wbGF0ZSgpKTtcbiAgICAgICAgdmFyIGNvbnRhaW5lciA9IGRvY3VtZW50LmNyZWF0ZURvY3VtZW50RnJhZ21lbnQoKTtcblxuICAgICAgICBmb3IoaSA9IDA7IGkgPCB0aGlzLmNvbGxlY3Rpb24ubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIHZhciBuYW1lID0gJ2NvbnRlbnRfbmV4dHN0ZXBzX2xlc3Nvbl8nKyBpO1xuICAgICAgICAgICAgdGhpc1tuYW1lXSA9IHRoaXMuYWRkX3N1YnZpZXcoQ29udGVudE5leHRTdGVwc0xlc3NvblZpZXcsIHtcbiAgICAgICAgICAgICAgICBtb2RlbDogdGhpcy5jb2xsZWN0aW9uLm1vZGVsc1tpXVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBjb250YWluZXIuYXBwZW5kQ2hpbGQodGhpc1tuYW1lXS5lbCk7XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLiQoXCIjY29udGVudC1uZXh0c3RlcHMtbGVzc29uc1wiKS5hcHBlbmQoY29udGFpbmVyKTtcbiAgICB9XG5cbn0pO1xuXG4vKipcbiAqIFZpZXcgdGhhdCB3cmFwcyBhIHRvcGljIG9uIHRoZSBjb250ZW50IGV4cGxvcmUgY2FyZCBvbiB0aGUgaG9tZSBwYWdlXG4gKi9cbndpbmRvdy5Db250ZW50RXhwbG9yZVRvcGljVmlldyA9IEJhc2VWaWV3LmV4dGVuZCh7XG5cbiAgICB0ZW1wbGF0ZTogcmVxdWlyZShcIi4vaGJ0ZW1wbGF0ZXMvY29udGVudC1leHBsb3JlLXRvcGljLmhhbmRsZWJhcnNcIiksXG5cbiAgICBpbml0aWFsaXplOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdGhpcy5yZW5kZXIoKTtcbiAgICB9LFxuXG4gICAgcmVuZGVyOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdGhpcy4kZWwuaHRtbCh0aGlzLnRlbXBsYXRlKHRoaXMubW9kZWwuYXR0cmlidXRlcykpO1xuICAgIH1cblxufSk7XG5cbi8qKlxuICogVmlldyB0aGF0IHdyYXBzIGFsbCB0aGUgY29udGVudCBleHBsb3JlIGNhcmRzIG9uIHRoZSBob21lIHBhZ2VcbiAqL1xud2luZG93LkNvbnRlbnRFeHBsb3JlVmlldyA9IEJhc2VWaWV3LmV4dGVuZCh7XG5cbiAgICB0ZW1wbGF0ZTogcmVxdWlyZShcIi4vaGJ0ZW1wbGF0ZXMvY29udGVudC1leHBsb3JlLmhhbmRsZWJhcnNcIiksXG5cbiAgICBpbml0aWFsaXplOiBmdW5jdGlvbigpIHtcbiAgICAgICAgXy5iaW5kQWxsKHRoaXMsIFwicmVuZGVyXCIpO1xuICAgICAgICBpZiAodHlwZW9mIHRoaXMuY29sbGVjdGlvbiA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgICAgICAgdGhpcy5jb2xsZWN0aW9uID0gbmV3IG1vZGVscy5TdWdnZXN0ZWRDb250ZW50Q29sbGVjdGlvbihbXSwge2V4cGxvcmU6IHRydWV9KTtcbiAgICAgICAgICAgIHRoaXMubGlzdGVuVG8odGhpcy5jb2xsZWN0aW9uLCBcInN5bmNcIiwgdGhpcy5yZW5kZXIpO1xuICAgICAgICAgICAgdGhpcy5jb2xsZWN0aW9uLmZldGNoKCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLnJlbmRlcigpO1xuICAgICAgICB9XG5cbiAgICB9LFxuXG4gICAgcmVuZGVyOiBmdW5jdGlvbigpIHtcblxuICAgICAgICB0aGlzLiRlbC5odG1sKHRoaXMudGVtcGxhdGUoKSk7XG4gICAgICAgIHZhciBjb250YWluZXIgPSBkb2N1bWVudC5jcmVhdGVEb2N1bWVudEZyYWdtZW50KCk7XG5cbiAgICAgICAgZm9yKGkgPSAwOyBpIDwgdGhpcy5jb2xsZWN0aW9uLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICB2YXIgbmFtZSA9ICdjb250ZW50X2V4cGxvcmVfdG9waWNfJyArIGk7XG4gICAgICAgICAgICB0aGlzW25hbWVdID0gdGhpcy5hZGRfc3VidmlldyhDb250ZW50RXhwbG9yZVRvcGljVmlldywge1xuICAgICAgICAgICAgICAgIG1vZGVsOiB0aGlzLmNvbGxlY3Rpb24ubW9kZWxzW2ldXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGNvbnRhaW5lci5hcHBlbmRDaGlsZCh0aGlzW25hbWVdLmVsKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMuJChcIiNjb250ZW50LWV4cGxvcmUtdG9waWNzXCIpLmFwcGVuZChjb250YWluZXIpO1xuICAgIH1cblxufSk7XG5cbm1vZHVsZS5leHBvcnRzID0ge1xuICAgIEhvbWVwYWdlV3JhcHBlcjogSG9tZXBhZ2VXcmFwcGVyLFxuICAgIENvbnRlbnRFeHBsb3JlVmlldzogQ29udGVudEV4cGxvcmVWaWV3LFxuICAgIENvbnRlbnRSZXN1bWVWaWV3OiBDb250ZW50UmVzdW1lVmlldyxcbiAgICBDb250ZW50TmV4dFN0ZXBzVmlldzogQ29udGVudE5leHRTdGVwc1ZpZXcsXG4gICAgQ29udGVudEV4cGxvcmVUb3BpY1ZpZXc6IENvbnRlbnRFeHBsb3JlVG9waWNWaWV3LFxuICAgIENvbnRlbnROZXh0U3RlcHNMZXNzb25WaWV3OiBDb250ZW50TmV4dFN0ZXBzTGVzc29uVmlld1xufTtcbiIsInZhciAkID0gcmVxdWlyZShcIi4uL2Jhc2UvalF1ZXJ5XCIpO1xudmFyIEJhY2tib25lID0gcmVxdWlyZShcIi4uL2Jhc2UvYmFja2JvbmVcIik7XG5cblxuLy9Nb2RlbHNcblxudmFyIFN1Z2dlc3RlZENvbnRlbnRNb2RlbCA9IEJhY2tib25lLk1vZGVsLmV4dGVuZCh7fSk7XG5cblxuLy9Db2xsZWN0aW9uc1xuXG52YXIgU3VnZ2VzdGVkQ29udGVudENvbGxlY3Rpb24gPSBCYWNrYm9uZS5Db2xsZWN0aW9uLmV4dGVuZCh7XG5cdGluaXRpYWxpemU6IGZ1bmN0aW9uKG1vZGVscywgb3B0aW9ucykge1xuXHRcdHRoaXMuZmlsdGVycyA9ICQuZXh0ZW5kKHtcblx0XHRcdFwidXNlclwiOiB3aW5kb3cuc3RhdHVzTW9kZWwuZ2V0KFwidXNlcl9pZFwiKVxuXHRcdH0sIG9wdGlvbnMpO1xuXHR9LFxuXG5cdHVybDogZnVuY3Rpb24oKSB7XG5cdFx0cmV0dXJuIHdpbmRvdy5VcmxzLmNvbnRlbnRfcmVjb21tZW5kZXIoKSsgXCI/XCIgKyAkLnBhcmFtKHRoaXMuZmlsdGVycywgdHJ1ZSk7XG5cdH0sXG5cblx0bW9kZWw6IFN1Z2dlc3RlZENvbnRlbnRNb2RlbFxufSk7XG5cbm1vZHVsZS5leHBvcnRzID0ge1xuXHRTdWdnZXN0ZWRDb250ZW50TW9kZWw6IFN1Z2dlc3RlZENvbnRlbnRNb2RlbCxcblx0U3VnZ2VzdGVkQ29udGVudENvbGxlY3Rpb246IFN1Z2dlc3RlZENvbnRlbnRDb2xsZWN0aW9uXG59OyIsIi8vIGhic2Z5IGNvbXBpbGVkIEhhbmRsZWJhcnMgdGVtcGxhdGVcbnZhciBIYW5kbGViYXJzQ29tcGlsZXIgPSByZXF1aXJlKCdoYnNmeS9ydW50aW1lJyk7XG5tb2R1bGUuZXhwb3J0cyA9IEhhbmRsZWJhcnNDb21waWxlci50ZW1wbGF0ZShmdW5jdGlvbiAoSGFuZGxlYmFycyxkZXB0aDAsaGVscGVycyxwYXJ0aWFscyxkYXRhKSB7XG4gIHRoaXMuY29tcGlsZXJJbmZvID0gWzQsJz49IDEuMC4wJ107XG5oZWxwZXJzID0gdGhpcy5tZXJnZShoZWxwZXJzLCBIYW5kbGViYXJzLmhlbHBlcnMpOyBkYXRhID0gZGF0YSB8fCB7fTtcbiAgdmFyIGJ1ZmZlciA9IFwiXCIsIHN0YWNrMSwgaGVscGVyLCBvcHRpb25zLCBoZWxwZXJNaXNzaW5nPWhlbHBlcnMuaGVscGVyTWlzc2luZywgZXNjYXBlRXhwcmVzc2lvbj10aGlzLmVzY2FwZUV4cHJlc3Npb24sIGZ1bmN0aW9uVHlwZT1cImZ1bmN0aW9uXCIsIHNlbGY9dGhpcztcblxuZnVuY3Rpb24gcHJvZ3JhbTEoZGVwdGgwLGRhdGEpIHtcbiAgXG4gIHZhciBidWZmZXIgPSBcIlwiLCBzdGFjazEsIGhlbHBlcjtcbiAgYnVmZmVyICs9IFwiXFxuICAgICAgPGRpdiBjbGFzcz1cXFwicm93XFxcIj5cXG4gICAgICAgIDxjZW50ZXI+XFxuICAgICAgICAgIDxkaXYgY2xhc3M9XFxcImNvbC14cy0xMlxcXCI+XFxuICAgICAgICAgICAgPGgyIGNsYXNzPVxcXCJoNFxcXCI+XCI7XG4gIGlmIChoZWxwZXIgPSBoZWxwZXJzLnRpdGxlKSB7IHN0YWNrMSA9IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSk7IH1cbiAgZWxzZSB7IGhlbHBlciA9IChkZXB0aDAgJiYgZGVwdGgwLnRpdGxlKTsgc3RhY2sxID0gdHlwZW9mIGhlbHBlciA9PT0gZnVuY3Rpb25UeXBlID8gaGVscGVyLmNhbGwoZGVwdGgwLCB7aGFzaDp7fSxkYXRhOmRhdGF9KSA6IGhlbHBlcjsgfVxuICBidWZmZXIgKz0gZXNjYXBlRXhwcmVzc2lvbihzdGFjazEpXG4gICAgKyBcIjwvaDI+XFxuICAgICAgICAgIDwvZGl2PlxcbiAgICAgICAgPC9jZW50ZXI+XFxuICAgICAgPC9kaXY+XFxuICAgICAgPGRpdiBjbGFzcz1cXFwicm93XFxcIj5cXG4gICAgICAgIDxkaXYgY2xhc3M9XFxcImNvbC14cy0xMlxcXCI+XFxuICAgICAgICAgIDxjZW50ZXI+XFxuICAgICAgICAgIDwhLS1BTFQgZm9yIGltYWdlIGdldHMgcmVhZCBmcm9tICdkZXNjcmlwdGlvbicgc28gaXQgZG9lc24ndCBuZWVkIHRvIGJlIHJlYWQgdHdpY2UtLT5cXG4gICAgICAgICAgICA8aW1nIHNyYz1cXFwiXCJcbiAgICArIGVzY2FwZUV4cHJlc3Npb24oKChzdGFjazEgPSAoKHN0YWNrMSA9IChkZXB0aDAgJiYgZGVwdGgwLmNvbnRlbnRfdXJscykpLHN0YWNrMSA9PSBudWxsIHx8IHN0YWNrMSA9PT0gZmFsc2UgPyBzdGFjazEgOiBzdGFjazEudGh1bWJuYWlsKSksdHlwZW9mIHN0YWNrMSA9PT0gZnVuY3Rpb25UeXBlID8gc3RhY2sxLmFwcGx5KGRlcHRoMCkgOiBzdGFjazEpKVxuICAgICsgXCJcXFwiIGNsYXNzPVxcXCJpbWctcmVzcG9uc2l2ZVxcXCJcXG4gICAgICAgICAgICAgICAgIFwiO1xuICBzdGFjazEgPSBoZWxwZXJzWydpZiddLmNhbGwoZGVwdGgwLCAoZGVwdGgwICYmIGRlcHRoMC5kZXNjcmlwdGlvbiksIHtoYXNoOnt9LGludmVyc2U6c2VsZi5wcm9ncmFtKDQsIHByb2dyYW00LCBkYXRhKSxmbjpzZWxmLnByb2dyYW0oMiwgcHJvZ3JhbTIsIGRhdGEpLGRhdGE6ZGF0YX0pO1xuICBpZihzdGFjazEgfHwgc3RhY2sxID09PSAwKSB7IGJ1ZmZlciArPSBzdGFjazE7IH1cbiAgYnVmZmVyICs9IFwiPlxcbiAgICAgICAgICA8L2NlbnRlcj5cXG4gICAgICAgIDwvZGl2PlxcbiAgICAgIDwvZGl2PlxcbiAgICAgICAgXCI7XG4gIHN0YWNrMSA9IGhlbHBlcnNbJ2lmJ10uY2FsbChkZXB0aDAsIChkZXB0aDAgJiYgZGVwdGgwLmRlc2NyaXB0aW9uKSwge2hhc2g6e30saW52ZXJzZTpzZWxmLm5vb3AsZm46c2VsZi5wcm9ncmFtKDYsIHByb2dyYW02LCBkYXRhKSxkYXRhOmRhdGF9KTtcbiAgaWYoc3RhY2sxIHx8IHN0YWNrMSA9PT0gMCkgeyBidWZmZXIgKz0gc3RhY2sxOyB9XG4gIGJ1ZmZlciArPSBcIiBcXG4gICAgICBcIjtcbiAgcmV0dXJuIGJ1ZmZlcjtcbiAgfVxuZnVuY3Rpb24gcHJvZ3JhbTIoZGVwdGgwLGRhdGEpIHtcbiAgXG4gIFxuICByZXR1cm4gXCJcXG4gICAgICAgICAgICAgICAgICAgICBhcmlhLWhpZGRlbj1cXFwidHJ1ZVxcXCIgcm9sZT1cXFwicHJlc2VudGF0aW9uXFxcIlxcbiAgICAgICAgICAgICAgICAgXCI7XG4gIH1cblxuZnVuY3Rpb24gcHJvZ3JhbTQoZGVwdGgwLGRhdGEpIHtcbiAgXG4gIHZhciBidWZmZXIgPSBcIlwiLCBoZWxwZXIsIG9wdGlvbnM7XG4gIGJ1ZmZlciArPSBcIlxcbiAgICAgICAgICAgICAgICAgICAgIGFsdD1cXFwiXCJcbiAgICArIGVzY2FwZUV4cHJlc3Npb24oKGhlbHBlciA9IGhlbHBlcnMudHJ1bmNhdGUgfHwgKGRlcHRoMCAmJiBkZXB0aDAudHJ1bmNhdGUpLG9wdGlvbnM9e2hhc2g6e30sZGF0YTpkYXRhfSxoZWxwZXIgPyBoZWxwZXIuY2FsbChkZXB0aDAsIChkZXB0aDAgJiYgZGVwdGgwLmRlc2NyaXB0aW9uKSwgMTUwLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwidHJ1bmNhdGVcIiwgKGRlcHRoMCAmJiBkZXB0aDAuZGVzY3JpcHRpb24pLCAxNTAsIG9wdGlvbnMpKSlcbiAgICArIFwiXFxcIlxcbiAgICAgICAgICAgICAgICAgXCI7XG4gIHJldHVybiBidWZmZXI7XG4gIH1cblxuZnVuY3Rpb24gcHJvZ3JhbTYoZGVwdGgwLGRhdGEpIHtcbiAgXG4gIHZhciBidWZmZXIgPSBcIlwiLCBoZWxwZXIsIG9wdGlvbnM7XG4gIGJ1ZmZlciArPSBcIlxcbiAgICAgICAgPGRpdiBjbGFzcz1cXFwicm93XFxcIj5cXG4gICAgICAgICAgPGRpdiBjbGFzcz1cXFwiY29sLXhzLTEyXFxcIj5cXG4gICAgICAgICAgICA8cCBjbGFzcz1cXFwiaDNcXFwiPlwiXG4gICAgKyBlc2NhcGVFeHByZXNzaW9uKChoZWxwZXIgPSBoZWxwZXJzLl8gfHwgKGRlcHRoMCAmJiBkZXB0aDAuXyksb3B0aW9ucz17aGFzaDp7fSxkYXRhOmRhdGF9LGhlbHBlciA/IGhlbHBlci5jYWxsKGRlcHRoMCwgXCJEZXNjcmlwdGlvblwiLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwiX1wiLCBcIkRlc2NyaXB0aW9uXCIsIG9wdGlvbnMpKSlcbiAgICArIFwiOjwvcD5cXG4gICAgICAgICAgPC9kaXY+XFxuICAgICAgICA8L2Rpdj5cXG4gICAgICAgIDxkaXYgY2xhc3M9XFxcInJvd1xcXCI+XFxuICAgICAgICAgIDxkaXYgY2xhc3M9XFxcImNvbC14cy0xMlxcXCI+XFxuICAgICAgICAgICAgPHA+XCJcbiAgICArIGVzY2FwZUV4cHJlc3Npb24oKGhlbHBlciA9IGhlbHBlcnMudHJ1bmNhdGUgfHwgKGRlcHRoMCAmJiBkZXB0aDAudHJ1bmNhdGUpLG9wdGlvbnM9e2hhc2g6e30sZGF0YTpkYXRhfSxoZWxwZXIgPyBoZWxwZXIuY2FsbChkZXB0aDAsIChkZXB0aDAgJiYgZGVwdGgwLmRlc2NyaXB0aW9uKSwgMTAwLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwidHJ1bmNhdGVcIiwgKGRlcHRoMCAmJiBkZXB0aDAuZGVzY3JpcHRpb24pLCAxMDAsIG9wdGlvbnMpKSlcbiAgICArIFwiPC9wPlxcbiAgICAgICAgICA8L2Rpdj5cXG4gICAgICAgIDwvZGl2PlxcbiAgICAgICAgXCI7XG4gIHJldHVybiBidWZmZXI7XG4gIH1cblxuZnVuY3Rpb24gcHJvZ3JhbTgoZGVwdGgwLGRhdGEpIHtcbiAgXG4gIHZhciBidWZmZXIgPSBcIlwiLCBzdGFjazEsIGhlbHBlciwgb3B0aW9ucztcbiAgYnVmZmVyICs9IFwiXFxuICAgICAgPGRpdiBjbGFzcz1cXFwicm93XFxcIj5cXG4gICAgICAgIDxkaXYgY2xhc3M9XFxcImNvbC14cy0zXFxcIj5cXG4gICAgICAgICAgPGNlbnRlcj5cXG4gICAgICAgICAgICA8c3BhbiBhcmlhLWhpZGRlbj1cXFwidHJ1ZVxcXCIgcm9sZT1cXFwicHJlc2VudGF0aW9uXFxcIj48aSBpZD1cXFwiZXhlcmNpc2UtaWNvblxcXCIgY2xhc3M9XFxcImljb24tXCI7XG4gIGlmIChoZWxwZXIgPSBoZWxwZXJzLmtpbmQpIHsgc3RhY2sxID0gaGVscGVyLmNhbGwoZGVwdGgwLCB7aGFzaDp7fSxkYXRhOmRhdGF9KTsgfVxuICBlbHNlIHsgaGVscGVyID0gKGRlcHRoMCAmJiBkZXB0aDAua2luZCk7IHN0YWNrMSA9IHR5cGVvZiBoZWxwZXIgPT09IGZ1bmN0aW9uVHlwZSA/IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSkgOiBoZWxwZXI7IH1cbiAgYnVmZmVyICs9IGVzY2FwZUV4cHJlc3Npb24oc3RhY2sxKVxuICAgICsgXCIgZ2x5cGhpY29uIGdseXBoaWNvbi1wZW5jaWwgZ2x5LWgxXFxcIj48L2k+PC9zcGFuPlxcbiAgICAgICAgICA8L2NlbnRlcj5cXG4gICAgICAgIDwvZGl2PiBcXG4gICAgICAgIFxcbiAgICAgICAgPGRpdiBjbGFzcz1cXFwiY29sLXhzLTlcXFwiPlxcbiAgICAgICAgICA8aDIgY2xhc3M9XFxcImg0XFxcIj5cIlxuICAgICsgZXNjYXBlRXhwcmVzc2lvbigoaGVscGVyID0gaGVscGVycy5fIHx8IChkZXB0aDAgJiYgZGVwdGgwLl8pLG9wdGlvbnM9e2hhc2g6e30sZGF0YTpkYXRhfSxoZWxwZXIgPyBoZWxwZXIuY2FsbChkZXB0aDAsIChkZXB0aDAgJiYgZGVwdGgwLmtpbmQpLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwiX1wiLCAoZGVwdGgwICYmIGRlcHRoMC5raW5kKSwgb3B0aW9ucykpKVxuICAgICsgXCI6PGJyIC8+XFxuICAgICAgICAgIFwiO1xuICBpZiAoaGVscGVyID0gaGVscGVycy50aXRsZSkgeyBzdGFjazEgPSBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pOyB9XG4gIGVsc2UgeyBoZWxwZXIgPSAoZGVwdGgwICYmIGRlcHRoMC50aXRsZSk7IHN0YWNrMSA9IHR5cGVvZiBoZWxwZXIgPT09IGZ1bmN0aW9uVHlwZSA/IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSkgOiBoZWxwZXI7IH1cbiAgYnVmZmVyICs9IGVzY2FwZUV4cHJlc3Npb24oc3RhY2sxKVxuICAgICsgXCI8L2gyPlxcbiAgICAgICAgPC9kaXY+XFxuICAgICAgICBcXG48IS0tIE5PIGRlc2NyaXB0aW9ucyBmb3IgZXhjZXJjaXNlPyBJcyBpdCBuZWNlc3Nhcnk/XFxuICAgICAgICBcIjtcbiAgc3RhY2sxID0gaGVscGVyc1snaWYnXS5jYWxsKGRlcHRoMCwgKGRlcHRoMCAmJiBkZXB0aDAuZGVzY3JpcHRpb24pLCB7aGFzaDp7fSxpbnZlcnNlOnNlbGYubm9vcCxmbjpzZWxmLnByb2dyYW0oOSwgcHJvZ3JhbTksIGRhdGEpLGRhdGE6ZGF0YX0pO1xuICBpZihzdGFjazEgfHwgc3RhY2sxID09PSAwKSB7IGJ1ZmZlciArPSBzdGFjazE7IH1cbiAgYnVmZmVyICs9IFwiXFxuLS0+XFxuICAgICAgICBcXG4gICAgICA8L2Rpdj5cXG4gICAgICBcIjtcbiAgcmV0dXJuIGJ1ZmZlcjtcbiAgfVxuZnVuY3Rpb24gcHJvZ3JhbTkoZGVwdGgwLGRhdGEpIHtcbiAgXG4gIHZhciBidWZmZXIgPSBcIlwiLCBoZWxwZXIsIG9wdGlvbnM7XG4gIGJ1ZmZlciArPSBcIlxcbiAgICAgICAgICA8ZGl2IGNsYXNzPVxcXCJjb2wteHMtMTJcXFwiPlxcbiAgICAgICAgICAgIDxoMz48c21hbGw+RGVzY3JpcHRpb246PC9zbWFsbD48L2gzPlxcbiAgICAgICAgICAgIDxwPlwiXG4gICAgKyBlc2NhcGVFeHByZXNzaW9uKChoZWxwZXIgPSBoZWxwZXJzLnRydW5jYXRlIHx8IChkZXB0aDAgJiYgZGVwdGgwLnRydW5jYXRlKSxvcHRpb25zPXtoYXNoOnt9LGRhdGE6ZGF0YX0saGVscGVyID8gaGVscGVyLmNhbGwoZGVwdGgwLCAoZGVwdGgwICYmIGRlcHRoMC5kZXNjcmlwdGlvbiksIDEwMCwgb3B0aW9ucykgOiBoZWxwZXJNaXNzaW5nLmNhbGwoZGVwdGgwLCBcInRydW5jYXRlXCIsIChkZXB0aDAgJiYgZGVwdGgwLmRlc2NyaXB0aW9uKSwgMTAwLCBvcHRpb25zKSkpXG4gICAgKyBcIjwvcD5cXG4gICAgICAgICAgPC9kaXY+XFxuICAgICAgICBcIjtcbiAgcmV0dXJuIGJ1ZmZlcjtcbiAgfVxuXG4gIGJ1ZmZlciArPSBcIjxkaXYgY2xhc3M9XFxcImNvbnRhaW5lciBjYXJkXFxcIj5cXG4gIDwhLS1UaGlzIGlzIHdoZXJlIHRoZSBjYXJkIHRpdGxlIGlzLS0+XFxuICA8ZGl2IGNsYXNzPVxcXCJyb3cgY2FyZC10aXRsZVxcXCI+XFxuICAgIDxkaXYgY2xhc3M9XFxcImNvbC14cy05XFxcIj5cXG4gICAgICA8aDE+XCJcbiAgICArIGVzY2FwZUV4cHJlc3Npb24oKGhlbHBlciA9IGhlbHBlcnMuXyB8fCAoZGVwdGgwICYmIGRlcHRoMC5fKSxvcHRpb25zPXtoYXNoOnt9LGRhdGE6ZGF0YX0saGVscGVyID8gaGVscGVyLmNhbGwoZGVwdGgwLCBcIlJlc3VtZVwiLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwiX1wiLCBcIlJlc3VtZVwiLCBvcHRpb25zKSkpXG4gICAgKyBcIjwvaDE+XFxuICAgIDwvZGl2PlxcbiAgICA8ZGl2IGNsYXNzPVxcXCJjb2wteHMtM1xcXCI+XFxuICAgICAgPHNwYW4gYXJpYS1oaWRkZW49XFxcInRydWVcXFwiIHJvbGU9XFxcInByZXNlbnRhdGlvblxcXCI+PGkgY2xhc3M9XFxcImdseXBoaWNvbiBnbHlwaGljb24tcGxheS1jaXJjbGUgZ2x5LWgxXFxcIj48L2k+PC9zcGFuPlxcbiAgICA8L2Rpdj5cXG4gICAgPGhyIGNsYXNzPVxcXCJtb2R1bGVfZGl2aWRlclxcXCIgLz5cXG4gIDwvZGl2PlxcbiAgPGEgaHJlZj1cXFwiL2xlYXJuL1wiO1xuICBpZiAoaGVscGVyID0gaGVscGVycy5wYXRoKSB7IHN0YWNrMSA9IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSk7IH1cbiAgZWxzZSB7IGhlbHBlciA9IChkZXB0aDAgJiYgZGVwdGgwLnBhdGgpOyBzdGFjazEgPSB0eXBlb2YgaGVscGVyID09PSBmdW5jdGlvblR5cGUgPyBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pIDogaGVscGVyOyB9XG4gIGJ1ZmZlciArPSBlc2NhcGVFeHByZXNzaW9uKHN0YWNrMSlcbiAgICArIFwiXFxcIiBjbGFzcz1cXFwiY29udGVudC1yZXN1bWUtdG9waWMtbGlua1xcXCI+XFxuICAgIDwhLS1XaGVyZSB0aGUgdmlkZW8gdGh1bWJuYWlsIGFuZCBkZXNjcmlwdGlvbiBnby0tPlxcbiAgICA8ZGl2IGlkPVxcXCJjb250ZW50LXJlc3VtZS10aHVtYm5haWxcXFwiPlxcbiAgICAgIFwiO1xuICBzdGFjazEgPSBoZWxwZXJzWydpZiddLmNhbGwoZGVwdGgwLCAoKHN0YWNrMSA9IChkZXB0aDAgJiYgZGVwdGgwLmNvbnRlbnRfdXJscykpLHN0YWNrMSA9PSBudWxsIHx8IHN0YWNrMSA9PT0gZmFsc2UgPyBzdGFjazEgOiBzdGFjazEudGh1bWJuYWlsKSwge2hhc2g6e30saW52ZXJzZTpzZWxmLnByb2dyYW0oOCwgcHJvZ3JhbTgsIGRhdGEpLGZuOnNlbGYucHJvZ3JhbSgxLCBwcm9ncmFtMSwgZGF0YSksZGF0YTpkYXRhfSk7XG4gIGlmKHN0YWNrMSB8fCBzdGFjazEgPT09IDApIHsgYnVmZmVyICs9IHN0YWNrMTsgfVxuICBidWZmZXIgKz0gXCJcXG4gICAgPC9kaXY+XFxuICA8L2E+XFxuPC9kaXY+XFxuXCI7XG4gIHJldHVybiBidWZmZXI7XG4gIH0pO1xuIiwiLy8gaGJzZnkgY29tcGlsZWQgSGFuZGxlYmFycyB0ZW1wbGF0ZVxudmFyIEhhbmRsZWJhcnNDb21waWxlciA9IHJlcXVpcmUoJ2hic2Z5L3J1bnRpbWUnKTtcbm1vZHVsZS5leHBvcnRzID0gSGFuZGxlYmFyc0NvbXBpbGVyLnRlbXBsYXRlKGZ1bmN0aW9uIChIYW5kbGViYXJzLGRlcHRoMCxoZWxwZXJzLHBhcnRpYWxzLGRhdGEpIHtcbiAgdGhpcy5jb21waWxlckluZm8gPSBbNCwnPj0gMS4wLjAnXTtcbmhlbHBlcnMgPSB0aGlzLm1lcmdlKGhlbHBlcnMsIEhhbmRsZWJhcnMuaGVscGVycyk7IGRhdGEgPSBkYXRhIHx8IHt9O1xuICBcblxuXG4gIHJldHVybiBcIjxkaXYgY2xhc3M9XFxcImNvbnRhaW5lclxcXCIgaWQ9XFxcImNvbnRlbnQtcmVjLXdyYXBwZXJcXFwiPlxcbiAgICA8ZGl2IGNsYXNzPVxcXCJyb3dcXFwiPlxcbiAgICAgICAgPGRpdiBjbGFzcz1cXFwiY29sLW1kLTRcXFwiIGlkPVxcXCJyZXN1bWVcXFwiPlxcbiAgICAgICAgPC9kaXY+XFxuICAgICAgICBcXG4gICAgICAgIDxkaXYgY2xhc3M9XFxcImNvbC1tZC00XFxcIiBpZD1cXFwibmV4dHN0ZXBzXFxcIj5cXG4gICAgICAgIDwvZGl2PlxcbiAgICAgICAgXFxuICAgICAgICA8ZGl2IGNsYXNzPVxcXCJjb2wtbWQtNFxcXCIgaWQ9XFxcImV4cGxvcmVcXFwiPlxcbiAgICAgICAgPC9kaXY+XFxuXFxuICAgIDwvZGl2PlxcbjwvZGl2PlwiO1xuICB9KTtcbiIsIi8vIGhic2Z5IGNvbXBpbGVkIEhhbmRsZWJhcnMgdGVtcGxhdGVcbnZhciBIYW5kbGViYXJzQ29tcGlsZXIgPSByZXF1aXJlKCdoYnNmeS9ydW50aW1lJyk7XG5tb2R1bGUuZXhwb3J0cyA9IEhhbmRsZWJhcnNDb21waWxlci50ZW1wbGF0ZShmdW5jdGlvbiAoSGFuZGxlYmFycyxkZXB0aDAsaGVscGVycyxwYXJ0aWFscyxkYXRhKSB7XG4gIHRoaXMuY29tcGlsZXJJbmZvID0gWzQsJz49IDEuMC4wJ107XG5oZWxwZXJzID0gdGhpcy5tZXJnZShoZWxwZXJzLCBIYW5kbGViYXJzLmhlbHBlcnMpOyBkYXRhID0gZGF0YSB8fCB7fTtcbiAgdmFyIGJ1ZmZlciA9IFwiXCIsIGhlbHBlciwgb3B0aW9ucywgaGVscGVyTWlzc2luZz1oZWxwZXJzLmhlbHBlck1pc3NpbmcsIGVzY2FwZUV4cHJlc3Npb249dGhpcy5lc2NhcGVFeHByZXNzaW9uO1xuXG5cbiAgYnVmZmVyICs9IFwiPGRpdiBjbGFzcz1cXFwiY29udGFpbmVyIGNhcmRcXFwiPlxcbiAgPCEtLVRoaXMgaXMgd2hlcmUgdGhlIHRpdGxlIHRvIHRoZSBjYXJkIGdvZXMtLT5cXG4gIDxkaXYgY2xhc3M9XFxcInJvdyBjYXJkLXRpdGxlXFxcIj5cXG4gICAgICA8ZGl2IGNsYXNzPVxcXCJjb2wteHMtOVxcXCI+XFxuICAgICAgICAgIDxoMT5cIlxuICAgICsgZXNjYXBlRXhwcmVzc2lvbigoaGVscGVyID0gaGVscGVycy5fIHx8IChkZXB0aDAgJiYgZGVwdGgwLl8pLG9wdGlvbnM9e2hhc2g6e30sZGF0YTpkYXRhfSxoZWxwZXIgPyBoZWxwZXIuY2FsbChkZXB0aDAsIFwiTmV4dCBTdGVwc1wiLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwiX1wiLCBcIk5leHQgU3RlcHNcIiwgb3B0aW9ucykpKVxuICAgICsgXCI8L2gxPlxcbiAgICAgIDwvZGl2PlxcbiAgICAgIDxkaXYgY2xhc3M9XFxcImNvbC14cy0zXFxcIj5cXG4gICAgICAgICAgPHNwYW4gYXJpYS1oaWRkZW49XFxcInRydWVcXFwiIHJvbGU9XFxcInByZXNlbnRhdGlvblxcXCI+PGkgY2xhc3M9XFxcImdseXBoaWNvbiBnbHlwaGljb24tb2sgZ2x5LWgxXFxcIj48L2k+PC9zcGFuPlxcbiAgICAgIDwvZGl2PlxcbiAgICA8aHIgY2xhc3M9XFxcIm1vZHVsZV9kaXZpZGVyXFxcIi8+XFxuICA8L2Rpdj5cXG5cXG4gIDwhLS1XaGVyZSBhbGwgdGhlICdsZXNzb25zJyBhcmUgYmVpbmcgaW5qZWN0ZWQtLT5cXG4gIDxkaXYgaWQ9XFxcImNvbnRlbnQtbmV4dHN0ZXBzLWxlc3NvbnNcXFwiPlxcbiAgPC9kaXY+XFxuXFxuICA8IS0tIFNlZSBBbGwgY29tbWVudGVkIG91dCB1bnRpbCB3ZSBoYXZlIGZ1bmN0aW9uYWxpdHkgZm9yIGl0IC0tPlxcbiAgPCEtLUxpbmsgdG8gYWxsIG9mIHRoZSB0b3BpY3MgdGhlIHN0dWRlbnQgaGFzIHN0YXJ0ZWQtLT5cXG4gIDwhLS0gPGRpdiBjbGFzcz1cXFwicm93XFxcIj5cXG4gICAgPGRpdiBjbGFzcz1cXFwiY29sLXhzLTEyXFxcIj5cXG4gICAgICA8aDM+PGEgaHJlZj1cXFwiXFxcIj5TZWUgQWxsLi4uPC9hPjwvaDM+XFxuICAgIDwvZGl2PlxcbiAgPC9kaXY+IC0tPlxcbjwvZGl2PlxcblwiO1xuICByZXR1cm4gYnVmZmVyO1xuICB9KTtcbiIsIi8vIGhic2Z5IGNvbXBpbGVkIEhhbmRsZWJhcnMgdGVtcGxhdGVcbnZhciBIYW5kbGViYXJzQ29tcGlsZXIgPSByZXF1aXJlKCdoYnNmeS9ydW50aW1lJyk7XG5tb2R1bGUuZXhwb3J0cyA9IEhhbmRsZWJhcnNDb21waWxlci50ZW1wbGF0ZShmdW5jdGlvbiAoSGFuZGxlYmFycyxkZXB0aDAsaGVscGVycyxwYXJ0aWFscyxkYXRhKSB7XG4gIHRoaXMuY29tcGlsZXJJbmZvID0gWzQsJz49IDEuMC4wJ107XG5oZWxwZXJzID0gdGhpcy5tZXJnZShoZWxwZXJzLCBIYW5kbGViYXJzLmhlbHBlcnMpOyBkYXRhID0gZGF0YSB8fCB7fTtcbiAgdmFyIGJ1ZmZlciA9IFwiXCIsIHN0YWNrMSwgaGVscGVyLCBvcHRpb25zLCBoZWxwZXJNaXNzaW5nPWhlbHBlcnMuaGVscGVyTWlzc2luZywgZXNjYXBlRXhwcmVzc2lvbj10aGlzLmVzY2FwZUV4cHJlc3Npb24sIGZ1bmN0aW9uVHlwZT1cImZ1bmN0aW9uXCIsIHNlbGY9dGhpcztcblxuZnVuY3Rpb24gcHJvZ3JhbTEoZGVwdGgwLGRhdGEpIHtcbiAgXG4gIHZhciBidWZmZXIgPSBcIlwiLCBzdGFjazE7XG4gIGJ1ZmZlciArPSBcIlxcbiAgICAgICAgICA8aW1nIHNyYz1cXFwiXCJcbiAgICArIGVzY2FwZUV4cHJlc3Npb24oKChzdGFjazEgPSAoKHN0YWNrMSA9IChkZXB0aDAgJiYgZGVwdGgwLmNvbnRlbnRfdXJscykpLHN0YWNrMSA9PSBudWxsIHx8IHN0YWNrMSA9PT0gZmFsc2UgPyBzdGFjazEgOiBzdGFjazEudGh1bWJuYWlsKSksdHlwZW9mIHN0YWNrMSA9PT0gZnVuY3Rpb25UeXBlID8gc3RhY2sxLmFwcGx5KGRlcHRoMCkgOiBzdGFjazEpKVxuICAgICsgXCJcXFwiIGNsYXNzPVxcXCJpbWctcmVzcG9uc2l2ZVxcXCJcXG4gICAgICAgICAgICAgIFwiO1xuICBzdGFjazEgPSBoZWxwZXJzWydpZiddLmNhbGwoZGVwdGgwLCAoZGVwdGgwICYmIGRlcHRoMC5kZXNjcmlwdGlvbiksIHtoYXNoOnt9LGludmVyc2U6c2VsZi5wcm9ncmFtKDQsIHByb2dyYW00LCBkYXRhKSxmbjpzZWxmLnByb2dyYW0oMiwgcHJvZ3JhbTIsIGRhdGEpLGRhdGE6ZGF0YX0pO1xuICBpZihzdGFjazEgfHwgc3RhY2sxID09PSAwKSB7IGJ1ZmZlciArPSBzdGFjazE7IH1cbiAgYnVmZmVyICs9IFwiPlxcbiAgICAgICAgICBcIjtcbiAgcmV0dXJuIGJ1ZmZlcjtcbiAgfVxuZnVuY3Rpb24gcHJvZ3JhbTIoZGVwdGgwLGRhdGEpIHtcbiAgXG4gIFxuICByZXR1cm4gXCJcXG4gICAgICAgICAgICAgICAgICBhcmlhLWhpZGRlbj1cXFwidHJ1ZVxcXCIgcm9sZT1cXFwicHJlc2VudGF0aW9uXFxcIlxcbiAgICAgICAgICAgICAgXCI7XG4gIH1cblxuZnVuY3Rpb24gcHJvZ3JhbTQoZGVwdGgwLGRhdGEpIHtcbiAgXG4gIHZhciBidWZmZXIgPSBcIlwiLCBoZWxwZXIsIG9wdGlvbnM7XG4gIGJ1ZmZlciArPSBcIlxcbiAgICAgICAgICAgICAgICAgIGFsdD1cXFwiXCJcbiAgICArIGVzY2FwZUV4cHJlc3Npb24oKGhlbHBlciA9IGhlbHBlcnMudHJ1bmNhdGUgfHwgKGRlcHRoMCAmJiBkZXB0aDAudHJ1bmNhdGUpLG9wdGlvbnM9e2hhc2g6e30sZGF0YTpkYXRhfSxoZWxwZXIgPyBoZWxwZXIuY2FsbChkZXB0aDAsIChkZXB0aDAgJiYgZGVwdGgwLmRlc2NyaXB0aW9uKSwgMTUwLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwidHJ1bmNhdGVcIiwgKGRlcHRoMCAmJiBkZXB0aDAuZGVzY3JpcHRpb24pLCAxNTAsIG9wdGlvbnMpKSlcbiAgICArIFwiXFxcIlxcbiAgICAgICAgICAgICAgXCI7XG4gIHJldHVybiBidWZmZXI7XG4gIH1cblxuZnVuY3Rpb24gcHJvZ3JhbTYoZGVwdGgwLGRhdGEpIHtcbiAgXG4gIHZhciBidWZmZXIgPSBcIlwiLCBzdGFjazEsIGhlbHBlcjtcbiAgYnVmZmVyICs9IFwiXFxuICAgICAgICAgIDxzcGFuIGFyaWEtaGlkZGVuPVxcXCJ0cnVlXFxcIiByb2xlPVxcXCJwcmVzZW50YXRpb25cXFwiPjxpIGNsYXNzPVxcXCJpY29uLVwiO1xuICBpZiAoaGVscGVyID0gaGVscGVycy5raW5kKSB7IHN0YWNrMSA9IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSk7IH1cbiAgZWxzZSB7IGhlbHBlciA9IChkZXB0aDAgJiYgZGVwdGgwLmtpbmQpOyBzdGFjazEgPSB0eXBlb2YgaGVscGVyID09PSBmdW5jdGlvblR5cGUgPyBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pIDogaGVscGVyOyB9XG4gIGJ1ZmZlciArPSBlc2NhcGVFeHByZXNzaW9uKHN0YWNrMSlcbiAgICArIFwiIGdseXBoaWNvbiBnbHlwaGljb24tZXhwYW5kIGdseS1oMVxcXCI+PC9pPjwvc3Bhbj5cXG4gICAgICAgICAgXCI7XG4gIHJldHVybiBidWZmZXI7XG4gIH1cblxuICBidWZmZXIgKz0gXCJcXG48ZGl2IGNsYXNzPVxcXCJyb3dcXFwiIGNsYXNzPVxcXCJjb250ZW50LW5leHRzdGVwcy1sZXNzb25cXFwiPlxcblx0PGEgaHJlZj1cXFwiL2xlYXJuL1wiO1xuICBpZiAoaGVscGVyID0gaGVscGVycy5wYXRoKSB7IHN0YWNrMSA9IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSk7IH1cbiAgZWxzZSB7IGhlbHBlciA9IChkZXB0aDAgJiYgZGVwdGgwLnBhdGgpOyBzdGFjazEgPSB0eXBlb2YgaGVscGVyID09PSBmdW5jdGlvblR5cGUgPyBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pIDogaGVscGVyOyB9XG4gIGJ1ZmZlciArPSBlc2NhcGVFeHByZXNzaW9uKHN0YWNrMSlcbiAgICArIFwiXFxcIiBjbGFzcz1cXFwiY29udGVudC1uZXh0c3RlcHMtbGVzc29uLWxpbmtcXFwiPlxcbiAgICAgIDxkaXYgY2xhc3M9XFxcImNvbC14cy0zXFxcIj5cXG4gICAgICAgIDxjZW50ZXI+XFxuICAgICAgICA8IS0tQUxUIGZvciBpbWFnZSBnZXRzIHJlYWQgZnJvbSAnZGVzY3JpcHRpb24nIHNvIGl0IGRvZXNuJ3QgbmVlZCB0byBiZSByZWFkIHR3aWNlLS0+XFxuICAgICAgICAgIFwiO1xuICBzdGFjazEgPSBoZWxwZXJzWydpZiddLmNhbGwoZGVwdGgwLCAoKHN0YWNrMSA9IChkZXB0aDAgJiYgZGVwdGgwLmNvbnRlbnRfdXJscykpLHN0YWNrMSA9PSBudWxsIHx8IHN0YWNrMSA9PT0gZmFsc2UgPyBzdGFjazEgOiBzdGFjazEudGh1bWJuYWlsKSwge2hhc2g6e30saW52ZXJzZTpzZWxmLnByb2dyYW0oNiwgcHJvZ3JhbTYsIGRhdGEpLGZuOnNlbGYucHJvZ3JhbSgxLCBwcm9ncmFtMSwgZGF0YSksZGF0YTpkYXRhfSk7XG4gIGlmKHN0YWNrMSB8fCBzdGFjazEgPT09IDApIHsgYnVmZmVyICs9IHN0YWNrMTsgfVxuICBidWZmZXIgKz0gXCJcXG4gICAgICAgIDwvY2VudGVyPlxcbiAgICAgIDwvZGl2PlxcblxcbiAgICAgIDxkaXYgY2xhc3M9XFxcImNvbC14cy02XFxcIj5cXG4gICAgICAgICAgPGgyIGNsYXNzPVxcXCJoNFxcXCI+XFxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XFxcInNtYWxsXFxcIj5cIlxuICAgICsgZXNjYXBlRXhwcmVzc2lvbigoKHN0YWNrMSA9ICgoc3RhY2sxID0gKGRlcHRoMCAmJiBkZXB0aDAudG9waWMpKSxzdGFjazEgPT0gbnVsbCB8fCBzdGFjazEgPT09IGZhbHNlID8gc3RhY2sxIDogc3RhY2sxLnRpdGxlKSksdHlwZW9mIHN0YWNrMSA9PT0gZnVuY3Rpb25UeXBlID8gc3RhY2sxLmFwcGx5KGRlcHRoMCkgOiBzdGFjazEpKVxuICAgICsgXCI6PC9zcGFuPlxcbiAgICAgICAgICAgIDxiciAvPlxcbiAgICAgICAgICAgIFwiO1xuICBpZiAoaGVscGVyID0gaGVscGVycy50aXRsZSkgeyBzdGFjazEgPSBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pOyB9XG4gIGVsc2UgeyBoZWxwZXIgPSAoZGVwdGgwICYmIGRlcHRoMC50aXRsZSk7IHN0YWNrMSA9IHR5cGVvZiBoZWxwZXIgPT09IGZ1bmN0aW9uVHlwZSA/IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSkgOiBoZWxwZXI7IH1cbiAgYnVmZmVyICs9IGVzY2FwZUV4cHJlc3Npb24oc3RhY2sxKVxuICAgICsgXCJcXG4gICAgICAgICAgPC9oMj5cXG4gICAgICA8L2Rpdj5cXG4gICAgPC9hPlxcbiAgICA8IS0tVGhlIFVSTCB3aXRob3V0IHRoZSBzcGVjaWZpYyB2aWRlbywgc28gdGhhdCB3ZSBzZWUgdGhlIHBhdGhcXG4gICAgYWxvbmcgdGhlIG5hdiBhbmQgc2hvdyB0aGVtIHRoZSBlbnRpcmUgc2VyaWVzLS0+XFxuICAgIDxhIGhyZWY9XFxcIi9sZWFybi9cIlxuICAgICsgZXNjYXBlRXhwcmVzc2lvbigoKHN0YWNrMSA9ICgoc3RhY2sxID0gKGRlcHRoMCAmJiBkZXB0aDAudG9waWMpKSxzdGFjazEgPT0gbnVsbCB8fCBzdGFjazEgPT09IGZhbHNlID8gc3RhY2sxIDogc3RhY2sxLnBhdGgpKSx0eXBlb2Ygc3RhY2sxID09PSBmdW5jdGlvblR5cGUgPyBzdGFjazEuYXBwbHkoZGVwdGgwKSA6IHN0YWNrMSkpXG4gICAgKyBcIlxcXCIgY2xhc3M9XFxcImNvbnRlbnQtbmV4dHN0ZXBzLXRvcGljLWxpbmtcXFwiPlxcbiAgICAgIDxkaXYgY2xhc3M9XFxcImNvbC14cy0zXFxcIj5cXG4gICAgICAgICAgPHAgY2xhc3M9XFxcImg0XFxcIj5cIlxuICAgICsgZXNjYXBlRXhwcmVzc2lvbigoaGVscGVyID0gaGVscGVycy5fIHx8IChkZXB0aDAgJiYgZGVwdGgwLl8pLG9wdGlvbnM9e2hhc2g6e30sZGF0YTpkYXRhfSxoZWxwZXIgPyBoZWxwZXIuY2FsbChkZXB0aDAsIFwiVG9waWNcIiwgb3B0aW9ucykgOiBoZWxwZXJNaXNzaW5nLmNhbGwoZGVwdGgwLCBcIl9cIiwgXCJUb3BpY1wiLCBvcHRpb25zKSkpXG4gICAgKyBcIjo8L3A+XFxuICAgICAgICAgIDxzcGFuIGFyaWEtaGlkZGVuPVxcXCJ0cnVlXFxcIiByb2xlPVxcXCJwcmVzZW50YXRpb25cXFwiPjxpIGNsYXNzPVxcXCJuc19zZXJpZXNfYXJyb3cgZ2x5cGhpY29uIGdseXBoaWNvbi1hcnJvdy1yaWdodFxcXCI+PC9pPjwvc3Bhbj5cXG4gICAgICAgICAgPCEtLVJhZGluYTogU2luY2UgZ2x5cGggaXMgaW52aXNpYmxlLCBhZGRpbmcgJ3NyLW9ubHknIHRvcGljIHRpdGxlLS0+XFxuICAgICAgICAgIDxzcGFuIGNsYXNzPVxcXCJzci1vbmx5XFxcIj5cIlxuICAgICsgZXNjYXBlRXhwcmVzc2lvbigoKHN0YWNrMSA9ICgoc3RhY2sxID0gKGRlcHRoMCAmJiBkZXB0aDAudG9waWMpKSxzdGFjazEgPT0gbnVsbCB8fCBzdGFjazEgPT09IGZhbHNlID8gc3RhY2sxIDogc3RhY2sxLnRpdGxlKSksdHlwZW9mIHN0YWNrMSA9PT0gZnVuY3Rpb25UeXBlID8gc3RhY2sxLmFwcGx5KGRlcHRoMCkgOiBzdGFjazEpKVxuICAgICsgXCI8L3NwYW4+XFxuICAgICAgPC9kaXY+XFxuICAgIDwvYT5cXG48aHIgY2xhc3M9XFxcIm1vZHVsZV9kaXZpZGVyXFxcIj5cXG48L2Rpdj5cXG5cIjtcbiAgcmV0dXJuIGJ1ZmZlcjtcbiAgfSk7XG4iLCIvLyBoYnNmeSBjb21waWxlZCBIYW5kbGViYXJzIHRlbXBsYXRlXG52YXIgSGFuZGxlYmFyc0NvbXBpbGVyID0gcmVxdWlyZSgnaGJzZnkvcnVudGltZScpO1xubW9kdWxlLmV4cG9ydHMgPSBIYW5kbGViYXJzQ29tcGlsZXIudGVtcGxhdGUoZnVuY3Rpb24gKEhhbmRsZWJhcnMsZGVwdGgwLGhlbHBlcnMscGFydGlhbHMsZGF0YSkge1xuICB0aGlzLmNvbXBpbGVySW5mbyA9IFs0LCc+PSAxLjAuMCddO1xuaGVscGVycyA9IHRoaXMubWVyZ2UoaGVscGVycywgSGFuZGxlYmFycy5oZWxwZXJzKTsgZGF0YSA9IGRhdGEgfHwge307XG4gIHZhciBidWZmZXIgPSBcIlwiLCBoZWxwZXIsIG9wdGlvbnMsIGhlbHBlck1pc3Npbmc9aGVscGVycy5oZWxwZXJNaXNzaW5nLCBlc2NhcGVFeHByZXNzaW9uPXRoaXMuZXNjYXBlRXhwcmVzc2lvbjtcblxuXG4gIGJ1ZmZlciArPSBcIjxkaXYgY2xhc3M9XFxcImNvbnRhaW5lciBjYXJkXFxcIj5cXG4gIDwhLS1UaGlzIGlzIHdoZXJlIHRoZSBjYXJkIHRpdGxlIGlzLS0+XFxuICA8ZGl2IGNsYXNzPVxcXCJyb3cgY2FyZC10aXRsZVxcXCI+XFxuICAgICAgPGRpdiBjbGFzcz1cXFwiY29sLXhzLTlcXFwiPlxcbiAgICAgICAgPGgxIGNsYXNzPVxcXCJjYXJkLXRpdGxlXFxcIj5cIlxuICAgICsgZXNjYXBlRXhwcmVzc2lvbigoaGVscGVyID0gaGVscGVycy5fIHx8IChkZXB0aDAgJiYgZGVwdGgwLl8pLG9wdGlvbnM9e2hhc2g6e30sZGF0YTpkYXRhfSxoZWxwZXIgPyBoZWxwZXIuY2FsbChkZXB0aDAsIFwiRXhwbG9yZVwiLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwiX1wiLCBcIkV4cGxvcmVcIiwgb3B0aW9ucykpKVxuICAgICsgXCI8L2gxPlxcbiAgICAgIDwvZGl2PlxcbiAgICAgIDxkaXYgY2xhc3M9XFxcImNvbC14cy0zXFxcIj5cXG4gICAgICAgICAgPHNwYW4gYXJpYS1oaWRkZW49XFxcInRydWVcXFwiIHJvbGU9XFxcInByZXNlbnRhdGlvblxcXCI+PGkgY2xhc3M9XFxcImdseXBoaWNvbiBnbHlwaGljb24tcm9hZCBnbHktaDFcXFwiPjwvaT48L3NwYW4+XFxuICAgICAgPC9kaXY+XFxuICAgICAgPGhyIGNsYXNzPVxcXCJtb2R1bGVfZGl2aWRlclxcXCIvPlxcbiAgPC9kaXY+XFxuXFxuICA8IS0tQ2FyZCBib2R5LS0+XFxuICA8ZGl2IGNsYXNzPVxcXCJyb3dcXFwiPlxcbiAgICA8ZGl2IGNsYXNzPVxcXCJjb2wteHMtMTJcXFwiPlxcbiAgICAgIDxkaXYgaWQ9XFxcImNvbnRlbnQtZXhwbG9yZS10b3BpY3NcXFwiPjwvZGl2PlxcbiAgICA8L2Rpdj5cXG4gIDwvZGl2PlxcblxcbjwvZGl2PlxcblwiO1xuICByZXR1cm4gYnVmZmVyO1xuICB9KTtcbiIsIi8vIGhic2Z5IGNvbXBpbGVkIEhhbmRsZWJhcnMgdGVtcGxhdGVcbnZhciBIYW5kbGViYXJzQ29tcGlsZXIgPSByZXF1aXJlKCdoYnNmeS9ydW50aW1lJyk7XG5tb2R1bGUuZXhwb3J0cyA9IEhhbmRsZWJhcnNDb21waWxlci50ZW1wbGF0ZShmdW5jdGlvbiAoSGFuZGxlYmFycyxkZXB0aDAsaGVscGVycyxwYXJ0aWFscyxkYXRhKSB7XG4gIHRoaXMuY29tcGlsZXJJbmZvID0gWzQsJz49IDEuMC4wJ107XG5oZWxwZXJzID0gdGhpcy5tZXJnZShoZWxwZXJzLCBIYW5kbGViYXJzLmhlbHBlcnMpOyBkYXRhID0gZGF0YSB8fCB7fTtcbiAgdmFyIGJ1ZmZlciA9IFwiXCIsIHN0YWNrMSwgaGVscGVyLCBvcHRpb25zLCBoZWxwZXJNaXNzaW5nPWhlbHBlcnMuaGVscGVyTWlzc2luZywgZXNjYXBlRXhwcmVzc2lvbj10aGlzLmVzY2FwZUV4cHJlc3Npb24sIGZ1bmN0aW9uVHlwZT1cImZ1bmN0aW9uXCIsIHNlbGY9dGhpcztcblxuZnVuY3Rpb24gcHJvZ3JhbTEoZGVwdGgwLGRhdGEpIHtcbiAgXG4gIHZhciBidWZmZXIgPSBcIlwiLCBzdGFjazEsIGhlbHBlciwgb3B0aW9ucztcbiAgYnVmZmVyICs9IFwiXFxuICAgICAgPGRpdiBjbGFzcz1cXFwiY29sLXhzLTdcXFwiPlxcbiAgICAgICAgPHAgY2xhc3M9XFxcImg0XFxcIj5cIlxuICAgICsgZXNjYXBlRXhwcmVzc2lvbigoaGVscGVyID0gaGVscGVycy5fIHx8IChkZXB0aDAgJiYgZGVwdGgwLl8pLG9wdGlvbnM9e2hhc2g6e30sZGF0YTpkYXRhfSxoZWxwZXIgPyBoZWxwZXIuY2FsbChkZXB0aDAsIFwiRGVzY3JpcHRpb25cIiwgb3B0aW9ucykgOiBoZWxwZXJNaXNzaW5nLmNhbGwoZGVwdGgwLCBcIl9cIiwgXCJEZXNjcmlwdGlvblwiLCBvcHRpb25zKSkpXG4gICAgKyBcIjo8L3A+XFxuICAgICAgICA8cCBhcmlhLWhpZGRlbj1cXFwidHJ1ZVxcXCI+XCJcbiAgICArIGVzY2FwZUV4cHJlc3Npb24oKGhlbHBlciA9IGhlbHBlcnMudHJ1bmNhdGUgfHwgKGRlcHRoMCAmJiBkZXB0aDAudHJ1bmNhdGUpLG9wdGlvbnM9e2hhc2g6e30sZGF0YTpkYXRhfSxoZWxwZXIgPyBoZWxwZXIuY2FsbChkZXB0aDAsICgoc3RhY2sxID0gKGRlcHRoMCAmJiBkZXB0aDAuc3VnZ2VzdGVkX3RvcGljKSksc3RhY2sxID09IG51bGwgfHwgc3RhY2sxID09PSBmYWxzZSA/IHN0YWNrMSA6IHN0YWNrMS5kZXNjcmlwdGlvbiksIDcwLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwidHJ1bmNhdGVcIiwgKChzdGFjazEgPSAoZGVwdGgwICYmIGRlcHRoMC5zdWdnZXN0ZWRfdG9waWMpKSxzdGFjazEgPT0gbnVsbCB8fCBzdGFjazEgPT09IGZhbHNlID8gc3RhY2sxIDogc3RhY2sxLmRlc2NyaXB0aW9uKSwgNzAsIG9wdGlvbnMpKSlcbiAgICArIFwiPC9wPlxcbiAgICAgICAgPHNwYW4gY2xhc3M9XFxcInNyLW9ubHlcXFwiPlwiXG4gICAgKyBlc2NhcGVFeHByZXNzaW9uKCgoc3RhY2sxID0gKChzdGFjazEgPSAoZGVwdGgwICYmIGRlcHRoMC5zdWdnZXN0ZWRfdG9waWMpKSxzdGFjazEgPT0gbnVsbCB8fCBzdGFjazEgPT09IGZhbHNlID8gc3RhY2sxIDogc3RhY2sxLmRlc2NyaXB0aW9uKSksdHlwZW9mIHN0YWNrMSA9PT0gZnVuY3Rpb25UeXBlID8gc3RhY2sxLmFwcGx5KGRlcHRoMCkgOiBzdGFjazEpKVxuICAgICsgXCI8L3NwYW4+XFxuICAgICAgPC9kaXY+XFxuICAgICAgXCI7XG4gIHJldHVybiBidWZmZXI7XG4gIH1cblxuICBidWZmZXIgKz0gXCI8IS0tbGlrZWx5IHRvIGJlIGEgbGluayB0byB0aGUgc3ViamVjdCBpbiB0aGUgc2lkZW5hdiB0cmVlLS0+XFxuPGEgaHJlZj1cXFwiL2xlYXJuL1wiXG4gICAgKyBlc2NhcGVFeHByZXNzaW9uKCgoc3RhY2sxID0gKChzdGFjazEgPSAoZGVwdGgwICYmIGRlcHRoMC5zdWdnZXN0ZWRfdG9waWMpKSxzdGFjazEgPT0gbnVsbCB8fCBzdGFjazEgPT09IGZhbHNlID8gc3RhY2sxIDogc3RhY2sxLnBhdGgpKSx0eXBlb2Ygc3RhY2sxID09PSBmdW5jdGlvblR5cGUgPyBzdGFjazEuYXBwbHkoZGVwdGgwKSA6IHN0YWNrMSkpXG4gICAgKyBcIlxcXCIgY2xhc3M9XFxcImNvbnRlbnQtZXhwbG9yZS10b3BpYy1saW5rXFxcIj5cXG4gIDxkaXYgY2xhc3M9XFxcImNvbnRlbnQtZXhwbG9yZS10b3BpY1xcXCI+XFxuICAgIDxkaXYgY2xhc3M9XFxcInJvd1xcXCI+XFxuICAgICAgPGRpdiBjbGFzcz1cXFwiY29sLXhzLTEyXFxcIj5cXG4gICAgICAgICAgPHAgY2xhc3M9XFxcInVwMTBcXFwiPlwiXG4gICAgKyBlc2NhcGVFeHByZXNzaW9uKChoZWxwZXIgPSBoZWxwZXJzLl8gfHwgKGRlcHRoMCAmJiBkZXB0aDAuXyksb3B0aW9ucz17aGFzaDp7fSxkYXRhOmRhdGF9LGhlbHBlciA/IGhlbHBlci5jYWxsKGRlcHRoMCwgXCJCYXNlZCBvbiB5b3VyIGludGVyZXN0IGluXCIsIG9wdGlvbnMpIDogaGVscGVyTWlzc2luZy5jYWxsKGRlcHRoMCwgXCJfXCIsIFwiQmFzZWQgb24geW91ciBpbnRlcmVzdCBpblwiLCBvcHRpb25zKSkpXG4gICAgKyBcIiA8Yj5cIlxuICAgICsgZXNjYXBlRXhwcmVzc2lvbigoKHN0YWNrMSA9ICgoc3RhY2sxID0gKGRlcHRoMCAmJiBkZXB0aDAuaW50ZXJlc3RfdG9waWMpKSxzdGFjazEgPT0gbnVsbCB8fCBzdGFjazEgPT09IGZhbHNlID8gc3RhY2sxIDogc3RhY2sxLnRpdGxlKSksdHlwZW9mIHN0YWNrMSA9PT0gZnVuY3Rpb25UeXBlID8gc3RhY2sxLmFwcGx5KGRlcHRoMCkgOiBzdGFjazEpKVxuICAgICsgXCI8L2I+PHNwYW4gY2xhc3M9XFxcInNyLW9ubHlcXFwiPlwiXG4gICAgKyBlc2NhcGVFeHByZXNzaW9uKChoZWxwZXIgPSBoZWxwZXJzLl8gfHwgKGRlcHRoMCAmJiBkZXB0aDAuXyksb3B0aW9ucz17aGFzaDp7fSxkYXRhOmRhdGF9LGhlbHBlciA/IGhlbHBlci5jYWxsKGRlcHRoMCwgXCIsIHdlIHJlY29tbWVuZCB5b3VcIiwgb3B0aW9ucykgOiBoZWxwZXJNaXNzaW5nLmNhbGwoZGVwdGgwLCBcIl9cIiwgXCIsIHdlIHJlY29tbWVuZCB5b3VcIiwgb3B0aW9ucykpKVxuICAgICsgXCI8L3NwYW4+OjwvcD5cXG4gICAgICA8L2Rpdj5cXG4gICAgPC9kaXY+XFxuICAgIDxkaXYgY2xhc3M9XFxcInJvd1xcXCI+XFxuICAgICAgPGRpdiBjbGFzcz1cXFwiY29sLXhzLTVcXFwiPlxcbiAgICAgICAgICA8aDIgY2xhc3M9XFxcImgzXFxcIj5cIlxuICAgICsgZXNjYXBlRXhwcmVzc2lvbigoKHN0YWNrMSA9ICgoc3RhY2sxID0gKGRlcHRoMCAmJiBkZXB0aDAuc3VnZ2VzdGVkX3RvcGljKSksc3RhY2sxID09IG51bGwgfHwgc3RhY2sxID09PSBmYWxzZSA/IHN0YWNrMSA6IHN0YWNrMS50aXRsZSkpLHR5cGVvZiBzdGFjazEgPT09IGZ1bmN0aW9uVHlwZSA/IHN0YWNrMS5hcHBseShkZXB0aDApIDogc3RhY2sxKSlcbiAgICArIFwiOjwvaDI+XFxuICAgICAgPC9kaXY+XFxuICAgICAgXCI7XG4gIHN0YWNrMSA9IGhlbHBlcnNbJ2lmJ10uY2FsbChkZXB0aDAsICgoc3RhY2sxID0gKGRlcHRoMCAmJiBkZXB0aDAuc3VnZ2VzdGVkX3RvcGljKSksc3RhY2sxID09IG51bGwgfHwgc3RhY2sxID09PSBmYWxzZSA/IHN0YWNrMSA6IHN0YWNrMS5kZXNjcmlwdGlvbiksIHtoYXNoOnt9LGludmVyc2U6c2VsZi5ub29wLGZuOnNlbGYucHJvZ3JhbSgxLCBwcm9ncmFtMSwgZGF0YSksZGF0YTpkYXRhfSk7XG4gIGlmKHN0YWNrMSB8fCBzdGFjazEgPT09IDApIHsgYnVmZmVyICs9IHN0YWNrMTsgfVxuICBidWZmZXIgKz0gXCJcXG4gICAgICA8aHIgY2xhc3M9XFxcIm1vZHVsZV9kaXZpZGVyXFxcIiAvPlxcbiAgICA8L2Rpdj5cXG5cXG4gIDwvZGl2PlxcbjwvYT5cXG5cIjtcbiAgcmV0dXJuIGJ1ZmZlcjtcbiAgfSk7XG4iLCIoZnVuY3Rpb24oKSB7IHZhciBoZWFkID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeVRhZ05hbWUoJ2hlYWQnKVswXTsgdmFyIHN0eWxlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3R5bGUnKTsgc3R5bGUudHlwZSA9ICd0ZXh0L2Nzcyc7dmFyIGNzcyA9IFwiLnN1Z2dlc3RlZC1hY3Rpb257YmFja2dyb3VuZC1jb2xvcjojZjdmN2Y3O2NvbG9yOiM0NDQgIWltcG9ydGFudDtkaXNwbGF5OmJsb2NrO21hcmdpbi1ib3R0b206MDtwYWRkaW5nOjE0cHg7cG9zaXRpb246cmVsYXRpdmU7ZmxvYXQ6bGVmdDttYXJnaW4tcmlnaHQ6MjVweDttaW4taGVpZ2h0OjIyMXB4fS5zdWdnZXN0ZWQtYWN0aW9uc3twYWRkaW5nLXRvcDoxMjRweH0uc3VnZ2VzdGVkLWFjdGlvbjpob3Zlcntib3JkZXItY29sb3I6I2MzY2E3ZDstd2Via2l0LWJveC1zaGFkb3c6MCAwIDZweCAzcHggIzVhYTY4NTstbW96LWJveC1zaGFkb3c6MCAwIDZweCAzcHggIzVhYTY4NTtib3gtc2hhZG93OjAgMCA2cHggM3B4ICM1YWE2ODV9LnN1Z2dlc3RlZC1hY3Rpb24gYTpob3Zlcnt0ZXh0LWRlY29yYXRpb246bm9uZSAhaW1wb3J0YW50O2NvbG9yOiMwMDU5ODd9I3N1Z2dlc3RlZC1hY3Rpb24taW1hZ2UtbGluay1ob21lcGFnZXttYXJnaW46YXV0b30uc3VnZ2VzdGVkLWFjdGlvbi10aXRsZXtjb2xvcjojMDA1OTg3O3RleHQtZGVjb3JhdGlvbjpub25lO2ZvbnQtc2l6ZToyMXB4fS5zdWdnZXN0ZWQtYWN0aW9uLWJpZy1idXR0b257Ym9yZGVyLXRvcC1yaWdodC1yYWRpdXM6MTVweDtib3JkZXItdG9wLWxlZnQtcmFkaXVzOjVweH0uc3VnZ2VzdGVkLWFjdGlvbi1iaWctYnV0dG9uIGgxe2NvbG9yOndoaXRlO3RleHQtYWxpZ246Y2VudGVyfS5tZXNzYWdle21hcmdpbi1sZWZ0OjdweH0ubWFpbi1oZWFkbGluZXtmb250LXNpemU6MjZweDttYXJnaW46MTBweCAwIDIwcHggMDtwYWRkaW5nOjB9LnRvcGljLWxpc3R7cGFkZGluZzo3cHggMCAwIDA7bWFyZ2luOjA7Zm9udC1zaXplOjI0cHg7Zm9udC1mYW1pbHk6XFxcIk11c2VvU2FuczUwMFxcXCIsc2Fucy1zZXJpZn0udG9waWMgYXtwYWRkaW5nOjAgMCA4cHggNDBweDtmb250LXNpemU6MThweDtsaW5lLWhlaWdodDo0MHB4fWE6aG92ZXIsYTpob3ZlciAuc3VnZ2VzdGVkLWFjdGlvbi10aXRsZXtjb2xvcjojMmY5MmE1ICFpbXBvcnRhbnR9LmZyb250LXBhZ2V7cGFkZGluZy1sZWZ0OjdweH0uZmxvYXQtY2VudGVye2Rpc3BsYXk6dGFibGU7bWFyZ2luLWxlZnQ6YXV0bzttYXJnaW4tcmlnaHQ6YXV0b30udGFibGV7d2lkdGg6MTAwJX0uYmxvY2t7ZGlzcGxheTpibG9ja310ZCBkaXZ7dGV4dC1hbGlnbjpjZW50ZXJ9I3BsYXlsaXN0cyAuY2VsbC1jb250ZW50e2NvbG9yOiMzMDU4ODQ7bWFyZ2luLWJvdHRvbToxMHB4O2hlaWdodDo2MHB4fS5wdWxsLXJpZ2h0e2Zsb2F0OnJpZ2h0fS5wdWxsLWxlZnR7ZmxvYXQ6bGVmdH0ucGxheWxpc3QtbGlzdC1pdGVte2ZvbnQtc2l6ZToxNXB4O2Rpc3BsYXk6aW5saW5lLWJsb2NrO3dpZHRoOjIwJTtib3JkZXI6MXB4IHNvbGlkIGJsYWNrO2ZvbnQtZmFtaWx5Om11c2Vvc2FuczUwMDtoZWlnaHQ6MTAwcHg7cGFkZGluZzoxMHB4O2JveC1zaXppbmc6Ym9yZGVyLWJveDstbW96LWJveC1zaXppbmc6Ym9yZGVyLWJveDstd2Via2l0LWJveC1zaXppbmc6Ym9yZGVyLWJveH0ucGxheWxpc3QtbGlzdC1pdGVtOmhvdmVye2JhY2tncm91bmQtY29sb3I6I2Q1ZDVkNX0ucGxheWxpc3QtbGlzdC1oZWFkZXJ7cGFkZGluZzoxMHB4O2JhY2tncm91bmQtY29sb3I6IzhmYzQ3NTtjb2xvcjp3aGl0ZX1cIjtpZiAoc3R5bGUuc3R5bGVTaGVldCl7IHN0eWxlLnN0eWxlU2hlZXQuY3NzVGV4dCA9IGNzczsgfSBlbHNlIHsgc3R5bGUuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlVGV4dE5vZGUoY3NzKSk7IH0gaGVhZC5hcHBlbmRDaGlsZChzdHlsZSk7fSgpKSIsIihmdW5jdGlvbigpIHsgdmFyIGhlYWQgPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5VGFnTmFtZSgnaGVhZCcpWzBdOyB2YXIgc3R5bGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzdHlsZScpOyBzdHlsZS50eXBlID0gJ3RleHQvY3NzJzt2YXIgY3NzID0gXCIuY29udGVudC1uZXh0c3RlcHMtdG9waWMtbGluayBkaXZ7YmFja2dyb3VuZC1jb2xvcjojNWFhNjg1O2NvbG9yOndoaXRlfVwiO2lmIChzdHlsZS5zdHlsZVNoZWV0KXsgc3R5bGUuc3R5bGVTaGVldC5jc3NUZXh0ID0gY3NzOyB9IGVsc2UgeyBzdHlsZS5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVUZXh0Tm9kZShjc3MpKTsgfSBoZWFkLmFwcGVuZENoaWxkKHN0eWxlKTt9KCkpIl19
