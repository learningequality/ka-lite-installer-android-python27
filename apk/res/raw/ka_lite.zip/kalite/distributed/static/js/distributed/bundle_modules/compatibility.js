window.JSON = require("JSON2");
require("html5shiv");
require("ie8");
window.console = window.console || {log: function() {}};