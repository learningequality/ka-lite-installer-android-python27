// This file exists to add qtip into the global namespace, for automatic screenshots.
var $ = require("base/jQuery");
require("qtip2");