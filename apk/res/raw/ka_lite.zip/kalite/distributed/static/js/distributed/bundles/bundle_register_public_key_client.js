require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"register_public_key_client":[function(require,module,exports){
var $ = require("../base/jQuery");
var messages = require("../utils/messages");
var api = require("../utils/api");

function reload() {
    window.location.reload();
}

function auto_register() {
    // Disable and show message
    $("#one-click-register").toggleClass("disabled", true);
    messages.show_message("info", gettext("Contacting central server to register; page will reload upon success."));

    // window.auto_registration_url is defined by a template context variable.
    api.doRequest(window.auto_registration_url, null, {dataType: "jsonp"})
        .success(function() {
            messages.show_message("success", "Auto-registered.");
            window.location.reload();
        })
        .fail(function(a, b) {
            // Re-enable
            $("#one-click-register").toggleClass("disabled", false);
        });
}

$(function() {
    $(".refresh-link").click(reload);
    $("#one-click-register").click(auto_register);
});

},{"../base/jQuery":45,"../utils/api":124,"../utils/messages":128}]},{},["register_public_key_client"])
//# sourceMappingURL=data:application/json;charset:utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9mYWN0b3ItYnVuZGxlL25vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJrYWxpdGUvZGlzdHJpYnV0ZWQvc3RhdGljL2pzL2Rpc3RyaWJ1dGVkL2J1bmRsZV9tb2R1bGVzL3JlZ2lzdGVyX3B1YmxpY19rZXlfY2xpZW50LmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwiZmlsZSI6ImdlbmVyYXRlZC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzQ29udGVudCI6WyIoZnVuY3Rpb24gZSh0LG4scil7ZnVuY3Rpb24gcyhvLHUpe2lmKCFuW29dKXtpZighdFtvXSl7dmFyIGE9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtpZighdSYmYSlyZXR1cm4gYShvLCEwKTtpZihpKXJldHVybiBpKG8sITApO3ZhciBmPW5ldyBFcnJvcihcIkNhbm5vdCBmaW5kIG1vZHVsZSAnXCIrbytcIidcIik7dGhyb3cgZi5jb2RlPVwiTU9EVUxFX05PVF9GT1VORFwiLGZ9dmFyIGw9bltvXT17ZXhwb3J0czp7fX07dFtvXVswXS5jYWxsKGwuZXhwb3J0cyxmdW5jdGlvbihlKXt2YXIgbj10W29dWzFdW2VdO3JldHVybiBzKG4/bjplKX0sbCxsLmV4cG9ydHMsZSx0LG4scil9cmV0dXJuIG5bb10uZXhwb3J0c312YXIgaT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2Zvcih2YXIgbz0wO288ci5sZW5ndGg7bysrKXMocltvXSk7cmV0dXJuIHN9KSIsInZhciAkID0gcmVxdWlyZShcIi4uL2Jhc2UvalF1ZXJ5XCIpO1xyXG52YXIgbWVzc2FnZXMgPSByZXF1aXJlKFwiLi4vdXRpbHMvbWVzc2FnZXNcIik7XHJcbnZhciBhcGkgPSByZXF1aXJlKFwiLi4vdXRpbHMvYXBpXCIpO1xyXG5cclxuZnVuY3Rpb24gcmVsb2FkKCkge1xyXG4gICAgd2luZG93LmxvY2F0aW9uLnJlbG9hZCgpO1xyXG59XHJcblxyXG5mdW5jdGlvbiBhdXRvX3JlZ2lzdGVyKCkge1xyXG4gICAgLy8gRGlzYWJsZSBhbmQgc2hvdyBtZXNzYWdlXHJcbiAgICAkKFwiI29uZS1jbGljay1yZWdpc3RlclwiKS50b2dnbGVDbGFzcyhcImRpc2FibGVkXCIsIHRydWUpO1xyXG4gICAgbWVzc2FnZXMuc2hvd19tZXNzYWdlKFwiaW5mb1wiLCBnZXR0ZXh0KFwiQ29udGFjdGluZyBjZW50cmFsIHNlcnZlciB0byByZWdpc3RlcjsgcGFnZSB3aWxsIHJlbG9hZCB1cG9uIHN1Y2Nlc3MuXCIpKTtcclxuXHJcbiAgICAvLyB3aW5kb3cuYXV0b19yZWdpc3RyYXRpb25fdXJsIGlzIGRlZmluZWQgYnkgYSB0ZW1wbGF0ZSBjb250ZXh0IHZhcmlhYmxlLlxyXG4gICAgYXBpLmRvUmVxdWVzdCh3aW5kb3cuYXV0b19yZWdpc3RyYXRpb25fdXJsLCBudWxsLCB7ZGF0YVR5cGU6IFwianNvbnBcIn0pXHJcbiAgICAgICAgLnN1Y2Nlc3MoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgIG1lc3NhZ2VzLnNob3dfbWVzc2FnZShcInN1Y2Nlc3NcIiwgXCJBdXRvLXJlZ2lzdGVyZWQuXCIpO1xyXG4gICAgICAgICAgICB3aW5kb3cubG9jYXRpb24ucmVsb2FkKCk7XHJcbiAgICAgICAgfSlcclxuICAgICAgICAuZmFpbChmdW5jdGlvbihhLCBiKSB7XHJcbiAgICAgICAgICAgIC8vIFJlLWVuYWJsZVxyXG4gICAgICAgICAgICAkKFwiI29uZS1jbGljay1yZWdpc3RlclwiKS50b2dnbGVDbGFzcyhcImRpc2FibGVkXCIsIGZhbHNlKTtcclxuICAgICAgICB9KTtcclxufVxyXG5cclxuJChmdW5jdGlvbigpIHtcclxuICAgICQoXCIucmVmcmVzaC1saW5rXCIpLmNsaWNrKHJlbG9hZCk7XHJcbiAgICAkKFwiI29uZS1jbGljay1yZWdpc3RlclwiKS5jbGljayhhdXRvX3JlZ2lzdGVyKTtcclxufSk7XHJcbiJdfQ==
