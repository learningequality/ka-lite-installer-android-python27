var $ = require("base/jQuery");
var StudentProgressContainerView = require("../student_progress/views").StudentProgressContainerView;

global.$ = $;
global.StudentProgressContainerView = StudentProgressContainerView;