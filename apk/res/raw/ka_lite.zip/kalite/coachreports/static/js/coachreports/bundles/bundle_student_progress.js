require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"student_progress":[function(require,module,exports){
(function (global){
var $ = require("base/jQuery");
var StudentProgressContainerView = require("../student_progress/views").StudentProgressContainerView;

global.$ = $;
global.StudentProgressContainerView = StudentProgressContainerView;
}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{"../student_progress/views":14,"base/jQuery":45}],14:[function(require,module,exports){
var Backbone = require("base/backbone");
var Handlebars = require("base/handlebars");

var Models = require("./models");


var PlaylistProgressDetailView = Backbone.View.extend({

    template: require('./hbtemplates/playlist-progress-details.handlebars'),

    initialize: function() {
        this.listenTo(this.collection, 'sync', this.render);
    },

    render: function() {
        this.$el.html(this.template({
            data: this.collection.models
        }));

        return this;
    }
});

var PlaylistProgressView = Backbone.View.extend({

    template: require('./hbtemplates/playlist-progress-container.handlebars'),

    events: {
        "click .toggle-details": "toggle_details"
    },

    initialize: function(options) {
        this.details_fetched = false;

        this.detailed_view = new PlaylistProgressDetailView({
            collection: new Models.PlaylistProgressDetailCollection([], {
                playlist_id: this.model.attributes.id,
                user_id: options.user_id
            })
        });

        this.listenTo(this.detailed_view.collection, "sync", this.render_details);
    },

    render: function() {
        this.$el.html(this.template(this.model.toJSON()));
        return this;
    },

    render_details: function() {
        this.$(".playlist-progress-details").html(this.detailed_view.render().el).show();

        // opt in bootstrap tooltip functionality
        this.$('.progress-indicator-sm').popover({
            trigger: 'click hover',
            animation: false
        });
    },

    toggle_details: function() {
        // Fetch data if we don't have it yet
        var self = this;
        if (!this.details_fetched) {
            this.detailed_view.collection.fetch({
                success: function() {
                    self.details_fetched = true;
                }
            });
        }

        // Show or hide details
        this.$(".expand-collapse").toggleClass("glyphicon-chevron-down glyphicon-chevron-up");
        this.$(".playlist-progress-details").slideToggle();
    }
});

var StudentProgressContainerView = Backbone.View.extend({
    // The containing view
    template: require('./hbtemplates/student-progress-container.handlebars'),

    initialize: function(options) {
        this.user_id = options.user_id;

        this.collection =  new Models.PlaylistProgressCollection([], {user_id: this.user_id});

        this.listenTo(this.collection, 'add', this.add_one);
        
        var self = this;

        this.render();

        this.collection.fetch({
            success: function() {
                 if (self.collection.length === 0) {       //if the student visits the my progress page before attempting any quizes/videos
                              if (window.statusModel.is_student()) {
                                  show_message("info", gettext("Click on the LEARN button above to get started on your learning journey."));
                              }
                              self.$el.html("");             //this is done to remove the 'Progress Report' header
                      }
                   }
               });
    },

    render: function() {
        // Only render container once
        this.$el.html(this.template());
    },

    add_one: function(playlist) {
        var view  = new PlaylistProgressView({
            model: playlist,
            user_id: this.user_id
        });
        this.$("#playlists-container").append(view.render().el);
    }
});

module.exports = {
    StudentProgressContainerView: StudentProgressContainerView,
    PlaylistProgressView: PlaylistProgressView,
    PlaylistProgressDetailView: PlaylistProgressDetailView
};

},{"./hbtemplates/playlist-progress-container.handlebars":10,"./hbtemplates/playlist-progress-details.handlebars":11,"./hbtemplates/student-progress-container.handlebars":12,"./models":13,"base/backbone":42,"base/handlebars":44}],13:[function(require,module,exports){
var Backbone = require("base/backbone");
var sprintf = require("sprintf-js").sprintf;

var PlaylistProgressModel = Backbone.Model.extend();

var PlaylistProgressDetailModel = Backbone.Model.extend();

// Collections
var PlaylistProgressCollection = Backbone.Collection.extend({
    model: PlaylistProgressModel,

    initialize: function(model, options) {
        this.user_id = options.user_id;
    },

    url: function() {
        return sprintf("%(playlist_url)s?user_id=%(user_id)s", {"playlist_url": PLAYLIST_PROGRESS_URL, "user_id": this.user_id});
    }
});

var PlaylistProgressDetailCollection = Backbone.Collection.extend({
    model: PlaylistProgressDetailModel,

    initialize: function(models, options) {
        this.playlist_id = options.playlist_id;
        this.user_id = options.user_id;
    },

    url: function() {
        var base = sprintf("%(playlist_url)s?user_id=%(user_id)s&playlist_id=", {"playlist_url": PLAYLIST_PROGRESS_DETAIL_URL, "user_id": this.user_id});
        return base + this.playlist_id;
    }
});

module.exports = {
    PlaylistProgressModel: PlaylistProgressModel,
    PlaylistProgressDetailModel: PlaylistProgressDetailModel,
    PlaylistProgressCollection: PlaylistProgressCollection,
    PlaylistProgressDetailCollection: PlaylistProgressDetailCollection
};
},{"base/backbone":42,"sprintf-js":581}],12:[function(require,module,exports){
// hbsfy compiled Handlebars template
var HandlebarsCompiler = require('hbsfy/runtime');
module.exports = HandlebarsCompiler.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", helper, options, helperMissing=helpers.helperMissing, escapeExpression=this.escapeExpression;


  buffer += "<h1 class=\"h2\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "Progress report", options) : helperMissing.call(depth0, "_", "Progress report", options)))
    + "</h1>\n<div id=\"playlists-container\"></div>\n";
  return buffer;
  });

},{"hbsfy/runtime":354}],11:[function(require,module,exports){
// hbsfy compiled Handlebars template
var HandlebarsCompiler = require('hbsfy/runtime');
module.exports = HandlebarsCompiler.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var stack1, helperMissing=helpers.helperMissing, escapeExpression=this.escapeExpression, functionType="function", self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n    \n<div class=\"sr-only\">\n        <a href=\"/learn/"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.path)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\"><h3>"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.title)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</h3></a>\n        <div>\n            "
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, " Status: ", options) : helperMissing.call(depth0, "_", " Status: ", options)))
    + "\n            ";
  stack1 = (helper = helpers.ifcond || (depth0 && depth0.ifcond),options={hash:{},inverse:self.noop,fn:self.program(2, program2, data),data:data},helper ? helper.call(depth0, ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.status), "===", "complete", options) : helperMissing.call(depth0, "ifcond", ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.status), "===", "complete", options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n            ";
  stack1 = (helper = helpers.ifcond || (depth0 && depth0.ifcond),options={hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data},helper ? helper.call(depth0, ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.status), "===", "inprogress", options) : helperMissing.call(depth0, "ifcond", ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.status), "===", "inprogress", options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n            ";
  stack1 = (helper = helpers.ifcond || (depth0 && depth0.ifcond),options={hash:{},inverse:self.noop,fn:self.program(6, program6, data),data:data},helper ? helper.call(depth0, ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.status), "===", "struggling", options) : helperMissing.call(depth0, "ifcond", ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.status), "===", "struggling", options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            \n            ";
  stack1 = (helper = helpers.ifcond || (depth0 && depth0.ifcond),options={hash:{},inverse:self.noop,fn:self.program(8, program8, data),data:data},helper ? helper.call(depth0, ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.status), "===", "notstarted", options) : helperMissing.call(depth0, "ifcond", ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.status), "===", "notstarted", options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "                \n        </div>\n        <div>\n            \n            \n            ";
  stack1 = (helper = helpers.ifcond || (depth0 && depth0.ifcond),options={hash:{},inverse:self.noop,fn:self.program(10, program10, data),data:data},helper ? helper.call(depth0, ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.kind), "===", "Video", options) : helperMissing.call(depth0, "ifcond", ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.kind), "===", "Video", options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n            \n            ";
  stack1 = (helper = helpers.ifcond || (depth0 && depth0.ifcond),options={hash:{},inverse:self.noop,fn:self.program(12, program12, data),data:data},helper ? helper.call(depth0, ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.kind), "===", "Exercise", options) : helperMissing.call(depth0, "ifcond", ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.kind), "===", "Exercise", options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n            \n            ";
  stack1 = (helper = helpers.ifcond || (depth0 && depth0.ifcond),options={hash:{},inverse:self.noop,fn:self.program(14, program14, data),data:data},helper ? helper.call(depth0, ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.kind), "===", "Quiz", options) : helperMissing.call(depth0, "ifcond", ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.kind), "===", "Quiz", options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        </div>\n</div>\n\n<div class=\"col-sm-1 progress-block\" aria-hidden=\"true\" role=\"presentation\">\n    <a href=\"/learn/"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.path)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\">\n    <div \n        class=\"progress-indicator progress-indicator-sm "
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.status)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\"\n        data-toggle=\"popover\" data-placement=\"top\" \n        \n        \n        ";
  stack1 = (helper = helpers.ifcond || (depth0 && depth0.ifcond),options={hash:{},inverse:self.noop,fn:self.program(16, program16, data),data:data},helper ? helper.call(depth0, ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.kind), "===", "Video", options) : helperMissing.call(depth0, "ifcond", ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.kind), "===", "Video", options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n        \n        ";
  stack1 = (helper = helpers.ifcond || (depth0 && depth0.ifcond),options={hash:{},inverse:self.noop,fn:self.program(18, program18, data),data:data},helper ? helper.call(depth0, ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.kind), "===", "Exercise", options) : helperMissing.call(depth0, "ifcond", ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.kind), "===", "Exercise", options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n        \n        ";
  stack1 = (helper = helpers.ifcond || (depth0 && depth0.ifcond),options={hash:{},inverse:self.noop,fn:self.program(20, program20, data),data:data},helper ? helper.call(depth0, ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.kind), "===", "Quiz", options) : helperMissing.call(depth0, "ifcond", ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.kind), "===", "Quiz", options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    > \n        <div class=\"sidebar-icon icon-"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.kind)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + " icon-label icon-label-sm\"></div>\n    </div>\n    <span class=\"progress-item-title\">"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.title)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</span></a>\n</div>\n";
  return buffer;
  }
function program2(depth0,data) {
  
  var buffer = "", helper, options;
  buffer += "\n                "
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, " Completed. ", options) : helperMissing.call(depth0, "_", " Completed. ", options)))
    + "\n            ";
  return buffer;
  }

function program4(depth0,data) {
  
  var buffer = "", helper, options;
  buffer += "\n                "
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, " In progress. ", options) : helperMissing.call(depth0, "_", " In progress. ", options)))
    + "\n            ";
  return buffer;
  }

function program6(depth0,data) {
  
  var buffer = "", helper, options;
  buffer += "\n                "
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, " Struggling. ", options) : helperMissing.call(depth0, "_", " Struggling. ", options)))
    + "\n            ";
  return buffer;
  }

function program8(depth0,data) {
  
  var buffer = "", helper, options;
  buffer += "\n                "
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, " Not started. ", options) : helperMissing.call(depth0, "_", " Not started. ", options)))
    + "\n            ";
  return buffer;
  }

function program10(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n                <span>"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, " For this video you completed ", options) : helperMissing.call(depth0, "_", " For this video you completed ", options)))
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.score)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "%.</span>\n            ";
  return buffer;
  }

function program12(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n                <span>"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, " For this exercise your streak is ", options) : helperMissing.call(depth0, "_", " For this exercise your streak is ", options)))
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.score)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "%.</span>\n            ";
  return buffer;
  }

function program14(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n                <span>"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, " For this quiz your score is ", options) : helperMissing.call(depth0, "_", " For this quiz your score is ", options)))
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.score)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "%.</span>\n            ";
  return buffer;
  }

function program16(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n            title=\""
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.title)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\"\n            data-content=\"% Complete: "
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.score)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\"\n        ";
  return buffer;
  }

function program18(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n            title=\""
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.title)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\"\n            data-content=\"Streak: "
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.score)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "%\"\n        ";
  return buffer;
  }

function program20(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n            title=\"Quiz for "
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.title)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\"\n            data-content=\"Score: "
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.attributes)),stack1 == null || stack1 === false ? stack1 : stack1.score)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "%\"\n        ";
  return buffer;
  }

  stack1 = helpers.each.call(depth0, (depth0 && depth0.data), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { return stack1; }
  else { return ''; }
  });

},{"hbsfy/runtime":354}],10:[function(require,module,exports){
// hbsfy compiled Handlebars template
var HandlebarsCompiler = require('hbsfy/runtime');
module.exports = HandlebarsCompiler.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, options, helperMissing=helpers.helperMissing, escapeExpression=this.escapeExpression, self=this, functionType="function";

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n                    ";
  stack1 = helpers.unless.call(depth0, (depth0 && depth0.vid_pct_started), {hash:{},inverse:self.noop,fn:self.program(2, program2, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                ";
  return buffer;
  }
function program2(depth0,data) {
  
  var buffer = "", helper, options;
  buffer += "\n                        <span class=\"sr-only\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "You haven't started to watch videos! ", options) : helperMissing.call(depth0, "_", "You haven't started to watch videos! ", options)))
    + "</span>\n                    ";
  return buffer;
  }

function program4(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n                    <div class=\"progress-bar progress-bar-success\" title=\"% Completed\" style=\"width: ";
  if (helper = helpers.vid_pct_complete) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.vid_pct_complete); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "%\">\n                        <span class=\"sr-only\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "Of those you have completed ", options) : helperMissing.call(depth0, "_", "Of those you have completed ", options)))
    + "</span>\n                        <span>";
  if (helper = helpers.vid_pct_complete) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.vid_pct_complete); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "%</span>\n                    </div>\n                ";
  return buffer;
  }

function program6(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n                    <div class=\"progress-bar inprogress\" title=\"% In-Progress\" style=\"width: ";
  if (helper = helpers.vid_pct_started) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.vid_pct_started); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "%\">\n                    ";
  stack1 = (helper = helpers.ifcond || (depth0 && depth0.ifcond),options={hash:{},inverse:self.noop,fn:self.program(7, program7, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.vid_pct_started), "<", 100, options) : helperMissing.call(depth0, "ifcond", (depth0 && depth0.vid_pct_started), "<", 100, options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                    ";
  stack1 = (helper = helpers.ifcond || (depth0 && depth0.ifcond),options={hash:{},inverse:self.noop,fn:self.program(9, program9, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.vid_pct_started), "===", 100, options) : helperMissing.call(depth0, "ifcond", (depth0 && depth0.vid_pct_started), "===", 100, options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                    </div>\n                ";
  return buffer;
  }
function program7(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n                        <span class=\"sr-only\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "You are still working on ", options) : helperMissing.call(depth0, "_", "You are still working on ", options)))
    + "</span>\n                        <span>";
  if (helper = helpers.vid_pct_started) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.vid_pct_started); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "%</span>\n                    ";
  return buffer;
  }

function program9(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n                        <span class=\"sr-only\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "You are still working on all of them.", options) : helperMissing.call(depth0, "_", "You are still working on all of them.", options)))
    + "</span>\n                        <span aria-hidden=\"true\" role=\"presentation\">";
  if (helper = helpers.vid_pct_started) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.vid_pct_started); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "%</span>\n                    ";
  return buffer;
  }

function program11(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n                    ";
  stack1 = helpers['if'].call(depth0, ((stack1 = (depth0 && depth0.ex_status)),stack1 == null || stack1 === false ? stack1 : stack1.notstarted), {hash:{},inverse:self.noop,fn:self.program(12, program12, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                ";
  return buffer;
  }
function program12(depth0,data) {
  
  var buffer = "", helper, options;
  buffer += "\n                        <span class=\"sr-only\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "You haven't started to work on exercises! ", options) : helperMissing.call(depth0, "_", "You haven't started to work on exercises! ", options)))
    + "</span>\n                    ";
  return buffer;
  }

function program14(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n                    <div class=\"progress-bar progress-bar-success\" title=\"% Mastered\" style=\"width: ";
  if (helper = helpers.ex_pct_mastered) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.ex_pct_mastered); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "%\">\n                        <span class=\"sr-only\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "Of those you have mastered ", options) : helperMissing.call(depth0, "_", "Of those you have mastered ", options)))
    + "</span>\n                        <span>";
  if (helper = helpers.ex_pct_mastered) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.ex_pct_mastered); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "%</span>\n                    </div>\n                ";
  return buffer;
  }

function program16(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n                    <div class=\"progress-bar inprogress\" title=\"% In-Progress\" style=\"width: ";
  if (helper = helpers.ex_pct_incomplete) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.ex_pct_incomplete); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "%\">\n                    ";
  stack1 = (helper = helpers.ifcond || (depth0 && depth0.ifcond),options={hash:{},inverse:self.noop,fn:self.program(17, program17, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.ex_pct_incomplete), "<", 100, options) : helperMissing.call(depth0, "ifcond", (depth0 && depth0.ex_pct_incomplete), "<", 100, options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                    ";
  stack1 = (helper = helpers.ifcond || (depth0 && depth0.ifcond),options={hash:{},inverse:self.noop,fn:self.program(19, program19, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.ex_pct_incomplete), "===", 100, options) : helperMissing.call(depth0, "ifcond", (depth0 && depth0.ex_pct_incomplete), "===", 100, options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                    </div>\n                ";
  return buffer;
  }
function program17(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n                        <span class=\"sr-only\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "You are still working on ", options) : helperMissing.call(depth0, "_", "You are still working on ", options)))
    + "</span>\n                        <span>";
  if (helper = helpers.ex_pct_incomplete) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.ex_pct_incomplete); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "%</span>\n                    ";
  return buffer;
  }

function program19(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n                        <span class=\"sr-only\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "You are still working on all of them.", options) : helperMissing.call(depth0, "_", "You are still working on all of them.", options)))
    + "</span>\n                        <span aria-hidden=\"true\" role=\"presentation\">";
  if (helper = helpers.ex_pct_incomplete) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.ex_pct_incomplete); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "%</span>\n                    ";
  return buffer;
  }

function program21(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n                    <div class=\"progress-bar struggling\" title=\"% Struggling\" style=\"width: ";
  if (helper = helpers.ex_pct_struggling) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.ex_pct_struggling); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "%\">\n                        <span class=\"sr-only\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "And seem to be struggling with ", options) : helperMissing.call(depth0, "_", "And seem to be struggling with ", options)))
    + "</span>\n                        <span>";
  if (helper = helpers.ex_pct_struggling) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.ex_pct_struggling); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "%</span>\n                    </div>\n                ";
  return buffer;
  }

function program23(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n    <div class=\"row progress-block\">\n        <div class=\"col-sm-2\">\n            <div class=\"progress-indicator progress-indicator-lg center-block ";
  if (helper = helpers.quiz_status) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.quiz_status); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">\n                <span class=\"sr-only\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "There are ", options) : helperMissing.call(depth0, "_", "There are ", options)))
    + "</span>\n                <span class=\"sidebar-icon icon-Quiz icon-label icon-label-lg\"></span>\n                <span class=\"sr-only\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, " quizzes.", options) : helperMissing.call(depth0, "_", " quizzes.", options)))
    + "</span>\n            </div>\n        </div>\n        <div class=\"col-sm-10\">\n            <div class=\"progress playlist-progress-bar\">\n                ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.quiz_pct_score), {hash:{},inverse:self.noop,fn:self.program(24, program24, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            </div>\n        </div>\n    </div>\n    ";
  return buffer;
  }
function program24(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n                <div class=\"progress-bar ";
  if (helper = helpers.quiz_status) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.quiz_status); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" title=\"% Score\" style=\"width: ";
  if (helper = helpers.quiz_pct_score) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.quiz_pct_score); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "%\">\n                    \n                    <span class=\"sr-only\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "And your score is ", options) : helperMissing.call(depth0, "_", "And your score is ", options)))
    + "</span>\n                    <span>";
  if (helper = helpers.quiz_pct_score) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.quiz_pct_score); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "%</span>\n                </div>\n                ";
  return buffer;
  }

  buffer += "<div class=\"well\">\n    <div class=\"row\">\n        <div class=\"col-xs-12\">\n            <h2 class=\"h3 playlist-title center-block\">\n                <a href=\""
    + escapeExpression(((stack1 = (depth0 && depth0.url)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\">";
  if (helper = helpers.title) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.title); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</a>\n            </h2>\n            <div class=\"sr-only\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "In this topic ", options) : helperMissing.call(depth0, "_", "In this topic ", options)))
    + "</div>\n        </div>\n    </div>\n    \n    <div class=\"row progress-block\">\n        <div class=\"col-sm-2\">\n            <div class=\"progress-indicator progress-indicator-lg center-block ";
  if (helper = helpers.vid_status) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.vid_status); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">\n                <span class=\"sr-only\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "there are ", options) : helperMissing.call(depth0, "_", "there are ", options)))
    + "</span>\n                <div class=\"sidebar-icon icon-Video icon-label icon-label-lg\"><span class=\"progress-indicator content-counter label label-primary\">";
  if (helper = helpers.n_pl_videos) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.n_pl_videos); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span></div>\n                <span class=\"sr-only\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, " videos.", options) : helperMissing.call(depth0, "_", " videos.", options)))
    + "</span>\n            </div>\n        </div>\n        <div class=\"col-sm-10\">\n            <div class=\"progress playlist-progress-bar\">\n                ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.n_pl_videos), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.vid_pct_complete), {hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.vid_pct_started), {hash:{},inverse:self.noop,fn:self.program(6, program6, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            </div>\n        </div>\n    </div>\n    \n    <div class=\"row progress-block\">\n        <div class=\"col-sm-2\">\n            <div class=\"progress-indicator progress-indicator-lg center-block ";
  if (helper = helpers.ex_status) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.ex_status); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">\n                <span class=\"sr-only\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "There are ", options) : helperMissing.call(depth0, "_", "There are ", options)))
    + "</span>\n                <div class=\"sidebar-icon icon-Exercise icon-label icon-label-lg\"><span class=\"progress-indicator content-counter label label-primary\">";
  if (helper = helpers.n_pl_exercises) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.n_pl_exercises); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span></div>\n                <span class=\"sr-only\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, " exercises.", options) : helperMissing.call(depth0, "_", " exercises.", options)))
    + "</span>\n            </div>\n        </div>\n        <div class=\"col-sm-10\">\n            <div class=\"progress playlist-progress-bar\">\n                ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.n_pl_exercises), {hash:{},inverse:self.noop,fn:self.program(11, program11, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.ex_pct_mastered), {hash:{},inverse:self.noop,fn:self.program(14, program14, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.ex_pct_incomplete), {hash:{},inverse:self.noop,fn:self.program(16, program16, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.ex_pct_struggling), {hash:{},inverse:self.noop,fn:self.program(21, program21, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            </div>\n        </div>\n    </div>\n    \n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.quiz_exists), {hash:{},inverse:self.noop,fn:self.program(23, program23, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    <div class=\"row\">\n        <div class=\"col-xs-12\">\n            <button class=\"btn btn-sm btn-primary center-block toggle-details\" aria-label=\"Press to open detailed view\"><span class=\"expand-collapse glyphicon glyphicon-chevron-down\"></span></button>\n        </div>\n    </div>\n    <div class=\"row playlist-progress-details\">\n        <div class=\"col-xs-12\">\n            <img class=\"center-block\" src=\"/static/images/loading.gif\" aria-hidden=\"true\" role=\"presentation\"/>\n        </div>\n    </div>\n</div>\n";
  return buffer;
  });

},{"hbsfy/runtime":354}]},{},["student_progress"])
//# sourceMappingURL=data:application/json;charset:utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9mYWN0b3ItYnVuZGxlL25vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJrYWxpdGUvY29hY2hyZXBvcnRzL3N0YXRpYy9qcy9jb2FjaHJlcG9ydHMvYnVuZGxlX21vZHVsZXMvc3R1ZGVudF9wcm9ncmVzcy5qcyIsImthbGl0ZS9jb2FjaHJlcG9ydHMvc3RhdGljL2pzL2NvYWNocmVwb3J0cy9zdHVkZW50X3Byb2dyZXNzL3ZpZXdzLmpzIiwia2FsaXRlL2NvYWNocmVwb3J0cy9zdGF0aWMvanMvY29hY2hyZXBvcnRzL3N0dWRlbnRfcHJvZ3Jlc3MvbW9kZWxzLmpzIiwia2FsaXRlL2NvYWNocmVwb3J0cy9zdGF0aWMvanMvY29hY2hyZXBvcnRzL3N0dWRlbnRfcHJvZ3Jlc3MvaGJ0ZW1wbGF0ZXMvc3R1ZGVudC1wcm9ncmVzcy1jb250YWluZXIuaGFuZGxlYmFycyIsImthbGl0ZS9jb2FjaHJlcG9ydHMvc3RhdGljL2pzL2NvYWNocmVwb3J0cy9zdHVkZW50X3Byb2dyZXNzL2hidGVtcGxhdGVzL3BsYXlsaXN0LXByb2dyZXNzLWRldGFpbHMuaGFuZGxlYmFycyIsImthbGl0ZS9jb2FjaHJlcG9ydHMvc3RhdGljL2pzL2NvYWNocmVwb3J0cy9zdHVkZW50X3Byb2dyZXNzL2hidGVtcGxhdGVzL3BsYXlsaXN0LXByb2dyZXNzLWNvbnRhaW5lci5oYW5kbGViYXJzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7QUNKQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDMUhBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3ZDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDaEtBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsImZpbGUiOiJnZW5lcmF0ZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsiKGZ1bmN0aW9uIGUodCxuLHIpe2Z1bmN0aW9uIHMobyx1KXtpZighbltvXSl7aWYoIXRbb10pe3ZhciBhPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7aWYoIXUmJmEpcmV0dXJuIGEobywhMCk7aWYoaSlyZXR1cm4gaShvLCEwKTt2YXIgZj1uZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBtb2R1bGUgJ1wiK28rXCInXCIpO3Rocm93IGYuY29kZT1cIk1PRFVMRV9OT1RfRk9VTkRcIixmfXZhciBsPW5bb109e2V4cG9ydHM6e319O3Rbb11bMF0uY2FsbChsLmV4cG9ydHMsZnVuY3Rpb24oZSl7dmFyIG49dFtvXVsxXVtlXTtyZXR1cm4gcyhuP246ZSl9LGwsbC5leHBvcnRzLGUsdCxuLHIpfXJldHVybiBuW29dLmV4cG9ydHN9dmFyIGk9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtmb3IodmFyIG89MDtvPHIubGVuZ3RoO28rKylzKHJbb10pO3JldHVybiBzfSkiLCJ2YXIgJCA9IHJlcXVpcmUoXCJiYXNlL2pRdWVyeVwiKTtcbnZhciBTdHVkZW50UHJvZ3Jlc3NDb250YWluZXJWaWV3ID0gcmVxdWlyZShcIi4uL3N0dWRlbnRfcHJvZ3Jlc3Mvdmlld3NcIikuU3R1ZGVudFByb2dyZXNzQ29udGFpbmVyVmlldztcblxuZ2xvYmFsLiQgPSAkO1xuZ2xvYmFsLlN0dWRlbnRQcm9ncmVzc0NvbnRhaW5lclZpZXcgPSBTdHVkZW50UHJvZ3Jlc3NDb250YWluZXJWaWV3OyIsInZhciBCYWNrYm9uZSA9IHJlcXVpcmUoXCJiYXNlL2JhY2tib25lXCIpO1xudmFyIEhhbmRsZWJhcnMgPSByZXF1aXJlKFwiYmFzZS9oYW5kbGViYXJzXCIpO1xuXG52YXIgTW9kZWxzID0gcmVxdWlyZShcIi4vbW9kZWxzXCIpO1xuXG5cbnZhciBQbGF5bGlzdFByb2dyZXNzRGV0YWlsVmlldyA9IEJhY2tib25lLlZpZXcuZXh0ZW5kKHtcblxuICAgIHRlbXBsYXRlOiByZXF1aXJlKCcuL2hidGVtcGxhdGVzL3BsYXlsaXN0LXByb2dyZXNzLWRldGFpbHMuaGFuZGxlYmFycycpLFxuXG4gICAgaW5pdGlhbGl6ZTogZnVuY3Rpb24oKSB7XG4gICAgICAgIHRoaXMubGlzdGVuVG8odGhpcy5jb2xsZWN0aW9uLCAnc3luYycsIHRoaXMucmVuZGVyKTtcbiAgICB9LFxuXG4gICAgcmVuZGVyOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdGhpcy4kZWwuaHRtbCh0aGlzLnRlbXBsYXRlKHtcbiAgICAgICAgICAgIGRhdGE6IHRoaXMuY29sbGVjdGlvbi5tb2RlbHNcbiAgICAgICAgfSkpO1xuXG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbn0pO1xuXG52YXIgUGxheWxpc3RQcm9ncmVzc1ZpZXcgPSBCYWNrYm9uZS5WaWV3LmV4dGVuZCh7XG5cbiAgICB0ZW1wbGF0ZTogcmVxdWlyZSgnLi9oYnRlbXBsYXRlcy9wbGF5bGlzdC1wcm9ncmVzcy1jb250YWluZXIuaGFuZGxlYmFycycpLFxuXG4gICAgZXZlbnRzOiB7XG4gICAgICAgIFwiY2xpY2sgLnRvZ2dsZS1kZXRhaWxzXCI6IFwidG9nZ2xlX2RldGFpbHNcIlxuICAgIH0sXG5cbiAgICBpbml0aWFsaXplOiBmdW5jdGlvbihvcHRpb25zKSB7XG4gICAgICAgIHRoaXMuZGV0YWlsc19mZXRjaGVkID0gZmFsc2U7XG5cbiAgICAgICAgdGhpcy5kZXRhaWxlZF92aWV3ID0gbmV3IFBsYXlsaXN0UHJvZ3Jlc3NEZXRhaWxWaWV3KHtcbiAgICAgICAgICAgIGNvbGxlY3Rpb246IG5ldyBNb2RlbHMuUGxheWxpc3RQcm9ncmVzc0RldGFpbENvbGxlY3Rpb24oW10sIHtcbiAgICAgICAgICAgICAgICBwbGF5bGlzdF9pZDogdGhpcy5tb2RlbC5hdHRyaWJ1dGVzLmlkLFxuICAgICAgICAgICAgICAgIHVzZXJfaWQ6IG9wdGlvbnMudXNlcl9pZFxuICAgICAgICAgICAgfSlcbiAgICAgICAgfSk7XG5cbiAgICAgICAgdGhpcy5saXN0ZW5Ubyh0aGlzLmRldGFpbGVkX3ZpZXcuY29sbGVjdGlvbiwgXCJzeW5jXCIsIHRoaXMucmVuZGVyX2RldGFpbHMpO1xuICAgIH0sXG5cbiAgICByZW5kZXI6IGZ1bmN0aW9uKCkge1xuICAgICAgICB0aGlzLiRlbC5odG1sKHRoaXMudGVtcGxhdGUodGhpcy5tb2RlbC50b0pTT04oKSkpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9LFxuXG4gICAgcmVuZGVyX2RldGFpbHM6IGZ1bmN0aW9uKCkge1xuICAgICAgICB0aGlzLiQoXCIucGxheWxpc3QtcHJvZ3Jlc3MtZGV0YWlsc1wiKS5odG1sKHRoaXMuZGV0YWlsZWRfdmlldy5yZW5kZXIoKS5lbCkuc2hvdygpO1xuXG4gICAgICAgIC8vIG9wdCBpbiBib290c3RyYXAgdG9vbHRpcCBmdW5jdGlvbmFsaXR5XG4gICAgICAgIHRoaXMuJCgnLnByb2dyZXNzLWluZGljYXRvci1zbScpLnBvcG92ZXIoe1xuICAgICAgICAgICAgdHJpZ2dlcjogJ2NsaWNrIGhvdmVyJyxcbiAgICAgICAgICAgIGFuaW1hdGlvbjogZmFsc2VcbiAgICAgICAgfSk7XG4gICAgfSxcblxuICAgIHRvZ2dsZV9kZXRhaWxzOiBmdW5jdGlvbigpIHtcbiAgICAgICAgLy8gRmV0Y2ggZGF0YSBpZiB3ZSBkb24ndCBoYXZlIGl0IHlldFxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgICAgIGlmICghdGhpcy5kZXRhaWxzX2ZldGNoZWQpIHtcbiAgICAgICAgICAgIHRoaXMuZGV0YWlsZWRfdmlldy5jb2xsZWN0aW9uLmZldGNoKHtcbiAgICAgICAgICAgICAgICBzdWNjZXNzOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICAgICAgc2VsZi5kZXRhaWxzX2ZldGNoZWQgPSB0cnVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gU2hvdyBvciBoaWRlIGRldGFpbHNcbiAgICAgICAgdGhpcy4kKFwiLmV4cGFuZC1jb2xsYXBzZVwiKS50b2dnbGVDbGFzcyhcImdseXBoaWNvbi1jaGV2cm9uLWRvd24gZ2x5cGhpY29uLWNoZXZyb24tdXBcIik7XG4gICAgICAgIHRoaXMuJChcIi5wbGF5bGlzdC1wcm9ncmVzcy1kZXRhaWxzXCIpLnNsaWRlVG9nZ2xlKCk7XG4gICAgfVxufSk7XG5cbnZhciBTdHVkZW50UHJvZ3Jlc3NDb250YWluZXJWaWV3ID0gQmFja2JvbmUuVmlldy5leHRlbmQoe1xuICAgIC8vIFRoZSBjb250YWluaW5nIHZpZXdcbiAgICB0ZW1wbGF0ZTogcmVxdWlyZSgnLi9oYnRlbXBsYXRlcy9zdHVkZW50LXByb2dyZXNzLWNvbnRhaW5lci5oYW5kbGViYXJzJyksXG5cbiAgICBpbml0aWFsaXplOiBmdW5jdGlvbihvcHRpb25zKSB7XG4gICAgICAgIHRoaXMudXNlcl9pZCA9IG9wdGlvbnMudXNlcl9pZDtcblxuICAgICAgICB0aGlzLmNvbGxlY3Rpb24gPSAgbmV3IE1vZGVscy5QbGF5bGlzdFByb2dyZXNzQ29sbGVjdGlvbihbXSwge3VzZXJfaWQ6IHRoaXMudXNlcl9pZH0pO1xuXG4gICAgICAgIHRoaXMubGlzdGVuVG8odGhpcy5jb2xsZWN0aW9uLCAnYWRkJywgdGhpcy5hZGRfb25lKTtcbiAgICAgICAgXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcblxuICAgICAgICB0aGlzLnJlbmRlcigpO1xuXG4gICAgICAgIHRoaXMuY29sbGVjdGlvbi5mZXRjaCh7XG4gICAgICAgICAgICBzdWNjZXNzOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICAgaWYgKHNlbGYuY29sbGVjdGlvbi5sZW5ndGggPT09IDApIHsgICAgICAgLy9pZiB0aGUgc3R1ZGVudCB2aXNpdHMgdGhlIG15IHByb2dyZXNzIHBhZ2UgYmVmb3JlIGF0dGVtcHRpbmcgYW55IHF1aXplcy92aWRlb3NcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh3aW5kb3cuc3RhdHVzTW9kZWwuaXNfc3R1ZGVudCgpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvd19tZXNzYWdlKFwiaW5mb1wiLCBnZXR0ZXh0KFwiQ2xpY2sgb24gdGhlIExFQVJOIGJ1dHRvbiBhYm92ZSB0byBnZXQgc3RhcnRlZCBvbiB5b3VyIGxlYXJuaW5nIGpvdXJuZXkuXCIpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGYuJGVsLmh0bWwoXCJcIik7ICAgICAgICAgICAgIC8vdGhpcyBpcyBkb25lIHRvIHJlbW92ZSB0aGUgJ1Byb2dyZXNzIFJlcG9ydCcgaGVhZGVyXG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgIH0pO1xuICAgIH0sXG5cbiAgICByZW5kZXI6IGZ1bmN0aW9uKCkge1xuICAgICAgICAvLyBPbmx5IHJlbmRlciBjb250YWluZXIgb25jZVxuICAgICAgICB0aGlzLiRlbC5odG1sKHRoaXMudGVtcGxhdGUoKSk7XG4gICAgfSxcblxuICAgIGFkZF9vbmU6IGZ1bmN0aW9uKHBsYXlsaXN0KSB7XG4gICAgICAgIHZhciB2aWV3ICA9IG5ldyBQbGF5bGlzdFByb2dyZXNzVmlldyh7XG4gICAgICAgICAgICBtb2RlbDogcGxheWxpc3QsXG4gICAgICAgICAgICB1c2VyX2lkOiB0aGlzLnVzZXJfaWRcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMuJChcIiNwbGF5bGlzdHMtY29udGFpbmVyXCIpLmFwcGVuZCh2aWV3LnJlbmRlcigpLmVsKTtcbiAgICB9XG59KTtcblxubW9kdWxlLmV4cG9ydHMgPSB7XG4gICAgU3R1ZGVudFByb2dyZXNzQ29udGFpbmVyVmlldzogU3R1ZGVudFByb2dyZXNzQ29udGFpbmVyVmlldyxcbiAgICBQbGF5bGlzdFByb2dyZXNzVmlldzogUGxheWxpc3RQcm9ncmVzc1ZpZXcsXG4gICAgUGxheWxpc3RQcm9ncmVzc0RldGFpbFZpZXc6IFBsYXlsaXN0UHJvZ3Jlc3NEZXRhaWxWaWV3XG59O1xuIiwidmFyIEJhY2tib25lID0gcmVxdWlyZShcImJhc2UvYmFja2JvbmVcIik7XG52YXIgc3ByaW50ZiA9IHJlcXVpcmUoXCJzcHJpbnRmLWpzXCIpLnNwcmludGY7XG5cbnZhciBQbGF5bGlzdFByb2dyZXNzTW9kZWwgPSBCYWNrYm9uZS5Nb2RlbC5leHRlbmQoKTtcblxudmFyIFBsYXlsaXN0UHJvZ3Jlc3NEZXRhaWxNb2RlbCA9IEJhY2tib25lLk1vZGVsLmV4dGVuZCgpO1xuXG4vLyBDb2xsZWN0aW9uc1xudmFyIFBsYXlsaXN0UHJvZ3Jlc3NDb2xsZWN0aW9uID0gQmFja2JvbmUuQ29sbGVjdGlvbi5leHRlbmQoe1xuICAgIG1vZGVsOiBQbGF5bGlzdFByb2dyZXNzTW9kZWwsXG5cbiAgICBpbml0aWFsaXplOiBmdW5jdGlvbihtb2RlbCwgb3B0aW9ucykge1xuICAgICAgICB0aGlzLnVzZXJfaWQgPSBvcHRpb25zLnVzZXJfaWQ7XG4gICAgfSxcblxuICAgIHVybDogZnVuY3Rpb24oKSB7XG4gICAgICAgIHJldHVybiBzcHJpbnRmKFwiJShwbGF5bGlzdF91cmwpcz91c2VyX2lkPSUodXNlcl9pZClzXCIsIHtcInBsYXlsaXN0X3VybFwiOiBQTEFZTElTVF9QUk9HUkVTU19VUkwsIFwidXNlcl9pZFwiOiB0aGlzLnVzZXJfaWR9KTtcbiAgICB9XG59KTtcblxudmFyIFBsYXlsaXN0UHJvZ3Jlc3NEZXRhaWxDb2xsZWN0aW9uID0gQmFja2JvbmUuQ29sbGVjdGlvbi5leHRlbmQoe1xuICAgIG1vZGVsOiBQbGF5bGlzdFByb2dyZXNzRGV0YWlsTW9kZWwsXG5cbiAgICBpbml0aWFsaXplOiBmdW5jdGlvbihtb2RlbHMsIG9wdGlvbnMpIHtcbiAgICAgICAgdGhpcy5wbGF5bGlzdF9pZCA9IG9wdGlvbnMucGxheWxpc3RfaWQ7XG4gICAgICAgIHRoaXMudXNlcl9pZCA9IG9wdGlvbnMudXNlcl9pZDtcbiAgICB9LFxuXG4gICAgdXJsOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdmFyIGJhc2UgPSBzcHJpbnRmKFwiJShwbGF5bGlzdF91cmwpcz91c2VyX2lkPSUodXNlcl9pZClzJnBsYXlsaXN0X2lkPVwiLCB7XCJwbGF5bGlzdF91cmxcIjogUExBWUxJU1RfUFJPR1JFU1NfREVUQUlMX1VSTCwgXCJ1c2VyX2lkXCI6IHRoaXMudXNlcl9pZH0pO1xuICAgICAgICByZXR1cm4gYmFzZSArIHRoaXMucGxheWxpc3RfaWQ7XG4gICAgfVxufSk7XG5cbm1vZHVsZS5leHBvcnRzID0ge1xuICAgIFBsYXlsaXN0UHJvZ3Jlc3NNb2RlbDogUGxheWxpc3RQcm9ncmVzc01vZGVsLFxuICAgIFBsYXlsaXN0UHJvZ3Jlc3NEZXRhaWxNb2RlbDogUGxheWxpc3RQcm9ncmVzc0RldGFpbE1vZGVsLFxuICAgIFBsYXlsaXN0UHJvZ3Jlc3NDb2xsZWN0aW9uOiBQbGF5bGlzdFByb2dyZXNzQ29sbGVjdGlvbixcbiAgICBQbGF5bGlzdFByb2dyZXNzRGV0YWlsQ29sbGVjdGlvbjogUGxheWxpc3RQcm9ncmVzc0RldGFpbENvbGxlY3Rpb25cbn07IiwiLy8gaGJzZnkgY29tcGlsZWQgSGFuZGxlYmFycyB0ZW1wbGF0ZVxudmFyIEhhbmRsZWJhcnNDb21waWxlciA9IHJlcXVpcmUoJ2hic2Z5L3J1bnRpbWUnKTtcbm1vZHVsZS5leHBvcnRzID0gSGFuZGxlYmFyc0NvbXBpbGVyLnRlbXBsYXRlKGZ1bmN0aW9uIChIYW5kbGViYXJzLGRlcHRoMCxoZWxwZXJzLHBhcnRpYWxzLGRhdGEpIHtcbiAgdGhpcy5jb21waWxlckluZm8gPSBbNCwnPj0gMS4wLjAnXTtcbmhlbHBlcnMgPSB0aGlzLm1lcmdlKGhlbHBlcnMsIEhhbmRsZWJhcnMuaGVscGVycyk7IGRhdGEgPSBkYXRhIHx8IHt9O1xuICB2YXIgYnVmZmVyID0gXCJcIiwgaGVscGVyLCBvcHRpb25zLCBoZWxwZXJNaXNzaW5nPWhlbHBlcnMuaGVscGVyTWlzc2luZywgZXNjYXBlRXhwcmVzc2lvbj10aGlzLmVzY2FwZUV4cHJlc3Npb247XG5cblxuICBidWZmZXIgKz0gXCI8aDEgY2xhc3M9XFxcImgyXFxcIj5cIlxuICAgICsgZXNjYXBlRXhwcmVzc2lvbigoaGVscGVyID0gaGVscGVycy5fIHx8IChkZXB0aDAgJiYgZGVwdGgwLl8pLG9wdGlvbnM9e2hhc2g6e30sZGF0YTpkYXRhfSxoZWxwZXIgPyBoZWxwZXIuY2FsbChkZXB0aDAsIFwiUHJvZ3Jlc3MgcmVwb3J0XCIsIG9wdGlvbnMpIDogaGVscGVyTWlzc2luZy5jYWxsKGRlcHRoMCwgXCJfXCIsIFwiUHJvZ3Jlc3MgcmVwb3J0XCIsIG9wdGlvbnMpKSlcbiAgICArIFwiPC9oMT5cXG48ZGl2IGlkPVxcXCJwbGF5bGlzdHMtY29udGFpbmVyXFxcIj48L2Rpdj5cXG5cIjtcbiAgcmV0dXJuIGJ1ZmZlcjtcbiAgfSk7XG4iLCIvLyBoYnNmeSBjb21waWxlZCBIYW5kbGViYXJzIHRlbXBsYXRlXG52YXIgSGFuZGxlYmFyc0NvbXBpbGVyID0gcmVxdWlyZSgnaGJzZnkvcnVudGltZScpO1xubW9kdWxlLmV4cG9ydHMgPSBIYW5kbGViYXJzQ29tcGlsZXIudGVtcGxhdGUoZnVuY3Rpb24gKEhhbmRsZWJhcnMsZGVwdGgwLGhlbHBlcnMscGFydGlhbHMsZGF0YSkge1xuICB0aGlzLmNvbXBpbGVySW5mbyA9IFs0LCc+PSAxLjAuMCddO1xuaGVscGVycyA9IHRoaXMubWVyZ2UoaGVscGVycywgSGFuZGxlYmFycy5oZWxwZXJzKTsgZGF0YSA9IGRhdGEgfHwge307XG4gIHZhciBzdGFjazEsIGhlbHBlck1pc3Npbmc9aGVscGVycy5oZWxwZXJNaXNzaW5nLCBlc2NhcGVFeHByZXNzaW9uPXRoaXMuZXNjYXBlRXhwcmVzc2lvbiwgZnVuY3Rpb25UeXBlPVwiZnVuY3Rpb25cIiwgc2VsZj10aGlzO1xuXG5mdW5jdGlvbiBwcm9ncmFtMShkZXB0aDAsZGF0YSkge1xuICBcbiAgdmFyIGJ1ZmZlciA9IFwiXCIsIHN0YWNrMSwgaGVscGVyLCBvcHRpb25zO1xuICBidWZmZXIgKz0gXCJcXG4gICAgXFxuPGRpdiBjbGFzcz1cXFwic3Itb25seVxcXCI+XFxuICAgICAgICA8YSBocmVmPVxcXCIvbGVhcm4vXCJcbiAgICArIGVzY2FwZUV4cHJlc3Npb24oKChzdGFjazEgPSAoKHN0YWNrMSA9IChkZXB0aDAgJiYgZGVwdGgwLmF0dHJpYnV0ZXMpKSxzdGFjazEgPT0gbnVsbCB8fCBzdGFjazEgPT09IGZhbHNlID8gc3RhY2sxIDogc3RhY2sxLnBhdGgpKSx0eXBlb2Ygc3RhY2sxID09PSBmdW5jdGlvblR5cGUgPyBzdGFjazEuYXBwbHkoZGVwdGgwKSA6IHN0YWNrMSkpXG4gICAgKyBcIlxcXCI+PGgzPlwiXG4gICAgKyBlc2NhcGVFeHByZXNzaW9uKCgoc3RhY2sxID0gKChzdGFjazEgPSAoZGVwdGgwICYmIGRlcHRoMC5hdHRyaWJ1dGVzKSksc3RhY2sxID09IG51bGwgfHwgc3RhY2sxID09PSBmYWxzZSA/IHN0YWNrMSA6IHN0YWNrMS50aXRsZSkpLHR5cGVvZiBzdGFjazEgPT09IGZ1bmN0aW9uVHlwZSA/IHN0YWNrMS5hcHBseShkZXB0aDApIDogc3RhY2sxKSlcbiAgICArIFwiPC9oMz48L2E+XFxuICAgICAgICA8ZGl2PlxcbiAgICAgICAgICAgIFwiXG4gICAgKyBlc2NhcGVFeHByZXNzaW9uKChoZWxwZXIgPSBoZWxwZXJzLl8gfHwgKGRlcHRoMCAmJiBkZXB0aDAuXyksb3B0aW9ucz17aGFzaDp7fSxkYXRhOmRhdGF9LGhlbHBlciA/IGhlbHBlci5jYWxsKGRlcHRoMCwgXCIgU3RhdHVzOiBcIiwgb3B0aW9ucykgOiBoZWxwZXJNaXNzaW5nLmNhbGwoZGVwdGgwLCBcIl9cIiwgXCIgU3RhdHVzOiBcIiwgb3B0aW9ucykpKVxuICAgICsgXCJcXG4gICAgICAgICAgICBcIjtcbiAgc3RhY2sxID0gKGhlbHBlciA9IGhlbHBlcnMuaWZjb25kIHx8IChkZXB0aDAgJiYgZGVwdGgwLmlmY29uZCksb3B0aW9ucz17aGFzaDp7fSxpbnZlcnNlOnNlbGYubm9vcCxmbjpzZWxmLnByb2dyYW0oMiwgcHJvZ3JhbTIsIGRhdGEpLGRhdGE6ZGF0YX0saGVscGVyID8gaGVscGVyLmNhbGwoZGVwdGgwLCAoKHN0YWNrMSA9IChkZXB0aDAgJiYgZGVwdGgwLmF0dHJpYnV0ZXMpKSxzdGFjazEgPT0gbnVsbCB8fCBzdGFjazEgPT09IGZhbHNlID8gc3RhY2sxIDogc3RhY2sxLnN0YXR1cyksIFwiPT09XCIsIFwiY29tcGxldGVcIiwgb3B0aW9ucykgOiBoZWxwZXJNaXNzaW5nLmNhbGwoZGVwdGgwLCBcImlmY29uZFwiLCAoKHN0YWNrMSA9IChkZXB0aDAgJiYgZGVwdGgwLmF0dHJpYnV0ZXMpKSxzdGFjazEgPT0gbnVsbCB8fCBzdGFjazEgPT09IGZhbHNlID8gc3RhY2sxIDogc3RhY2sxLnN0YXR1cyksIFwiPT09XCIsIFwiY29tcGxldGVcIiwgb3B0aW9ucykpO1xuICBpZihzdGFjazEgfHwgc3RhY2sxID09PSAwKSB7IGJ1ZmZlciArPSBzdGFjazE7IH1cbiAgYnVmZmVyICs9IFwiXFxuXFxuICAgICAgICAgICAgXCI7XG4gIHN0YWNrMSA9IChoZWxwZXIgPSBoZWxwZXJzLmlmY29uZCB8fCAoZGVwdGgwICYmIGRlcHRoMC5pZmNvbmQpLG9wdGlvbnM9e2hhc2g6e30saW52ZXJzZTpzZWxmLm5vb3AsZm46c2VsZi5wcm9ncmFtKDQsIHByb2dyYW00LCBkYXRhKSxkYXRhOmRhdGF9LGhlbHBlciA/IGhlbHBlci5jYWxsKGRlcHRoMCwgKChzdGFjazEgPSAoZGVwdGgwICYmIGRlcHRoMC5hdHRyaWJ1dGVzKSksc3RhY2sxID09IG51bGwgfHwgc3RhY2sxID09PSBmYWxzZSA/IHN0YWNrMSA6IHN0YWNrMS5zdGF0dXMpLCBcIj09PVwiLCBcImlucHJvZ3Jlc3NcIiwgb3B0aW9ucykgOiBoZWxwZXJNaXNzaW5nLmNhbGwoZGVwdGgwLCBcImlmY29uZFwiLCAoKHN0YWNrMSA9IChkZXB0aDAgJiYgZGVwdGgwLmF0dHJpYnV0ZXMpKSxzdGFjazEgPT0gbnVsbCB8fCBzdGFjazEgPT09IGZhbHNlID8gc3RhY2sxIDogc3RhY2sxLnN0YXR1cyksIFwiPT09XCIsIFwiaW5wcm9ncmVzc1wiLCBvcHRpb25zKSk7XG4gIGlmKHN0YWNrMSB8fCBzdGFjazEgPT09IDApIHsgYnVmZmVyICs9IHN0YWNrMTsgfVxuICBidWZmZXIgKz0gXCJcXG5cXG4gICAgICAgICAgICBcIjtcbiAgc3RhY2sxID0gKGhlbHBlciA9IGhlbHBlcnMuaWZjb25kIHx8IChkZXB0aDAgJiYgZGVwdGgwLmlmY29uZCksb3B0aW9ucz17aGFzaDp7fSxpbnZlcnNlOnNlbGYubm9vcCxmbjpzZWxmLnByb2dyYW0oNiwgcHJvZ3JhbTYsIGRhdGEpLGRhdGE6ZGF0YX0saGVscGVyID8gaGVscGVyLmNhbGwoZGVwdGgwLCAoKHN0YWNrMSA9IChkZXB0aDAgJiYgZGVwdGgwLmF0dHJpYnV0ZXMpKSxzdGFjazEgPT0gbnVsbCB8fCBzdGFjazEgPT09IGZhbHNlID8gc3RhY2sxIDogc3RhY2sxLnN0YXR1cyksIFwiPT09XCIsIFwic3RydWdnbGluZ1wiLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwiaWZjb25kXCIsICgoc3RhY2sxID0gKGRlcHRoMCAmJiBkZXB0aDAuYXR0cmlidXRlcykpLHN0YWNrMSA9PSBudWxsIHx8IHN0YWNrMSA9PT0gZmFsc2UgPyBzdGFjazEgOiBzdGFjazEuc3RhdHVzKSwgXCI9PT1cIiwgXCJzdHJ1Z2dsaW5nXCIsIG9wdGlvbnMpKTtcbiAgaWYoc3RhY2sxIHx8IHN0YWNrMSA9PT0gMCkgeyBidWZmZXIgKz0gc3RhY2sxOyB9XG4gIGJ1ZmZlciArPSBcIlxcbiAgICAgICAgICAgIFxcbiAgICAgICAgICAgIFwiO1xuICBzdGFjazEgPSAoaGVscGVyID0gaGVscGVycy5pZmNvbmQgfHwgKGRlcHRoMCAmJiBkZXB0aDAuaWZjb25kKSxvcHRpb25zPXtoYXNoOnt9LGludmVyc2U6c2VsZi5ub29wLGZuOnNlbGYucHJvZ3JhbSg4LCBwcm9ncmFtOCwgZGF0YSksZGF0YTpkYXRhfSxoZWxwZXIgPyBoZWxwZXIuY2FsbChkZXB0aDAsICgoc3RhY2sxID0gKGRlcHRoMCAmJiBkZXB0aDAuYXR0cmlidXRlcykpLHN0YWNrMSA9PSBudWxsIHx8IHN0YWNrMSA9PT0gZmFsc2UgPyBzdGFjazEgOiBzdGFjazEuc3RhdHVzKSwgXCI9PT1cIiwgXCJub3RzdGFydGVkXCIsIG9wdGlvbnMpIDogaGVscGVyTWlzc2luZy5jYWxsKGRlcHRoMCwgXCJpZmNvbmRcIiwgKChzdGFjazEgPSAoZGVwdGgwICYmIGRlcHRoMC5hdHRyaWJ1dGVzKSksc3RhY2sxID09IG51bGwgfHwgc3RhY2sxID09PSBmYWxzZSA/IHN0YWNrMSA6IHN0YWNrMS5zdGF0dXMpLCBcIj09PVwiLCBcIm5vdHN0YXJ0ZWRcIiwgb3B0aW9ucykpO1xuICBpZihzdGFjazEgfHwgc3RhY2sxID09PSAwKSB7IGJ1ZmZlciArPSBzdGFjazE7IH1cbiAgYnVmZmVyICs9IFwiICAgICAgICAgICAgICAgIFxcbiAgICAgICAgPC9kaXY+XFxuICAgICAgICA8ZGl2PlxcbiAgICAgICAgICAgIFxcbiAgICAgICAgICAgIFxcbiAgICAgICAgICAgIFwiO1xuICBzdGFjazEgPSAoaGVscGVyID0gaGVscGVycy5pZmNvbmQgfHwgKGRlcHRoMCAmJiBkZXB0aDAuaWZjb25kKSxvcHRpb25zPXtoYXNoOnt9LGludmVyc2U6c2VsZi5ub29wLGZuOnNlbGYucHJvZ3JhbSgxMCwgcHJvZ3JhbTEwLCBkYXRhKSxkYXRhOmRhdGF9LGhlbHBlciA/IGhlbHBlci5jYWxsKGRlcHRoMCwgKChzdGFjazEgPSAoZGVwdGgwICYmIGRlcHRoMC5hdHRyaWJ1dGVzKSksc3RhY2sxID09IG51bGwgfHwgc3RhY2sxID09PSBmYWxzZSA/IHN0YWNrMSA6IHN0YWNrMS5raW5kKSwgXCI9PT1cIiwgXCJWaWRlb1wiLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwiaWZjb25kXCIsICgoc3RhY2sxID0gKGRlcHRoMCAmJiBkZXB0aDAuYXR0cmlidXRlcykpLHN0YWNrMSA9PSBudWxsIHx8IHN0YWNrMSA9PT0gZmFsc2UgPyBzdGFjazEgOiBzdGFjazEua2luZCksIFwiPT09XCIsIFwiVmlkZW9cIiwgb3B0aW9ucykpO1xuICBpZihzdGFjazEgfHwgc3RhY2sxID09PSAwKSB7IGJ1ZmZlciArPSBzdGFjazE7IH1cbiAgYnVmZmVyICs9IFwiXFxuXFxuICAgICAgICAgICAgXFxuICAgICAgICAgICAgXCI7XG4gIHN0YWNrMSA9IChoZWxwZXIgPSBoZWxwZXJzLmlmY29uZCB8fCAoZGVwdGgwICYmIGRlcHRoMC5pZmNvbmQpLG9wdGlvbnM9e2hhc2g6e30saW52ZXJzZTpzZWxmLm5vb3AsZm46c2VsZi5wcm9ncmFtKDEyLCBwcm9ncmFtMTIsIGRhdGEpLGRhdGE6ZGF0YX0saGVscGVyID8gaGVscGVyLmNhbGwoZGVwdGgwLCAoKHN0YWNrMSA9IChkZXB0aDAgJiYgZGVwdGgwLmF0dHJpYnV0ZXMpKSxzdGFjazEgPT0gbnVsbCB8fCBzdGFjazEgPT09IGZhbHNlID8gc3RhY2sxIDogc3RhY2sxLmtpbmQpLCBcIj09PVwiLCBcIkV4ZXJjaXNlXCIsIG9wdGlvbnMpIDogaGVscGVyTWlzc2luZy5jYWxsKGRlcHRoMCwgXCJpZmNvbmRcIiwgKChzdGFjazEgPSAoZGVwdGgwICYmIGRlcHRoMC5hdHRyaWJ1dGVzKSksc3RhY2sxID09IG51bGwgfHwgc3RhY2sxID09PSBmYWxzZSA/IHN0YWNrMSA6IHN0YWNrMS5raW5kKSwgXCI9PT1cIiwgXCJFeGVyY2lzZVwiLCBvcHRpb25zKSk7XG4gIGlmKHN0YWNrMSB8fCBzdGFjazEgPT09IDApIHsgYnVmZmVyICs9IHN0YWNrMTsgfVxuICBidWZmZXIgKz0gXCJcXG5cXG4gICAgICAgICAgICBcXG4gICAgICAgICAgICBcIjtcbiAgc3RhY2sxID0gKGhlbHBlciA9IGhlbHBlcnMuaWZjb25kIHx8IChkZXB0aDAgJiYgZGVwdGgwLmlmY29uZCksb3B0aW9ucz17aGFzaDp7fSxpbnZlcnNlOnNlbGYubm9vcCxmbjpzZWxmLnByb2dyYW0oMTQsIHByb2dyYW0xNCwgZGF0YSksZGF0YTpkYXRhfSxoZWxwZXIgPyBoZWxwZXIuY2FsbChkZXB0aDAsICgoc3RhY2sxID0gKGRlcHRoMCAmJiBkZXB0aDAuYXR0cmlidXRlcykpLHN0YWNrMSA9PSBudWxsIHx8IHN0YWNrMSA9PT0gZmFsc2UgPyBzdGFjazEgOiBzdGFjazEua2luZCksIFwiPT09XCIsIFwiUXVpelwiLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwiaWZjb25kXCIsICgoc3RhY2sxID0gKGRlcHRoMCAmJiBkZXB0aDAuYXR0cmlidXRlcykpLHN0YWNrMSA9PSBudWxsIHx8IHN0YWNrMSA9PT0gZmFsc2UgPyBzdGFjazEgOiBzdGFjazEua2luZCksIFwiPT09XCIsIFwiUXVpelwiLCBvcHRpb25zKSk7XG4gIGlmKHN0YWNrMSB8fCBzdGFjazEgPT09IDApIHsgYnVmZmVyICs9IHN0YWNrMTsgfVxuICBidWZmZXIgKz0gXCJcXG4gICAgICAgIDwvZGl2PlxcbjwvZGl2PlxcblxcbjxkaXYgY2xhc3M9XFxcImNvbC1zbS0xIHByb2dyZXNzLWJsb2NrXFxcIiBhcmlhLWhpZGRlbj1cXFwidHJ1ZVxcXCIgcm9sZT1cXFwicHJlc2VudGF0aW9uXFxcIj5cXG4gICAgPGEgaHJlZj1cXFwiL2xlYXJuL1wiXG4gICAgKyBlc2NhcGVFeHByZXNzaW9uKCgoc3RhY2sxID0gKChzdGFjazEgPSAoZGVwdGgwICYmIGRlcHRoMC5hdHRyaWJ1dGVzKSksc3RhY2sxID09IG51bGwgfHwgc3RhY2sxID09PSBmYWxzZSA/IHN0YWNrMSA6IHN0YWNrMS5wYXRoKSksdHlwZW9mIHN0YWNrMSA9PT0gZnVuY3Rpb25UeXBlID8gc3RhY2sxLmFwcGx5KGRlcHRoMCkgOiBzdGFjazEpKVxuICAgICsgXCJcXFwiPlxcbiAgICA8ZGl2IFxcbiAgICAgICAgY2xhc3M9XFxcInByb2dyZXNzLWluZGljYXRvciBwcm9ncmVzcy1pbmRpY2F0b3Itc20gXCJcbiAgICArIGVzY2FwZUV4cHJlc3Npb24oKChzdGFjazEgPSAoKHN0YWNrMSA9IChkZXB0aDAgJiYgZGVwdGgwLmF0dHJpYnV0ZXMpKSxzdGFjazEgPT0gbnVsbCB8fCBzdGFjazEgPT09IGZhbHNlID8gc3RhY2sxIDogc3RhY2sxLnN0YXR1cykpLHR5cGVvZiBzdGFjazEgPT09IGZ1bmN0aW9uVHlwZSA/IHN0YWNrMS5hcHBseShkZXB0aDApIDogc3RhY2sxKSlcbiAgICArIFwiXFxcIlxcbiAgICAgICAgZGF0YS10b2dnbGU9XFxcInBvcG92ZXJcXFwiIGRhdGEtcGxhY2VtZW50PVxcXCJ0b3BcXFwiIFxcbiAgICAgICAgXFxuICAgICAgICBcXG4gICAgICAgIFwiO1xuICBzdGFjazEgPSAoaGVscGVyID0gaGVscGVycy5pZmNvbmQgfHwgKGRlcHRoMCAmJiBkZXB0aDAuaWZjb25kKSxvcHRpb25zPXtoYXNoOnt9LGludmVyc2U6c2VsZi5ub29wLGZuOnNlbGYucHJvZ3JhbSgxNiwgcHJvZ3JhbTE2LCBkYXRhKSxkYXRhOmRhdGF9LGhlbHBlciA/IGhlbHBlci5jYWxsKGRlcHRoMCwgKChzdGFjazEgPSAoZGVwdGgwICYmIGRlcHRoMC5hdHRyaWJ1dGVzKSksc3RhY2sxID09IG51bGwgfHwgc3RhY2sxID09PSBmYWxzZSA/IHN0YWNrMSA6IHN0YWNrMS5raW5kKSwgXCI9PT1cIiwgXCJWaWRlb1wiLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwiaWZjb25kXCIsICgoc3RhY2sxID0gKGRlcHRoMCAmJiBkZXB0aDAuYXR0cmlidXRlcykpLHN0YWNrMSA9PSBudWxsIHx8IHN0YWNrMSA9PT0gZmFsc2UgPyBzdGFjazEgOiBzdGFjazEua2luZCksIFwiPT09XCIsIFwiVmlkZW9cIiwgb3B0aW9ucykpO1xuICBpZihzdGFjazEgfHwgc3RhY2sxID09PSAwKSB7IGJ1ZmZlciArPSBzdGFjazE7IH1cbiAgYnVmZmVyICs9IFwiXFxuXFxuICAgICAgICBcXG4gICAgICAgIFwiO1xuICBzdGFjazEgPSAoaGVscGVyID0gaGVscGVycy5pZmNvbmQgfHwgKGRlcHRoMCAmJiBkZXB0aDAuaWZjb25kKSxvcHRpb25zPXtoYXNoOnt9LGludmVyc2U6c2VsZi5ub29wLGZuOnNlbGYucHJvZ3JhbSgxOCwgcHJvZ3JhbTE4LCBkYXRhKSxkYXRhOmRhdGF9LGhlbHBlciA/IGhlbHBlci5jYWxsKGRlcHRoMCwgKChzdGFjazEgPSAoZGVwdGgwICYmIGRlcHRoMC5hdHRyaWJ1dGVzKSksc3RhY2sxID09IG51bGwgfHwgc3RhY2sxID09PSBmYWxzZSA/IHN0YWNrMSA6IHN0YWNrMS5raW5kKSwgXCI9PT1cIiwgXCJFeGVyY2lzZVwiLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwiaWZjb25kXCIsICgoc3RhY2sxID0gKGRlcHRoMCAmJiBkZXB0aDAuYXR0cmlidXRlcykpLHN0YWNrMSA9PSBudWxsIHx8IHN0YWNrMSA9PT0gZmFsc2UgPyBzdGFjazEgOiBzdGFjazEua2luZCksIFwiPT09XCIsIFwiRXhlcmNpc2VcIiwgb3B0aW9ucykpO1xuICBpZihzdGFjazEgfHwgc3RhY2sxID09PSAwKSB7IGJ1ZmZlciArPSBzdGFjazE7IH1cbiAgYnVmZmVyICs9IFwiXFxuXFxuICAgICAgICBcXG4gICAgICAgIFwiO1xuICBzdGFjazEgPSAoaGVscGVyID0gaGVscGVycy5pZmNvbmQgfHwgKGRlcHRoMCAmJiBkZXB0aDAuaWZjb25kKSxvcHRpb25zPXtoYXNoOnt9LGludmVyc2U6c2VsZi5ub29wLGZuOnNlbGYucHJvZ3JhbSgyMCwgcHJvZ3JhbTIwLCBkYXRhKSxkYXRhOmRhdGF9LGhlbHBlciA/IGhlbHBlci5jYWxsKGRlcHRoMCwgKChzdGFjazEgPSAoZGVwdGgwICYmIGRlcHRoMC5hdHRyaWJ1dGVzKSksc3RhY2sxID09IG51bGwgfHwgc3RhY2sxID09PSBmYWxzZSA/IHN0YWNrMSA6IHN0YWNrMS5raW5kKSwgXCI9PT1cIiwgXCJRdWl6XCIsIG9wdGlvbnMpIDogaGVscGVyTWlzc2luZy5jYWxsKGRlcHRoMCwgXCJpZmNvbmRcIiwgKChzdGFjazEgPSAoZGVwdGgwICYmIGRlcHRoMC5hdHRyaWJ1dGVzKSksc3RhY2sxID09IG51bGwgfHwgc3RhY2sxID09PSBmYWxzZSA/IHN0YWNrMSA6IHN0YWNrMS5raW5kKSwgXCI9PT1cIiwgXCJRdWl6XCIsIG9wdGlvbnMpKTtcbiAgaWYoc3RhY2sxIHx8IHN0YWNrMSA9PT0gMCkgeyBidWZmZXIgKz0gc3RhY2sxOyB9XG4gIGJ1ZmZlciArPSBcIlxcbiAgICA+IFxcbiAgICAgICAgPGRpdiBjbGFzcz1cXFwic2lkZWJhci1pY29uIGljb24tXCJcbiAgICArIGVzY2FwZUV4cHJlc3Npb24oKChzdGFjazEgPSAoKHN0YWNrMSA9IChkZXB0aDAgJiYgZGVwdGgwLmF0dHJpYnV0ZXMpKSxzdGFjazEgPT0gbnVsbCB8fCBzdGFjazEgPT09IGZhbHNlID8gc3RhY2sxIDogc3RhY2sxLmtpbmQpKSx0eXBlb2Ygc3RhY2sxID09PSBmdW5jdGlvblR5cGUgPyBzdGFjazEuYXBwbHkoZGVwdGgwKSA6IHN0YWNrMSkpXG4gICAgKyBcIiBpY29uLWxhYmVsIGljb24tbGFiZWwtc21cXFwiPjwvZGl2PlxcbiAgICA8L2Rpdj5cXG4gICAgPHNwYW4gY2xhc3M9XFxcInByb2dyZXNzLWl0ZW0tdGl0bGVcXFwiPlwiXG4gICAgKyBlc2NhcGVFeHByZXNzaW9uKCgoc3RhY2sxID0gKChzdGFjazEgPSAoZGVwdGgwICYmIGRlcHRoMC5hdHRyaWJ1dGVzKSksc3RhY2sxID09IG51bGwgfHwgc3RhY2sxID09PSBmYWxzZSA/IHN0YWNrMSA6IHN0YWNrMS50aXRsZSkpLHR5cGVvZiBzdGFjazEgPT09IGZ1bmN0aW9uVHlwZSA/IHN0YWNrMS5hcHBseShkZXB0aDApIDogc3RhY2sxKSlcbiAgICArIFwiPC9zcGFuPjwvYT5cXG48L2Rpdj5cXG5cIjtcbiAgcmV0dXJuIGJ1ZmZlcjtcbiAgfVxuZnVuY3Rpb24gcHJvZ3JhbTIoZGVwdGgwLGRhdGEpIHtcbiAgXG4gIHZhciBidWZmZXIgPSBcIlwiLCBoZWxwZXIsIG9wdGlvbnM7XG4gIGJ1ZmZlciArPSBcIlxcbiAgICAgICAgICAgICAgICBcIlxuICAgICsgZXNjYXBlRXhwcmVzc2lvbigoaGVscGVyID0gaGVscGVycy5fIHx8IChkZXB0aDAgJiYgZGVwdGgwLl8pLG9wdGlvbnM9e2hhc2g6e30sZGF0YTpkYXRhfSxoZWxwZXIgPyBoZWxwZXIuY2FsbChkZXB0aDAsIFwiIENvbXBsZXRlZC4gXCIsIG9wdGlvbnMpIDogaGVscGVyTWlzc2luZy5jYWxsKGRlcHRoMCwgXCJfXCIsIFwiIENvbXBsZXRlZC4gXCIsIG9wdGlvbnMpKSlcbiAgICArIFwiXFxuICAgICAgICAgICAgXCI7XG4gIHJldHVybiBidWZmZXI7XG4gIH1cblxuZnVuY3Rpb24gcHJvZ3JhbTQoZGVwdGgwLGRhdGEpIHtcbiAgXG4gIHZhciBidWZmZXIgPSBcIlwiLCBoZWxwZXIsIG9wdGlvbnM7XG4gIGJ1ZmZlciArPSBcIlxcbiAgICAgICAgICAgICAgICBcIlxuICAgICsgZXNjYXBlRXhwcmVzc2lvbigoaGVscGVyID0gaGVscGVycy5fIHx8IChkZXB0aDAgJiYgZGVwdGgwLl8pLG9wdGlvbnM9e2hhc2g6e30sZGF0YTpkYXRhfSxoZWxwZXIgPyBoZWxwZXIuY2FsbChkZXB0aDAsIFwiIEluIHByb2dyZXNzLiBcIiwgb3B0aW9ucykgOiBoZWxwZXJNaXNzaW5nLmNhbGwoZGVwdGgwLCBcIl9cIiwgXCIgSW4gcHJvZ3Jlc3MuIFwiLCBvcHRpb25zKSkpXG4gICAgKyBcIlxcbiAgICAgICAgICAgIFwiO1xuICByZXR1cm4gYnVmZmVyO1xuICB9XG5cbmZ1bmN0aW9uIHByb2dyYW02KGRlcHRoMCxkYXRhKSB7XG4gIFxuICB2YXIgYnVmZmVyID0gXCJcIiwgaGVscGVyLCBvcHRpb25zO1xuICBidWZmZXIgKz0gXCJcXG4gICAgICAgICAgICAgICAgXCJcbiAgICArIGVzY2FwZUV4cHJlc3Npb24oKGhlbHBlciA9IGhlbHBlcnMuXyB8fCAoZGVwdGgwICYmIGRlcHRoMC5fKSxvcHRpb25zPXtoYXNoOnt9LGRhdGE6ZGF0YX0saGVscGVyID8gaGVscGVyLmNhbGwoZGVwdGgwLCBcIiBTdHJ1Z2dsaW5nLiBcIiwgb3B0aW9ucykgOiBoZWxwZXJNaXNzaW5nLmNhbGwoZGVwdGgwLCBcIl9cIiwgXCIgU3RydWdnbGluZy4gXCIsIG9wdGlvbnMpKSlcbiAgICArIFwiXFxuICAgICAgICAgICAgXCI7XG4gIHJldHVybiBidWZmZXI7XG4gIH1cblxuZnVuY3Rpb24gcHJvZ3JhbTgoZGVwdGgwLGRhdGEpIHtcbiAgXG4gIHZhciBidWZmZXIgPSBcIlwiLCBoZWxwZXIsIG9wdGlvbnM7XG4gIGJ1ZmZlciArPSBcIlxcbiAgICAgICAgICAgICAgICBcIlxuICAgICsgZXNjYXBlRXhwcmVzc2lvbigoaGVscGVyID0gaGVscGVycy5fIHx8IChkZXB0aDAgJiYgZGVwdGgwLl8pLG9wdGlvbnM9e2hhc2g6e30sZGF0YTpkYXRhfSxoZWxwZXIgPyBoZWxwZXIuY2FsbChkZXB0aDAsIFwiIE5vdCBzdGFydGVkLiBcIiwgb3B0aW9ucykgOiBoZWxwZXJNaXNzaW5nLmNhbGwoZGVwdGgwLCBcIl9cIiwgXCIgTm90IHN0YXJ0ZWQuIFwiLCBvcHRpb25zKSkpXG4gICAgKyBcIlxcbiAgICAgICAgICAgIFwiO1xuICByZXR1cm4gYnVmZmVyO1xuICB9XG5cbmZ1bmN0aW9uIHByb2dyYW0xMChkZXB0aDAsZGF0YSkge1xuICBcbiAgdmFyIGJ1ZmZlciA9IFwiXCIsIHN0YWNrMSwgaGVscGVyLCBvcHRpb25zO1xuICBidWZmZXIgKz0gXCJcXG4gICAgICAgICAgICAgICAgPHNwYW4+XCJcbiAgICArIGVzY2FwZUV4cHJlc3Npb24oKGhlbHBlciA9IGhlbHBlcnMuXyB8fCAoZGVwdGgwICYmIGRlcHRoMC5fKSxvcHRpb25zPXtoYXNoOnt9LGRhdGE6ZGF0YX0saGVscGVyID8gaGVscGVyLmNhbGwoZGVwdGgwLCBcIiBGb3IgdGhpcyB2aWRlbyB5b3UgY29tcGxldGVkIFwiLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwiX1wiLCBcIiBGb3IgdGhpcyB2aWRlbyB5b3UgY29tcGxldGVkIFwiLCBvcHRpb25zKSkpXG4gICAgKyBlc2NhcGVFeHByZXNzaW9uKCgoc3RhY2sxID0gKChzdGFjazEgPSAoZGVwdGgwICYmIGRlcHRoMC5hdHRyaWJ1dGVzKSksc3RhY2sxID09IG51bGwgfHwgc3RhY2sxID09PSBmYWxzZSA/IHN0YWNrMSA6IHN0YWNrMS5zY29yZSkpLHR5cGVvZiBzdGFjazEgPT09IGZ1bmN0aW9uVHlwZSA/IHN0YWNrMS5hcHBseShkZXB0aDApIDogc3RhY2sxKSlcbiAgICArIFwiJS48L3NwYW4+XFxuICAgICAgICAgICAgXCI7XG4gIHJldHVybiBidWZmZXI7XG4gIH1cblxuZnVuY3Rpb24gcHJvZ3JhbTEyKGRlcHRoMCxkYXRhKSB7XG4gIFxuICB2YXIgYnVmZmVyID0gXCJcIiwgc3RhY2sxLCBoZWxwZXIsIG9wdGlvbnM7XG4gIGJ1ZmZlciArPSBcIlxcbiAgICAgICAgICAgICAgICA8c3Bhbj5cIlxuICAgICsgZXNjYXBlRXhwcmVzc2lvbigoaGVscGVyID0gaGVscGVycy5fIHx8IChkZXB0aDAgJiYgZGVwdGgwLl8pLG9wdGlvbnM9e2hhc2g6e30sZGF0YTpkYXRhfSxoZWxwZXIgPyBoZWxwZXIuY2FsbChkZXB0aDAsIFwiIEZvciB0aGlzIGV4ZXJjaXNlIHlvdXIgc3RyZWFrIGlzIFwiLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwiX1wiLCBcIiBGb3IgdGhpcyBleGVyY2lzZSB5b3VyIHN0cmVhayBpcyBcIiwgb3B0aW9ucykpKVxuICAgICsgZXNjYXBlRXhwcmVzc2lvbigoKHN0YWNrMSA9ICgoc3RhY2sxID0gKGRlcHRoMCAmJiBkZXB0aDAuYXR0cmlidXRlcykpLHN0YWNrMSA9PSBudWxsIHx8IHN0YWNrMSA9PT0gZmFsc2UgPyBzdGFjazEgOiBzdGFjazEuc2NvcmUpKSx0eXBlb2Ygc3RhY2sxID09PSBmdW5jdGlvblR5cGUgPyBzdGFjazEuYXBwbHkoZGVwdGgwKSA6IHN0YWNrMSkpXG4gICAgKyBcIiUuPC9zcGFuPlxcbiAgICAgICAgICAgIFwiO1xuICByZXR1cm4gYnVmZmVyO1xuICB9XG5cbmZ1bmN0aW9uIHByb2dyYW0xNChkZXB0aDAsZGF0YSkge1xuICBcbiAgdmFyIGJ1ZmZlciA9IFwiXCIsIHN0YWNrMSwgaGVscGVyLCBvcHRpb25zO1xuICBidWZmZXIgKz0gXCJcXG4gICAgICAgICAgICAgICAgPHNwYW4+XCJcbiAgICArIGVzY2FwZUV4cHJlc3Npb24oKGhlbHBlciA9IGhlbHBlcnMuXyB8fCAoZGVwdGgwICYmIGRlcHRoMC5fKSxvcHRpb25zPXtoYXNoOnt9LGRhdGE6ZGF0YX0saGVscGVyID8gaGVscGVyLmNhbGwoZGVwdGgwLCBcIiBGb3IgdGhpcyBxdWl6IHlvdXIgc2NvcmUgaXMgXCIsIG9wdGlvbnMpIDogaGVscGVyTWlzc2luZy5jYWxsKGRlcHRoMCwgXCJfXCIsIFwiIEZvciB0aGlzIHF1aXogeW91ciBzY29yZSBpcyBcIiwgb3B0aW9ucykpKVxuICAgICsgZXNjYXBlRXhwcmVzc2lvbigoKHN0YWNrMSA9ICgoc3RhY2sxID0gKGRlcHRoMCAmJiBkZXB0aDAuYXR0cmlidXRlcykpLHN0YWNrMSA9PSBudWxsIHx8IHN0YWNrMSA9PT0gZmFsc2UgPyBzdGFjazEgOiBzdGFjazEuc2NvcmUpKSx0eXBlb2Ygc3RhY2sxID09PSBmdW5jdGlvblR5cGUgPyBzdGFjazEuYXBwbHkoZGVwdGgwKSA6IHN0YWNrMSkpXG4gICAgKyBcIiUuPC9zcGFuPlxcbiAgICAgICAgICAgIFwiO1xuICByZXR1cm4gYnVmZmVyO1xuICB9XG5cbmZ1bmN0aW9uIHByb2dyYW0xNihkZXB0aDAsZGF0YSkge1xuICBcbiAgdmFyIGJ1ZmZlciA9IFwiXCIsIHN0YWNrMTtcbiAgYnVmZmVyICs9IFwiXFxuICAgICAgICAgICAgdGl0bGU9XFxcIlwiXG4gICAgKyBlc2NhcGVFeHByZXNzaW9uKCgoc3RhY2sxID0gKChzdGFjazEgPSAoZGVwdGgwICYmIGRlcHRoMC5hdHRyaWJ1dGVzKSksc3RhY2sxID09IG51bGwgfHwgc3RhY2sxID09PSBmYWxzZSA/IHN0YWNrMSA6IHN0YWNrMS50aXRsZSkpLHR5cGVvZiBzdGFjazEgPT09IGZ1bmN0aW9uVHlwZSA/IHN0YWNrMS5hcHBseShkZXB0aDApIDogc3RhY2sxKSlcbiAgICArIFwiXFxcIlxcbiAgICAgICAgICAgIGRhdGEtY29udGVudD1cXFwiJSBDb21wbGV0ZTogXCJcbiAgICArIGVzY2FwZUV4cHJlc3Npb24oKChzdGFjazEgPSAoKHN0YWNrMSA9IChkZXB0aDAgJiYgZGVwdGgwLmF0dHJpYnV0ZXMpKSxzdGFjazEgPT0gbnVsbCB8fCBzdGFjazEgPT09IGZhbHNlID8gc3RhY2sxIDogc3RhY2sxLnNjb3JlKSksdHlwZW9mIHN0YWNrMSA9PT0gZnVuY3Rpb25UeXBlID8gc3RhY2sxLmFwcGx5KGRlcHRoMCkgOiBzdGFjazEpKVxuICAgICsgXCJcXFwiXFxuICAgICAgICBcIjtcbiAgcmV0dXJuIGJ1ZmZlcjtcbiAgfVxuXG5mdW5jdGlvbiBwcm9ncmFtMTgoZGVwdGgwLGRhdGEpIHtcbiAgXG4gIHZhciBidWZmZXIgPSBcIlwiLCBzdGFjazE7XG4gIGJ1ZmZlciArPSBcIlxcbiAgICAgICAgICAgIHRpdGxlPVxcXCJcIlxuICAgICsgZXNjYXBlRXhwcmVzc2lvbigoKHN0YWNrMSA9ICgoc3RhY2sxID0gKGRlcHRoMCAmJiBkZXB0aDAuYXR0cmlidXRlcykpLHN0YWNrMSA9PSBudWxsIHx8IHN0YWNrMSA9PT0gZmFsc2UgPyBzdGFjazEgOiBzdGFjazEudGl0bGUpKSx0eXBlb2Ygc3RhY2sxID09PSBmdW5jdGlvblR5cGUgPyBzdGFjazEuYXBwbHkoZGVwdGgwKSA6IHN0YWNrMSkpXG4gICAgKyBcIlxcXCJcXG4gICAgICAgICAgICBkYXRhLWNvbnRlbnQ9XFxcIlN0cmVhazogXCJcbiAgICArIGVzY2FwZUV4cHJlc3Npb24oKChzdGFjazEgPSAoKHN0YWNrMSA9IChkZXB0aDAgJiYgZGVwdGgwLmF0dHJpYnV0ZXMpKSxzdGFjazEgPT0gbnVsbCB8fCBzdGFjazEgPT09IGZhbHNlID8gc3RhY2sxIDogc3RhY2sxLnNjb3JlKSksdHlwZW9mIHN0YWNrMSA9PT0gZnVuY3Rpb25UeXBlID8gc3RhY2sxLmFwcGx5KGRlcHRoMCkgOiBzdGFjazEpKVxuICAgICsgXCIlXFxcIlxcbiAgICAgICAgXCI7XG4gIHJldHVybiBidWZmZXI7XG4gIH1cblxuZnVuY3Rpb24gcHJvZ3JhbTIwKGRlcHRoMCxkYXRhKSB7XG4gIFxuICB2YXIgYnVmZmVyID0gXCJcIiwgc3RhY2sxO1xuICBidWZmZXIgKz0gXCJcXG4gICAgICAgICAgICB0aXRsZT1cXFwiUXVpeiBmb3IgXCJcbiAgICArIGVzY2FwZUV4cHJlc3Npb24oKChzdGFjazEgPSAoKHN0YWNrMSA9IChkZXB0aDAgJiYgZGVwdGgwLmF0dHJpYnV0ZXMpKSxzdGFjazEgPT0gbnVsbCB8fCBzdGFjazEgPT09IGZhbHNlID8gc3RhY2sxIDogc3RhY2sxLnRpdGxlKSksdHlwZW9mIHN0YWNrMSA9PT0gZnVuY3Rpb25UeXBlID8gc3RhY2sxLmFwcGx5KGRlcHRoMCkgOiBzdGFjazEpKVxuICAgICsgXCJcXFwiXFxuICAgICAgICAgICAgZGF0YS1jb250ZW50PVxcXCJTY29yZTogXCJcbiAgICArIGVzY2FwZUV4cHJlc3Npb24oKChzdGFjazEgPSAoKHN0YWNrMSA9IChkZXB0aDAgJiYgZGVwdGgwLmF0dHJpYnV0ZXMpKSxzdGFjazEgPT0gbnVsbCB8fCBzdGFjazEgPT09IGZhbHNlID8gc3RhY2sxIDogc3RhY2sxLnNjb3JlKSksdHlwZW9mIHN0YWNrMSA9PT0gZnVuY3Rpb25UeXBlID8gc3RhY2sxLmFwcGx5KGRlcHRoMCkgOiBzdGFjazEpKVxuICAgICsgXCIlXFxcIlxcbiAgICAgICAgXCI7XG4gIHJldHVybiBidWZmZXI7XG4gIH1cblxuICBzdGFjazEgPSBoZWxwZXJzLmVhY2guY2FsbChkZXB0aDAsIChkZXB0aDAgJiYgZGVwdGgwLmRhdGEpLCB7aGFzaDp7fSxpbnZlcnNlOnNlbGYubm9vcCxmbjpzZWxmLnByb2dyYW0oMSwgcHJvZ3JhbTEsIGRhdGEpLGRhdGE6ZGF0YX0pO1xuICBpZihzdGFjazEgfHwgc3RhY2sxID09PSAwKSB7IHJldHVybiBzdGFjazE7IH1cbiAgZWxzZSB7IHJldHVybiAnJzsgfVxuICB9KTtcbiIsIi8vIGhic2Z5IGNvbXBpbGVkIEhhbmRsZWJhcnMgdGVtcGxhdGVcbnZhciBIYW5kbGViYXJzQ29tcGlsZXIgPSByZXF1aXJlKCdoYnNmeS9ydW50aW1lJyk7XG5tb2R1bGUuZXhwb3J0cyA9IEhhbmRsZWJhcnNDb21waWxlci50ZW1wbGF0ZShmdW5jdGlvbiAoSGFuZGxlYmFycyxkZXB0aDAsaGVscGVycyxwYXJ0aWFscyxkYXRhKSB7XG4gIHRoaXMuY29tcGlsZXJJbmZvID0gWzQsJz49IDEuMC4wJ107XG5oZWxwZXJzID0gdGhpcy5tZXJnZShoZWxwZXJzLCBIYW5kbGViYXJzLmhlbHBlcnMpOyBkYXRhID0gZGF0YSB8fCB7fTtcbiAgdmFyIGJ1ZmZlciA9IFwiXCIsIHN0YWNrMSwgaGVscGVyLCBvcHRpb25zLCBoZWxwZXJNaXNzaW5nPWhlbHBlcnMuaGVscGVyTWlzc2luZywgZXNjYXBlRXhwcmVzc2lvbj10aGlzLmVzY2FwZUV4cHJlc3Npb24sIHNlbGY9dGhpcywgZnVuY3Rpb25UeXBlPVwiZnVuY3Rpb25cIjtcblxuZnVuY3Rpb24gcHJvZ3JhbTEoZGVwdGgwLGRhdGEpIHtcbiAgXG4gIHZhciBidWZmZXIgPSBcIlwiLCBzdGFjazE7XG4gIGJ1ZmZlciArPSBcIlxcbiAgICAgICAgICAgICAgICAgICAgXCI7XG4gIHN0YWNrMSA9IGhlbHBlcnMudW5sZXNzLmNhbGwoZGVwdGgwLCAoZGVwdGgwICYmIGRlcHRoMC52aWRfcGN0X3N0YXJ0ZWQpLCB7aGFzaDp7fSxpbnZlcnNlOnNlbGYubm9vcCxmbjpzZWxmLnByb2dyYW0oMiwgcHJvZ3JhbTIsIGRhdGEpLGRhdGE6ZGF0YX0pO1xuICBpZihzdGFjazEgfHwgc3RhY2sxID09PSAwKSB7IGJ1ZmZlciArPSBzdGFjazE7IH1cbiAgYnVmZmVyICs9IFwiXFxuICAgICAgICAgICAgICAgIFwiO1xuICByZXR1cm4gYnVmZmVyO1xuICB9XG5mdW5jdGlvbiBwcm9ncmFtMihkZXB0aDAsZGF0YSkge1xuICBcbiAgdmFyIGJ1ZmZlciA9IFwiXCIsIGhlbHBlciwgb3B0aW9ucztcbiAgYnVmZmVyICs9IFwiXFxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XFxcInNyLW9ubHlcXFwiPlwiXG4gICAgKyBlc2NhcGVFeHByZXNzaW9uKChoZWxwZXIgPSBoZWxwZXJzLl8gfHwgKGRlcHRoMCAmJiBkZXB0aDAuXyksb3B0aW9ucz17aGFzaDp7fSxkYXRhOmRhdGF9LGhlbHBlciA/IGhlbHBlci5jYWxsKGRlcHRoMCwgXCJZb3UgaGF2ZW4ndCBzdGFydGVkIHRvIHdhdGNoIHZpZGVvcyEgXCIsIG9wdGlvbnMpIDogaGVscGVyTWlzc2luZy5jYWxsKGRlcHRoMCwgXCJfXCIsIFwiWW91IGhhdmVuJ3Qgc3RhcnRlZCB0byB3YXRjaCB2aWRlb3MhIFwiLCBvcHRpb25zKSkpXG4gICAgKyBcIjwvc3Bhbj5cXG4gICAgICAgICAgICAgICAgICAgIFwiO1xuICByZXR1cm4gYnVmZmVyO1xuICB9XG5cbmZ1bmN0aW9uIHByb2dyYW00KGRlcHRoMCxkYXRhKSB7XG4gIFxuICB2YXIgYnVmZmVyID0gXCJcIiwgc3RhY2sxLCBoZWxwZXIsIG9wdGlvbnM7XG4gIGJ1ZmZlciArPSBcIlxcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cXFwicHJvZ3Jlc3MtYmFyIHByb2dyZXNzLWJhci1zdWNjZXNzXFxcIiB0aXRsZT1cXFwiJSBDb21wbGV0ZWRcXFwiIHN0eWxlPVxcXCJ3aWR0aDogXCI7XG4gIGlmIChoZWxwZXIgPSBoZWxwZXJzLnZpZF9wY3RfY29tcGxldGUpIHsgc3RhY2sxID0gaGVscGVyLmNhbGwoZGVwdGgwLCB7aGFzaDp7fSxkYXRhOmRhdGF9KTsgfVxuICBlbHNlIHsgaGVscGVyID0gKGRlcHRoMCAmJiBkZXB0aDAudmlkX3BjdF9jb21wbGV0ZSk7IHN0YWNrMSA9IHR5cGVvZiBoZWxwZXIgPT09IGZ1bmN0aW9uVHlwZSA/IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSkgOiBoZWxwZXI7IH1cbiAgYnVmZmVyICs9IGVzY2FwZUV4cHJlc3Npb24oc3RhY2sxKVxuICAgICsgXCIlXFxcIj5cXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cXFwic3Itb25seVxcXCI+XCJcbiAgICArIGVzY2FwZUV4cHJlc3Npb24oKGhlbHBlciA9IGhlbHBlcnMuXyB8fCAoZGVwdGgwICYmIGRlcHRoMC5fKSxvcHRpb25zPXtoYXNoOnt9LGRhdGE6ZGF0YX0saGVscGVyID8gaGVscGVyLmNhbGwoZGVwdGgwLCBcIk9mIHRob3NlIHlvdSBoYXZlIGNvbXBsZXRlZCBcIiwgb3B0aW9ucykgOiBoZWxwZXJNaXNzaW5nLmNhbGwoZGVwdGgwLCBcIl9cIiwgXCJPZiB0aG9zZSB5b3UgaGF2ZSBjb21wbGV0ZWQgXCIsIG9wdGlvbnMpKSlcbiAgICArIFwiPC9zcGFuPlxcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlwiO1xuICBpZiAoaGVscGVyID0gaGVscGVycy52aWRfcGN0X2NvbXBsZXRlKSB7IHN0YWNrMSA9IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSk7IH1cbiAgZWxzZSB7IGhlbHBlciA9IChkZXB0aDAgJiYgZGVwdGgwLnZpZF9wY3RfY29tcGxldGUpOyBzdGFjazEgPSB0eXBlb2YgaGVscGVyID09PSBmdW5jdGlvblR5cGUgPyBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pIDogaGVscGVyOyB9XG4gIGJ1ZmZlciArPSBlc2NhcGVFeHByZXNzaW9uKHN0YWNrMSlcbiAgICArIFwiJTwvc3Bhbj5cXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxcbiAgICAgICAgICAgICAgICBcIjtcbiAgcmV0dXJuIGJ1ZmZlcjtcbiAgfVxuXG5mdW5jdGlvbiBwcm9ncmFtNihkZXB0aDAsZGF0YSkge1xuICBcbiAgdmFyIGJ1ZmZlciA9IFwiXCIsIHN0YWNrMSwgaGVscGVyLCBvcHRpb25zO1xuICBidWZmZXIgKz0gXCJcXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XFxcInByb2dyZXNzLWJhciBpbnByb2dyZXNzXFxcIiB0aXRsZT1cXFwiJSBJbi1Qcm9ncmVzc1xcXCIgc3R5bGU9XFxcIndpZHRoOiBcIjtcbiAgaWYgKGhlbHBlciA9IGhlbHBlcnMudmlkX3BjdF9zdGFydGVkKSB7IHN0YWNrMSA9IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSk7IH1cbiAgZWxzZSB7IGhlbHBlciA9IChkZXB0aDAgJiYgZGVwdGgwLnZpZF9wY3Rfc3RhcnRlZCk7IHN0YWNrMSA9IHR5cGVvZiBoZWxwZXIgPT09IGZ1bmN0aW9uVHlwZSA/IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSkgOiBoZWxwZXI7IH1cbiAgYnVmZmVyICs9IGVzY2FwZUV4cHJlc3Npb24oc3RhY2sxKVxuICAgICsgXCIlXFxcIj5cXG4gICAgICAgICAgICAgICAgICAgIFwiO1xuICBzdGFjazEgPSAoaGVscGVyID0gaGVscGVycy5pZmNvbmQgfHwgKGRlcHRoMCAmJiBkZXB0aDAuaWZjb25kKSxvcHRpb25zPXtoYXNoOnt9LGludmVyc2U6c2VsZi5ub29wLGZuOnNlbGYucHJvZ3JhbSg3LCBwcm9ncmFtNywgZGF0YSksZGF0YTpkYXRhfSxoZWxwZXIgPyBoZWxwZXIuY2FsbChkZXB0aDAsIChkZXB0aDAgJiYgZGVwdGgwLnZpZF9wY3Rfc3RhcnRlZCksIFwiPFwiLCAxMDAsIG9wdGlvbnMpIDogaGVscGVyTWlzc2luZy5jYWxsKGRlcHRoMCwgXCJpZmNvbmRcIiwgKGRlcHRoMCAmJiBkZXB0aDAudmlkX3BjdF9zdGFydGVkKSwgXCI8XCIsIDEwMCwgb3B0aW9ucykpO1xuICBpZihzdGFjazEgfHwgc3RhY2sxID09PSAwKSB7IGJ1ZmZlciArPSBzdGFjazE7IH1cbiAgYnVmZmVyICs9IFwiXFxuICAgICAgICAgICAgICAgICAgICBcIjtcbiAgc3RhY2sxID0gKGhlbHBlciA9IGhlbHBlcnMuaWZjb25kIHx8IChkZXB0aDAgJiYgZGVwdGgwLmlmY29uZCksb3B0aW9ucz17aGFzaDp7fSxpbnZlcnNlOnNlbGYubm9vcCxmbjpzZWxmLnByb2dyYW0oOSwgcHJvZ3JhbTksIGRhdGEpLGRhdGE6ZGF0YX0saGVscGVyID8gaGVscGVyLmNhbGwoZGVwdGgwLCAoZGVwdGgwICYmIGRlcHRoMC52aWRfcGN0X3N0YXJ0ZWQpLCBcIj09PVwiLCAxMDAsIG9wdGlvbnMpIDogaGVscGVyTWlzc2luZy5jYWxsKGRlcHRoMCwgXCJpZmNvbmRcIiwgKGRlcHRoMCAmJiBkZXB0aDAudmlkX3BjdF9zdGFydGVkKSwgXCI9PT1cIiwgMTAwLCBvcHRpb25zKSk7XG4gIGlmKHN0YWNrMSB8fCBzdGFjazEgPT09IDApIHsgYnVmZmVyICs9IHN0YWNrMTsgfVxuICBidWZmZXIgKz0gXCJcXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxcbiAgICAgICAgICAgICAgICBcIjtcbiAgcmV0dXJuIGJ1ZmZlcjtcbiAgfVxuZnVuY3Rpb24gcHJvZ3JhbTcoZGVwdGgwLGRhdGEpIHtcbiAgXG4gIHZhciBidWZmZXIgPSBcIlwiLCBzdGFjazEsIGhlbHBlciwgb3B0aW9ucztcbiAgYnVmZmVyICs9IFwiXFxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XFxcInNyLW9ubHlcXFwiPlwiXG4gICAgKyBlc2NhcGVFeHByZXNzaW9uKChoZWxwZXIgPSBoZWxwZXJzLl8gfHwgKGRlcHRoMCAmJiBkZXB0aDAuXyksb3B0aW9ucz17aGFzaDp7fSxkYXRhOmRhdGF9LGhlbHBlciA/IGhlbHBlci5jYWxsKGRlcHRoMCwgXCJZb3UgYXJlIHN0aWxsIHdvcmtpbmcgb24gXCIsIG9wdGlvbnMpIDogaGVscGVyTWlzc2luZy5jYWxsKGRlcHRoMCwgXCJfXCIsIFwiWW91IGFyZSBzdGlsbCB3b3JraW5nIG9uIFwiLCBvcHRpb25zKSkpXG4gICAgKyBcIjwvc3Bhbj5cXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5cIjtcbiAgaWYgKGhlbHBlciA9IGhlbHBlcnMudmlkX3BjdF9zdGFydGVkKSB7IHN0YWNrMSA9IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSk7IH1cbiAgZWxzZSB7IGhlbHBlciA9IChkZXB0aDAgJiYgZGVwdGgwLnZpZF9wY3Rfc3RhcnRlZCk7IHN0YWNrMSA9IHR5cGVvZiBoZWxwZXIgPT09IGZ1bmN0aW9uVHlwZSA/IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSkgOiBoZWxwZXI7IH1cbiAgYnVmZmVyICs9IGVzY2FwZUV4cHJlc3Npb24oc3RhY2sxKVxuICAgICsgXCIlPC9zcGFuPlxcbiAgICAgICAgICAgICAgICAgICAgXCI7XG4gIHJldHVybiBidWZmZXI7XG4gIH1cblxuZnVuY3Rpb24gcHJvZ3JhbTkoZGVwdGgwLGRhdGEpIHtcbiAgXG4gIHZhciBidWZmZXIgPSBcIlwiLCBzdGFjazEsIGhlbHBlciwgb3B0aW9ucztcbiAgYnVmZmVyICs9IFwiXFxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XFxcInNyLW9ubHlcXFwiPlwiXG4gICAgKyBlc2NhcGVFeHByZXNzaW9uKChoZWxwZXIgPSBoZWxwZXJzLl8gfHwgKGRlcHRoMCAmJiBkZXB0aDAuXyksb3B0aW9ucz17aGFzaDp7fSxkYXRhOmRhdGF9LGhlbHBlciA/IGhlbHBlci5jYWxsKGRlcHRoMCwgXCJZb3UgYXJlIHN0aWxsIHdvcmtpbmcgb24gYWxsIG9mIHRoZW0uXCIsIG9wdGlvbnMpIDogaGVscGVyTWlzc2luZy5jYWxsKGRlcHRoMCwgXCJfXCIsIFwiWW91IGFyZSBzdGlsbCB3b3JraW5nIG9uIGFsbCBvZiB0aGVtLlwiLCBvcHRpb25zKSkpXG4gICAgKyBcIjwvc3Bhbj5cXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBhcmlhLWhpZGRlbj1cXFwidHJ1ZVxcXCIgcm9sZT1cXFwicHJlc2VudGF0aW9uXFxcIj5cIjtcbiAgaWYgKGhlbHBlciA9IGhlbHBlcnMudmlkX3BjdF9zdGFydGVkKSB7IHN0YWNrMSA9IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSk7IH1cbiAgZWxzZSB7IGhlbHBlciA9IChkZXB0aDAgJiYgZGVwdGgwLnZpZF9wY3Rfc3RhcnRlZCk7IHN0YWNrMSA9IHR5cGVvZiBoZWxwZXIgPT09IGZ1bmN0aW9uVHlwZSA/IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSkgOiBoZWxwZXI7IH1cbiAgYnVmZmVyICs9IGVzY2FwZUV4cHJlc3Npb24oc3RhY2sxKVxuICAgICsgXCIlPC9zcGFuPlxcbiAgICAgICAgICAgICAgICAgICAgXCI7XG4gIHJldHVybiBidWZmZXI7XG4gIH1cblxuZnVuY3Rpb24gcHJvZ3JhbTExKGRlcHRoMCxkYXRhKSB7XG4gIFxuICB2YXIgYnVmZmVyID0gXCJcIiwgc3RhY2sxO1xuICBidWZmZXIgKz0gXCJcXG4gICAgICAgICAgICAgICAgICAgIFwiO1xuICBzdGFjazEgPSBoZWxwZXJzWydpZiddLmNhbGwoZGVwdGgwLCAoKHN0YWNrMSA9IChkZXB0aDAgJiYgZGVwdGgwLmV4X3N0YXR1cykpLHN0YWNrMSA9PSBudWxsIHx8IHN0YWNrMSA9PT0gZmFsc2UgPyBzdGFjazEgOiBzdGFjazEubm90c3RhcnRlZCksIHtoYXNoOnt9LGludmVyc2U6c2VsZi5ub29wLGZuOnNlbGYucHJvZ3JhbSgxMiwgcHJvZ3JhbTEyLCBkYXRhKSxkYXRhOmRhdGF9KTtcbiAgaWYoc3RhY2sxIHx8IHN0YWNrMSA9PT0gMCkgeyBidWZmZXIgKz0gc3RhY2sxOyB9XG4gIGJ1ZmZlciArPSBcIlxcbiAgICAgICAgICAgICAgICBcIjtcbiAgcmV0dXJuIGJ1ZmZlcjtcbiAgfVxuZnVuY3Rpb24gcHJvZ3JhbTEyKGRlcHRoMCxkYXRhKSB7XG4gIFxuICB2YXIgYnVmZmVyID0gXCJcIiwgaGVscGVyLCBvcHRpb25zO1xuICBidWZmZXIgKz0gXCJcXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cXFwic3Itb25seVxcXCI+XCJcbiAgICArIGVzY2FwZUV4cHJlc3Npb24oKGhlbHBlciA9IGhlbHBlcnMuXyB8fCAoZGVwdGgwICYmIGRlcHRoMC5fKSxvcHRpb25zPXtoYXNoOnt9LGRhdGE6ZGF0YX0saGVscGVyID8gaGVscGVyLmNhbGwoZGVwdGgwLCBcIllvdSBoYXZlbid0IHN0YXJ0ZWQgdG8gd29yayBvbiBleGVyY2lzZXMhIFwiLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwiX1wiLCBcIllvdSBoYXZlbid0IHN0YXJ0ZWQgdG8gd29yayBvbiBleGVyY2lzZXMhIFwiLCBvcHRpb25zKSkpXG4gICAgKyBcIjwvc3Bhbj5cXG4gICAgICAgICAgICAgICAgICAgIFwiO1xuICByZXR1cm4gYnVmZmVyO1xuICB9XG5cbmZ1bmN0aW9uIHByb2dyYW0xNChkZXB0aDAsZGF0YSkge1xuICBcbiAgdmFyIGJ1ZmZlciA9IFwiXCIsIHN0YWNrMSwgaGVscGVyLCBvcHRpb25zO1xuICBidWZmZXIgKz0gXCJcXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XFxcInByb2dyZXNzLWJhciBwcm9ncmVzcy1iYXItc3VjY2Vzc1xcXCIgdGl0bGU9XFxcIiUgTWFzdGVyZWRcXFwiIHN0eWxlPVxcXCJ3aWR0aDogXCI7XG4gIGlmIChoZWxwZXIgPSBoZWxwZXJzLmV4X3BjdF9tYXN0ZXJlZCkgeyBzdGFjazEgPSBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pOyB9XG4gIGVsc2UgeyBoZWxwZXIgPSAoZGVwdGgwICYmIGRlcHRoMC5leF9wY3RfbWFzdGVyZWQpOyBzdGFjazEgPSB0eXBlb2YgaGVscGVyID09PSBmdW5jdGlvblR5cGUgPyBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pIDogaGVscGVyOyB9XG4gIGJ1ZmZlciArPSBlc2NhcGVFeHByZXNzaW9uKHN0YWNrMSlcbiAgICArIFwiJVxcXCI+XFxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XFxcInNyLW9ubHlcXFwiPlwiXG4gICAgKyBlc2NhcGVFeHByZXNzaW9uKChoZWxwZXIgPSBoZWxwZXJzLl8gfHwgKGRlcHRoMCAmJiBkZXB0aDAuXyksb3B0aW9ucz17aGFzaDp7fSxkYXRhOmRhdGF9LGhlbHBlciA/IGhlbHBlci5jYWxsKGRlcHRoMCwgXCJPZiB0aG9zZSB5b3UgaGF2ZSBtYXN0ZXJlZCBcIiwgb3B0aW9ucykgOiBoZWxwZXJNaXNzaW5nLmNhbGwoZGVwdGgwLCBcIl9cIiwgXCJPZiB0aG9zZSB5b3UgaGF2ZSBtYXN0ZXJlZCBcIiwgb3B0aW9ucykpKVxuICAgICsgXCI8L3NwYW4+XFxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+XCI7XG4gIGlmIChoZWxwZXIgPSBoZWxwZXJzLmV4X3BjdF9tYXN0ZXJlZCkgeyBzdGFjazEgPSBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pOyB9XG4gIGVsc2UgeyBoZWxwZXIgPSAoZGVwdGgwICYmIGRlcHRoMC5leF9wY3RfbWFzdGVyZWQpOyBzdGFjazEgPSB0eXBlb2YgaGVscGVyID09PSBmdW5jdGlvblR5cGUgPyBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pIDogaGVscGVyOyB9XG4gIGJ1ZmZlciArPSBlc2NhcGVFeHByZXNzaW9uKHN0YWNrMSlcbiAgICArIFwiJTwvc3Bhbj5cXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxcbiAgICAgICAgICAgICAgICBcIjtcbiAgcmV0dXJuIGJ1ZmZlcjtcbiAgfVxuXG5mdW5jdGlvbiBwcm9ncmFtMTYoZGVwdGgwLGRhdGEpIHtcbiAgXG4gIHZhciBidWZmZXIgPSBcIlwiLCBzdGFjazEsIGhlbHBlciwgb3B0aW9ucztcbiAgYnVmZmVyICs9IFwiXFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVxcXCJwcm9ncmVzcy1iYXIgaW5wcm9ncmVzc1xcXCIgdGl0bGU9XFxcIiUgSW4tUHJvZ3Jlc3NcXFwiIHN0eWxlPVxcXCJ3aWR0aDogXCI7XG4gIGlmIChoZWxwZXIgPSBoZWxwZXJzLmV4X3BjdF9pbmNvbXBsZXRlKSB7IHN0YWNrMSA9IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSk7IH1cbiAgZWxzZSB7IGhlbHBlciA9IChkZXB0aDAgJiYgZGVwdGgwLmV4X3BjdF9pbmNvbXBsZXRlKTsgc3RhY2sxID0gdHlwZW9mIGhlbHBlciA9PT0gZnVuY3Rpb25UeXBlID8gaGVscGVyLmNhbGwoZGVwdGgwLCB7aGFzaDp7fSxkYXRhOmRhdGF9KSA6IGhlbHBlcjsgfVxuICBidWZmZXIgKz0gZXNjYXBlRXhwcmVzc2lvbihzdGFjazEpXG4gICAgKyBcIiVcXFwiPlxcbiAgICAgICAgICAgICAgICAgICAgXCI7XG4gIHN0YWNrMSA9IChoZWxwZXIgPSBoZWxwZXJzLmlmY29uZCB8fCAoZGVwdGgwICYmIGRlcHRoMC5pZmNvbmQpLG9wdGlvbnM9e2hhc2g6e30saW52ZXJzZTpzZWxmLm5vb3AsZm46c2VsZi5wcm9ncmFtKDE3LCBwcm9ncmFtMTcsIGRhdGEpLGRhdGE6ZGF0YX0saGVscGVyID8gaGVscGVyLmNhbGwoZGVwdGgwLCAoZGVwdGgwICYmIGRlcHRoMC5leF9wY3RfaW5jb21wbGV0ZSksIFwiPFwiLCAxMDAsIG9wdGlvbnMpIDogaGVscGVyTWlzc2luZy5jYWxsKGRlcHRoMCwgXCJpZmNvbmRcIiwgKGRlcHRoMCAmJiBkZXB0aDAuZXhfcGN0X2luY29tcGxldGUpLCBcIjxcIiwgMTAwLCBvcHRpb25zKSk7XG4gIGlmKHN0YWNrMSB8fCBzdGFjazEgPT09IDApIHsgYnVmZmVyICs9IHN0YWNrMTsgfVxuICBidWZmZXIgKz0gXCJcXG4gICAgICAgICAgICAgICAgICAgIFwiO1xuICBzdGFjazEgPSAoaGVscGVyID0gaGVscGVycy5pZmNvbmQgfHwgKGRlcHRoMCAmJiBkZXB0aDAuaWZjb25kKSxvcHRpb25zPXtoYXNoOnt9LGludmVyc2U6c2VsZi5ub29wLGZuOnNlbGYucHJvZ3JhbSgxOSwgcHJvZ3JhbTE5LCBkYXRhKSxkYXRhOmRhdGF9LGhlbHBlciA/IGhlbHBlci5jYWxsKGRlcHRoMCwgKGRlcHRoMCAmJiBkZXB0aDAuZXhfcGN0X2luY29tcGxldGUpLCBcIj09PVwiLCAxMDAsIG9wdGlvbnMpIDogaGVscGVyTWlzc2luZy5jYWxsKGRlcHRoMCwgXCJpZmNvbmRcIiwgKGRlcHRoMCAmJiBkZXB0aDAuZXhfcGN0X2luY29tcGxldGUpLCBcIj09PVwiLCAxMDAsIG9wdGlvbnMpKTtcbiAgaWYoc3RhY2sxIHx8IHN0YWNrMSA9PT0gMCkgeyBidWZmZXIgKz0gc3RhY2sxOyB9XG4gIGJ1ZmZlciArPSBcIlxcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XFxuICAgICAgICAgICAgICAgIFwiO1xuICByZXR1cm4gYnVmZmVyO1xuICB9XG5mdW5jdGlvbiBwcm9ncmFtMTcoZGVwdGgwLGRhdGEpIHtcbiAgXG4gIHZhciBidWZmZXIgPSBcIlwiLCBzdGFjazEsIGhlbHBlciwgb3B0aW9ucztcbiAgYnVmZmVyICs9IFwiXFxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XFxcInNyLW9ubHlcXFwiPlwiXG4gICAgKyBlc2NhcGVFeHByZXNzaW9uKChoZWxwZXIgPSBoZWxwZXJzLl8gfHwgKGRlcHRoMCAmJiBkZXB0aDAuXyksb3B0aW9ucz17aGFzaDp7fSxkYXRhOmRhdGF9LGhlbHBlciA/IGhlbHBlci5jYWxsKGRlcHRoMCwgXCJZb3UgYXJlIHN0aWxsIHdvcmtpbmcgb24gXCIsIG9wdGlvbnMpIDogaGVscGVyTWlzc2luZy5jYWxsKGRlcHRoMCwgXCJfXCIsIFwiWW91IGFyZSBzdGlsbCB3b3JraW5nIG9uIFwiLCBvcHRpb25zKSkpXG4gICAgKyBcIjwvc3Bhbj5cXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5cIjtcbiAgaWYgKGhlbHBlciA9IGhlbHBlcnMuZXhfcGN0X2luY29tcGxldGUpIHsgc3RhY2sxID0gaGVscGVyLmNhbGwoZGVwdGgwLCB7aGFzaDp7fSxkYXRhOmRhdGF9KTsgfVxuICBlbHNlIHsgaGVscGVyID0gKGRlcHRoMCAmJiBkZXB0aDAuZXhfcGN0X2luY29tcGxldGUpOyBzdGFjazEgPSB0eXBlb2YgaGVscGVyID09PSBmdW5jdGlvblR5cGUgPyBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pIDogaGVscGVyOyB9XG4gIGJ1ZmZlciArPSBlc2NhcGVFeHByZXNzaW9uKHN0YWNrMSlcbiAgICArIFwiJTwvc3Bhbj5cXG4gICAgICAgICAgICAgICAgICAgIFwiO1xuICByZXR1cm4gYnVmZmVyO1xuICB9XG5cbmZ1bmN0aW9uIHByb2dyYW0xOShkZXB0aDAsZGF0YSkge1xuICBcbiAgdmFyIGJ1ZmZlciA9IFwiXCIsIHN0YWNrMSwgaGVscGVyLCBvcHRpb25zO1xuICBidWZmZXIgKz0gXCJcXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cXFwic3Itb25seVxcXCI+XCJcbiAgICArIGVzY2FwZUV4cHJlc3Npb24oKGhlbHBlciA9IGhlbHBlcnMuXyB8fCAoZGVwdGgwICYmIGRlcHRoMC5fKSxvcHRpb25zPXtoYXNoOnt9LGRhdGE6ZGF0YX0saGVscGVyID8gaGVscGVyLmNhbGwoZGVwdGgwLCBcIllvdSBhcmUgc3RpbGwgd29ya2luZyBvbiBhbGwgb2YgdGhlbS5cIiwgb3B0aW9ucykgOiBoZWxwZXJNaXNzaW5nLmNhbGwoZGVwdGgwLCBcIl9cIiwgXCJZb3UgYXJlIHN0aWxsIHdvcmtpbmcgb24gYWxsIG9mIHRoZW0uXCIsIG9wdGlvbnMpKSlcbiAgICArIFwiPC9zcGFuPlxcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGFyaWEtaGlkZGVuPVxcXCJ0cnVlXFxcIiByb2xlPVxcXCJwcmVzZW50YXRpb25cXFwiPlwiO1xuICBpZiAoaGVscGVyID0gaGVscGVycy5leF9wY3RfaW5jb21wbGV0ZSkgeyBzdGFjazEgPSBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pOyB9XG4gIGVsc2UgeyBoZWxwZXIgPSAoZGVwdGgwICYmIGRlcHRoMC5leF9wY3RfaW5jb21wbGV0ZSk7IHN0YWNrMSA9IHR5cGVvZiBoZWxwZXIgPT09IGZ1bmN0aW9uVHlwZSA/IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSkgOiBoZWxwZXI7IH1cbiAgYnVmZmVyICs9IGVzY2FwZUV4cHJlc3Npb24oc3RhY2sxKVxuICAgICsgXCIlPC9zcGFuPlxcbiAgICAgICAgICAgICAgICAgICAgXCI7XG4gIHJldHVybiBidWZmZXI7XG4gIH1cblxuZnVuY3Rpb24gcHJvZ3JhbTIxKGRlcHRoMCxkYXRhKSB7XG4gIFxuICB2YXIgYnVmZmVyID0gXCJcIiwgc3RhY2sxLCBoZWxwZXIsIG9wdGlvbnM7XG4gIGJ1ZmZlciArPSBcIlxcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cXFwicHJvZ3Jlc3MtYmFyIHN0cnVnZ2xpbmdcXFwiIHRpdGxlPVxcXCIlIFN0cnVnZ2xpbmdcXFwiIHN0eWxlPVxcXCJ3aWR0aDogXCI7XG4gIGlmIChoZWxwZXIgPSBoZWxwZXJzLmV4X3BjdF9zdHJ1Z2dsaW5nKSB7IHN0YWNrMSA9IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSk7IH1cbiAgZWxzZSB7IGhlbHBlciA9IChkZXB0aDAgJiYgZGVwdGgwLmV4X3BjdF9zdHJ1Z2dsaW5nKTsgc3RhY2sxID0gdHlwZW9mIGhlbHBlciA9PT0gZnVuY3Rpb25UeXBlID8gaGVscGVyLmNhbGwoZGVwdGgwLCB7aGFzaDp7fSxkYXRhOmRhdGF9KSA6IGhlbHBlcjsgfVxuICBidWZmZXIgKz0gZXNjYXBlRXhwcmVzc2lvbihzdGFjazEpXG4gICAgKyBcIiVcXFwiPlxcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVxcXCJzci1vbmx5XFxcIj5cIlxuICAgICsgZXNjYXBlRXhwcmVzc2lvbigoaGVscGVyID0gaGVscGVycy5fIHx8IChkZXB0aDAgJiYgZGVwdGgwLl8pLG9wdGlvbnM9e2hhc2g6e30sZGF0YTpkYXRhfSxoZWxwZXIgPyBoZWxwZXIuY2FsbChkZXB0aDAsIFwiQW5kIHNlZW0gdG8gYmUgc3RydWdnbGluZyB3aXRoIFwiLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwiX1wiLCBcIkFuZCBzZWVtIHRvIGJlIHN0cnVnZ2xpbmcgd2l0aCBcIiwgb3B0aW9ucykpKVxuICAgICsgXCI8L3NwYW4+XFxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+XCI7XG4gIGlmIChoZWxwZXIgPSBoZWxwZXJzLmV4X3BjdF9zdHJ1Z2dsaW5nKSB7IHN0YWNrMSA9IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSk7IH1cbiAgZWxzZSB7IGhlbHBlciA9IChkZXB0aDAgJiYgZGVwdGgwLmV4X3BjdF9zdHJ1Z2dsaW5nKTsgc3RhY2sxID0gdHlwZW9mIGhlbHBlciA9PT0gZnVuY3Rpb25UeXBlID8gaGVscGVyLmNhbGwoZGVwdGgwLCB7aGFzaDp7fSxkYXRhOmRhdGF9KSA6IGhlbHBlcjsgfVxuICBidWZmZXIgKz0gZXNjYXBlRXhwcmVzc2lvbihzdGFjazEpXG4gICAgKyBcIiU8L3NwYW4+XFxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cXG4gICAgICAgICAgICAgICAgXCI7XG4gIHJldHVybiBidWZmZXI7XG4gIH1cblxuZnVuY3Rpb24gcHJvZ3JhbTIzKGRlcHRoMCxkYXRhKSB7XG4gIFxuICB2YXIgYnVmZmVyID0gXCJcIiwgc3RhY2sxLCBoZWxwZXIsIG9wdGlvbnM7XG4gIGJ1ZmZlciArPSBcIlxcbiAgICA8ZGl2IGNsYXNzPVxcXCJyb3cgcHJvZ3Jlc3MtYmxvY2tcXFwiPlxcbiAgICAgICAgPGRpdiBjbGFzcz1cXFwiY29sLXNtLTJcXFwiPlxcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XFxcInByb2dyZXNzLWluZGljYXRvciBwcm9ncmVzcy1pbmRpY2F0b3ItbGcgY2VudGVyLWJsb2NrIFwiO1xuICBpZiAoaGVscGVyID0gaGVscGVycy5xdWl6X3N0YXR1cykgeyBzdGFjazEgPSBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pOyB9XG4gIGVsc2UgeyBoZWxwZXIgPSAoZGVwdGgwICYmIGRlcHRoMC5xdWl6X3N0YXR1cyk7IHN0YWNrMSA9IHR5cGVvZiBoZWxwZXIgPT09IGZ1bmN0aW9uVHlwZSA/IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSkgOiBoZWxwZXI7IH1cbiAgYnVmZmVyICs9IGVzY2FwZUV4cHJlc3Npb24oc3RhY2sxKVxuICAgICsgXCJcXFwiPlxcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cXFwic3Itb25seVxcXCI+XCJcbiAgICArIGVzY2FwZUV4cHJlc3Npb24oKGhlbHBlciA9IGhlbHBlcnMuXyB8fCAoZGVwdGgwICYmIGRlcHRoMC5fKSxvcHRpb25zPXtoYXNoOnt9LGRhdGE6ZGF0YX0saGVscGVyID8gaGVscGVyLmNhbGwoZGVwdGgwLCBcIlRoZXJlIGFyZSBcIiwgb3B0aW9ucykgOiBoZWxwZXJNaXNzaW5nLmNhbGwoZGVwdGgwLCBcIl9cIiwgXCJUaGVyZSBhcmUgXCIsIG9wdGlvbnMpKSlcbiAgICArIFwiPC9zcGFuPlxcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cXFwic2lkZWJhci1pY29uIGljb24tUXVpeiBpY29uLWxhYmVsIGljb24tbGFiZWwtbGdcXFwiPjwvc3Bhbj5cXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XFxcInNyLW9ubHlcXFwiPlwiXG4gICAgKyBlc2NhcGVFeHByZXNzaW9uKChoZWxwZXIgPSBoZWxwZXJzLl8gfHwgKGRlcHRoMCAmJiBkZXB0aDAuXyksb3B0aW9ucz17aGFzaDp7fSxkYXRhOmRhdGF9LGhlbHBlciA/IGhlbHBlci5jYWxsKGRlcHRoMCwgXCIgcXVpenplcy5cIiwgb3B0aW9ucykgOiBoZWxwZXJNaXNzaW5nLmNhbGwoZGVwdGgwLCBcIl9cIiwgXCIgcXVpenplcy5cIiwgb3B0aW9ucykpKVxuICAgICsgXCI8L3NwYW4+XFxuICAgICAgICAgICAgPC9kaXY+XFxuICAgICAgICA8L2Rpdj5cXG4gICAgICAgIDxkaXYgY2xhc3M9XFxcImNvbC1zbS0xMFxcXCI+XFxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cXFwicHJvZ3Jlc3MgcGxheWxpc3QtcHJvZ3Jlc3MtYmFyXFxcIj5cXG4gICAgICAgICAgICAgICAgXCI7XG4gIHN0YWNrMSA9IGhlbHBlcnNbJ2lmJ10uY2FsbChkZXB0aDAsIChkZXB0aDAgJiYgZGVwdGgwLnF1aXpfcGN0X3Njb3JlKSwge2hhc2g6e30saW52ZXJzZTpzZWxmLm5vb3AsZm46c2VsZi5wcm9ncmFtKDI0LCBwcm9ncmFtMjQsIGRhdGEpLGRhdGE6ZGF0YX0pO1xuICBpZihzdGFjazEgfHwgc3RhY2sxID09PSAwKSB7IGJ1ZmZlciArPSBzdGFjazE7IH1cbiAgYnVmZmVyICs9IFwiXFxuICAgICAgICAgICAgPC9kaXY+XFxuICAgICAgICA8L2Rpdj5cXG4gICAgPC9kaXY+XFxuICAgIFwiO1xuICByZXR1cm4gYnVmZmVyO1xuICB9XG5mdW5jdGlvbiBwcm9ncmFtMjQoZGVwdGgwLGRhdGEpIHtcbiAgXG4gIHZhciBidWZmZXIgPSBcIlwiLCBzdGFjazEsIGhlbHBlciwgb3B0aW9ucztcbiAgYnVmZmVyICs9IFwiXFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XFxcInByb2dyZXNzLWJhciBcIjtcbiAgaWYgKGhlbHBlciA9IGhlbHBlcnMucXVpel9zdGF0dXMpIHsgc3RhY2sxID0gaGVscGVyLmNhbGwoZGVwdGgwLCB7aGFzaDp7fSxkYXRhOmRhdGF9KTsgfVxuICBlbHNlIHsgaGVscGVyID0gKGRlcHRoMCAmJiBkZXB0aDAucXVpel9zdGF0dXMpOyBzdGFjazEgPSB0eXBlb2YgaGVscGVyID09PSBmdW5jdGlvblR5cGUgPyBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pIDogaGVscGVyOyB9XG4gIGJ1ZmZlciArPSBlc2NhcGVFeHByZXNzaW9uKHN0YWNrMSlcbiAgICArIFwiXFxcIiB0aXRsZT1cXFwiJSBTY29yZVxcXCIgc3R5bGU9XFxcIndpZHRoOiBcIjtcbiAgaWYgKGhlbHBlciA9IGhlbHBlcnMucXVpel9wY3Rfc2NvcmUpIHsgc3RhY2sxID0gaGVscGVyLmNhbGwoZGVwdGgwLCB7aGFzaDp7fSxkYXRhOmRhdGF9KTsgfVxuICBlbHNlIHsgaGVscGVyID0gKGRlcHRoMCAmJiBkZXB0aDAucXVpel9wY3Rfc2NvcmUpOyBzdGFjazEgPSB0eXBlb2YgaGVscGVyID09PSBmdW5jdGlvblR5cGUgPyBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pIDogaGVscGVyOyB9XG4gIGJ1ZmZlciArPSBlc2NhcGVFeHByZXNzaW9uKHN0YWNrMSlcbiAgICArIFwiJVxcXCI+XFxuICAgICAgICAgICAgICAgICAgICBcXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVxcXCJzci1vbmx5XFxcIj5cIlxuICAgICsgZXNjYXBlRXhwcmVzc2lvbigoaGVscGVyID0gaGVscGVycy5fIHx8IChkZXB0aDAgJiYgZGVwdGgwLl8pLG9wdGlvbnM9e2hhc2g6e30sZGF0YTpkYXRhfSxoZWxwZXIgPyBoZWxwZXIuY2FsbChkZXB0aDAsIFwiQW5kIHlvdXIgc2NvcmUgaXMgXCIsIG9wdGlvbnMpIDogaGVscGVyTWlzc2luZy5jYWxsKGRlcHRoMCwgXCJfXCIsIFwiQW5kIHlvdXIgc2NvcmUgaXMgXCIsIG9wdGlvbnMpKSlcbiAgICArIFwiPC9zcGFuPlxcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+XCI7XG4gIGlmIChoZWxwZXIgPSBoZWxwZXJzLnF1aXpfcGN0X3Njb3JlKSB7IHN0YWNrMSA9IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSk7IH1cbiAgZWxzZSB7IGhlbHBlciA9IChkZXB0aDAgJiYgZGVwdGgwLnF1aXpfcGN0X3Njb3JlKTsgc3RhY2sxID0gdHlwZW9mIGhlbHBlciA9PT0gZnVuY3Rpb25UeXBlID8gaGVscGVyLmNhbGwoZGVwdGgwLCB7aGFzaDp7fSxkYXRhOmRhdGF9KSA6IGhlbHBlcjsgfVxuICBidWZmZXIgKz0gZXNjYXBlRXhwcmVzc2lvbihzdGFjazEpXG4gICAgKyBcIiU8L3NwYW4+XFxuICAgICAgICAgICAgICAgIDwvZGl2PlxcbiAgICAgICAgICAgICAgICBcIjtcbiAgcmV0dXJuIGJ1ZmZlcjtcbiAgfVxuXG4gIGJ1ZmZlciArPSBcIjxkaXYgY2xhc3M9XFxcIndlbGxcXFwiPlxcbiAgICA8ZGl2IGNsYXNzPVxcXCJyb3dcXFwiPlxcbiAgICAgICAgPGRpdiBjbGFzcz1cXFwiY29sLXhzLTEyXFxcIj5cXG4gICAgICAgICAgICA8aDIgY2xhc3M9XFxcImgzIHBsYXlsaXN0LXRpdGxlIGNlbnRlci1ibG9ja1xcXCI+XFxuICAgICAgICAgICAgICAgIDxhIGhyZWY9XFxcIlwiXG4gICAgKyBlc2NhcGVFeHByZXNzaW9uKCgoc3RhY2sxID0gKGRlcHRoMCAmJiBkZXB0aDAudXJsKSksdHlwZW9mIHN0YWNrMSA9PT0gZnVuY3Rpb25UeXBlID8gc3RhY2sxLmFwcGx5KGRlcHRoMCkgOiBzdGFjazEpKVxuICAgICsgXCJcXFwiPlwiO1xuICBpZiAoaGVscGVyID0gaGVscGVycy50aXRsZSkgeyBzdGFjazEgPSBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pOyB9XG4gIGVsc2UgeyBoZWxwZXIgPSAoZGVwdGgwICYmIGRlcHRoMC50aXRsZSk7IHN0YWNrMSA9IHR5cGVvZiBoZWxwZXIgPT09IGZ1bmN0aW9uVHlwZSA/IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSkgOiBoZWxwZXI7IH1cbiAgYnVmZmVyICs9IGVzY2FwZUV4cHJlc3Npb24oc3RhY2sxKVxuICAgICsgXCI8L2E+XFxuICAgICAgICAgICAgPC9oMj5cXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVxcXCJzci1vbmx5XFxcIj5cIlxuICAgICsgZXNjYXBlRXhwcmVzc2lvbigoaGVscGVyID0gaGVscGVycy5fIHx8IChkZXB0aDAgJiYgZGVwdGgwLl8pLG9wdGlvbnM9e2hhc2g6e30sZGF0YTpkYXRhfSxoZWxwZXIgPyBoZWxwZXIuY2FsbChkZXB0aDAsIFwiSW4gdGhpcyB0b3BpYyBcIiwgb3B0aW9ucykgOiBoZWxwZXJNaXNzaW5nLmNhbGwoZGVwdGgwLCBcIl9cIiwgXCJJbiB0aGlzIHRvcGljIFwiLCBvcHRpb25zKSkpXG4gICAgKyBcIjwvZGl2PlxcbiAgICAgICAgPC9kaXY+XFxuICAgIDwvZGl2PlxcbiAgICBcXG4gICAgPGRpdiBjbGFzcz1cXFwicm93IHByb2dyZXNzLWJsb2NrXFxcIj5cXG4gICAgICAgIDxkaXYgY2xhc3M9XFxcImNvbC1zbS0yXFxcIj5cXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVxcXCJwcm9ncmVzcy1pbmRpY2F0b3IgcHJvZ3Jlc3MtaW5kaWNhdG9yLWxnIGNlbnRlci1ibG9jayBcIjtcbiAgaWYgKGhlbHBlciA9IGhlbHBlcnMudmlkX3N0YXR1cykgeyBzdGFjazEgPSBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pOyB9XG4gIGVsc2UgeyBoZWxwZXIgPSAoZGVwdGgwICYmIGRlcHRoMC52aWRfc3RhdHVzKTsgc3RhY2sxID0gdHlwZW9mIGhlbHBlciA9PT0gZnVuY3Rpb25UeXBlID8gaGVscGVyLmNhbGwoZGVwdGgwLCB7aGFzaDp7fSxkYXRhOmRhdGF9KSA6IGhlbHBlcjsgfVxuICBidWZmZXIgKz0gZXNjYXBlRXhwcmVzc2lvbihzdGFjazEpXG4gICAgKyBcIlxcXCI+XFxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVxcXCJzci1vbmx5XFxcIj5cIlxuICAgICsgZXNjYXBlRXhwcmVzc2lvbigoaGVscGVyID0gaGVscGVycy5fIHx8IChkZXB0aDAgJiYgZGVwdGgwLl8pLG9wdGlvbnM9e2hhc2g6e30sZGF0YTpkYXRhfSxoZWxwZXIgPyBoZWxwZXIuY2FsbChkZXB0aDAsIFwidGhlcmUgYXJlIFwiLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwiX1wiLCBcInRoZXJlIGFyZSBcIiwgb3B0aW9ucykpKVxuICAgICsgXCI8L3NwYW4+XFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XFxcInNpZGViYXItaWNvbiBpY29uLVZpZGVvIGljb24tbGFiZWwgaWNvbi1sYWJlbC1sZ1xcXCI+PHNwYW4gY2xhc3M9XFxcInByb2dyZXNzLWluZGljYXRvciBjb250ZW50LWNvdW50ZXIgbGFiZWwgbGFiZWwtcHJpbWFyeVxcXCI+XCI7XG4gIGlmIChoZWxwZXIgPSBoZWxwZXJzLm5fcGxfdmlkZW9zKSB7IHN0YWNrMSA9IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSk7IH1cbiAgZWxzZSB7IGhlbHBlciA9IChkZXB0aDAgJiYgZGVwdGgwLm5fcGxfdmlkZW9zKTsgc3RhY2sxID0gdHlwZW9mIGhlbHBlciA9PT0gZnVuY3Rpb25UeXBlID8gaGVscGVyLmNhbGwoZGVwdGgwLCB7aGFzaDp7fSxkYXRhOmRhdGF9KSA6IGhlbHBlcjsgfVxuICBidWZmZXIgKz0gZXNjYXBlRXhwcmVzc2lvbihzdGFjazEpXG4gICAgKyBcIjwvc3Bhbj48L2Rpdj5cXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XFxcInNyLW9ubHlcXFwiPlwiXG4gICAgKyBlc2NhcGVFeHByZXNzaW9uKChoZWxwZXIgPSBoZWxwZXJzLl8gfHwgKGRlcHRoMCAmJiBkZXB0aDAuXyksb3B0aW9ucz17aGFzaDp7fSxkYXRhOmRhdGF9LGhlbHBlciA/IGhlbHBlci5jYWxsKGRlcHRoMCwgXCIgdmlkZW9zLlwiLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwiX1wiLCBcIiB2aWRlb3MuXCIsIG9wdGlvbnMpKSlcbiAgICArIFwiPC9zcGFuPlxcbiAgICAgICAgICAgIDwvZGl2PlxcbiAgICAgICAgPC9kaXY+XFxuICAgICAgICA8ZGl2IGNsYXNzPVxcXCJjb2wtc20tMTBcXFwiPlxcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XFxcInByb2dyZXNzIHBsYXlsaXN0LXByb2dyZXNzLWJhclxcXCI+XFxuICAgICAgICAgICAgICAgIFwiO1xuICBzdGFjazEgPSBoZWxwZXJzWydpZiddLmNhbGwoZGVwdGgwLCAoZGVwdGgwICYmIGRlcHRoMC5uX3BsX3ZpZGVvcyksIHtoYXNoOnt9LGludmVyc2U6c2VsZi5ub29wLGZuOnNlbGYucHJvZ3JhbSgxLCBwcm9ncmFtMSwgZGF0YSksZGF0YTpkYXRhfSk7XG4gIGlmKHN0YWNrMSB8fCBzdGFjazEgPT09IDApIHsgYnVmZmVyICs9IHN0YWNrMTsgfVxuICBidWZmZXIgKz0gXCJcXG4gICAgICAgICAgICAgICAgXCI7XG4gIHN0YWNrMSA9IGhlbHBlcnNbJ2lmJ10uY2FsbChkZXB0aDAsIChkZXB0aDAgJiYgZGVwdGgwLnZpZF9wY3RfY29tcGxldGUpLCB7aGFzaDp7fSxpbnZlcnNlOnNlbGYubm9vcCxmbjpzZWxmLnByb2dyYW0oNCwgcHJvZ3JhbTQsIGRhdGEpLGRhdGE6ZGF0YX0pO1xuICBpZihzdGFjazEgfHwgc3RhY2sxID09PSAwKSB7IGJ1ZmZlciArPSBzdGFjazE7IH1cbiAgYnVmZmVyICs9IFwiXFxuICAgICAgICAgICAgICAgIFwiO1xuICBzdGFjazEgPSBoZWxwZXJzWydpZiddLmNhbGwoZGVwdGgwLCAoZGVwdGgwICYmIGRlcHRoMC52aWRfcGN0X3N0YXJ0ZWQpLCB7aGFzaDp7fSxpbnZlcnNlOnNlbGYubm9vcCxmbjpzZWxmLnByb2dyYW0oNiwgcHJvZ3JhbTYsIGRhdGEpLGRhdGE6ZGF0YX0pO1xuICBpZihzdGFjazEgfHwgc3RhY2sxID09PSAwKSB7IGJ1ZmZlciArPSBzdGFjazE7IH1cbiAgYnVmZmVyICs9IFwiXFxuICAgICAgICAgICAgPC9kaXY+XFxuICAgICAgICA8L2Rpdj5cXG4gICAgPC9kaXY+XFxuICAgIFxcbiAgICA8ZGl2IGNsYXNzPVxcXCJyb3cgcHJvZ3Jlc3MtYmxvY2tcXFwiPlxcbiAgICAgICAgPGRpdiBjbGFzcz1cXFwiY29sLXNtLTJcXFwiPlxcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XFxcInByb2dyZXNzLWluZGljYXRvciBwcm9ncmVzcy1pbmRpY2F0b3ItbGcgY2VudGVyLWJsb2NrIFwiO1xuICBpZiAoaGVscGVyID0gaGVscGVycy5leF9zdGF0dXMpIHsgc3RhY2sxID0gaGVscGVyLmNhbGwoZGVwdGgwLCB7aGFzaDp7fSxkYXRhOmRhdGF9KTsgfVxuICBlbHNlIHsgaGVscGVyID0gKGRlcHRoMCAmJiBkZXB0aDAuZXhfc3RhdHVzKTsgc3RhY2sxID0gdHlwZW9mIGhlbHBlciA9PT0gZnVuY3Rpb25UeXBlID8gaGVscGVyLmNhbGwoZGVwdGgwLCB7aGFzaDp7fSxkYXRhOmRhdGF9KSA6IGhlbHBlcjsgfVxuICBidWZmZXIgKz0gZXNjYXBlRXhwcmVzc2lvbihzdGFjazEpXG4gICAgKyBcIlxcXCI+XFxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVxcXCJzci1vbmx5XFxcIj5cIlxuICAgICsgZXNjYXBlRXhwcmVzc2lvbigoaGVscGVyID0gaGVscGVycy5fIHx8IChkZXB0aDAgJiYgZGVwdGgwLl8pLG9wdGlvbnM9e2hhc2g6e30sZGF0YTpkYXRhfSxoZWxwZXIgPyBoZWxwZXIuY2FsbChkZXB0aDAsIFwiVGhlcmUgYXJlIFwiLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwiX1wiLCBcIlRoZXJlIGFyZSBcIiwgb3B0aW9ucykpKVxuICAgICsgXCI8L3NwYW4+XFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XFxcInNpZGViYXItaWNvbiBpY29uLUV4ZXJjaXNlIGljb24tbGFiZWwgaWNvbi1sYWJlbC1sZ1xcXCI+PHNwYW4gY2xhc3M9XFxcInByb2dyZXNzLWluZGljYXRvciBjb250ZW50LWNvdW50ZXIgbGFiZWwgbGFiZWwtcHJpbWFyeVxcXCI+XCI7XG4gIGlmIChoZWxwZXIgPSBoZWxwZXJzLm5fcGxfZXhlcmNpc2VzKSB7IHN0YWNrMSA9IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSk7IH1cbiAgZWxzZSB7IGhlbHBlciA9IChkZXB0aDAgJiYgZGVwdGgwLm5fcGxfZXhlcmNpc2VzKTsgc3RhY2sxID0gdHlwZW9mIGhlbHBlciA9PT0gZnVuY3Rpb25UeXBlID8gaGVscGVyLmNhbGwoZGVwdGgwLCB7aGFzaDp7fSxkYXRhOmRhdGF9KSA6IGhlbHBlcjsgfVxuICBidWZmZXIgKz0gZXNjYXBlRXhwcmVzc2lvbihzdGFjazEpXG4gICAgKyBcIjwvc3Bhbj48L2Rpdj5cXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XFxcInNyLW9ubHlcXFwiPlwiXG4gICAgKyBlc2NhcGVFeHByZXNzaW9uKChoZWxwZXIgPSBoZWxwZXJzLl8gfHwgKGRlcHRoMCAmJiBkZXB0aDAuXyksb3B0aW9ucz17aGFzaDp7fSxkYXRhOmRhdGF9LGhlbHBlciA/IGhlbHBlci5jYWxsKGRlcHRoMCwgXCIgZXhlcmNpc2VzLlwiLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwiX1wiLCBcIiBleGVyY2lzZXMuXCIsIG9wdGlvbnMpKSlcbiAgICArIFwiPC9zcGFuPlxcbiAgICAgICAgICAgIDwvZGl2PlxcbiAgICAgICAgPC9kaXY+XFxuICAgICAgICA8ZGl2IGNsYXNzPVxcXCJjb2wtc20tMTBcXFwiPlxcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XFxcInByb2dyZXNzIHBsYXlsaXN0LXByb2dyZXNzLWJhclxcXCI+XFxuICAgICAgICAgICAgICAgIFwiO1xuICBzdGFjazEgPSBoZWxwZXJzWydpZiddLmNhbGwoZGVwdGgwLCAoZGVwdGgwICYmIGRlcHRoMC5uX3BsX2V4ZXJjaXNlcyksIHtoYXNoOnt9LGludmVyc2U6c2VsZi5ub29wLGZuOnNlbGYucHJvZ3JhbSgxMSwgcHJvZ3JhbTExLCBkYXRhKSxkYXRhOmRhdGF9KTtcbiAgaWYoc3RhY2sxIHx8IHN0YWNrMSA9PT0gMCkgeyBidWZmZXIgKz0gc3RhY2sxOyB9XG4gIGJ1ZmZlciArPSBcIlxcbiAgICAgICAgICAgICAgICBcIjtcbiAgc3RhY2sxID0gaGVscGVyc1snaWYnXS5jYWxsKGRlcHRoMCwgKGRlcHRoMCAmJiBkZXB0aDAuZXhfcGN0X21hc3RlcmVkKSwge2hhc2g6e30saW52ZXJzZTpzZWxmLm5vb3AsZm46c2VsZi5wcm9ncmFtKDE0LCBwcm9ncmFtMTQsIGRhdGEpLGRhdGE6ZGF0YX0pO1xuICBpZihzdGFjazEgfHwgc3RhY2sxID09PSAwKSB7IGJ1ZmZlciArPSBzdGFjazE7IH1cbiAgYnVmZmVyICs9IFwiXFxuICAgICAgICAgICAgICAgIFwiO1xuICBzdGFjazEgPSBoZWxwZXJzWydpZiddLmNhbGwoZGVwdGgwLCAoZGVwdGgwICYmIGRlcHRoMC5leF9wY3RfaW5jb21wbGV0ZSksIHtoYXNoOnt9LGludmVyc2U6c2VsZi5ub29wLGZuOnNlbGYucHJvZ3JhbSgxNiwgcHJvZ3JhbTE2LCBkYXRhKSxkYXRhOmRhdGF9KTtcbiAgaWYoc3RhY2sxIHx8IHN0YWNrMSA9PT0gMCkgeyBidWZmZXIgKz0gc3RhY2sxOyB9XG4gIGJ1ZmZlciArPSBcIlxcbiAgICAgICAgICAgICAgICBcIjtcbiAgc3RhY2sxID0gaGVscGVyc1snaWYnXS5jYWxsKGRlcHRoMCwgKGRlcHRoMCAmJiBkZXB0aDAuZXhfcGN0X3N0cnVnZ2xpbmcpLCB7aGFzaDp7fSxpbnZlcnNlOnNlbGYubm9vcCxmbjpzZWxmLnByb2dyYW0oMjEsIHByb2dyYW0yMSwgZGF0YSksZGF0YTpkYXRhfSk7XG4gIGlmKHN0YWNrMSB8fCBzdGFjazEgPT09IDApIHsgYnVmZmVyICs9IHN0YWNrMTsgfVxuICBidWZmZXIgKz0gXCJcXG4gICAgICAgICAgICA8L2Rpdj5cXG4gICAgICAgIDwvZGl2PlxcbiAgICA8L2Rpdj5cXG4gICAgXFxuICAgIFwiO1xuICBzdGFjazEgPSBoZWxwZXJzWydpZiddLmNhbGwoZGVwdGgwLCAoZGVwdGgwICYmIGRlcHRoMC5xdWl6X2V4aXN0cyksIHtoYXNoOnt9LGludmVyc2U6c2VsZi5ub29wLGZuOnNlbGYucHJvZ3JhbSgyMywgcHJvZ3JhbTIzLCBkYXRhKSxkYXRhOmRhdGF9KTtcbiAgaWYoc3RhY2sxIHx8IHN0YWNrMSA9PT0gMCkgeyBidWZmZXIgKz0gc3RhY2sxOyB9XG4gIGJ1ZmZlciArPSBcIlxcbiAgICA8ZGl2IGNsYXNzPVxcXCJyb3dcXFwiPlxcbiAgICAgICAgPGRpdiBjbGFzcz1cXFwiY29sLXhzLTEyXFxcIj5cXG4gICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVxcXCJidG4gYnRuLXNtIGJ0bi1wcmltYXJ5IGNlbnRlci1ibG9jayB0b2dnbGUtZGV0YWlsc1xcXCIgYXJpYS1sYWJlbD1cXFwiUHJlc3MgdG8gb3BlbiBkZXRhaWxlZCB2aWV3XFxcIj48c3BhbiBjbGFzcz1cXFwiZXhwYW5kLWNvbGxhcHNlIGdseXBoaWNvbiBnbHlwaGljb24tY2hldnJvbi1kb3duXFxcIj48L3NwYW4+PC9idXR0b24+XFxuICAgICAgICA8L2Rpdj5cXG4gICAgPC9kaXY+XFxuICAgIDxkaXYgY2xhc3M9XFxcInJvdyBwbGF5bGlzdC1wcm9ncmVzcy1kZXRhaWxzXFxcIj5cXG4gICAgICAgIDxkaXYgY2xhc3M9XFxcImNvbC14cy0xMlxcXCI+XFxuICAgICAgICAgICAgPGltZyBjbGFzcz1cXFwiY2VudGVyLWJsb2NrXFxcIiBzcmM9XFxcIi9zdGF0aWMvaW1hZ2VzL2xvYWRpbmcuZ2lmXFxcIiBhcmlhLWhpZGRlbj1cXFwidHJ1ZVxcXCIgcm9sZT1cXFwicHJlc2VudGF0aW9uXFxcIi8+XFxuICAgICAgICA8L2Rpdj5cXG4gICAgPC9kaXY+XFxuPC9kaXY+XFxuXCI7XG4gIHJldHVybiBidWZmZXI7XG4gIH0pO1xuIl19
